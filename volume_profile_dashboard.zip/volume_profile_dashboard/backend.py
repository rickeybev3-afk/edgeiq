import pandas as pd
import numpy as np
from datetime import datetime, date, timedelta, time as dtime
import pytz
import threading
import queue
from concurrent.futures import ThreadPoolExecutor, as_completed
import json
import csv
import os
import requests
from collections import deque
import streamlit as st
from supabase import create_client, Client

import re as _re
_raw_supabase_url = os.environ.get("SUPABASE_URL", "")
_url_match = _re.search(r'https://[a-z0-9]+\.supabase\.co', _raw_supabase_url)
SUPABASE_URL = _url_match.group(0) if _url_match else _raw_supabase_url
SUPABASE_KEY = (
    os.environ.get("SUPABASE_ANON_KEY") or
    os.environ.get("VITE_SUPABASE_ANON_KEY") or
    os.environ.get("SUPABASE_KEY")
)

if SUPABASE_URL and SUPABASE_KEY:
    supabase: Client = create_client(SUPABASE_URL, SUPABASE_KEY)
else:
    supabase = None
    print("WARNING: Supabase credentials not found in environment variables.")

# ── Supabase Auth helpers ─────────────────────────────────────────────────────

def auth_login(email: str, password: str) -> dict:
    """Sign in via Supabase email/password auth."""
    if not supabase:
        return {"user": None, "session": None, "error": "Supabase not configured."}
    try:
        resp = supabase.auth.sign_in_with_password({"email": email, "password": password})
        return {"user": resp.user, "session": resp.session, "error": None}
    except Exception as exc:
        msg = str(exc)
        if "Invalid login credentials" in msg:
            msg = "Invalid email or password."
        elif "Email not confirmed" in msg:
            msg = "Please confirm your email before logging in."
        return {"user": None, "session": None, "error": msg}


def auth_signup(email: str, password: str) -> dict:
    """Sign up via Supabase email/password auth."""
    if not supabase:
        return {"user": None, "session": None, "error": "Supabase not configured."}
    try:
        resp = supabase.auth.sign_up({"email": email, "password": password})
        return {"user": resp.user, "session": resp.session, "error": None}
    except Exception as exc:
        return {"user": None, "session": None, "error": str(exc)}


def auth_signout() -> None:
    """Sign out the current Supabase auth session."""
    if not supabase:
        return
    try:
        supabase.auth.sign_out()
    except Exception:
        pass


def check_user_id_column_exists() -> bool:
    """Return True if user_id column already exists in trade_journal."""
    if not supabase:
        return False
    try:
        supabase.table("trade_journal").select("user_id").limit(1).execute()
        return True
    except Exception as e:
        return "user_id" not in str(e)  # column error → False; other errors → assume True

from engine_v2 import (
    calculate_v2_metrics, get_profile_and_shape, calculate_historical_retention,
    identify_overhead_supply, detect_volatility_halts, v2_brain_final_boss,
    calculate_time_multiplier, v2_brain_v3, get_volume_profile_v2, v2_execution_logic
)

STATE_FILE   = "trade_state.json"
TRACKER_FILE = "accuracy_tracker.csv"
WEIGHTS_FILE = "brain_weights.json"   # ⛔ READ-ONLY — hand-calibrated signal weights; do not edit manually
HICONS_FILE  = "high_conviction_log.csv"
HICONS_THRESHOLD = 75.0
SA_JOURNAL_FILE  = "sa_journal.csv"
JOURNAL_PATH = "trade_journal.csv"
_JOURNAL_COLS = [
    "timestamp", "ticker", "price", "structure", "tcs", "rvol",
    "ib_high", "ib_low", "notes", "grade", "grade_reason",
]

_BRAIN_WEIGHT_KEYS = [
    "trend_bull", "trend_bear", "double_dist",
    "non_trend",  "normal",     "neutral",
    "ntrl_extreme", "nrml_variation",
]
_RECALIBRATE_EVERY = 10
EASTERN = pytz.timezone("America/New_York")

def fetch_bars(api_key, secret_key, ticker, trade_date, feed="sip"):
    from alpaca.data.historical import StockHistoricalDataClient
    from alpaca.data.requests import StockBarsRequest
    from alpaca.data.timeframe import TimeFrame
    client = StockHistoricalDataClient(api_key, secret_key)
    mo = EASTERN.localize(datetime(trade_date.year, trade_date.month, trade_date.day, 9, 30))
    mc = EASTERN.localize(datetime(trade_date.year, trade_date.month, trade_date.day, 16, 0))
    # When fetching today's intraday data cap end to now so the API doesn't
    # get a future end time. If we're before market open, nothing to fetch yet.
    now_et = datetime.now(EASTERN)
    if trade_date >= now_et.date():
        if now_et <= mo:
            return pd.DataFrame()   # pre-market — no bars yet
        if now_et < mc:
            mc = now_et             # mid-session — cap end to current time
    req = StockBarsRequest(symbol_or_symbols=ticker, timeframe=TimeFrame.Minute,
                           start=mo, end=mc, feed=feed)
    bars = client.get_stock_bars(req)
    df = bars.df
    if df.empty:
        return pd.DataFrame()
    if isinstance(df.index, pd.MultiIndex):
        df = df.xs(ticker, level="symbol")
    df.index = pd.to_datetime(df.index)
    if df.index.tz is None:
        df.index = df.index.tz_localize("UTC")
    df.index = df.index.tz_convert(EASTERN)
    df = df.sort_index()
    df = df[(df.index.time >= dtime(9, 30)) & (df.index.time <= dtime(16, 0))]
    return df


def compute_initial_balance(df):
    ib_end = df.index[0].replace(hour=10, minute=30, second=0)
    ib_data = df[df.index <= ib_end]
    if ib_data.empty:
        return None, None
    return float(ib_data["high"].max()), float(ib_data["low"].min())


def compute_volume_profile(df, num_bins):
    price_min = df["low"].min()
    price_max = df["high"].max()
    bins = np.linspace(price_min, price_max, num_bins + 1)
    bin_centers = (bins[:-1] + bins[1:]) / 2
    vap = np.zeros(num_bins)
    for _, row in df.iterrows():
        lo, hi, vol = row["low"], row["high"], row["volume"]
        i0 = max(0, int(np.searchsorted(bins, lo, side="left")) - 1)
        i1 = min(num_bins, int(np.searchsorted(bins, hi, side="right")))
        sp = i1 - i0
        if sp > 0:
            vap[i0:i1] += vol / sp
    poc_idx = int(np.argmax(vap))
    return bin_centers, vap, float(bin_centers[poc_idx])


def _compute_value_area(bin_centers, vap, pct=0.70):
    """Return (VAL, VAH) — the price range containing `pct` of session volume.

    Starts at the POC and expands one bin at a time (always adding whichever
    adjacent bin has more volume), until the accumulated total reaches the
    target percentage.  This is the CME / Market Profile standard method.
    """
    total = float(np.sum(vap))
    if total == 0 or len(vap) == 0:
        return None, None
    poc_idx = int(np.argmax(vap))
    acc = float(vap[poc_idx])
    lo = hi = poc_idx
    while acc / total < pct:
        can_up = hi + 1 < len(vap)
        can_dn = lo - 1 >= 0
        if not can_up and not can_dn:
            break
        uv = float(vap[hi + 1]) if can_up else -1.0
        dv = float(vap[lo - 1]) if can_dn else -1.0
        if uv >= dv:
            hi += 1; acc += uv
        else:
            lo -= 1; acc += dv
    return float(bin_centers[lo]), float(bin_centers[hi])


# ══════════════════════════════════════════════════════════════════════════════
# SMALL ACCOUNT CHALLENGE — HELPER FUNCTIONS
# ══════════════════════════════════════════════════════════════════════════════

def compute_macd(close_series, fast=12, slow=26, signal=9):
    """Return (macd_line, signal_line, histogram) as pandas Series."""
    ema_f = close_series.ewm(span=fast, adjust=False).mean()
    ema_s = close_series.ewm(span=slow, adjust=False).mean()
    macd  = ema_f - ema_s
    sig   = macd.ewm(span=signal, adjust=False).mean()
    return macd, sig, macd - sig



def get_whole_half_levels(price_low, price_high):
    """Return all $0.50 increment levels between price_low and price_high.
    Whole dollars are key resistance; half dollars secondary.
    """
    lo = np.floor(price_low * 2) / 2
    hi = np.ceil(price_high * 2) / 2
    return [round(x, 2) for x in np.arange(lo, hi + 0.01, 0.50)
            if price_low * 0.98 <= x <= price_high * 1.02]


def detect_poc_shift(bin_centers, vap):
    """Classify POC position relative to the full profile range.
    Upper third = Bullish (buyers in control); lower third = Bearish.
    """
    if len(bin_centers) == 0:
        return "Neutral — no data", "#ffa726"
    poc_idx = int(np.argmax(vap))
    pct = poc_idx / len(bin_centers)
    if pct >= 0.67:
        return "Bullish — POC in upper zone ↑", "#4caf50"
    if pct <= 0.33:
        return "Bearish — POC in lower zone ↓", "#ef5350"
    return "Neutral — POC mid-range", "#ffa726"


def count_consecutive_greens(df):
    """Count how many consecutive green candles appear at the tail of df."""
    closes = df["close"].values
    opens  = df["open"].values
    count  = 0
    for i in range(len(closes) - 1, -1, -1):
        if closes[i] > opens[i]:
            count += 1
        else:
            break
    return count


def compute_recovery_ratio(loss_pct):
    """Return the % gain required to recover from loss_pct% drawdown."""
    if loss_pct <= 0:
        return 0.0
    if loss_pct >= 100:
        return float("inf")
    return round((loss_pct / (100.0 - loss_pct)) * 100.0, 1)


def load_sa_journal():
    """Load the Small Account trade log from CSV."""
    if not os.path.exists(SA_JOURNAL_FILE):
        return []
    try:
        return pd.read_csv(SA_JOURNAL_FILE).to_dict("records")
    except Exception:
        return []


def save_sa_journal(entries):
    """Persist the Small Account trade log to CSV."""
    if not entries:
        return
    try:
        pd.DataFrame(entries).to_csv(SA_JOURNAL_FILE, index=False)
    except Exception:
        pass


def _find_peaks(smoothed, bin_centers, threshold_pct=0.30):
    """Return indices of local maxima that exceed threshold_pct of the profile max."""
    n = len(smoothed)
    max_v = smoothed.max()
    peaks = []
    for i in range(3, n - 3):
        if (smoothed[i] >= max_v * threshold_pct and
                smoothed[i] > smoothed[i-1] and smoothed[i] > smoothed[i+1] and
                smoothed[i] > smoothed[i-2] and smoothed[i] > smoothed[i+2]):
            # Deduplicate: require at least 3 bins from the previous accepted peak
            if not peaks or (i - peaks[-1]) >= 3:
                peaks.append(i)
    return peaks


def _is_strong_hvn(pk, vap):
    """True if peak qualifies as an HVN by small-cap DD criteria.

    Either:
      • Volume in ±2-bin window around peak > 20 % of total session volume, OR
      • Peak bin volume > 2.5× the average bin volume.
    """
    total_vol = vap.sum()
    if total_vol == 0:
        return False
    avg_bin = total_vol / len(vap)
    window = vap[max(0, pk-2): min(len(vap), pk+3)].sum()
    return (window / total_vol > 0.20) or (vap[pk] > 2.5 * avg_bin)


def _detect_double_distribution(bin_centers, vap, min_bin_sep=15):
    """Return (pk1_idx, pk2_idx, lvn_idx) if a valid Double Distribution is found, else None."""
    smoothed = np.convolve(vap.astype(float), np.ones(5)/5, mode="same")
    peaks = _find_peaks(smoothed, bin_centers, threshold_pct=0.25)
    for j in range(len(peaks) - 1):
        pk1, pk2 = peaks[j], peaks[j+1]
        # Must be at least 15 bins apart
        if (pk2 - pk1) < min_bin_sep:
            continue
        # Both peaks must qualify as strong HVNs
        if not (_is_strong_hvn(pk1, vap) and _is_strong_hvn(pk2, vap)):
            continue
        # Must have a clear LVN valley between them
        vi = int(np.argmin(smoothed[pk1:pk2+1])) + pk1
        if smoothed[vi] < 0.60 * min(smoothed[pk1], smoothed[pk2]):
            return pk1, pk2, vi
    return None


def compute_atr(df, period=14):
    """Average True Range over `period` bars (or full session when fewer bars available)."""
    if df.empty:
        return 0.01
    if len(df) < 2:
        return max(0.01, float(df["high"].iloc[0] - df["low"].iloc[0]))
    tr = pd.concat([
        df["high"] - df["low"],
        (df["high"] - df["close"].shift(1)).abs(),
        (df["low"]  - df["close"].shift(1)).abs(),
    ], axis=1).max(axis=1)
    return max(0.01, float(tr.rolling(period, min_periods=1).mean().iloc[-1]))


# ══════════════════════════════════════════════════════════════════════════════
# MARKET BRAIN  — real-time IB tracker + structure predictor
# ══════════════════════════════════════════════════════════════════════════════

class MarketBrain:
    """Runs alongside classify_day_structure to predict structure mid-session.

    Call update(df, rvol) on each refresh; read `.prediction` for the live call.
    After the actual structure is classified, call log_accuracy() to record
    Predicted vs Actual in accuracy_tracker.csv.
    """

    _STRUCTURE_COLORS = {
        "Trend Day":            "#ff9800",
        "Double Distribution":  "#00bcd4",
        "Non-Trend":            "#78909c",
        "Normal":               "#66bb6a",
        "Normal Variation":     "#aed581",
        "Neutral":              "#80cbc4",
        "Neutral Extreme":      "#7e57c2",
        "Analyzing IB…":        "#888888",
    }

    def __init__(self):
        self.ib_high        = 0.0
        self.ib_low         = float("inf")
        self.ib_set         = False
        self.high_touched   = False
        self.low_touched    = False
        self.prediction     = "Analyzing IB…"

    # ── Restore from session state so we survive Streamlit reruns ──────────────
    def load_from_session(self):
        self.ib_high      = st.session_state.brain_ib_high
        self.ib_low       = st.session_state.brain_ib_low
        self.ib_set       = st.session_state.brain_ib_set
        self.high_touched = st.session_state.brain_high_touched
        self.low_touched  = st.session_state.brain_low_touched
        self.prediction   = st.session_state.brain_predicted or "Analyzing IB…"

    def save_to_session(self):
        st.session_state.brain_ib_high      = self.ib_high
        st.session_state.brain_ib_low       = self.ib_low
        st.session_state.brain_ib_set       = self.ib_set
        st.session_state.brain_high_touched = self.high_touched
        st.session_state.brain_low_touched  = self.low_touched
        st.session_state.brain_predicted    = self.prediction

    # ── Main update call ───────────────────────────────────────────────────────
    def update(self, df, rvol=None, ib_vol_pct=None, poc_price=None, has_double_dist=False):
        """Ingest fresh bar data, update IB, and re-predict.

        The 7-structure framework (Dalton / volume profile):
        ┌─────────────────────────────────────────────────────────────────────┐
        │  IB interaction          │  Close position    │  Structure          │
        ├──────────────────────────┼────────────────────┼─────────────────────┤
        │  Neither side broken     │  IB was wide       │  Normal             │
        │  Neither side broken     │  IB was narrow/low │  Non-Trend          │
        │  BOTH sides broken       │  Near middle/IB    │  Neutral            │
        │  BOTH sides broken       │  Near day extreme  │  Neutral Extreme    │
        │  ONE side only broken    │  Moderate move     │  Normal Variation   │
        │  ONE side only broken    │  Two vol clusters  │  Double Distribution│
        │  ONE side only broken    │  Dominant/early    │  Trend Day          │
        └─────────────────────────────────────────────────────────────────────┘

        Parameters
        ----------
        df              : OHLCV DataFrame (ET-indexed, may contain NaN reindex rows)
        rvol            : relative volume vs expected; None → 0.0
        ib_vol_pct      : fraction of total session volume traded inside IB (0–1)
        poc_price       : Point of Control from volume profile
        has_double_dist : True when _detect_double_distribution() found two peaks
        """
        if df.empty:
            return
        # Strip NaN rows inserted by the chart reindex grid
        _df = df.dropna(subset=["open", "high", "low", "close"])
        if _df.empty:
            return
        rvol = rvol or 0.0
        ib_end = _df.index[0].replace(hour=10, minute=30, second=0)

        # Accumulate IB extremes over the first hour (9:30–10:30)
        ib_df = _df[_df.index <= ib_end]
        if not ib_df.empty:
            self.ib_high = max(self.ib_high, float(ib_df["high"].max()))
            self.ib_low  = min(self.ib_low,  float(ib_df["low"].min()))

        last_time = _df.index[-1].time()
        if last_time > dtime(10, 30):
            self.ib_set = True

        if self.ib_set and self.ib_high > 0 and self.ib_low < float("inf"):
            current_price = float(_df["close"].iloc[-1])
            day_high      = float(_df["high"].max())
            day_low       = float(_df["low"].min())
            ib_range      = self.ib_high - self.ib_low

            if day_high >= self.ib_high:  self.high_touched = True
            if day_low  <= self.ib_low:   self.low_touched  = True

            # ── IB interaction buckets (the core 3-way split) ─────────────────
            no_break     = not self.high_touched and not self.low_touched
            both_broken  = self.high_touched and self.low_touched
            one_side_up  = self.high_touched and not self.low_touched
            one_side_dn  = self.low_touched  and not self.high_touched
            one_side     = one_side_up or one_side_dn

            # ── Derived signals ───────────────────────────────────────────────
            _ivp            = ib_vol_pct if ib_vol_pct is not None else 0.5
            directional_vol = _ivp < 0.35   # <35% of volume in IB → directional
            balanced_vol    = _ivp > 0.62   # >62% of volume in IB → rotational

            poc_outside_ib  = (poc_price is not None
                               and (poc_price > self.ib_high or poc_price < self.ib_low))

            total_range      = day_high - day_low
            range_expansion  = total_range / ib_range if ib_range > 0 else 1.0

            # Where did price close in today's range? (0.0 = at day low, 1.0 = at day high)
            close_pct        = ((current_price - day_low) / total_range
                                if total_range > 0 else 0.5)
            # "Near extreme" = closing in the top 20% or bottom 20% of day range
            close_at_extreme = close_pct >= 0.80 or close_pct <= 0.20
            # "In the middle" = closing within IB range or close to it
            close_near_ib    = self.ib_low <= current_price <= self.ib_high

            # ── BRANCH 1: Neither IB side violated ───────────────────────────
            # Both Normal and Non-Trend have no break. The difference is IB SIZE:
            #   Normal   → wide IB set by large players early; price stays inside
            #   Non-Trend → narrow IB, no volume/interest (holiday, eve-of-news, etc.)
            if no_break:
                # < 1.5% of price AND balanced vol AND minimal range expansion = Non-Trend
                is_narrow = ib_range < 0.015 * self.ib_high
                if is_narrow and balanced_vol and range_expansion <= 1.25:
                    self.prediction = "Non-Trend"
                else:
                    self.prediction = "Normal"

            # ── BRANCH 2: BOTH IB sides violated → always Neutral family ─────
            # Transcript: "both sides violated → EITHER closes in middle (Neutral)
            # OR one side dominates and closes near an extreme (Neutral Extreme)"
            elif both_broken:
                if close_at_extreme:
                    self.prediction = "Neutral Extreme"
                else:
                    self.prediction = "Neutral"

            # ── BRANCH 3: ONE side only violated → Trend / Dbl Dist / Nrml Var
            # Transcript: Trend = "pretty much from the open, very dominant, ONE side only"
            # Double Dist = two distinct volume clusters; a thin LVN in the middle
            # Normal Variation = one side broken but NOT dominant/early
            else:  # one_side is True
                # Double Distribution: bimodal profile detected OR
                # POC migrated out of IB but IB still has meaningful volume
                # (volume stayed in 2 places, not fully directional)
                is_double = has_double_dist or (poc_outside_ib and not directional_vol)

                # Trend: POC fully migrated + all volume directional, OR
                # strong early break + close firmly at the extreme
                is_trend = (
                    (poc_outside_ib and directional_vol)
                    or (close_at_extreme and range_expansion >= 2.0)
                    or (close_at_extreme and rvol >= 2.0)
                    or (close_at_extreme and directional_vol)
                )

                if is_trend:
                    self.prediction = "Trend Day"
                elif is_double:
                    self.prediction = "Double Distribution"
                else:
                    self.prediction = "Normal Variation"
        else:
            self.prediction = "Analyzing IB…"

        self.save_to_session()

    def color(self):
        return self._STRUCTURE_COLORS.get(self.prediction, "#888")


# ── Accuracy tracker persistence ──────────────────────────────────────────────

def load_accuracy_tracker(user_id: str = "") -> pd.DataFrame:
    """Load MarketBrain accuracy history from Supabase, optionally filtered by user_id."""
    cols = ["timestamp", "symbol", "predicted", "actual", "correct",
            "entry_price", "exit_price", "mfe", "compare_key"]
    if not supabase:
        return pd.DataFrame(columns=cols)
    try:
        q = supabase.table("accuracy_tracker").select("*")
        if user_id:
            try:
                q = q.eq("user_id", user_id)
            except Exception:
                pass
        response = q.execute()
        data = response.data
        if not data:
            return pd.DataFrame(columns=cols)
        df = pd.DataFrame(data)
        for c in cols:
            if c not in df.columns:
                df[c] = ""
        return df
    except Exception as e:
        print(f"Database read error (tracker): {e}")
        return pd.DataFrame(columns=cols)


def log_accuracy_entry(symbol, predicted, actual, compare_key="",
                       entry_price=0.0, exit_price=0.0, mfe=0.0,
                       user_id: str = ""):
    """Log Predicted vs Actual structure to Supabase."""
    if not supabase:
        return
    correct = "✅" if _strip_emoji(predicted) in _strip_emoji(actual) or \
                     _strip_emoji(actual) in _strip_emoji(predicted) else "❌"
    row = {
        "timestamp":   datetime.now(EASTERN).strftime("%Y-%m-%d %H:%M:%S"),
        "symbol":      symbol,
        "predicted":   predicted,
        "actual":      actual,
        "correct":     correct,
        "entry_price": float(entry_price),
        "exit_price":  float(exit_price),
        "mfe":         float(mfe),
        "compare_key": compare_key,
    }
    if user_id:
        row["user_id"] = user_id
    try:
        supabase.table("accuracy_tracker").insert(row).execute()
        res = supabase.table("accuracy_tracker").select("id", count="exact").execute()
        _n_rows = res.count if res.count else 0
        if _n_rows > 0 and _n_rows % _RECALIBRATE_EVERY == 0:
            recalibrate_brain_weights()
    except Exception as e:
        print(f"Database write error (tracker): {e}")


def log_high_conviction(ticker, trade_date, structure, prob,
                        ib_high=None, ib_low=None, poc_price=None):
    """Append a row to high_conviction_log.csv when top prob ≥ HICONS_THRESHOLD.

    Deduplication: one row per ticker+date combination — existing row is
    updated (overwritten) if prob is higher than what was previously recorded.
    """
    _cols = ["timestamp", "ticker", "date", "structure", "prob_pct",
             "ib_high", "ib_low", "poc_price"]
    _row  = {
        "timestamp": datetime.now(EASTERN).strftime("%Y-%m-%d %H:%M:%S"),
        "ticker":    ticker,
        "date":      str(trade_date),
        "structure": structure,
        "prob_pct":  round(prob, 1),
        "ib_high":   round(ib_high, 4) if ib_high else "",
        "ib_low":    round(ib_low, 4)  if ib_low  else "",
        "poc_price": round(poc_price, 4) if poc_price else "",
    }
    # Load existing, drop any previous row for same ticker+date, then append
    if os.path.exists(HICONS_FILE):
        try:
            _df = pd.read_csv(HICONS_FILE, encoding="utf-8")
            _mask = ~((_df["ticker"] == ticker) & (_df["date"] == str(trade_date)))
            _df = _df[_mask]
        except Exception:
            _df = pd.DataFrame(columns=_cols)
    else:
        _df = pd.DataFrame(columns=_cols)
    _new = pd.concat([_df, pd.DataFrame([_row])], ignore_index=True)
    _new.to_csv(HICONS_FILE, index=False, encoding="utf-8")


def load_high_conviction_log():
    """Return the high conviction log as a DataFrame, newest entries first."""
    if not os.path.exists(HICONS_FILE):
        return pd.DataFrame()
    try:
        _df = pd.read_csv(HICONS_FILE, encoding="utf-8")
        if _df.empty:
            return _df
        return _df.sort_values("prob_pct", ascending=False).reset_index(drop=True)
    except Exception:
        return pd.DataFrame()


def _strip_emoji(s):
    """Rough emoji stripper for fuzzy structure matching."""
    import re
    return re.sub(r"[^\w\s/()]", "", str(s)).strip().lower()


# ══════════════════════════════════════════════════════════════════════════════
# ADAPTIVE BRAIN LEARNING — per-structure accuracy weights
# ══════════════════════════════════════════════════════════════════════════════

def _label_to_weight_key(label: str) -> str:
    """Map a raw structure label to one of the canonical weight keys."""
    s = label.lower()
    if "bear" in s or "down" in s:          return "trend_bear"
    if "trend" in s:                         return "trend_bull"
    if "double" in s or "dbl" in s:         return "double_dist"
    if "non" in s:                           return "non_trend"
    if "variation" in s or "var" in s:       return "nrml_variation"
    if "extreme" in s:                       return "ntrl_extreme"
    if "neutral" in s:                       return "neutral"
    if "normal" in s or "balance" in s:      return "normal"
    return "normal"   # safe default


def load_brain_weights() -> dict:
    """Load adaptive calibration weights from disk (defaults to 1.0 for all)."""
    defaults = {k: 1.0 for k in _BRAIN_WEIGHT_KEYS}
    if not os.path.exists(WEIGHTS_FILE):
        return defaults
    try:
        import json
        with open(WEIGHTS_FILE) as f:
            stored = json.load(f)
        # Merge: keep stored values, fill any missing keys with 1.0
        return {k: float(stored.get(k, 1.0)) for k in _BRAIN_WEIGHT_KEYS}
    except Exception:
        return defaults


def _save_brain_weights(weights: dict) -> None:
    import json
    with open(WEIGHTS_FILE, "w") as f:
        json.dump({k: round(float(v), 4) for k, v in weights.items()}, f, indent=2)


def recalibrate_brain_weights() -> dict:
    """Read the accuracy tracker, compute per-structure accuracy, and update weights.

    Learning rule (smoothed exponential moving average):
      target = 1.5 if acc ≥ 70% | 1.0 if 50-70% | 0.75 if 30-50% | 0.5 if < 30%
      new_weight = old_weight × 0.70  +  target × 0.30   (30% learning rate)

    Structures with fewer than 5 samples are left unchanged (avoid overfitting).
    Returns the updated weights dict.
    """
    weights = load_brain_weights()
    if not os.path.exists(TRACKER_FILE):
        return weights
    try:
        df = pd.read_csv(TRACKER_FILE)
        if df.empty or "predicted" not in df.columns or "correct" not in df.columns:
            return weights

        # Group by predicted structure
        for raw_label, grp in df.groupby("predicted"):
            if len(grp) < 5:
                continue   # too few samples — skip
            acc = (grp["correct"] == "✅").sum() / len(grp)
            wk  = _label_to_weight_key(str(raw_label))

            # Target weight based on accuracy band
            if acc >= 0.70:   target = 1.50
            elif acc >= 0.50: target = 1.00
            elif acc >= 0.30: target = 0.75
            else:             target = 0.50

            # Smooth update (EMA-style, 30% learning rate)
            old = weights.get(wk, 1.0)
            weights[wk] = round(old * 0.70 + target * 0.30, 4)

        _save_brain_weights(weights)
    except Exception:
        pass
    return weights


def brain_weights_summary() -> list[dict]:
    """Return a list of dicts for displaying the learned weight table."""
    weights  = load_brain_weights()
    if not os.path.exists(TRACKER_FILE):
        return []
    try:
        df = pd.read_csv(TRACKER_FILE)
        if df.empty or "predicted" not in df.columns:
            return []
        rows = []
        for raw_label, grp in df.groupby("predicted"):
            wk   = _label_to_weight_key(str(raw_label))
            n    = len(grp)
            acc  = (grp["correct"] == "✅").sum() / n if n > 0 else 0
            w    = weights.get(wk, 1.0)
            rows.append({
                "Structure":  raw_label,
                "Samples":    n,
                "Accuracy":   round(acc * 100, 1),
                "Multiplier": w,
                "Status": ("✅ Trusted" if w >= 1.3 else
                           "🟢 Good"    if w >= 1.0 else
                           "🟡 Reduced" if w >= 0.7 else
                           "🔴 Low Confidence"),
            })
        rows.sort(key=lambda r: r["Multiplier"], reverse=True)
        return rows
    except Exception:
        return []


# ── Position state persistence ────────────────────────────────────────────────

def load_position_state():
    """Load persisted position from trade_state.json into session state."""
    if not os.path.exists(STATE_FILE):
        return
    try:
        with open(STATE_FILE, "r") as f:
            data = json.load(f)
        for k in ("position_in", "position_avg_entry", "position_peak_price",
                  "position_ticker", "position_shares", "position_structure"):
            if k in data:
                st.session_state[k] = data[k]
    except Exception:
        pass


def save_position_state():
    """Persist current position session state to trade_state.json."""
    data = {k: st.session_state.get(k)
            for k in ("position_in", "position_avg_entry", "position_peak_price",
                      "position_ticker", "position_shares", "position_structure")}
    with open(STATE_FILE, "w") as f:
        json.dump(data, f)


def enter_position(ticker, avg_entry, shares, structure):
    st.session_state.position_in        = True
    st.session_state.position_avg_entry = float(avg_entry)
    st.session_state.position_peak_price = float(avg_entry)
    st.session_state.position_ticker    = ticker
    st.session_state.position_shares    = int(shares)
    st.session_state.position_structure = structure
    save_position_state()


def exit_position(exit_price, actual_structure=""):
    """Record the exit, log to accuracy tracker, clear position."""
    entry   = st.session_state.position_avg_entry
    mfe     = st.session_state.position_peak_price
    sym     = st.session_state.position_ticker
    pred    = st.session_state.position_structure
    shares  = st.session_state.position_shares
    if entry > 0:
        log_accuracy_entry(sym, pred, actual_structure or pred,
                           entry_price=entry, exit_price=float(exit_price), mfe=mfe)
    st.session_state.position_in        = False
    st.session_state.position_avg_entry = 0.0
    st.session_state.position_peak_price = 0.0
    st.session_state.position_ticker    = ""
    st.session_state.position_shares    = 0
    st.session_state.position_structure = ""
    save_position_state()
    pnl = (float(exit_price) - entry) * shares if shares > 0 else 0
    return pnl


# Load persisted position on startup (only runs once per session via default init)
if not st.session_state.get("_position_loaded"):
    load_position_state()
    st.session_state["_position_loaded"] = True


def compute_ib_volume_stats(df, ib_high, ib_low):
    """Return (ib_vol_pct, ib_range_ratio) — both in [0, 1].

    ib_vol_pct  : fraction of total session volume traded while close was inside [ib_low, ib_high]
    ib_range_ratio : IB range / day range  — how much of the day was captured in the opening hour
    """
    if df.empty or ib_high is None or ib_low is None:
        return 0.5, 0.5
    total_vol = float(df["volume"].sum())
    if total_vol <= 0:
        return 0.5, 0.5
    inside_mask = (df["close"] >= ib_low) & (df["close"] <= ib_high)
    ib_vol  = float(df.loc[inside_mask, "volume"].sum())
    ib_vol_pct = ib_vol / total_vol
    day_range = float(df["high"].max()) - float(df["low"].min())
    ib_range  = ib_high - ib_low
    ib_range_ratio = (ib_range / day_range) if day_range > 0 else 0.5
    return round(ib_vol_pct, 3), round(ib_range_ratio, 3)


# ╔══════════════════════════════════════════════════════════════════════════════╗
# ║  ⛔  READ-ONLY — DO NOT MODIFY                                              ║
# ║  classify_day_structure()                                                    ║
# ║  Core 7-structure IB-interaction decision tree.  Any change here breaks     ║
# ║  the entire signal engine and all downstream scoring.                        ║
# ╚══════════════════════════════════════════════════════════════════════════════╝
def classify_day_structure(df, bin_centers, vap, ib_high, ib_low, poc_price,
                           avg_daily_vol=None):
    """7-structure classification using the exact IB-interaction decision tree.

    Decision tree (mirrors the video framework):
      1. Double Distribution  — bimodal volume profile (always wins if detected)
      2. No IB break          — Normal (wide IB) or Non-Trend (narrow/low-vol IB)
      3. Both sides broken    — Neutral Extreme (close at day extreme) or Neutral
      4. One side only broken — Trend Day (dominant early move) or Normal Variation

    Returns (label, color, detail, insight).
    """
    day_high    = float(df["high"].max())
    day_low     = float(df["low"].min())
    total_range = day_high - day_low
    ib_range    = (ib_high - ib_low) if (ib_high is not None and ib_low is not None) else 0.0
    final_price = float(df["close"].iloc[-1])

    ib_vol_pct, ib_range_ratio = compute_ib_volume_stats(df, ib_high, ib_low)

    if total_range == 0 or ib_range == 0:
        return ("⚖️ Normal / Balanced", "#66bb6a",
                "Insufficient range data.",
                "Not enough price movement to classify structure reliably.")

    atr = compute_atr(df)

    # IB boundary flags
    ib_high_touched = day_high >= ib_high
    ib_low_touched  = day_low  <= ib_low
    both_touched    = ib_high_touched and ib_low_touched
    one_side_up     = ib_high_touched and not ib_low_touched
    one_side_down   = ib_low_touched  and not ib_high_touched
    no_break        = not ib_high_touched and not ib_low_touched

    # Distance of close from IB boundary
    if final_price > ib_high:
        dist_from_ib = final_price - ib_high
    elif final_price < ib_low:
        dist_from_ib = ib_low - final_price
    else:
        dist_from_ib = 0.0

    # Where did the close land in the day's range? (0 = at low, 1 = at high)
    close_pct       = (final_price - day_low) / total_range if total_range > 0 else 0.5
    # "At extreme" = top or bottom 20% of day range
    at_high_extreme = close_pct >= 0.80
    at_low_extreme  = close_pct <= 0.20
    at_extreme      = at_high_extreme or at_low_extreme

    # Early IB violation (first 2 hrs of regular session)
    two_hr_end = df.index[0].replace(hour=11, minute=30)
    early_df   = df[df.index <= two_hr_end]
    early_high = float(early_df["high"].max()) if not early_df.empty else day_high
    early_low  = float(early_df["low"].min())  if not early_df.empty else day_low
    viol_early_up   = early_high > ib_high
    viol_early_down = early_low  < ib_low

    # Directional-volume signal (IB vol% < 0.40 = volume moved outside IB = directional)
    directional_vol  = ib_vol_pct < 0.40 and ib_range_ratio < 0.40
    balanced_vol     = ib_vol_pct > 0.65

    # ── STEP 1: Double Distribution (volume-based, always wins if detected) ───
    dd = _detect_double_distribution(bin_centers, vap)
    if dd is not None:
        pk1, pk2, vi = dd
        sep_price = bin_centers[pk2] - bin_centers[pk1]
        lvn_price = float(bin_centers[vi])
        pct1 = vap[max(0,pk1-2):min(len(vap),pk1+3)].sum() / vap.sum() * 100
        pct2 = vap[max(0,pk2-2):min(len(vap),pk2+3)].sum() / vap.sum() * 100
        detail  = (f"HVNs at ${bin_centers[pk1]:.2f} ({pct1:.0f}% vol) & "
                   f"${bin_centers[pk2]:.2f} ({pct2:.0f}% vol). "
                   f"LVN at ${lvn_price:.2f} (${sep_price:.2f} gap).")
        insight = (f"Two separate auctions detected. LVN at ${lvn_price:.2f} separates the "
                   f"two value areas — expect rapid, high-momentum moves through it. "
                   f"Gap Fill toward the opposing HVN is the primary target.")
        return ("⚡ Double Distribution", "#00bcd4", detail, insight)

    # ── STEP 2: No IB break → Normal or Non-Trend ─────────────────────────────
    if no_break:
        # Non-Trend: narrow IB + low volume interest (holiday, eve-of-news, etc.)
        is_narrow_ib = ib_range < 0.20 * total_range
        total_vol = float(df["volume"].sum())
        if avg_daily_vol and avg_daily_vol > 0:
            pace     = (total_vol / max(1, len(df))) * 390.0
            is_low_vol = (pace / avg_daily_vol) < 0.80
        else:
            is_low_vol = ib_range / max(0.001, day_high) < 0.005
        ib_vol_confirms_nontrend = ib_vol_pct > 0.72 and ib_range_ratio < 0.25
        if is_narrow_ib and (is_low_vol or ib_vol_confirms_nontrend):
            detail  = (f"IB ${ib_range:.2f} = {ib_range/total_range*100:.0f}% of day range. "
                       f"IB volume {ib_vol_pct*100:.0f}% of session total. "
                       f"Volume participation is anemic — no institutional interest.")
            insight = (f"Tight initial balance with {ib_vol_pct*100:.0f}% of session volume "
                       f"inside the opening range signals no institutional interest. "
                       f"Avoid chasing breakouts. Wait for a volume-backed catalyst.")
            return ("😴 Non-Trend", "#78909c", detail, insight)

        # Normal: wide IB set by large players in first hour, never violated
        pct_inside = float(((df["close"] >= ib_low) & (df["close"] <= ib_high)).mean()) * 100
        ib_vol_str = (f"IB absorbed {ib_vol_pct*100:.0f}% of volume — "
                      f"{'strong balance' if ib_vol_pct > 0.60 else 'moderate balance'}.")
        detail  = (f"IB ${ib_high:.2f}–${ib_low:.2f} never violated. "
                   f"Price inside IB for {pct_inside:.0f}% of session. {ib_vol_str}")
        insight = (f"Classic Normal day — large players set a wide range early and left. "
                   f"{ib_vol_pct*100:.0f}% of volume stayed inside the 9:30–10:30 range. "
                   f"No directional conviction. Fade the extremes and target POC ${poc_price:.2f}.")
        return ("⚖️ Normal", "#66bb6a", detail, insight)

    # ── STEP 3: BOTH sides broken → always Neutral family ─────────────────────
    # Per the video: "both sides violated" means EITHER:
    #   • Neutral Extreme: one side ultimately dominated, close near the day extreme
    #   • Neutral: coast-to-coast but closes back in the middle area
    if both_touched:
        if at_extreme:
            side        = "high" if at_high_extreme else "low"
            extreme_lvl = ib_high if at_high_extreme else ib_low
            detail  = (f"Both IB extremes tested. Price closing at day's {side} "
                       f"(${final_price:.2f}, top {close_pct*100:.0f}% of range) — "
                       f"late-session dominance confirmed.")
            insight = (f"Both sides of the IB were probed, then one side took over. "
                       f"Late-session conviction pushed the close to the "
                       f"{'top' if at_high_extreme else 'bottom'} 20% of the day range. "
                       f"This pattern frequently resolves with a "
                       f"{'gap up' if at_high_extreme else 'gap down'} next morning. "
                       f"Key level: ${extreme_lvl:.2f}.")
            return ("⚡ Neutral Extreme", "#7e57c2", detail, insight)
        else:
            # Closes anywhere that is NOT at the extreme = Neutral
            # (back inside IB, between IB and extreme band, or middle of range)
            pct_inside = float(((df["close"] >= ib_low) & (df["close"] <= ib_high)).mean()) * 100
            detail  = (f"Both IB extremes tested. Close at ${final_price:.2f} "
                       f"({close_pct*100:.0f}% of day range) — neither side dominated.")
            insight = (f"Coast-to-coast action with no winner — a classic Neutral day. "
                       f"Large players on both sides active but not far off on value. "
                       f"Price gravitates back toward POC ${poc_price:.2f}. "
                       f"Fade the extremes; avoid chasing direction into the close.")
            return ("🔄 Neutral", "#80cbc4", detail, insight)

    # ── STEP 4: ONE side only broken → Trend Day or Normal Variation ──────────
    # Per the video: Trend = "dominated from pretty much the open, only one side violated"
    # Normal Variation = one side breached but NOT dominant/sustained
    bullish = one_side_up
    dist_atr = dist_from_ib / atr if atr > 0 else 0

    # Trend Day: early violation + close firmly outside IB + directional volume OR 2× ATR move
    is_trend = (
        ((viol_early_up   and at_high_extreme and bullish) or
         (viol_early_down and at_low_extreme  and not bullish))
        and (dist_from_ib > 1.0 * atr or directional_vol)
    )

    if is_trend:
        direction = "Bullish" if bullish else "Bearish"
        confirmed = " ✅ IB vol confirms" if directional_vol else ""
        detail  = (f"{direction} Trend — IB {'High' if bullish else 'Low'} violated early, "
                   f"price {dist_atr:.1f}× ATR outside IB. "
                   f"{ib_vol_pct*100:.0f}% of volume inside IB — directional flow.{confirmed}")
        insight = (f"Strong directional conviction from the open — only ONE IB side ever touched. "
                   f"{'Buyers' if bullish else 'Sellers'} dominated all session. "
                   f"Trend continuation is the high-probability path. "
                   f"Add on pullbacks to POC ${poc_price:.2f}; avoid fading.")
        lbl = "📈 Trend Day" if bullish else "📉 Trend Day (Bear)"
        return (lbl, "#ff9800", detail, insight)

    # Normal Variation: one side broken, but not a full trend
    direction = "Up" if bullish else "Down"
    detail  = (f"IB {'High' if bullish else 'Low'} "
               f"${ib_high if bullish else ib_low:.2f} breached; "
               f"opposite side ${ib_low if bullish else ib_high:.2f} held. "
               f"Close at ${final_price:.2f} ({close_pct*100:.0f}% of range).")
    insight = (f"{'Buyers' if bullish else 'Sellers'} pushed outside the opening range "
               f"but didn't sustain a full trend. "
               f"New value area forming {'above' if bullish else 'below'} "
               f"${ib_high if bullish else ib_low:.2f}. "
               f"Watch for acceptance or rejection at that level.")
    return (f"📊 Normal Variation ({direction})", "#aed581" if bullish else "#ffab91",
            detail, insight)


# ╔══════════════════════════════════════════════════════════════════════════════╗
# ║  ⛔  READ-ONLY — DO NOT MODIFY                                              ║
# ║  compute_structure_probabilities()                                           ║
# ║  Probabilistic scorer using the same decision tree as classify_day_         ║
# ║  structure().  Weights are hand-calibrated — do not touch.                  ║
# ╚══════════════════════════════════════════════════════════════════════════════╝
def compute_structure_probabilities(df, bin_centers, vap, ib_high, ib_low, poc_price):
    """Score each of the 7 structures using the same IB-interaction decision tree
    as classify_day_structure.  Scores are converted to percentages at the end.

    Key invariant (mirrors the video framework):
      • no_break       → only Normal / Non-Trend get high scores
      • both_hit       → only Neutral / Neutral Extreme get high scores
      • one_side_only  → only Trend / Normal Variation / Dbl Dist get high scores
    """
    day_high    = float(df["high"].max())
    day_low     = float(df["low"].min())
    total_range = day_high - day_low
    ib_range    = (ib_high - ib_low) if (ib_high is not None and ib_low is not None) else 0.0
    final_price = float(df["close"].iloc[-1])
    fallback    = {"Non-Trend": 14.0, "Normal": 14.0, "Trend": 14.0,
                   "Ntrl Extreme": 14.0, "Neutral": 14.0, "Nrml Var": 15.0, "Dbl Dist": 15.0}
    if total_range == 0 or ib_range == 0:
        return fallback

    ib_vol_pct, ib_range_ratio = compute_ib_volume_stats(df, ib_high, ib_low)

    rr          = total_range / ib_range
    pct_inside  = float(((df["close"] >= ib_low) & (df["close"] <= ib_high)).mean())

    # IB boundary state (the core 3-way split)
    ib_high_hit  = day_high >= ib_high
    ib_low_hit   = day_low  <= ib_low
    both_hit     = ib_high_hit and ib_low_hit
    one_side     = ib_high_hit ^ ib_low_hit   # XOR: exactly one side broken
    no_break     = not ib_high_hit and not ib_low_hit

    atr = compute_atr(df)
    if final_price > ib_high:
        dist_ib = final_price - ib_high
    elif final_price < ib_low:
        dist_ib = ib_low - final_price
    else:
        dist_ib = 0.0

    # Close position in day range (0 = at low, 1 = at high)
    close_pct   = (final_price - day_low) / total_range if total_range > 0 else 0.5
    at_extreme  = close_pct >= 0.80 or close_pct <= 0.20   # top/bottom 20% of range

    # Early IB violation — only meaningful for one-side-only days
    two_hr_end  = df.index[0].replace(hour=11, minute=30)
    early_df    = df[df.index <= two_hr_end]
    early_high  = float(early_df["high"].max()) if not early_df.empty else day_high
    early_low   = float(early_df["low"].min())  if not early_df.empty else day_low
    viol_early  = (early_high > ib_high) or (early_low < ib_low)

    directional_vol = ib_vol_pct < 0.40 and ib_range_ratio < 0.40
    has_dd          = _detect_double_distribution(bin_centers, vap) is not None

    # ── Volume multipliers ────────────────────────────────────────────────────
    ib_balance_boost = max(0.5, ib_vol_pct * 2.0)           # high → balanced day
    ib_trend_boost   = max(0.5, (1.0 - ib_vol_pct) * 2.0)  # low  → directional day

    # ── Scores gated by IB-interaction bucket ─────────────────────────────────
    # Non-Trend / Normal → only score when no IB break
    if no_break:
        is_narrow = ib_range < 0.20 * total_range
        s_nontrend = max(2.0, (1.0 - rr) * 40.0 * ib_balance_boost) if is_narrow else 2.0
        s_normal   = (5.0 + pct_inside * 60.0) * ib_balance_boost
    else:
        s_nontrend = 2.0
        s_normal   = 2.0

    # Neutral / Neutral Extreme → only score when BOTH sides broken
    if both_hit:
        s_ntrl_extreme = 70.0 if at_extreme else 4.0
        s_neutral      = 4.0  if at_extreme else 70.0
    else:
        s_ntrl_extreme = 2.0
        s_neutral      = 2.0

    # Trend / Normal Variation / Dbl Dist → only score when ONE side broken
    if one_side:
        # Trend: early break, close at extreme, directional volume
        trend_strength = 5.0 + max(0.0, (dist_ib / max(atr, 0.01) - 1.0) * 25.0)
        is_trend_day   = viol_early and at_extreme
        s_trend   = trend_strength * ib_trend_boost if is_trend_day else 4.0
        s_nrml_var= 4.0 if is_trend_day else (40.0 * (0.7 + 0.6 * (1.0 - ib_vol_pct)))
        s_dbl_dist= 70.0 if has_dd else 4.0
    else:
        s_trend    = 2.0
        s_nrml_var = 2.0
        s_dbl_dist = 70.0 if has_dd else 2.0   # DD can still override on both-hit days

    scores = {
        "Non-Trend":    s_nontrend,
        "Normal":       s_normal,
        "Trend":        s_trend,
        "Ntrl Extreme": s_ntrl_extreme,
        "Neutral":      s_neutral,
        "Nrml Var":     s_nrml_var,
        "Dbl Dist":     s_dbl_dist,
    }

    # ── Apply adaptive learned weights ─────────────────────────────────────────
    # Maps probability-engine keys → canonical weight keys
    _score_to_wkey = {
        "Non-Trend":    "non_trend",
        "Normal":       "normal",
        "Trend":        "trend_bull",
        "Ntrl Extreme": "ntrl_extreme",
        "Neutral":      "neutral",
        "Nrml Var":     "nrml_variation",
        "Dbl Dist":     "double_dist",
    }
    try:
        _w = load_brain_weights()
        scores = {k: v * _w.get(_score_to_wkey.get(k, "normal"), 1.0)
                  for k, v in scores.items()}
    except Exception:
        pass   # weights unavailable — use raw scores

    total = sum(scores.values())
    return {k: round(v / total * 100, 1) for k, v in scores.items()}


def fetch_avg_daily_volume(api_key, secret_key, ticker, trade_date, lookback_days=50):
    """Return the average total daily volume for ticker over the last N trading days before trade_date.
    Default is 50 days to provide a robust, statistically stable baseline."""
    from alpaca.data.historical import StockHistoricalDataClient
    from alpaca.data.requests import StockBarsRequest
    from alpaca.data.timeframe import TimeFrame
    client = StockHistoricalDataClient(api_key, secret_key)
    start = EASTERN.localize(
        datetime(trade_date.year, trade_date.month, trade_date.day) - timedelta(days=lookback_days * 2)
    )
    end = EASTERN.localize(datetime(trade_date.year, trade_date.month, trade_date.day))
    req = StockBarsRequest(symbol_or_symbols=ticker, timeframe=TimeFrame.Day, start=start, end=end)
    bars = client.get_stock_bars(req)
    df = bars.df
    if df.empty:
        return None
    if isinstance(df.index, pd.MultiIndex):
        df = df.xs(ticker, level="symbol")
    df = df.sort_index()
    # Keep only the last lookback_days complete days
    df = df.tail(lookback_days)
    if df.empty:
        return None
    return float(df["volume"].mean())


def fetch_etf_pct_change(api_key, secret_key, etf, trade_date, feed="iex"):
    """Return today's open-to-close percent change for the given ETF ticker."""
    try:
        df = fetch_bars(api_key, secret_key, etf, trade_date, feed=feed)
        if df.empty:
            return 0.0
        open_price = float(df["open"].iloc[0])
        close_price = float(df["close"].iloc[-1])
        if open_price == 0:
            return 0.0
        return (close_price - open_price) / open_price * 100.0
    except Exception:
        return 0.0


def is_market_open():
    """True if the current EST clock is within regular session hours (9:30–16:00)."""
    t = datetime.now(EASTERN).time()
    return dtime(9, 30) <= t <= dtime(16, 0)


def build_rvol_intraday_curve(api_key, secret_key, ticker, trade_date,
                               lookback_days=50, feed="iex"):
    """Build a 390-element list of average cumulative volume at each minute from open.

    Each element i represents the expected cumulative volume after (i+1) minutes of
    trading, averaged across the last lookback_days sessions before trade_date.
    Uses 50-day default for a statistically robust baseline.
    Returns None if insufficient data.
    """
    from alpaca.data.historical import StockHistoricalDataClient
    from alpaca.data.requests import StockBarsRequest
    from alpaca.data.timeframe import TimeFrame

    client = StockHistoricalDataClient(api_key, secret_key)
    start_dt = EASTERN.localize(
        datetime(trade_date.year, trade_date.month, trade_date.day)
        - timedelta(days=lookback_days * 3)   # extra buffer for weekends/holidays
    )
    end_dt = EASTERN.localize(
        datetime(trade_date.year, trade_date.month, trade_date.day)
    )
    req = StockBarsRequest(symbol_or_symbols=ticker, timeframe=TimeFrame.Minute,
                           start=start_dt, end=end_dt, feed=feed)
    bars = client.get_stock_bars(req)
    df_all = bars.df
    if df_all.empty:
        return None

    if isinstance(df_all.index, pd.MultiIndex):
        df_all = df_all.xs(ticker, level="symbol")
    df_all.index = pd.to_datetime(df_all.index)
    if df_all.index.tz is None:
        df_all.index = df_all.index.tz_localize("UTC")
    df_all.index = df_all.index.tz_convert(EASTERN)
    df_all = df_all.sort_index()

    # Keep only market hours
    df_all = df_all[(df_all.index.time >= dtime(9, 30)) &
                    (df_all.index.time <= dtime(16, 0))]
    if df_all.empty:
        return None

    # Vectorised minutes-from-open (9:30 = minute 0)
    df_all = df_all.copy()
    df_all["_mins"] = df_all.index.hour * 60 + df_all.index.minute - (9 * 60 + 30)
    df_all["_date"] = pd.to_datetime(df_all.index.date)

    day_curves = []
    for day, grp in df_all.groupby("_date"):
        if day.date() >= trade_date:           # exclude the analysis date itself
            continue
        cv = np.zeros(390)
        for _, row in grp.iterrows():
            m = int(row["_mins"])
            if 0 <= m < 390:
                cv[m] = float(row["volume"])
        day_curves.append(np.cumsum(cv))

    if not day_curves:
        return None

    day_curves = day_curves[-lookback_days:]   # keep most recent N days
    return np.mean(day_curves, axis=0).tolist()


def compute_rvol(df, intraday_curve=None, avg_daily_vol=None):
    """Time-segmented RVOL (preferred) with pace-adjusted fallback.

    Time-segmented: compare cumulative volume at current elapsed minute to the
    historical average cumulative volume at the same minute of day.
    Fallback: extrapolate current pace to full session / full-day average.
    Returns None if no baseline is available.
    """
    if df.empty:
        return None
    current_vol = float(df["volume"].sum())
    elapsed_bars = max(1, len(df))

    # ── Time-segmented RVOL ───────────────────────────────────────────────────
    if intraday_curve is not None and len(intraday_curve) >= elapsed_bars:
        idx = min(elapsed_bars - 1, len(intraday_curve) - 1)
        expected_vol = float(intraday_curve[idx])
        if expected_vol > 0:
            return round(current_vol / expected_vol, 2)

    # ── Pace-adjusted fallback ────────────────────────────────────────────────
    if avg_daily_vol is not None and avg_daily_vol > 0:
        pace = (current_vol / elapsed_bars) * 390   # 390-minute session
        return round(pace / avg_daily_vol, 2)

    return None


# ╔══════════════════════════════════════════════════════════════════════════════╗
# ║  ⛔  READ-ONLY — DO NOT MODIFY                                              ║
# ║  compute_buy_sell_pressure()                                                 ║
# ║  Tape-reading signal (uptick ratio, delta, absorption).  Core input to      ║
# ║  Edge Score and TCS.  Calibrated thresholds — do not touch.                 ║
# ╚══════════════════════════════════════════════════════════════════════════════╝
def compute_buy_sell_pressure(df,
                               lookback_len=10,
                               baseline_weight=0.5,
                               sell_pct_floor=0.0,
                               sell_pct_ceiling=1.0):
    """Estimate session-cumulative buy vs sell volume using the blended CLV+Tick method.

    Mirrors the ThinkScript Blended split formula:
        sellPctCLV  = (high − close) / (high − low)     ← close location value
        sellPctTick = 1 if close < close[1]              ← up/down tick
                      0 if close > close[1]
                      0.5 otherwise
        sellPctRaw      = (sellPctCLV + sellPctTick) / 2
        sellPctBaseline = rolling mean of sellPctRaw over lookback_len bars
        sellPctBlended  = (1−baseline_weight)×sellPctRaw + baseline_weight×sellPctBaseline
        sellPct         = clamp(sellPctBlended, floor, ceiling)
        buyPct          = 1 − sellPct

    Momentum compares last 5 bars vs prior 5 bars (RSI-style ramping detection).
    Returns dict with keys: buy_pct, sell_pct, trend_now, trend_prev,
                            total_buy, total_sell — or None if insufficient data.
    """
    if df.empty or len(df) < 2:
        return None
    _df = df.dropna(subset=["open", "high", "low", "close", "volume"]).copy()
    if len(_df) < 2:
        return None

    # ── CLV component ─────────────────────────────────────────────────────────
    hl = (_df["high"] - _df["low"]).replace(0, np.nan)
    sell_pct_clv = (((_df["high"] - _df["close"]) / hl).fillna(0.5)).clip(0, 1)

    # ── Up/Down Tick component ────────────────────────────────────────────────
    close_prev = _df["close"].shift(1)
    sell_pct_tick = np.where(
        _df["close"] < close_prev, 1.0,
        np.where(_df["close"] > close_prev, 0.0, 0.5)
    )
    sell_pct_tick = pd.Series(sell_pct_tick, index=_df.index).fillna(0.5)

    # ── Blend CLV + Tick → apply baseline smoothing → clamp ──────────────────
    sell_pct_raw      = (sell_pct_clv + sell_pct_tick) / 2.0
    sell_pct_baseline = sell_pct_raw.rolling(window=max(1, lookback_len),
                                              min_periods=1).mean()
    sell_pct_blended  = ((1.0 - baseline_weight) * sell_pct_raw
                         + baseline_weight * sell_pct_baseline)
    sell_pct          = sell_pct_blended.clip(sell_pct_floor, sell_pct_ceiling)
    buy_pct_series    = 1.0 - sell_pct

    _df["buy_vol"]  = _df["volume"] * buy_pct_series
    _df["sell_vol"] = _df["volume"] * sell_pct

    total_buy  = float(_df["buy_vol"].sum())
    total_sell = float(_df["sell_vol"].sum())
    total_vol  = total_buy + total_sell
    if total_vol == 0:
        return None

    buy_pct_session = total_buy / total_vol * 100.0

    def _pct(sub):
        b = float(sub["buy_vol"].sum())
        s = float(sub["sell_vol"].sum())
        return b / (b + s) * 100.0 if (b + s) > 0 else 50.0

    # Momentum: last 5 bars vs prior 5 bars
    recent5    = _df.tail(5)
    prior5     = _df.iloc[-10:-5] if len(_df) >= 10 else _df.head(max(1, len(_df) // 2))
    trend_now  = _pct(recent5)
    trend_prev = _pct(prior5)

    return {
        "buy_pct":    round(buy_pct_session, 1),
        "sell_pct":   round(100.0 - buy_pct_session, 1),
        "trend_now":  round(trend_now, 1),
        "trend_prev": round(trend_prev, 1),
        "total_buy":  total_buy,
        "total_sell": total_sell,
    }


def rvol_classify(rvol, pct_chg_today, elapsed_bars=None, price_now=None):
    """Time-aware RVOL label.

    elapsed_bars — minutes since 9:30 AM open (None = historical full-day view)
    price_now    — current last price (for small-cap volatility adjustment)
    Returns (label | None, color, is_runner, is_play)
    """
    if rvol is None:
        return None, "#aaaaaa", False, False

    # ── Runner tiers (highest priority) ───────────────────────────────────────
    if rvol > 5.5:
        return "🚀 MULTI-DAY RUNNER POTENTIAL", "#FFD700", True, True
    if rvol > 4.0:
        return "🔥 STOCK IN PLAY", "#FF6B35", False, True

    # ── 9:30–10:00 AM "Fuel Check" (first 30 minutes of session) ─────────────
    is_open_window = elapsed_bars is not None and 1 <= elapsed_bars <= 30
    if is_open_window and rvol > 3.0:
        return "🔥 HIGH CONVICTION OPEN", "#FF9500", False, True

    # ── Fake-out with small-cap volatility adjustment ─────────────────────────
    if rvol < 1.2 and pct_chg_today > 0.5:
        # For stocks priced $2–$20 (small-cap / low-float) noise threshold is 1%
        # — only flag as fake-out if divergence is meaningful (> 1% move)
        if price_now is not None and 2.0 <= price_now <= 20.0:
            if pct_chg_today < 1.0:          # within noise band → ignore
                return None, "#aaaaaa", False, False
        return "⚠️ DEAD CAT / FAKE-OUT RISK", "#ef5350", False, False

    return None, "#aaaaaa", False, False


def compute_model_prediction(df, rvol, tcs, sector_bonus, market_open=True):
    """Classify move as Fake-out / High Conviction / Consolidation.

    market_open=False → returns ('Market Closed', '') so the renderer shows
    the sleep-mode info box instead of a directional warning.
    """
    if not market_open:
        return "Market Closed", ""

    if len(df) < 2:
        return "Consolidation", "Insufficient bars for prediction."

    price_start = float(df["open"].iloc[0])
    price_now   = float(df["close"].iloc[-1])
    pct_chg = (price_now - price_start) / price_start * 100.0 if price_start > 0 else 0.0

    # Fake-out: price up but volume weak
    if rvol is not None and rvol < 1.2 and pct_chg > 0.5:
        return ("Fake-out",
                f"Price +{pct_chg:.1f}% on anemic RVOL {rvol:.1f}× — volume is NOT confirming "
                "the move. High reversal risk. Wait for RVOL > 2.0 before trusting direction.")

    # High Conviction: strong RVOL + strong TCS
    if rvol is not None and rvol > 4.0 and tcs >= 60:
        tail = " Sector tailwind adds confirmation." if sector_bonus > 0 else ""
        return ("High Conviction",
                f"RVOL {rvol:.1f}× surge confirms directional participation. "
                f"TCS {tcs:.0f}% — institutional footprint visible. "
                f"Trend continuation is the high-probability path.{tail}")

    # Consolidation: low TCS
    if tcs < 35:
        return ("Consolidation",
                f"TCS {tcs:.0f}% — low trend energy. Price coiling inside range. "
                "Watch for a Volume Velocity spike to signal the next push.")

    # Moderate high conviction
    if abs(pct_chg) > 0.5 and (rvol is None or rvol >= 1.5):
        direction = f"+{pct_chg:.1f}%" if pct_chg > 0 else f"{pct_chg:.1f}%"
        bias = "upward" if pct_chg > 0 else "downward"
        return ("High Conviction",
                f"Price {direction} with TCS {tcs:.0f}% and volume not diverging. "
                f"Structure supports {bias} continuation.")

    return ("Consolidation",
            f"Mixed signals — TCS {tcs:.0f}%, "
            f"RVOL {'N/A' if rvol is None else f'{rvol:.1f}×'}. "
            "Price and volume not clearly aligned; range-bound action expected.")


def compute_tcs(df, ib_high, ib_low, poc_price, sector_bonus=0.0):
    """Trend Confidence Score (0–100).

    Three equally-weighted factors:
      • Range Factor    (40 pts) — day range vs IB range
      • Velocity Factor (30 pts) — current vol/min vs session avg vol/min
      • Structure Factor (30 pts) — price > 1 ATR from POC and trending away
    Optional sector_bonus: +10 pts if sector ETF is up > 1%.
    """
    tcs = 0.0

    day_high = float(df["high"].max())
    day_low = float(df["low"].min())
    total_range = day_high - day_low
    ib_range = (ib_high - ib_low) if (ib_high and ib_low) else 0.0
    final_price = float(df["close"].iloc[-1])

    # ── Range Factor (40 pts) ─────────────────────────────────────────────────
    if ib_range > 0:
        rr = total_range / ib_range
        if rr >= 2.5:
            tcs += 40.0
        elif rr > 1.1:
            tcs += 40.0 * (rr - 1.1) / (2.5 - 1.1)

    # ── Velocity Factor (30 pts) ──────────────────────────────────────────────
    if len(df) >= 6:
        w = min(3, len(df) // 2)
        current_vel = float(df["volume"].iloc[-w:].mean())
        avg_vel = float(df["volume"].mean())
        if avg_vel > 0:
            vr = current_vel / avg_vel
            if vr >= 2.0:
                tcs += 30.0
            elif vr > 1.0:
                tcs += 30.0 * (vr - 1.0) / (2.0 - 1.0)

    # ── Structure Factor (30 pts) ─────────────────────────────────────────────
    if len(df) >= 3:
        high = df["high"]
        low = df["low"]
        prev_close = df["close"].shift(1)
        tr = pd.concat(
            [high - low, (high - prev_close).abs(), (low - prev_close).abs()], axis=1
        ).max(axis=1)
        atr = float(tr.rolling(window=min(14, len(df))).mean().iloc[-1])

        if atr > 0 and abs(final_price - poc_price) > atr:
            # "Moving" = last 3 closes trending further from POC
            if len(df) >= 4:
                poc_side = 1 if final_price > poc_price else -1
                move = float(df["close"].iloc[-1]) - float(df["close"].iloc[-4])
                if move * poc_side > 0:
                    tcs += 30.0          # trending away — full credit
                else:
                    tcs += 15.0          # beyond ATR but stalling
            else:
                tcs += 20.0

    # ── Sector Tailwind bonus (+10 pts if sector ETF up > 1%) ────────────────
    tcs += sector_bonus

    return round(min(100.0, tcs), 1)


def compute_volume_velocity(df):
    if len(df) < 4:
        return None, None, None
    w = min(3, len(df) // 2)
    recent = float(df["volume"].iloc[-w:].mean())
    if len(df) < 2 * w:
        return recent, None, None
    prev = float(df["volume"].iloc[-2*w:-w].mean())
    if prev == 0:
        return recent, None, None
    chg = (recent - prev) / prev * 100
    return recent, abs(chg), ("↑" if chg >= 0 else "↓")


def compute_target_zones(df, ib_high, ib_low, bin_centers, vap, tcs):
    """Return a list of dynamic target zone dicts based on structure.

    Each dict: {type, price, label, color, description, [lvn_price, lvn_idx]}
    """
    targets = []
    if df.empty or ib_high is None or ib_low is None:
        return targets
    ib_range = ib_high - ib_low
    if ib_range <= 0:
        return targets

    final_price  = float(df["close"].iloc[-1])
    day_high     = float(df["high"].max())
    day_low      = float(df["low"].min())

    ib_high_violated = bool((df["high"] >= ib_high).any())
    ib_low_violated  = bool((df["low"]  <= ib_low).any())
    price_back_inside = ib_low < final_price < ib_high

    # ── Coast-to-Coast ────────────────────────────────────────────────────────
    if ib_high_violated and price_back_inside:
        targets.append({
            "type": "coast_to_coast",
            "price": ib_low,
            "label": "🎯 C2C Target",
            "color": "#ff5252",
            "description": (f"IB High violated → price returned inside → "
                            f"Coast-to-Coast target: IB Low ${ib_low:.2f}"),
        })
    if ib_low_violated and price_back_inside:
        targets.append({
            "type": "coast_to_coast",
            "price": ib_high,
            "label": "🎯 C2C Target",
            "color": "#00e676",
            "description": (f"IB Low violated → price returned inside → "
                            f"Coast-to-Coast target: IB High ${ib_high:.2f}"),
        })

    # ── Range Extension  (TCS > 70 %) ────────────────────────────────────────
    if tcs > 70 and ib_range > 0:
        bullish = ib_high_violated and not ib_low_violated
        bearish = ib_low_violated  and not ib_high_violated
        if bullish:
            ext15 = ib_high + 1.5 * ib_range
            ext20 = ib_high + 2.0 * ib_range
            targets.append({"type": "trend_extension", "price": ext15,
                            "label": "🎯 1.5× Ext", "color": "#26a69a",
                            "description": f"Bullish 1.5× IB extension: ${ext15:.2f}"})
            targets.append({"type": "trend_extension", "price": ext20,
                            "label": "🎯 2.0× Ext", "color": "#4caf50",
                            "description": f"Bullish 2.0× IB extension: ${ext20:.2f}"})
        elif bearish:
            ext15 = ib_low - 1.5 * ib_range
            ext20 = ib_low - 2.0 * ib_range
            targets.append({"type": "trend_extension", "price": ext15,
                            "label": "🎯 1.5× Ext", "color": "#ef5350",
                            "description": f"Bearish 1.5× IB extension: ${ext15:.2f}"})
            targets.append({"type": "trend_extension", "price": ext20,
                            "label": "🎯 2.0× Ext", "color": "#c62828",
                            "description": f"Bearish 2.0× IB extension: ${ext20:.2f}"})

    # ── Gap Fill (Double Distribution LVN) ───────────────────────────────────
    dd = _detect_double_distribution(bin_centers, vap)
    if dd is not None:
        pk1, pk2, vi = dd
        lvn_price = float(bin_centers[vi])
        hvn1 = float(bin_centers[pk1])
        hvn2 = float(bin_centers[pk2])
        target_hvn = hvn2 if final_price < lvn_price else hvn1
        targets.append({
            "type": "gap_fill",
            "price": target_hvn,
            "lvn_price": lvn_price,
            "lvn_idx": int(vi),
            "label": "🎯 Gap Fill",
            "color": "#ffd700",
            "description": (f"DD LVN at ${lvn_price:.2f} → "
                            f"Gap Fill target ${target_hvn:.2f}"),
        })

    return targets


def _stream_worker(api_key, secret_key, ticker, feed_str, data_queue, stop_event):
    import asyncio
    from alpaca.data.live import StockDataStream
    from alpaca.data.enums import DataFeed

    feed_enum = DataFeed.SIP if feed_str == "sip" else DataFeed.IEX
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    stream = StockDataStream(api_key, secret_key, feed=feed_enum)

    async def on_trade(trade):
        try:
            data_queue.put_nowait({"t": "trade", "p": float(trade.price),
                                   "s": float(trade.size), "ts": trade.timestamp})
        except Exception:
            pass

    async def on_bar(bar):
        try:
            data_queue.put_nowait({"t": "bar", "o": float(bar.open), "h": float(bar.high),
                                   "l": float(bar.low), "c": float(bar.close),
                                   "v": float(bar.volume), "ts": bar.timestamp})
        except Exception:
            pass

    stream.subscribe_trades(on_trade, ticker)
    stream.subscribe_bars(on_bar, ticker)

    async def run_until_stopped():
        # _run_forever() is the actual coroutine; stream.run() wraps it in
        # asyncio.run() which would conflict with our already-running loop.
        task = asyncio.ensure_future(stream._run_forever())
        while not stop_event.is_set():
            await asyncio.sleep(0.3)
            if task.done():
                break
        stream.stop()
        try:
            await asyncio.wait_for(task, timeout=5.0)
        except (asyncio.TimeoutError, asyncio.CancelledError):
            pass
        except Exception:
            pass
        finally:
            if not task.done():
                task.cancel()

    try:
        loop.run_until_complete(run_until_stopped())
    except Exception as e:
        try:
            data_queue.put_nowait({"t": "error", "msg": str(e)})
        except Exception:
            pass
    finally:
        try:
            loop.close()
        except Exception:
            pass


def start_stream(api_key, secret_key, ticker, feed_str):
    q = queue.Queue(maxsize=10000)
    ev = threading.Event()
    t = threading.Thread(target=_stream_worker,
                         args=(api_key, secret_key, ticker, feed_str, q, ev),
                         daemon=True)
    t.start()
    st.session_state.live_queue = q
    st.session_state.live_stop_event = ev
    st.session_state.live_thread = t
    st.session_state.live_active = True
    st.session_state.live_bars = []
    st.session_state.live_current_bar = None
    st.session_state.live_trades = deque(maxlen=3000)
    st.session_state.live_ticker = ticker
    st.session_state.live_error = None
    # Reset alert state for the new session
    st.session_state.tcs_fired_high = False
    st.session_state.tcs_was_high = False


def stop_stream():
    if st.session_state.live_stop_event:
        st.session_state.live_stop_event.set()
    st.session_state.live_active = False
    st.session_state.live_queue = None
    st.session_state.live_stop_event = None
    st.session_state.live_thread = None


def drain_queue():
    q = st.session_state.live_queue
    if q is None:
        return
    cur = st.session_state.live_current_bar or {}
    processed = 0
    while processed < 1000:
        try:
            item = q.get_nowait()
            processed += 1
        except queue.Empty:
            break
        t = item.get("t")
        if t == "error":
            st.session_state.live_error = item.get("msg", "Unknown error")
            st.session_state.live_active = False
        elif t == "bar":
            st.session_state.live_bars.append(
                {"open": item["o"], "high": item["h"], "low": item["l"],
                 "close": item["c"], "volume": item["v"], "timestamp": item["ts"]}
            )
            cur = {}
        elif t == "trade":
            p, s, ts = item["p"], item["s"], item["ts"]
            st.session_state.live_trades.append({"price": p, "size": s, "ts": ts})
            if not cur:
                cur = {"open": p, "high": p, "low": p, "close": p, "volume": s, "timestamp": ts}
            else:
                cur["high"] = max(cur["high"], p)
                cur["low"] = min(cur["low"], p)
                cur["close"] = p
                cur["volume"] = cur.get("volume", 0) + s
                cur["timestamp"] = ts
    st.session_state.live_current_bar = cur if cur else None


def build_live_df():
    rows = list(st.session_state.live_bars)
    if st.session_state.live_current_bar:
        rows.append(st.session_state.live_current_bar)
    if not rows:
        return pd.DataFrame()
    df = pd.DataFrame(rows)
    df.index = pd.to_datetime(df["timestamp"])
    if df.index.tz is None:
        df.index = df.index.tz_localize("UTC")
    df.index = df.index.tz_convert(EASTERN)
    df = df.drop(columns=["timestamp"], errors="ignore")
    needed = ["open", "high", "low", "close", "volume"]
    if not all(c in df.columns for c in needed):
        return pd.DataFrame()
    df = df[needed].sort_index()
    df = df[(df.index.time >= dtime(9, 30)) & (df.index.time <= dtime(16, 0))]
    return df


# ══════════════════════════════════════════════════════════════════════════════
# TRADE JOURNAL
# ══════════════════════════════════════════════════════════════════════════════

import csv
import os

JOURNAL_PATH = "trade_journal.csv"
_JOURNAL_COLS = [
    "timestamp", "ticker", "price", "structure", "tcs", "rvol",
    "ib_high", "ib_low", "notes", "grade", "grade_reason",
]


def load_journal(user_id: str = "") -> "pd.DataFrame":
    """Load the trade journal from Supabase, optionally filtered by user_id."""
    if not supabase:
        return pd.DataFrame(columns=_JOURNAL_COLS)
    try:
        q = supabase.table("trade_journal").select("*")
        if user_id:
            try:
                q = q.eq("user_id", user_id)
            except Exception:
                pass
        response = q.execute()
        data = response.data
        if not data:
            return pd.DataFrame(columns=_JOURNAL_COLS)
        df = pd.DataFrame(data)
        for col in _JOURNAL_COLS:
            if col not in df.columns:
                df[col] = ""
        return df[_JOURNAL_COLS]
    except Exception as e:
        print(f"Database read error (journal): {e}")
        return pd.DataFrame(columns=_JOURNAL_COLS)


def save_journal_entry(entry: dict, user_id: str = ""):
    """Save a new trade journal entry to Supabase."""
    if not supabase:
        print("Error: Supabase not connected.")
        return
    try:
        row = {k: entry.get(k, None) for k in _JOURNAL_COLS}
        if user_id:
            row["user_id"] = user_id
        supabase.table("trade_journal").insert(row).execute()
    except Exception as e:
        print(f"Database write error (journal): {e}")


def fetch_live_quote(ticker: str) -> dict:
    """Fetch current price and today's volume via yfinance.
    Returns dict with keys: price, volume, error (None on success).
    """
    try:
        import yfinance as yf
        t = yf.Ticker(ticker.upper().strip())
        info = t.fast_info
        price  = float(info.last_price)  if info.last_price  else None
        volume = int(info.three_month_average_volume) if info.three_month_average_volume else None
        # prefer today's volume from 1d history
        hist = t.history(period="1d", interval="1m")
        if not hist.empty and "Volume" in hist.columns:
            volume = int(hist["Volume"].sum())
        if price is None:
            return {"price": None, "volume": None, "error": f"No data returned for '{ticker}'"}
        return {"price": round(price, 4), "volume": volume, "error": None}
    except Exception as e:
        return {"price": None, "volume": None, "error": str(e)}


def fetch_alpaca_fills(api_key: str, secret_key: str,
                       is_paper: bool = True,
                       trade_date: str = None) -> tuple:
    """Fetch filled orders from Alpaca Trading REST API for a given date.

    Returns (fills_list, error_string).  error_string is None on success.
    """
    base = ("https://paper-api.alpaca.markets"
            if is_paper else "https://api.alpaca.markets")
    headers = {
        "APCA-API-KEY-ID":     api_key,
        "APCA-API-SECRET-KEY": secret_key,
    }
    if trade_date is None:
        trade_date = datetime.now(EASTERN).strftime("%Y-%m-%d")

    params = {
        "status":    "closed",
        "after":     f"{trade_date}T00:00:00Z",
        "until":     f"{trade_date}T23:59:59Z",
        "limit":     200,
        "direction": "desc",
    }
    try:
        resp = requests.get(f"{base}/v2/orders",
                            headers=headers, params=params, timeout=12)
        if resp.status_code == 401:
            return [], "Authentication failed — check your API Key and Secret Key."
        if resp.status_code == 403:
            return [], "Access forbidden — are you using a paper key on a live endpoint (or vice versa)?"
        resp.raise_for_status()
        orders = resp.json()
        if isinstance(orders, dict) and "message" in orders:
            return [], orders["message"]
        filled = [o for o in orders if o.get("status") == "filled"]
        return filled, None
    except requests.exceptions.Timeout:
        return [], "Request timed out — Alpaca API did not respond in time."
    except Exception as exc:
        return [], str(exc)


def match_fills_to_roundtrips(fills: list) -> list:
    """Match Alpaca buy+sell fills into round-trip trades.

    Groups fills by symbol, computes weighted-average entry/exit,
    and returns a list of trade summary dicts.
    """
    from collections import defaultdict
    by_sym = defaultdict(lambda: {"buys": [], "sells": []})

    for order in fills:
        sym        = (order.get("symbol") or "").upper()
        side       = order.get("side", "")
        fill_price = float(order.get("filled_avg_price") or 0)
        qty        = float(order.get("filled_qty") or 0)
        filled_at  = str(order.get("filled_at") or "")
        if fill_price <= 0 or qty <= 0:
            continue
        if side == "buy":
            by_sym[sym]["buys"].append({"price": fill_price, "qty": qty, "time": filled_at})
        elif side == "sell":
            by_sym[sym]["sells"].append({"price": fill_price, "qty": qty, "time": filled_at})

    results = []
    for sym, sides in by_sym.items():
        if not sides["buys"] or not sides["sells"]:
            continue
        total_buy_qty  = sum(b["qty"] for b in sides["buys"])
        total_sell_qty = sum(s["qty"] for s in sides["sells"])
        avg_entry = (sum(b["price"] * b["qty"] for b in sides["buys"])  / total_buy_qty)
        avg_exit  = (sum(s["price"] * s["qty"] for s in sides["sells"]) / total_sell_qty)
        matched_qty   = min(total_buy_qty, total_sell_qty)
        pnl_dollars   = (avg_exit - avg_entry) * matched_qty
        pnl_pct       = ((avg_exit - avg_entry) / avg_entry * 100) if avg_entry > 0 else 0.0
        win_loss      = "Win" if pnl_dollars > 0 else ("Loss" if pnl_dollars < 0 else "Breakeven")

        # Earliest fill time for display
        all_times = [b["time"] for b in sides["buys"]] + [s["time"] for s in sides["sells"]]
        earliest  = sorted(t for t in all_times if t)[:1]
        fill_time = earliest[0][:16].replace("T", " ") if earliest else ""

        results.append({
            "symbol":      sym,
            "avg_entry":   round(avg_entry, 4),
            "avg_exit":    round(avg_exit, 4),
            "qty":         matched_qty,
            "pnl_dollars": round(pnl_dollars, 4),
            "pnl_pct":     round(pnl_pct, 2),
            "win_loss":    win_loss,
            "fill_time":   fill_time,
        })

    results.sort(key=lambda r: r["fill_time"])
    return results


def save_trade_review(journal_row: dict, exit_price: float,
                      actual_structure: str, direction: str = "Long",
                      user_id: str = "") -> dict:
    """Calculate trade outcome and persist to accuracy_tracker.

    Parameters
    ----------
    journal_row      : row dict from trade_journal (must have 'ticker', 'price', 'structure')
    exit_price       : actual exit price entered by the user
    actual_structure : actual day structure the user observed
    direction        : "Long" or "Short"

    Returns
    -------
    dict with keys: win_loss, pnl_dollars, pnl_pct, correct_structure
    """
    entry_price = float(journal_row.get("price", 0.0))
    ticker      = str(journal_row.get("ticker", ""))
    predicted   = str(journal_row.get("structure", ""))

    if entry_price <= 0:
        return {"win_loss": "N/A", "pnl_dollars": 0.0, "pnl_pct": 0.0,
                "correct_structure": False, "error": "Invalid entry price"}

    pnl_dollars = (exit_price - entry_price) if direction == "Long" \
                  else (entry_price - exit_price)
    pnl_pct     = (pnl_dollars / entry_price) * 100
    win_loss    = "Win" if pnl_dollars > 0 else ("Loss" if pnl_dollars < 0 else "Breakeven")

    correct_structure = (
        _strip_emoji(predicted.lower()) in _strip_emoji(actual_structure.lower()) or
        _strip_emoji(actual_structure.lower()) in _strip_emoji(predicted.lower())
    )

    log_accuracy_entry(
        symbol      = ticker,
        predicted   = predicted,
        actual      = actual_structure,
        compare_key = "manual_review",
        entry_price = entry_price,
        exit_price  = exit_price,
        mfe         = round(pnl_dollars, 4),
        user_id     = user_id,
    )

    return {
        "win_loss":          win_loss,
        "pnl_dollars":       round(pnl_dollars, 4),
        "pnl_pct":           round(pnl_pct, 2),
        "correct_structure": correct_structure,
        "error":             None,
    }


def compute_trade_grade(rvol, tcs, price, ib_high, ib_low, structure_label):
    """Return (grade, reason) based on RVOL, TCS, price relative to IB."""
    rvol_val = rvol if rvol is not None else 0.0
    is_trend  = "trend" in structure_label.lower()
    price_inside_ib = (
        (ib_low is not None and ib_high is not None) and (ib_low < price < ib_high)
    )
    price_above_ib = (ib_high is not None) and (price > ib_high)

    # F — disqualifying conditions first
    if rvol_val < 1.0:
        return "F", f"Grade F: Low-volume setup (RVOL {rvol_val:.1f}×) — unfavorable odds."
    if is_trend and price_inside_ib:
        return "F", "Grade F: Trend attempt but price is still inside IB — no breakout confirmation."

    # A — ideal setup
    if rvol_val > 4.0 and tcs > 70 and price_above_ib:
        return "A", (f"Grade A: RVOL {rvol_val:.1f}×, TCS {tcs:.0f}%, price above IB High — "
                     f"elite, high-conviction setup.")

    # B — solid
    if rvol_val > 2.0 and tcs > 50:
        return "B", (f"Grade B: RVOL {rvol_val:.1f}×, TCS {tcs:.0f}% — solid participation "
                     f"with reasonable confidence.")

    # C — moderate
    if (1.0 <= rvol_val <= 2.0) or (30 <= tcs <= 50):
        return "C", (f"Grade C: Moderate quality (RVOL {rvol_val:.1f}×, TCS {tcs:.0f}%) — "
                     f"acceptable but below ideal thresholds.")

    # F — catch-all low confidence
    return "F", (f"Grade F: Low confidence (RVOL {rvol_val:.1f}×, TCS {tcs:.0f}%) — "
                 f"avoid or reduce size significantly.")


_GRADE_COLORS = {"A": "#4caf50", "B": "#26a69a", "C": "#ffa726", "F": "#ef5350"}
_GRADE_SCORE  = {"A": 4, "B": 3, "C": 2, "F": 1}


def fetch_snapshots_bulk(api_key, secret_key, tickers, feed="iex"):
    """Batch-fetch latest price + previous day's close for a list of tickers.

    Works during market hours AND after hours / weekends by cascading through
    every available data field on the snapshot object.

    Returns {sym: {"price": float, "prev_close": float}} for qualifying tickers.
    Raises on authentication / network errors so the caller can show them.
    """
    from alpaca.data.historical import StockHistoricalDataClient
    from alpaca.data.requests import StockSnapshotRequest, StockBarsRequest
    from alpaca.data.timeframe import TimeFrame

    client = StockHistoricalDataClient(api_key, secret_key)

    # ── Step 1: try snapshot endpoint ─────────────────────────────────────────
    snap_result = {}
    try:
        req   = StockSnapshotRequest(symbol_or_symbols=list(tickers), feed=feed)
        snaps = client.get_stock_snapshot(req)

        for sym, snap in snaps.items():
            try:
                # Price: latest_trade → latest_quote mid → daily_bar close
                price = None
                if getattr(snap, "latest_trade", None) and snap.latest_trade.price:
                    price = float(snap.latest_trade.price)
                if price is None and getattr(snap, "latest_quote", None):
                    q = snap.latest_quote
                    ask = getattr(q, "ask_price", None)
                    bid = getattr(q, "bid_price", None)
                    if ask and bid and ask > 0 and bid > 0:
                        price = (float(ask) + float(bid)) / 2
                if price is None and getattr(snap, "daily_bar", None) and snap.daily_bar.close:
                    price = float(snap.daily_bar.close)

                # Prev close: prev_daily_bar → fall back to daily_bar open
                prev_close = None
                if getattr(snap, "prev_daily_bar", None) and snap.prev_daily_bar.close:
                    prev_close = float(snap.prev_daily_bar.close)
                if prev_close is None and getattr(snap, "daily_bar", None) and snap.daily_bar.open:
                    prev_close = float(snap.daily_bar.open)

                if price and price > 0:
                    snap_result[sym] = {
                        "price":      price,
                        "prev_close": prev_close if prev_close and prev_close > 0 else price,
                    }
            except Exception:
                pass
    except Exception as snap_err:
        # Snapshot endpoint failed entirely — fall through to daily bars
        snap_err_str = str(snap_err)
        if any(k in snap_err_str.lower() for k in ("forbidden", "unauthorized", "403", "401")):
            raise  # bad credentials — surface immediately

    if snap_result:
        return snap_result

    # ── Step 2: fallback — fetch last 5 daily bars for each ticker ─────────────
    # This path is used when the snapshot returns empty (e.g. after hours on IEX)
    daily_result = {}
    end_dt   = datetime.now(pytz.UTC)
    start_dt = end_dt - timedelta(days=10)

    for sym in tickers:
        try:
            req = StockBarsRequest(
                symbol_or_symbols=sym,
                timeframe=TimeFrame.Day,
                start=start_dt,
                end=end_dt,
                feed=feed,
            )
            bars = client.get_stock_bars(req)
            df   = bars.df
            if df.empty:
                continue
            if isinstance(df.index, pd.MultiIndex):
                df = df.xs(sym, level="symbol")
            df = df.sort_index()
            if len(df) < 1:
                continue
            price      = float(df["close"].iloc[-1])
            prev_close = float(df["close"].iloc[-2]) if len(df) >= 2 else price
            if price > 0:
                daily_result[sym] = {"price": price, "prev_close": prev_close}
        except Exception:
            pass

    return daily_result


def fetch_premarket_vols(api_key, secret_key, ticker, trade_date,
                         lookback_days=10, feed="iex"):
    """Fetch today's pre-market volume + 10-day historical average.

    Pre-market window = 4:00 AM – 9:29 AM EST (regular extended hours).
    Returns (today_pm_vol: float, avg_hist_pm_vol: float | None).
    """
    from alpaca.data.historical import StockHistoricalDataClient
    from alpaca.data.requests import StockBarsRequest
    from alpaca.data.timeframe import TimeFrame

    client = StockHistoricalDataClient(api_key, secret_key)
    start_dt = EASTERN.localize(
        datetime(trade_date.year, trade_date.month, trade_date.day)
        - timedelta(days=lookback_days * 3)   # buffer for weekends / holidays
    )
    # Include up to 9:30 AM today to capture this morning's pre-market bars
    end_dt = EASTERN.localize(
        datetime(trade_date.year, trade_date.month, trade_date.day, 9, 30)
    )
    req = StockBarsRequest(symbol_or_symbols=ticker, timeframe=TimeFrame.Minute,
                           start=start_dt, end=end_dt, feed=feed)
    bars = client.get_stock_bars(req)
    df = bars.df
    if df.empty:
        return 0.0, None

    if isinstance(df.index, pd.MultiIndex):
        df = df.xs(ticker, level="symbol")
    df.index = pd.to_datetime(df.index)
    if df.index.tz is None:
        df.index = df.index.tz_localize("UTC")
    df.index = df.index.tz_convert(EASTERN)
    df = df.sort_index()

    # Filter to pre-market window: 4:00 AM – 9:29 AM
    df = df[(df.index.time >= dtime(4, 0)) & (df.index.time < dtime(9, 30))]
    df["_date"] = df.index.date
    daily_vols = df.groupby("_date")["volume"].sum()

    today_vol = float(daily_vols.get(trade_date, 0.0))
    hist_vols = daily_vols[daily_vols.index < trade_date].tail(lookback_days)
    avg_vol = float(hist_vols.mean()) if not hist_vols.empty else None

    return today_vol, avg_vol


def run_gap_scanner(api_key, secret_key, watchlist, trade_date, feed="iex"):
    """Run the full gap-scanner pipeline and return the top 10 tickers by PM RVOL.

    Pipeline:
      1. Batch-fetch snapshots (price + prev_close)
      2. Filter to $1–$50 price range (covers most small-cap universe)
      3. Fetch pre-market volumes + 10-day historical average per qualifying ticker
      4. Compute Gap % and Pre-Market RVOL
      5. Sort by RVOL descending, return top 10

    Returns list of dicts: [{ticker, price, gap_pct, pm_vol, avg_pm_vol, pm_rvol}]
    Raises exceptions so the caller can surface them to the UI.
    """
    # Step 1 — batch snapshots (let exception propagate so UI can show the message)
    snaps = fetch_snapshots_bulk(api_key, secret_key, watchlist, feed=feed)

    if not snaps:
        raise ValueError(
            "No snapshot data returned. Check your API credentials and that the "
            "tickers exist on Alpaca."
        )

    # Step 2 — filter by price ($1–$50 covers the small-cap universe)
    qualifying = {
        sym: d for sym, d in snaps.items()
        if d.get("price") is not None and 1.0 <= d["price"] <= 50.0
    }
    if not qualifying:
        out_of_range = [s for s, d in snaps.items() if d.get("price") is not None]
        raise ValueError(
            f"All {len(out_of_range)} tickers are outside the $1–$50 scan range "
            f"({', '.join(out_of_range[:5])}). "
            "Add small-cap tickers to your watchlist."
        )

    # Step 3 & 4 — pre-market volume + compute metrics
    # On IEX (free tier) pre-market bars are unavailable — we gracefully degrade
    # to gap-only mode after the first subscription error.
    pm_data_available = True
    rows = []
    for sym, snap_data in qualifying.items():
        pm_vol, avg_pm_vol = 0.0, None
        if pm_data_available:
            try:
                pm_vol, avg_pm_vol = fetch_premarket_vols(
                    api_key, secret_key, sym, trade_date,
                    lookback_days=10, feed=feed)
            except Exception as _pm_err:
                err_str = str(_pm_err).lower()
                if "subscription" in err_str or "permit" in err_str or "sip" in err_str:
                    # Free-tier account — skip PM vol for all remaining tickers
                    pm_data_available = False
                # Any other error: leave pm_vol/avg_pm_vol as 0/None and continue

        price      = snap_data["price"]
        prev_close = snap_data["prev_close"]
        gap_pct    = ((price - prev_close) / prev_close * 100.0
                      if prev_close and prev_close > 0 else 0.0)
        pm_rvol    = (round(pm_vol / avg_pm_vol, 2)
                      if avg_pm_vol and avg_pm_vol > 0 else None)

        rows.append({
            "ticker":          sym,
            "price":           round(price, 2),
            "gap_pct":         round(gap_pct, 2),
            "pm_vol":          int(pm_vol),
            "avg_pm_vol":      round(avg_pm_vol, 0) if avg_pm_vol else None,
            "pm_rvol":         pm_rvol,
            "pm_data_available": pm_data_available,
        })

    # Step 5 — sort by absolute gap %, then RVOL as tiebreaker, top 10
    rows.sort(key=lambda r: (
        abs(r["gap_pct"]),
        r["pm_rvol"] if r["pm_rvol"] is not None else -1,
    ), reverse=True)

    # Tag each row with whether PM data was available for this scan
    for r in rows:
        r["pm_data_available"] = pm_data_available

    return rows[:10]


def _parse_batch_pairs(text: str) -> list[tuple]:
    """Parse 'M/D: T1, T2, ...' lines into [(ticker, date), ...] for year 2026."""
    import re
    pairs = []
    for line in text.strip().splitlines():
        line = line.strip()
        if not line or ":" not in line:
            continue
        date_part, tickers_part = line.split(":", 1)
        date_part = date_part.strip()
        m = re.match(r"(\d{1,2})/(\d{1,2})", date_part)
        if not m:
            continue
        mo, dy = int(m.group(1)), int(m.group(2))
        try:
            trade_date = date(2026, mo, dy)
        except ValueError:
            continue
        for t in tickers_part.split(","):
            t = t.strip().upper()
            if t:
                pairs.append((t, trade_date))
    return pairs


def run_single_backtest(api_key, secret_key, ticker, trade_date, feed="iex", num_bins=100):
    """Full pipeline for one ticker/date: fetch → classify → brain → log."""
    result = {"ticker": ticker, "date": str(trade_date),
              "predicted": "—", "actual": "—", "correct": "—", "status": "OK"}
    try:
        df = fetch_bars(api_key, secret_key, ticker, trade_date, feed=feed)
        if df.empty or len(df) < 10:
            result["status"] = "No data"
            return result

        bin_centers, vap, poc_price = compute_volume_profile(df, num_bins)
        ib_high, ib_low = compute_initial_balance(df)
        if ib_high is None or ib_low is None:
            result["status"] = "No IB data"
            return result

        label, color, detail, insight = classify_day_structure(
            df, bin_centers, vap, ib_high, ib_low, poc_price
        )
        result["actual"] = label

        # Simulate MarketBrain with the full day's bars + rich signals
        brain = MarketBrain()
        try:
            _bt_ivp, _ = compute_ib_volume_stats(df, ib_high, ib_low)
        except Exception:
            _bt_ivp = None
        _bt_has_dd = _detect_double_distribution(bin_centers, vap) is not None
        brain.update(df, ib_vol_pct=_bt_ivp, poc_price=poc_price,
                     has_double_dist=_bt_has_dd)
        prediction = brain.prediction
        result["predicted"] = prediction

        if not brain.ib_set or prediction == "Analyzing IB…":
            result["status"] = "IB incomplete"
            return result

        # Build compare_key and dedup check
        ck = f"{ticker}_{trade_date}_{float(ib_high):.4f}_{float(ib_low):.4f}"
        if os.path.exists(TRACKER_FILE):
            try:
                _chk = pd.read_csv(TRACKER_FILE, encoding="utf-8")
                if "compare_key" in _chk.columns and (_chk["compare_key"] == ck).any():
                    result["status"] = "Already logged"
                    # Still show correct/wrong from existing row
                    _row = _chk[_chk["compare_key"] == ck]
                    if not _row.empty and "correct" in _row.columns:
                        result["correct"] = str(_row["correct"].iloc[0])
                    return result
            except Exception:
                pass

        log_accuracy_entry(ticker, prediction, label, compare_key=ck)
        result["correct"] = ("✅" if _strip_emoji(prediction) in _strip_emoji(label)
                             or _strip_emoji(label) in _strip_emoji(prediction) else "❌")
    except Exception as e:
        result["status"] = f"Error: {str(e)[:60]}"
    return result


# ── Analytics & Edge ──────────────────────────────────────────────────────────

def compute_edge_analytics(journal_df: pd.DataFrame,
                           tracker_df: pd.DataFrame) -> dict:
    """Join trade_journal + accuracy_tracker and compute full edge stats.

    Returns
    -------
    dict with keys:
      summary            – high-level KPIs
      equity_curve       – DataFrame (timestamp, symbol, mfe, cumulative_pnl)
      daily_pnl          – DataFrame (date, pnl, cumulative_pnl)
      win_rate_by_struct – DataFrame (structure, trades, wins, win_rate, avg_pnl)
      grade_distribution – dict {grade: count}
      tcs_edge           – DataFrame (tcs_bucket, trades, win_rate)
    """
    empty = {
        "summary": {
            "win_rate": 0.0, "total_pnl": 0.0, "avg_win": 0.0,
            "avg_loss": 0.0, "profit_factor": 0.0,
            "total_trades": 0, "trade_days": 0,
        },
        "equity_curve":        pd.DataFrame(),
        "daily_pnl":           pd.DataFrame(),
        "win_rate_by_struct":  pd.DataFrame(),
        "grade_distribution":  {},
        "tcs_edge":            pd.DataFrame(),
    }

    # ── Clean tracker ──────────────────────────────────────────────────────
    tdf = tracker_df.copy() if not tracker_df.empty else pd.DataFrame()
    if tdf.empty:
        return empty

    for col in ("entry_price", "exit_price", "mfe"):
        tdf[col] = pd.to_numeric(tdf.get(col, 0), errors="coerce").fillna(0.0)
    tdf["timestamp"] = pd.to_datetime(tdf.get("timestamp", pd.NaT), errors="coerce")

    trades = tdf[(tdf["entry_price"] > 0) & (tdf["exit_price"] > 0)].copy()
    if trades.empty:
        return empty

    trades = trades.sort_values("timestamp").reset_index(drop=True)

    wins   = trades[trades["mfe"] > 0]
    losses = trades[trades["mfe"] < 0]

    total_trades  = len(trades)
    win_count     = len(wins)
    win_rate      = round(win_count / total_trades * 100, 1) if total_trades else 0.0
    total_pnl     = round(float(trades["mfe"].sum()), 2)
    avg_win       = round(float(wins["mfe"].mean()), 2)   if not wins.empty   else 0.0
    avg_loss      = round(float(losses["mfe"].mean()), 2) if not losses.empty else 0.0
    gross_win     = float(wins["mfe"].sum())              if not wins.empty   else 0.0
    gross_loss    = abs(float(losses["mfe"].sum()))       if not losses.empty else 0.0
    profit_factor = round(gross_win / gross_loss, 2)      if gross_loss > 0   else 999.0
    trade_days    = int(trades["timestamp"].dt.date.nunique())

    # ── Equity curve ────────────────────────────────────────────────────────
    trades["cumulative_pnl"] = trades["mfe"].cumsum()
    equity_curve = trades[["timestamp", "symbol", "mfe", "cumulative_pnl"]].copy()

    # ── Daily P&L ───────────────────────────────────────────────────────────
    trades["date"] = trades["timestamp"].dt.date
    daily = (trades.groupby("date")["mfe"].sum()
             .reset_index().rename(columns={"mfe": "pnl"}))
    daily["cumulative_pnl"] = daily["pnl"].cumsum()

    # ── Win rate by predicted structure ─────────────────────────────────────
    struct_rows = []
    if "predicted" in trades.columns:
        for struct, grp in trades.groupby("predicted"):
            s = str(struct).strip()
            if not s:
                continue
            tc = len(grp); wc = int((grp["mfe"] > 0).sum())
            struct_rows.append({
                "structure": s,
                "trades":    tc,
                "wins":      wc,
                "win_rate":  round(wc / tc * 100, 1) if tc else 0.0,
                "avg_pnl":   round(float(grp["mfe"].mean()), 2),
            })
    wr_struct = (pd.DataFrame(struct_rows).sort_values("win_rate", ascending=False)
                 if struct_rows else pd.DataFrame())

    # ── TCS edge ────────────────────────────────────────────────────────────
    tcs_edge = pd.DataFrame()
    if not journal_df.empty and "tcs" in journal_df.columns:
        jdf = journal_df.copy()
        jdf["tcs"] = pd.to_numeric(jdf.get("tcs", 0), errors="coerce").fillna(0)
        jdf["tcs_bucket"] = pd.cut(
            jdf["tcs"],
            bins=[0, 40, 55, 65, 75, 101],
            labels=["<40", "40–54", "55–64", "65–74", "75+"],
        )
        jdf["timestamp"] = pd.to_datetime(jdf.get("timestamp", ""), errors="coerce")
        merged = pd.merge(
            jdf[["timestamp", "ticker", "tcs", "tcs_bucket"]],
            trades[["timestamp", "symbol", "mfe"]],
            left_on="ticker", right_on="symbol", how="inner",
            suffixes=("_j", "_t"),
        )
        if not merged.empty:
            tcs_rows = []
            for bkt, grp in merged.groupby("tcs_bucket", observed=True):
                tc = len(grp); wc = int((grp["mfe"] > 0).sum())
                tcs_rows.append({
                    "tcs_bucket": str(bkt),
                    "trades":     tc,
                    "win_rate":   round(wc / tc * 100, 1) if tc else 0.0,
                })
            tcs_edge = pd.DataFrame(tcs_rows)

    # ── Grade distribution ──────────────────────────────────────────────────
    grade_dist = {}
    if not journal_df.empty and "grade" in journal_df.columns:
        grade_dist = {str(k): int(v)
                      for k, v in journal_df["grade"].value_counts().items()}

    return {
        "summary": {
            "win_rate": win_rate, "total_pnl": total_pnl,
            "avg_win": avg_win,   "avg_loss": avg_loss,
            "profit_factor": profit_factor,
            "total_trades": total_trades, "trade_days": trade_days,
        },
        "equity_curve":       equity_curve,
        "daily_pnl":          daily,
        "win_rate_by_struct": wr_struct,
        "grade_distribution": grade_dist,
        "tcs_edge":           tcs_edge,
    }


# ── Live Playbook Screener ──────────────────────────────────────────────────────
def scan_playbook(api_key: str, secret_key: str, top: int = 50) -> tuple:
    """Scan Alpaca for today's most-active and top-gaining small-cap stocks ($2–$20).

    Returns
    -------
    (rows: list[dict], error: str)
        rows — sorted by % change descending; each dict has:
            ticker, price, change_pct, volume, source
        error — non-empty string only if *both* endpoints fail
    """
    if not api_key or not secret_key:
        return [], "No API credentials provided."

    headers = {
        "APCA-API-KEY-ID":     api_key,
        "APCA-API-SECRET-KEY": secret_key,
        "accept":              "application/json",
    }
    base   = "https://data.alpaca.markets/v1beta1/screener/stocks"
    pool   = {}
    errors = []

    # ── Most Actives ─────────────────────────────────────────────────────────
    try:
        r = requests.get(
            f"{base}/most-actives",
            params={"by": "volume", "top": top},
            headers=headers,
            timeout=10,
        )
        if r.status_code == 200:
            for item in r.json().get("most_actives", []):
                sym        = str(item.get("symbol", "")).upper()
                price      = float(item.get("price", 0) or 0)
                change_pct = float(item.get("percent_change", 0) or 0)
                volume     = int(item.get("volume", 0) or 0)
                if sym and 2.0 <= price <= 20.0:
                    pool[sym] = {
                        "ticker":     sym,
                        "price":      price,
                        "change_pct": change_pct,
                        "volume":     volume,
                        "source":     "Active",
                    }
        else:
            errors.append(f"most-actives HTTP {r.status_code}")
    except Exception as exc:
        errors.append(f"most-actives: {exc}")

    # ── Top Gainers ───────────────────────────────────────────────────────────
    try:
        r = requests.get(
            f"{base}/movers",
            params={"top": top},
            headers=headers,
            timeout=10,
        )
        if r.status_code == 200:
            for item in r.json().get("gainers", []):
                sym        = str(item.get("symbol", "")).upper()
                price      = float(item.get("price", 0) or 0)
                change_pct = float(item.get("percent_change", 0) or 0)
                volume     = int(item.get("volume", 0) or 0)
                if sym and 2.0 <= price <= 20.0:
                    if sym in pool:
                        pool[sym]["source"] = "Active + Gainer"
                    else:
                        pool[sym] = {
                            "ticker":     sym,
                            "price":      price,
                            "change_pct": change_pct,
                            "volume":     volume,
                            "source":     "Gainer",
                        }
        else:
            errors.append(f"movers HTTP {r.status_code}")
    except Exception as exc:
        errors.append(f"movers: {exc}")

    rows = sorted(pool.values(), key=lambda x: x["change_pct"], reverse=True)
    err  = "; ".join(errors) if (errors and not rows) else ""
    return rows, err


# ── Historical Backtester ───────────────────────────────────────────────────────
_BACKTEST_DIRECTIONAL  = ("Trend", "Nrml Var", "Normal Var")
_BACKTEST_RANGE        = ("Non-Trend", "Non Trend")
_BACKTEST_NEUTRAL_EXT  = ("Ntrl Extreme", "Neutral Extreme")  # high-vol: any break wins
_BACKTEST_BALANCED     = ("Neutral",)                          # pure balanced: needs both sides
_BACKTEST_BIMODAL      = ("Dbl Dist", "Double")
_BACKTEST_NORMAL       = ("Normal",)   # Normal (not Var) — range-ish


def _backtest_single(api_key: str, secret_key: str, sym: str,
                     trade_date, feed: str, price_min: float, price_max: float,
                     cutoff_hour: int = 10, cutoff_minute: int = 30):
    """Fetch one ticker's historical bars, score the morning, evaluate the afternoon.

    Returns a result dict or None if data is insufficient / out of price range.
    """
    try:
        df = fetch_bars(api_key, secret_key, sym, trade_date, feed=feed)
        if df.empty or len(df) < 10:
            return None

        # Price range gate: use first bar open price
        open_px = float(df["open"].iloc[0])
        if not (price_min <= open_px <= price_max):
            return None

        # Split at prediction cutoff (IB always 9:30–10:30; engine sees up to cutoff)
        ib_cutoff = df.index[0].replace(hour=cutoff_hour, minute=cutoff_minute, second=0)
        pm_df  = df[df.index <= ib_cutoff]   # engine input (9:30 → cutoff)
        aft_df = df[df.index > ib_cutoff]    # actual outcome (cutoff → 4:00 PM)

        if len(pm_df) < 5 or len(aft_df) < 5:
            return None

        # Morning engine run
        ib_high, ib_low = compute_initial_balance(pm_df)
        if not ib_high or not ib_low:
            return None

        bin_centers, vap, poc_price = compute_volume_profile(pm_df, num_bins=30)
        tcs   = float(compute_tcs(pm_df, ib_high, ib_low, poc_price))
        probs = compute_structure_probabilities(
            pm_df, bin_centers, vap, ib_high, ib_low, poc_price
        )
        predicted = max(probs, key=probs.get) if probs else "—"
        confidence = round(probs.get(predicted, 0.0), 1)

        # Afternoon reality
        aft_high = float(aft_df["high"].max())
        aft_low  = float(aft_df["low"].min())
        close_px = float(aft_df["close"].iloc[-1])

        broke_up   = aft_high > ib_high
        broke_down = aft_low  < ib_low

        if broke_up and broke_down:
            actual_outcome = "Both Sides"
            actual_icon    = "↕"
        elif broke_up:
            actual_outcome = "Bullish Break"
            actual_icon    = "↑"
        elif broke_down:
            actual_outcome = "Bearish Break"
            actual_icon    = "↓"
        else:
            actual_outcome = "Range-Bound"
            actual_icon    = "—"

        # Win/Loss: does predicted category match actual outcome?
        is_dir      = any(k in predicted for k in _BACKTEST_DIRECTIONAL)
        is_range    = any(k in predicted for k in _BACKTEST_RANGE)
        is_neut_ext = any(k in predicted for k in _BACKTEST_NEUTRAL_EXT)
        is_balanced = (not is_neut_ext and
                       any(k in predicted for k in _BACKTEST_BALANCED))
        is_bimodal  = any(k in predicted for k in _BACKTEST_BIMODAL)
        is_normal   = (not is_dir and not is_range and not is_neut_ext
                       and not is_balanced and not is_bimodal
                       and "Normal" in predicted)

        if is_dir:
            # Trend / Nrml Var → one side breaks in any direction
            win = actual_outcome in ("Bullish Break", "Bearish Break")
        elif is_neut_ext:
            # Ntrl Extreme → high-vol structure: any IB break counts as win
            win = actual_outcome in ("Bullish Break", "Bearish Break", "Both Sides")
        elif is_range or is_normal:
            # Non-Trend / Normal → price stayed inside IB
            win = actual_outcome == "Range-Bound"
        elif is_balanced:
            # Pure Neutral → balanced two-sided day
            win = actual_outcome in ("Both Sides", "Bullish Break", "Bearish Break")
        elif is_bimodal:
            # Dbl Dist → any break away from low-volume node
            win = actual_outcome in ("Bullish Break", "Bearish Break", "Both Sides")
        else:
            win = False

        # Follow-through % = how far price ran from the broken IB boundary
        # to the best post-IB point (afternoon high or low).
        # Bullish break  → (afternoon_high  − ib_high) / ib_high
        # Bearish break  → (ib_low − afternoon_low)   / ib_low
        # Both sides     → larger of the two
        # Range-bound    → 0  (never broke)
        if broke_up and broke_down:
            _ft_up   = (aft_high - ib_high) / ib_high * 100
            _ft_down = (ib_low   - aft_low)  / ib_low  * 100
            aft_move = _ft_up if _ft_up >= _ft_down else -_ft_down
        elif broke_up:
            aft_move = (aft_high - ib_high) / ib_high * 100
        elif broke_down:
            aft_move = -((ib_low - aft_low) / ib_low * 100)
        else:
            aft_move = 0.0

        # ── False break detection ────────────────────────────────────────────────
        # A false break = IB violated but price closed back inside within 30 min
        # (6 × 5-min bars). This is the classic "shake & bake" reversal trap.
        _aft_r = aft_df.reset_index()
        false_break_up   = False
        false_break_down = False
        if broke_up:
            _up_bars = _aft_r[_aft_r["high"] > ib_high]
            if not _up_bars.empty:
                _fi = _up_bars.index[0]
                _w  = _aft_r.loc[_fi : _fi + 6]
                false_break_up = bool((_w["close"] < ib_high).any())
        if broke_down:
            _dn_bars = _aft_r[_aft_r["low"] < ib_low]
            if not _dn_bars.empty:
                _fi = _dn_bars.index[0]
                _w  = _aft_r.loc[_fi : _fi + 6]
                false_break_down = bool((_w["close"] > ib_low).any())

        return {
            "ticker":           sym,
            "open_price":       round(open_px, 2),
            "ib_high":          round(ib_high, 2),
            "ib_low":           round(ib_low, 2),
            "tcs":              round(tcs, 1),
            "predicted":        predicted,
            "confidence":       confidence,
            "actual_outcome":   actual_outcome,
            "actual_icon":      actual_icon,
            "close_price":      round(close_px, 2),
            "aft_move_pct":     round(aft_move, 2),
            "win_loss":         "Win" if win else "Loss",
            "false_break_up":   false_break_up,
            "false_break_down": false_break_down,
        }
    except Exception:
        return None


def run_historical_backtest(
    api_key: str, secret_key: str,
    trade_date,
    tickers: list,
    feed: str = "sip",
    price_min: float = 2.0,
    price_max: float = 20.0,
    cutoff_hour: int = 10,
    cutoff_minute: int = 30,
) -> tuple:
    """Run the quant engine on morning-only historical data and score against afternoon.

    Returns (results: list[dict], summary: dict).
    Results are sorted by TCS descending.
    """
    if not tickers:
        return [], {"error": "No tickers provided."}
    if not api_key or not secret_key:
        return [], {"error": "Alpaca credentials missing."}

    results = []
    with ThreadPoolExecutor(max_workers=min(10, len(tickers))) as executor:
        futures = {
            executor.submit(
                _backtest_single, api_key, secret_key, sym,
                trade_date, feed, price_min, price_max,
                cutoff_hour, cutoff_minute
            ): sym
            for sym in tickers
        }
        for future in as_completed(futures):
            r = future.result()
            if r is not None:
                results.append(r)

    if not results:
        return [], {"error": "No valid data returned. Check tickers and date (market must have been open)."}

    results.sort(key=lambda x: x["tcs"], reverse=True)

    wins     = sum(1 for r in results if r["win_loss"] == "Win")
    losses   = len(results) - wins
    win_rate = round(wins / len(results) * 100, 1) if results else 0.0

    # Directional breakdown — independent of structure prediction accuracy
    bull_rows  = [r for r in results if r["actual_outcome"] == "Bullish Break"]
    bear_rows  = [r for r in results if r["actual_outcome"] == "Bearish Break"]
    both_rows  = [r for r in results if r["actual_outcome"] == "Both Sides"]
    range_rows = [r for r in results if r["actual_outcome"] == "Range-Bound"]

    avg_bull_ft = (round(sum(r["aft_move_pct"] for r in bull_rows) / len(bull_rows), 1)
                   if bull_rows else 0.0)
    avg_bear_ft = (round(sum(abs(r["aft_move_pct"]) for r in bear_rows) / len(bear_rows), 1)
                   if bear_rows else 0.0)

    long_win_rate = round(len(bull_rows) / len(results) * 100, 1) if results else 0.0

    # False break stats
    fb_up   = [r for r in results if r.get("false_break_up")]
    fb_down = [r for r in results if r.get("false_break_down")]
    _breakable = len(bull_rows) + len(bear_rows) + len(both_rows)
    false_break_rate = (round((len(fb_up) + len(fb_down)) / _breakable * 100, 1)
                        if _breakable else 0.0)

    summary = {
        "win_rate":         win_rate,
        "total":            len(results),
        "wins":             wins,
        "losses":           losses,
        "highest_tcs":      round(max(r["tcs"] for r in results), 1),
        "avg_tcs":          round(sum(r["tcs"] for r in results) / len(results), 1),
        "bull_breaks":      len(bull_rows),
        "bear_breaks":      len(bear_rows),
        "both_breaks":      len(both_rows),
        "range_bound":      len(range_rows),
        "avg_bull_ft":      avg_bull_ft,
        "avg_bear_ft":      avg_bear_ft,
        "long_win_rate":    long_win_rate,
        "false_break_rate": false_break_rate,
        "fb_up_count":      len(fb_up),
        "fb_down_count":    len(fb_down),
    }
    return results, summary


def run_backtest_range(
    api_key: str, secret_key: str,
    start_date, end_date,
    tickers: list,
    feed: str = "sip",
    price_min: float = 2.0,
    price_max: float = 20.0,
) -> tuple:
    """Run the backtest across a date range (max 22 weekdays ≈ 1 month).

    Returns (all_results, agg_summary, daily_list) where:
    - all_results   : flat list of every row with 'sim_date' added
    - agg_summary   : aggregate stats across all days
    - daily_list    : [(date, results, summary), ...] one entry per trading day
    """
    # Collect weekdays in range, cap at 22 (~1 calendar month)
    trading_days = []
    cur = start_date
    while cur <= end_date and len(trading_days) < 22:
        if cur.weekday() < 5:
            trading_days.append(cur)
        cur += timedelta(days=1)

    if not trading_days:
        return [], {"error": "No trading days in selected range."}, []

    daily_list = []
    for d in trading_days:
        r, s = run_historical_backtest(
            api_key, secret_key, d, tickers, feed, price_min, price_max
        )
        if not s.get("error") and r:
            for row in r:
                row["sim_date"] = str(d)
            daily_list.append((d, r, s))

    if not daily_list:
        return [], {"error": "No valid data for any date in range."}, []

    all_results = []
    for _, r, _ in daily_list:
        all_results.extend(r)

    total = len(all_results)
    wins  = sum(1 for r in all_results if r["win_loss"] == "Win")

    bull_rows  = [r for r in all_results if r["actual_outcome"] == "Bullish Break"]
    bear_rows  = [r for r in all_results if r["actual_outcome"] == "Bearish Break"]
    both_rows  = [r for r in all_results if r["actual_outcome"] == "Both Sides"]
    range_rows = [r for r in all_results if r["actual_outcome"] == "Range-Bound"]
    fb_up      = [r for r in all_results if r.get("false_break_up")]
    fb_down    = [r for r in all_results if r.get("false_break_down")]

    _breakable    = len(bull_rows) + len(bear_rows) + len(both_rows)
    avg_bull_ft   = (round(sum(r["aft_move_pct"] for r in bull_rows) / len(bull_rows), 1)
                     if bull_rows else 0.0)
    avg_bear_ft   = (round(sum(abs(r["aft_move_pct"]) for r in bear_rows) / len(bear_rows), 1)
                     if bear_rows else 0.0)
    false_brk_rt  = (round((len(fb_up) + len(fb_down)) / _breakable * 100, 1)
                     if _breakable else 0.0)

    agg_summary = {
        "win_rate":         round(wins / total * 100, 1) if total else 0.0,
        "total":            total,
        "wins":             wins,
        "losses":           total - wins,
        "highest_tcs":      round(max(r["tcs"] for r in all_results), 1),
        "avg_tcs":          round(sum(r["tcs"] for r in all_results) / total, 1),
        "bull_breaks":      len(bull_rows),
        "bear_breaks":      len(bear_rows),
        "both_breaks":      len(both_rows),
        "range_bound":      len(range_rows),
        "avg_bull_ft":      avg_bull_ft,
        "avg_bear_ft":      avg_bear_ft,
        "long_win_rate":    round(len(bull_rows) / total * 100, 1) if total else 0.0,
        "false_break_rate": false_brk_rt,
        "fb_up_count":      len(fb_up),
        "fb_down_count":    len(fb_down),
        "days_run":         len(daily_list),
    }
    return all_results, agg_summary, daily_list


# ── Backtest Supabase persistence ────────────────────────────────────────────
def save_backtest_sim_runs(rows: list, user_id: str = ""):
    """Batch-insert backtest simulation rows to Supabase."""
    if not supabase or not rows:
        return
    try:
        records = [
            {
                "user_id":        user_id or "",
                "sim_date":       str(r.get("sim_date", "")),
                "ticker":         r.get("ticker", ""),
                "open_price":     r.get("open_price"),
                "ib_low":         r.get("ib_low"),
                "ib_high":        r.get("ib_high"),
                "tcs":            r.get("tcs"),
                "predicted":      r.get("predicted", ""),
                "actual_outcome": r.get("actual_outcome", ""),
                "win_loss":       r.get("win_loss", ""),
                "follow_thru_pct": r.get("aft_move_pct"),
                "false_break_up":   bool(r.get("false_break_up", False)),
                "false_break_down": bool(r.get("false_break_down", False)),
            }
            for r in rows
        ]
        supabase.table("backtest_sim_runs").insert(records).execute()
    except Exception as e:
        print(f"Backtest save error: {e}")


def load_backtest_sim_history(user_id: str = "") -> "pd.DataFrame":
    """Load saved backtest runs from Supabase (most recent first, up to 1000 rows)."""
    if not supabase:
        return pd.DataFrame()
    try:
        q = supabase.table("backtest_sim_runs").select("*")
        if user_id:
            q = q.eq("user_id", user_id)
        data = q.order("sim_date", desc=True).limit(1000).execute().data
        return pd.DataFrame(data) if data else pd.DataFrame()
    except Exception as e:
        print(f"Backtest load error: {e}")
        return pd.DataFrame()


# ── Playbook Quant Scoring ──────────────────────────────────────────────────────
def _score_single_ticker(api_key: str, secret_key: str, sym: str,
                         trade_date, feed: str = "iex"):
    """Fetch intraday bars for one ticker and return (sym, tcs, top_structure, struct_conf).

    Returns (sym, None, None, 0.0) on any data or calculation failure.
    struct_conf = probability (0–100) of the top structure prediction.
    """
    try:
        df = fetch_bars(api_key, secret_key, sym, trade_date, feed=feed)
        if df.empty or len(df) < 5:
            return sym, None, None, 0.0

        ib_high, ib_low = compute_initial_balance(df)
        if not ib_high or not ib_low:
            ib_high = float(df["high"].max())
            ib_low  = float(df["low"].min())

        bin_centers, vap, poc_price = compute_volume_profile(df, num_bins=50)
        tcs   = compute_tcs(df, ib_high, ib_low, poc_price)
        probs = compute_structure_probabilities(
            df, bin_centers, vap, ib_high, ib_low, poc_price
        )
        top_struct  = max(probs, key=probs.get) if probs else "—"
        struct_conf = round(float(probs.get(top_struct, 0.0)), 1) if probs else 0.0
        return sym, round(float(tcs), 1), top_struct, struct_conf
    except Exception:
        return sym, None, None, 0.0


# ── Discord Alert Engine ─────────────────────────────────────────────────────
_discord_alert_cache: dict = {}   # {ticker_YYYY-MM-DD: timestamp_float}


def send_discord_alert(
    webhook_url: str,
    ticker: str,
    price: float,
    rvol: float,
    tcs: float,
    structure: str,
    edge_score: float = 0.0,
) -> bool:
    """Send a high-conviction signal embed to a Discord webhook.

    Returns True on success, False on failure or if the webhook URL is blank.
    Callers should check the per-day de-dup cache before calling this.
    """
    if not webhook_url or not webhook_url.startswith("http"):
        return False

    rvol_str   = f"{rvol:.1f}x" if rvol else "—"
    price_str  = f"${price:.2f}" if price else "—"
    tcs_bar    = "🟩" * int(tcs // 20) + "⬜" * (5 - int(tcs // 20))
    edge_color = 0x4CAF50 if edge_score >= 85 else (0xFFA726 if edge_score >= 75 else 0x90CAF9)

    payload = {
        "username": "VolumeProfile Bot",
        "avatar_url": "https://cdn-icons-png.flaticon.com/512/2172/2172832.png",
        "embeds": [
            {
                "title": f"🚀 HIGH CONVICTION SIGNAL — ${ticker}",
                "color": edge_color,
                "fields": [
                    {"name": "💰 Price",       "value": price_str,           "inline": True},
                    {"name": "📊 TCS",         "value": f"{tcs:.0f}/100 {tcs_bar}", "inline": True},
                    {"name": "⚡ Edge Score",  "value": f"{edge_score:.0f}/100",    "inline": True},
                    {"name": "🔥 RVOL",        "value": rvol_str,            "inline": True},
                    {"name": "🏗️ Structure",   "value": structure or "—",    "inline": True},
                    {"name": "📅 Date",        "value": date.today().strftime("%b %d, %Y"), "inline": True},
                ],
                "footer": {"text": "Volume Profile Terminal · Auto-Alert"},
            }
        ],
    }
    try:
        resp = requests.post(webhook_url, json=payload, timeout=5)
        return resp.status_code in (200, 204)
    except Exception:
        return False


def _maybe_discord_alert(
    webhook_url: str,
    ticker: str,
    price: float,
    rvol: float,
    tcs: float,
    structure: str,
    edge_score: float,
) -> None:
    """Fire a Discord alert for this ticker if it hasn't been alerted today."""
    if not webhook_url:
        return
    cache_key = f"{ticker}_{date.today().isoformat()}"
    if cache_key in _discord_alert_cache:
        return
    success = send_discord_alert(
        webhook_url=webhook_url,
        ticker=ticker,
        price=price,
        rvol=rvol,
        tcs=tcs,
        structure=structure,
        edge_score=edge_score,
    )
    if success:
        _discord_alert_cache[cache_key] = True
        # Prune old keys (keep only today's entries)
        today = date.today().isoformat()
        stale = [k for k in list(_discord_alert_cache) if not k.endswith(today)]
        for k in stale:
            _discord_alert_cache.pop(k, None)


def score_playbook_tickers(rows: list, api_key: str, secret_key: str,
                           feed: str = "iex", max_tickers: int = 20,
                           user_id: str = "",
                           discord_webhook_url: str = "") -> list:
    """Enrich Playbook rows with TCS, structure, and self-calibrating Edge Score.

    Edge Score (0–100) combines TCS, structure confidence, recent market
    environment, and false break rate — weights auto-calibrate from saved
    backtest history.
    """
    if not rows or not api_key or not secret_key:
        for row in rows:
            row.setdefault("tcs", None)
            row.setdefault("structure", "—")
            row.setdefault("edge_score", None)
        return rows

    # Pre-load adaptive weights + environment stats once for the whole batch
    weights  = compute_adaptive_weights(user_id)
    env_stat = get_recent_env_stats(user_id, days=5)

    # Roll back to most recent trading weekday (Mon=0 … Fri=4)
    trade_date = date.today()
    while trade_date.weekday() >= 5:          # 5=Sat, 6=Sun
        trade_date -= timedelta(days=1)

    subset = rows[:max_tickers]
    scored: dict = {}

    with ThreadPoolExecutor(max_workers=min(8, len(subset))) as executor:
        future_map = {
            executor.submit(
                _score_single_ticker, api_key, secret_key,
                r["ticker"], trade_date, feed
            ): r["ticker"]
            for r in subset
        }
        for future in as_completed(future_map):
            sym, tcs, structure, struct_conf = future.result()
            scored[sym] = (tcs, structure if structure else "—", struct_conf)

    for row in rows:
        sym = row["ticker"]
        if sym in scored:
            tcs, structure, struct_conf = scored[sym]
            row["tcs"]         = tcs
            row["structure"]   = structure
            row["struct_conf"] = struct_conf
            if tcs is not None:
                edge, breakdown = compute_edge_score(
                    tcs=tcs,
                    structure_conf=struct_conf,
                    env_long_rate=env_stat["long_rate"],
                    recent_false_brk_rate=env_stat["false_brk_rate"],
                    weights=weights,
                )
                row["edge_score"]     = edge
                row["edge_breakdown"] = breakdown
                # ── Discord alert: TCS ≥ 80 and Edge Score ≥ 75 ──────────────
                if discord_webhook_url and tcs >= 80 and edge >= 75:
                    _maybe_discord_alert(
                        webhook_url=discord_webhook_url,
                        ticker=sym,
                        price=float(row.get("price") or 0),
                        rvol=float(row.get("rvol") or 0),
                        tcs=tcs,
                        structure=structure,
                        edge_score=edge,
                    )
            else:
                row["edge_score"]     = None
                row["edge_breakdown"] = {}
        else:
            row["tcs"]         = None
            row["structure"]   = "—"
            row["struct_conf"] = 0.0
            row["edge_score"]  = None
            row["edge_breakdown"] = {}

    # Sort by edge score descending (None last)
    rows.sort(key=lambda r: r.get("edge_score") or -1, reverse=True)
    return rows


# ── Self-Calibrating Edge Score Engine ──────────────────────────────────────
_DEFAULT_EDGE_WEIGHTS = {
    "tcs":         0.35,
    "structure":   0.25,
    "environment": 0.25,
    "false_break": 0.15,
}


def compute_adaptive_weights(user_id: str = "") -> dict:
    """Load backtest history and compute data-calibrated signal weights.

    Requires at least 15 saved rows to calibrate. Falls back to defaults
    if there is insufficient data or Supabase is unavailable.

    Returns a dict with keys: tcs, structure, environment, false_break,
    rows_used (int), calibrated (bool).
    """
    df = load_backtest_sim_history(user_id)
    if df.empty:
        return {**_DEFAULT_EDGE_WEIGHTS, "rows_used": 0, "calibrated": False}

    try:
        # Deduplicate: keep only the most recent run for each (ticker, sim_date) pair
        # so replaying the same backtest day doesn't skew the weights
        df["sim_date"] = pd.to_datetime(df.get("sim_date", pd.NaT), errors="coerce")
        if "ticker" in df.columns and "sim_date" in df.columns:
            df = (df.sort_values("created_at", errors="ignore")
                    .drop_duplicates(subset=["ticker", "sim_date"], keep="last")
                    .reset_index(drop=True))

        if len(df) < 15:
            return {**_DEFAULT_EDGE_WEIGHTS, "rows_used": len(df), "calibrated": False}

        df["win_bin"] = (df["win_loss"] == "Win").astype(float)
        df["tcs_num"] = pd.to_numeric(df["tcs"], errors="coerce").fillna(0)

        # TCS correlation with wins (Pearson)
        tcs_corr = float(df["tcs_num"].corr(df["win_bin"]))
        if pd.isna(tcs_corr):
            tcs_corr = 0.0
        # Shift base weight by correlation signal, clamp to [0.15, 0.55]
        tcs_w = max(0.15, min(0.55, 0.35 + tcs_corr * 0.25))

        # Structure reliability: how well has the model been winning overall?
        overall_wr = float(df["win_bin"].mean())
        # Higher overall win rate → structure predictions are reliable → weight more
        struct_w = max(0.10, min(0.40, 0.25 + (overall_wr - 0.50) * 0.30))

        # Remaining weight split 60/40 between environment and false break
        remaining = max(0.10, 1.0 - tcs_w - struct_w)
        env_w = round(remaining * 0.60, 3)
        fb_w  = round(remaining * 0.40, 3)

        return {
            "tcs":         round(tcs_w, 3),
            "structure":   round(struct_w, 3),
            "environment": env_w,
            "false_break": fb_w,
            "rows_used":   len(df),
            "calibrated":  True,
        }
    except Exception:
        return {**_DEFAULT_EDGE_WEIGHTS, "rows_used": len(df), "calibrated": False}


def get_recent_env_stats(user_id: str = "", days: int = 5) -> dict:
    """Get recent market environment stats from saved backtest history.

    Returns dict with:
    - long_rate (float 0–100): % of recent setups that went bullish
    - false_brk_rate (float 0–100): % of IB breaks that reversed within 30 min
    - rows_used (int): how many rows were used
    """
    df = load_backtest_sim_history(user_id)
    if df.empty:
        return {"long_rate": 50.0, "false_brk_rate": 0.0, "rows_used": 0}

    try:
        df["sim_date"] = pd.to_datetime(df["sim_date"], errors="coerce")
        # Deduplicate replays: one row per (ticker, sim_date), most recent run
        if "ticker" in df.columns and "sim_date" in df.columns:
            df = (df.sort_values("created_at", errors="ignore")
                    .drop_duplicates(subset=["ticker", "sim_date"], keep="last")
                    .reset_index(drop=True))
        cutoff = pd.Timestamp.now(tz="UTC").tz_localize(None) - pd.Timedelta(days=days)
        recent = df[df["sim_date"] >= cutoff]
        if len(recent) < 10:
            recent = df.tail(50)   # fallback: last 50 rows regardless of date

        bull  = (recent["actual_outcome"] == "Bullish Break").sum()
        total = len(recent)
        long_rate = round(float(bull) / total * 100, 1) if total else 50.0

        fb_up   = recent["false_break_up"].fillna(False).astype(bool).sum()
        fb_down = recent["false_break_down"].fillna(False).astype(bool).sum()
        breakable = int((recent["actual_outcome"] != "Range-Bound").sum())
        false_brk_rate = (round((int(fb_up) + int(fb_down)) / breakable * 100, 1)
                          if breakable else 0.0)

        return {
            "long_rate":      long_rate,
            "false_brk_rate": false_brk_rate,
            "rows_used":      total,
        }
    except Exception:
        return {"long_rate": 50.0, "false_brk_rate": 0.0, "rows_used": 0}


def compute_edge_score(
    tcs: float,
    structure_conf: float,
    env_long_rate: float,
    recent_false_brk_rate: float,
    weights: dict,
) -> tuple:
    """Compute a composite 0–100 Edge Score for a live setup.

    Returns (score: float, breakdown: dict).

    Inputs (all 0–100):
    - tcs                  : TCS momentum score
    - structure_conf       : model's confidence in its top structure pick
    - env_long_rate        : % of recent setups that went bullish (market environment)
    - recent_false_brk_rate: % of recent IB breaks that faked out (lower = cleaner tape)
    """
    w = weights

    tcs_pts    = min(100.0, max(0.0, tcs))            * w.get("tcs",         0.35)
    struct_pts = min(100.0, max(0.0, structure_conf))  * w.get("structure",   0.25)
    env_pts    = min(100.0, max(0.0, env_long_rate))   * w.get("environment", 0.25)
    fb_clean   = max(0.0, 100.0 - recent_false_brk_rate)
    fb_pts     = fb_clean                              * w.get("false_break", 0.15)

    score = round(min(100.0, tcs_pts + struct_pts + env_pts + fb_pts), 1)
    return score, {
        "tcs_pts":    round(tcs_pts,    1),
        "struct_pts": round(struct_pts, 1),
        "env_pts":    round(env_pts,    1),
        "fb_pts":     round(fb_pts,     1),
        "total":      score,
    }


# ── Backtest Structure Analytics ─────────────────────────────────────────────
def compute_backtest_structure_stats(user_id: str = "") -> "pd.DataFrame":
    """Compute win rate, avg follow-through, and false break rate by structure type.

    Uses saved backtest_sim_runs (deduplicated by ticker+date) so the stats
    reflect unique setups only, not replay noise.

    Returns a DataFrame with columns:
      structure, trades, wins, win_rate, avg_follow_thru, false_brk_rate
    Sorted by win_rate descending.
    """
    df = load_backtest_sim_history(user_id)
    if df.empty:
        return pd.DataFrame(columns=[
            "structure", "trades", "wins", "win_rate", "avg_follow_thru", "false_brk_rate"
        ])

    try:
        df["sim_date"] = pd.to_datetime(df.get("sim_date", pd.NaT), errors="coerce")
        if "ticker" in df.columns and "sim_date" in df.columns:
            df = (df.sort_values("created_at", errors="ignore")
                    .drop_duplicates(subset=["ticker", "sim_date"], keep="last")
                    .reset_index(drop=True))

        if "predicted_structure" not in df.columns:
            return pd.DataFrame()

        df["win_bin"]   = (df["win_loss"] == "Win").astype(int)
        df["ft_num"]    = pd.to_numeric(df.get("follow_thru_pct", pd.Series(dtype=float)),
                                        errors="coerce")
        fb_up   = df.get("false_break_up",   pd.Series([False] * len(df))).fillna(False).astype(bool)
        fb_down = df.get("false_break_down",  pd.Series([False] * len(df))).fillna(False).astype(bool)
        df["false_brk"] = (fb_up | fb_down).astype(int)

        grp = df.groupby("predicted_structure", as_index=False).agg(
            trades        = ("win_bin",    "count"),
            wins          = ("win_bin",    "sum"),
            avg_follow_thru = ("ft_num",  lambda x: round(x.mean(), 2) if x.notna().any() else 0.0),
            false_brks    = ("false_brk", "sum"),
        )
        grp["win_rate"]       = (grp["wins"] / grp["trades"] * 100).round(1)
        grp["false_brk_rate"] = (grp["false_brks"] / grp["trades"] * 100).round(1)
        grp = grp.rename(columns={"predicted_structure": "structure"})
        grp = grp.sort_values("win_rate", ascending=False).reset_index(drop=True)
        return grp[["structure", "trades", "wins", "win_rate", "avg_follow_thru", "false_brk_rate"]]
    except Exception:
        return pd.DataFrame()


# ── Watchlist Persistence ─────────────────────────────────────────────────────
def save_watchlist(tickers: list, user_id: str = "") -> bool:
    """Upsert a user's custom watchlist to Supabase (table: user_watchlist).

    Stores one row per user with a JSON-encoded list of tickers.
    Returns True on success, False on failure.
    """
    if not supabase:
        return False
    try:
        import json as _json
        payload = {
            "user_id":   user_id or "anonymous",
            "tickers":   _json.dumps([t.strip().upper() for t in tickers if t.strip()]),
            "updated_at": datetime.utcnow().isoformat(),
        }
        supabase.table("user_watchlist").upsert(payload, on_conflict="user_id").execute()
        return True
    except Exception:
        return False


def load_watchlist(user_id: str = "") -> list:
    """Load a user's saved watchlist from Supabase.

    Returns a list of ticker strings, or [] if not found / table missing.
    """
    if not supabase:
        return []
    try:
        import json as _json
        uid = user_id or "anonymous"
        res = (supabase.table("user_watchlist")
               .select("tickers")
               .eq("user_id", uid)
               .limit(1)
               .execute())
        if res.data:
            raw = res.data[0].get("tickers", "[]")
            return _json.loads(raw) if isinstance(raw, str) else list(raw)
        return []
    except Exception:
        return []


# ── God Mode — Live Trade Execution ──────────────────────────────────────────

def execute_alpaca_trade(
    api_key: str,
    secret_key: str,
    is_paper: bool,
    ticker: str,
    qty: int,
    side: str,
    limit_price: float = None,
) -> dict:
    """Submit a live or paper trade to Alpaca.

    Parameters
    ----------
    api_key, secret_key : Alpaca credentials entered in the sidebar.
    is_paper            : True  → paper trading endpoint
                          False → live trading endpoint
    ticker              : Stock symbol, e.g. 'GME'
    qty                 : Number of shares (whole shares only)
    side                : 'buy' or 'sell'
    limit_price         : If provided, submits a Day Limit order;
                          otherwise submits a Market order.

    Returns
    -------
    dict with keys:
        success  (bool)
        order_id (str)   — Alpaca order UUID on success
        message  (str)   — human-readable confirmation or error detail
    """
    if not api_key or not secret_key:
        return {"success": False, "order_id": None,
                "message": "No API credentials — enter your Alpaca key and secret in the sidebar."}
    if qty <= 0:
        return {"success": False, "order_id": None,
                "message": "Quantity must be at least 1 share."}
    if side not in ("buy", "sell"):
        return {"success": False, "order_id": None,
                "message": f"Invalid side '{side}' — must be 'buy' or 'sell'."}

    try:
        from alpaca.trading.client import TradingClient
        from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest
        from alpaca.trading.enums import OrderSide, TimeInForce

        client = TradingClient(api_key, secret_key, paper=is_paper)

        order_side = OrderSide.BUY if side == "buy" else OrderSide.SELL

        if limit_price is not None and limit_price > 0:
            req = LimitOrderRequest(
                symbol=ticker.upper(),
                qty=qty,
                side=order_side,
                time_in_force=TimeInForce.DAY,
                limit_price=round(float(limit_price), 2),
            )
            order_type_label = f"LIMIT @ ${limit_price:.2f}"
        else:
            req = MarketOrderRequest(
                symbol=ticker.upper(),
                qty=qty,
                side=order_side,
                time_in_force=TimeInForce.DAY,
            )
            order_type_label = "MARKET"

        order = client.submit_order(req)
        env_label = "PAPER" if is_paper else "LIVE"
        return {
            "success":  True,
            "order_id": str(order.id),
            "message":  (
                f"✅ {env_label} {side.upper()} {qty} {ticker.upper()} "
                f"({order_type_label}) submitted. "
                f"Order ID: {order.id} · Status: {order.status}"
            ),
        }

    except Exception as exc:
        return {"success": False, "order_id": None, "message": f"Alpaca error: {exc}"}


