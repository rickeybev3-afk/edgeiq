import streamlit as st
import pandas as pd
import plotly.graph_objects as go
from plotly.subplots import make_subplots
from datetime import datetime, date, timedelta, time as dtime
import time
import pytz
import os

from backend import *
from backend import (
    _compute_value_area, _strip_emoji,
    _parse_batch_pairs, _RECALIBRATE_EVERY, _BRAIN_WEIGHT_KEYS,
    _JOURNAL_COLS, _find_peaks, _is_strong_hvn, _detect_double_distribution,
    _label_to_weight_key, _save_brain_weights, _stream_worker, _GRADE_COLORS, _GRADE_SCORE,
    _compress_image_b64,
    _edge_band, _rvol_band,
    save_signal_conditions, log_signal_outcome, get_predictive_context,
    compute_win_rates, monte_carlo_equity_curves,
    compute_order_flow_signals,
    load_watchlist,
    get_next_trading_day,
    detect_chart_patterns,
    parse_webull_csv,
    compute_journal_model_crossref,
    compute_pretrade_quality,
    scan_ticker_patterns,
    enrich_trade_context,
    enrich_eod_from_journal,
    compute_setup_brief,
    scan_journal_patterns,
)

st.set_page_config(page_title="Volume Profile Dashboard", page_icon="📊", layout="wide")

# ── Session state ──────────────────────────────────────────────────────────────
_DEFAULTS = {
    "live_active": False,
    "live_bars": [],
    "live_current_bar": None,
    "live_trades": deque(maxlen=3000),
    "live_thread": None,
    "live_stop_event": None,
    "live_queue": None,
    "live_ticker": "",
    "live_error": None,
    # Alert state
    "tcs_fired_high": False,   # True once ≥ 80% crossed this session
    "tcs_was_high": False,     # True while TCS was ≥ 60% (for chop-drop detection)
    "sound_trigger": 0,        # Incremented to force fresh audio iframe
    # RVOL / Sector cache — pre-fetched once per analysis session
    "rvol_avg_vol": None,          # Average daily volume (5-day lookback)
    "sector_pct_chg": 0.0,         # Sector ETF % change for current date
    "rvol_intraday_curve": None,   # Per-minute cumulative vol curve (390 elements)
    # Ticker widget state (explicit key so scanner can override)
    "ticker_input": "AAPL",
    # Auto-run flag: scanner sets this to True to trigger historical analysis on next rerun
    "auto_run": False,
    # Gap Scanner results cache
    "scanner_results": [],         # [{ticker, price, gap_pct, pm_vol, avg_pm_vol, pm_rvol}]
    "scanner_last_run": None,      # datetime of last successful scan
    # Last analysis snapshot — used by Live Pulse header + Log Entry
    "last_analysis_state": None,
    # Auth
    "auth_user":    None,   # supabase User object when logged in
    "auth_user_id": "",     # user UUID string
    "auth_email":   "",     # user email string
    # Trade journal active tab state
    "active_tab": 0,
    # Position tracking
    "position_in":          False,
    "position_avg_entry":   0.0,
    "position_peak_price":  0.0,
    "position_ticker":      "",
    "position_shares":      0,
    "position_structure":   "",
    # MarketBrain — stores the live predicted structure between reruns
    "brain_session_correct":  0,    # correct predictions this session
    "brain_session_total":    0,    # total comparisons this session
    "brain_last_compared":    "",   # "TICKER_YYYY-MM-DD" — dedup key
    "brain_predicted":        None,
    "brain_ib_high":        0.0,
    "brain_ib_low":         float("inf"),
    "brain_ib_set":         False,
    "brain_high_touched":   False,
    "brain_low_touched":    False,
    # Replay mode
    "replay_bars":          None,   # full-day DataFrame (all bars)
    "replay_bar_idx":       0,      # index of current visible bar (0-based)
    "replay_playing":       False,  # auto-advance in progress
    "replay_speed":         1,      # bars advanced per step
    "replay_ticker":        "",
    "replay_date":          None,
    "replay_avg_vol":       None,
    "replay_intraday_curve": None,
    "replay_sector_bonus":  0.0,
    # Small Account Challenge tab
    "sa_account_bal":       5000.0,
    "sa_risk_pct":          2.0,
    "sa_pdt_used":          0,
    "sa_news_confirmed":    False,
    "sa_float_est":         0.0,
    "last_bars":            None,   # Real bars from last analysis run
    "sa_bin_centers":       None,   # VP bin centers for SA tab
    "sa_vap":               None,   # VP volumes for SA tab
}
for _k, _v in _DEFAULTS.items():
    if _k not in st.session_state:
        st.session_state[_k] = _v

# ── Restore today's brain accuracy counters from Supabase on first load ────────
if st.session_state.brain_session_total == 0:
    try:
        _restore_df = load_accuracy_tracker()
        if "timestamp" in _restore_df.columns and not _restore_df.empty:
            _today_str  = datetime.now(EASTERN).strftime("%Y-%m-%d")
            _today_rows = _restore_df[
                _restore_df["timestamp"].astype(str).str.startswith(_today_str)
            ]
            if not _today_rows.empty and "correct" in _today_rows.columns:
                st.session_state.brain_session_total   = int(len(_today_rows))
                st.session_state.brain_session_correct = int(
                    (_today_rows["correct"] == "✅").sum())
                if "compare_key" in _today_rows.columns:
                    _non_empty = _today_rows["compare_key"].dropna()
                    _non_empty = _non_empty[_non_empty.astype(str).str.strip() != ""]
                    if not _non_empty.empty:
                        st.session_state.brain_last_compared = str(_non_empty.iloc[-1])
    except Exception:
        pass  # safe fallback — counters stay at 0

# ── Audio JS (Web Audio API, synthesised tones — no external files) ────────────
_CHIME_JS = """(function(){
  try{
    var C=new(window.AudioContext||window.webkitAudioContext)();
    [[523.25,0],[659.25,0.18],[783.99,0.36],[1046.50,0.54]].forEach(function(fd){
      var o=C.createOscillator(),g=C.createGain();
      o.type='sine'; o.frequency.value=fd[0];
      o.connect(g); g.connect(C.destination);
      var t=C.currentTime+fd[1];
      g.gain.setValueAtTime(0.001,t);
      g.gain.linearRampToValueAtTime(0.26,t+0.04);
      g.gain.exponentialRampToValueAtTime(0.001,t+0.42);
      o.start(t); o.stop(t+0.43);
    });
  }catch(e){}
})();"""

_LOW_TONE_JS = """(function(){
  try{
    var C=new(window.AudioContext||window.webkitAudioContext)();
    [[240,0],[200,0.26],[155,0.52]].forEach(function(fd){
      var o=C.createOscillator(),g=C.createGain();
      o.type='triangle'; o.frequency.value=fd[0];
      o.connect(g); g.connect(C.destination);
      var t=C.currentTime+fd[1];
      g.gain.setValueAtTime(0.001,t);
      g.gain.linearRampToValueAtTime(0.32,t+0.05);
      g.gain.exponentialRampToValueAtTime(0.001,t+0.40);
      o.start(t); o.stop(t+0.41);
    });
  }catch(e){}
})();"""

_TARGET_JS = """(function(){
  try{
    var C=new(window.AudioContext||window.webkitAudioContext)();
    [[1174.66,0],[1318.51,0.14],[1568.0,0.28],[1318.51,0.42]].forEach(function(fd){
      var o=C.createOscillator(),g=C.createGain();
      o.type='triangle'; o.frequency.value=fd[0];
      o.connect(g); g.connect(C.destination);
      var t=C.currentTime+fd[1];
      g.gain.setValueAtTime(0.001,t);
      g.gain.linearRampToValueAtTime(0.30,t+0.03);
      g.gain.exponentialRampToValueAtTime(0.001,t+0.55);
      o.start(t); o.stop(t+0.56);
    });
  }catch(e){}
})();"""

EASTERN = pytz.timezone("America/New_York")

# ══════════════════════════════════════════════════════════════════════════════
# CORE MATH
# ══════════════════════════════════════════════════════════════════════════════

def check_tcs_alerts(tcs: float, audio_enabled: bool):
    """Fire visual toast + audio when TCS crosses key thresholds."""
    import streamlit.components.v1 as components

    # ── HIGH CONVICTION: TCS ≥ 80%, fires only once per session ───────────────
    if tcs >= 80 and not st.session_state.tcs_fired_high:
        st.session_state.tcs_fired_high = True
        st.session_state.tcs_was_high = True
        st.toast("🚀 HIGH CONVICTION TREND DETECTED", icon="🚀")
        if audio_enabled:
            n = st.session_state.sound_trigger + 1
            st.session_state.sound_trigger = n
            components.html(
                f'<script>/* hc:{n} */{_CHIME_JS}</script>',
                height=0, scrolling=False
            )

    # Track whether TCS has been "high" (≥ 60%) so we can detect a drop
    elif tcs >= 60:
        st.session_state.tcs_was_high = True

    # ── CHOP RISK: TCS drops below 30 after being high ────────────────────────
    if tcs < 30 and st.session_state.tcs_was_high:
        st.session_state.tcs_was_high = False
        st.toast("⚠️ CHOP RISK INCREASED", icon="⚠️")
        if audio_enabled:
            n = st.session_state.sound_trigger + 1
            st.session_state.sound_trigger = n
            components.html(
                f'<script>/* cr:{n} */{_LOW_TONE_JS}</script>',
                height=0, scrolling=False
            )


# ══════════════════════════════════════════════════════════════════════════════
# TARGET ZONES
# ══════════════════════════════════════════════════════════════════════════════

def check_target_alerts(price, targets, audio_enabled):
    """Fire a unique 'Target Reached' sound when price touches a target zone (0.5% tol)."""
    import streamlit.components.v1 as components
    if not audio_enabled or not targets or price is None:
        return
    tol = price * 0.005
    for tz in targets:
        key = f"target_fired_{tz['type']}_{tz['price']:.2f}"
        if abs(price - tz["price"]) <= tol and not st.session_state.get(key, False):
            st.session_state[key] = True
            st.toast(f"🎯 Target Reached — {tz['label']} at ${tz['price']:.2f}", icon="🎯")
            n = st.session_state.get("sound_trigger", 0) + 1
            st.session_state["sound_trigger"] = n
            components.html(
                f'<script>/* tr:{n} */{_TARGET_JS}</script>',
                height=0, scrolling=False
            )


# ══════════════════════════════════════════════════════════════════════════════
# AUTH
# ══════════════════════════════════════════════════════════════════════════════

def render_login_page():
    """Full-page login / sign-up screen shown when no user is authenticated."""
    st.markdown("""
    <style>
    .auth-card {
        max-width: 440px; margin: 60px auto 0 auto;
        background: #12122288; border: 1px solid #2a2a4a;
        border-radius: 16px; padding: 40px 36px;
    }
    .auth-logo {
        text-align: center; font-size: 48px; margin-bottom: 4px;
    }
    .auth-title {
        text-align: center; font-size: 22px; font-weight: 800;
        color: #e0e0e0; letter-spacing: -0.5px; margin-bottom: 4px;
    }
    .auth-sub {
        text-align: center; font-size: 12px; color: #5c6bc0;
        text-transform: uppercase; letter-spacing: 1px; margin-bottom: 28px;
    }
    </style>
    <div class="auth-card">
      <div class="auth-logo">📊</div>
      <div class="auth-title">Volume Profile Terminal</div>
      <div class="auth-sub">Professional Trading Analytics</div>
    </div>
    """, unsafe_allow_html=True)

    # Center the form using columns
    _, col, _ = st.columns([1, 2, 1])
    with col:
        _auth_tab = st.radio(
            "Action", ["🔐 Log In", "📝 Sign Up"],
            horizontal=True, key="auth_tab_select", label_visibility="collapsed",
        )
        st.markdown("")

        _email = st.text_input(
            "Email", placeholder="you@example.com",
            key="auth_email_input", label_visibility="collapsed",
        )
        _password = st.text_input(
            "Password", type="password", placeholder="Password",
            key="auth_password_input", label_visibility="collapsed",
        )

        if _auth_tab == "🔐 Log In":
            if st.button("Log In", use_container_width=True, type="primary",
                         key="auth_login_btn"):
                if not _email or not _password:
                    st.error("Please enter your email and password.")
                else:
                    with st.spinner("Logging in…"):
                        _res = auth_login(_email.strip(), _password)
                    if _res["error"]:
                        st.error(_res["error"])
                    else:
                        _u  = _res["user"]
                        _s  = _res.get("session") or (_res.get("session"))
                        st.session_state["auth_user"]    = _u
                        st.session_state["auth_user_id"] = str(_u.id) if _u else ""
                        st.session_state["auth_email"]   = str(_u.email) if _u else _email
                        # Persist session so next restart auto-logs in
                        _rt = getattr(_res.get("session"), "refresh_token", None)
                        if _u and _rt:
                            save_session_cache(str(_u.id), str(_u.email), _rt)
                        st.success("Logged in! Loading dashboard…")
                        st.rerun()
        else:
            st.caption("Password must be at least 6 characters.")
            if st.button("Create Account", use_container_width=True, type="primary",
                         key="auth_signup_btn"):
                if not _email or not _password:
                    st.error("Please enter your email and password.")
                elif len(_password) < 6:
                    st.error("Password must be at least 6 characters.")
                else:
                    with st.spinner("Creating account…"):
                        _res = auth_signup(_email.strip(), _password)
                    if _res["error"]:
                        st.error(_res["error"])
                    else:
                        _u = _res["user"]
                        if _u and _u.id:
                            st.session_state["auth_user"]    = _u
                            st.session_state["auth_user_id"] = str(_u.id)
                            st.session_state["auth_email"]   = str(_u.email)
                            _rt2 = getattr(_res.get("session"), "refresh_token", None)
                            if _rt2:
                                save_session_cache(str(_u.id), str(_u.email), _rt2)
                            st.success("Account created! Loading dashboard…")
                            st.rerun()
                        else:
                            st.success(
                                "Account created! Check your email to confirm, "
                                "then log in below."
                            )

        st.markdown(
            '<div style="text-align:center; font-size:10px; color:#333; margin-top:24px;">'
            'Powered by Supabase Auth · Data isolated per account'
            '</div>', unsafe_allow_html=True,
        )


# ══════════════════════════════════════════════════════════════════════════════
# LIVE STREAM
# ══════════════════════════════════════════════════════════════════════════════

def render_log_entry_ui():
    """Show the Notes box + LOG ENTRY button below the chart."""
    state = st.session_state.get("last_analysis_state")
    if not state:
        return
    with st.expander("💾 Log This Trade Entry", expanded=True):
        ticker  = state.get("ticker", "?")
        price   = state.get("price", 0.0)
        tcs     = state.get("tcs", 0.0)
        rvol    = state.get("rvol") or 0.0
        struct  = state.get("structure", "?")
        st.markdown(
            f"**Ready to log:** `{ticker}` @ `${price:.2f}` — "
            f"TCS `{tcs:.0f}` · RVOL `{rvol:.2f}x` · Structure `{struct}`"
        )

        # ── Live Quote Fetch ──────────────────────────────────────────────────
        st.markdown(
            '<div style="font-size:11px; color:#5c6bc0; text-transform:uppercase; '
            'letter-spacing:1px; margin:8px 0 4px 0;">🔍 Override / Verify Live Price</div>',
            unsafe_allow_html=True,
        )
        _fc1, _fc2 = st.columns([3, 1])
        with _fc1:
            _fetch_ticker = st.text_input(
                "Ticker to fetch", value=ticker,
                placeholder="e.g. TSLA", label_visibility="collapsed",
                key="live_fetch_ticker_input",
            )
        with _fc2:
            _fetch_clicked = st.button("Fetch Price", use_container_width=True,
                                       key="live_fetch_btn")
        if _fetch_clicked:
            with st.spinner(f"Fetching live quote for {_fetch_ticker}…"):
                _q = fetch_live_quote(_fetch_ticker)
            if _q["error"]:
                st.error(f"Could not fetch `{_fetch_ticker}`: {_q['error']}")
            else:
                st.session_state["_fetched_price"]  = _q["price"]
                st.session_state["_fetched_volume"] = _q["volume"]
                st.session_state["_fetched_symbol"] = _fetch_ticker.upper()

        if st.session_state.get("_fetched_price") is not None:
            _fp  = st.session_state["_fetched_price"]
            _fv  = st.session_state["_fetched_volume"]
            _fsym = st.session_state.get("_fetched_symbol", "")
            _vol_str = f"{_fv:,}" if _fv else "—"
            st.markdown(
                f'<div style="background:#0d2b1a; border:1px solid #2e7d32; border-radius:6px; '
                f'padding:6px 12px; margin:4px 0; display:flex; gap:24px; align-items:center;">'
                f'<span style="color:#81c784; font-weight:700; font-size:13px;">{_fsym}</span>'
                f'<span style="color:#a5d6a7;">Price: <b style="color:#e8f5e9;">${_fp:.2f}</b></span>'
                f'<span style="color:#a5d6a7;">Vol today: <b style="color:#e8f5e9;">{_vol_str}</b></span>'
                f'<span style="font-size:10px; color:#555;">via yfinance</span>'
                f'</div>',
                unsafe_allow_html=True,
            )
            # Use fetched price in the log entry
            price = _fp

        # ── Entry time override ───────────────────────────────────────────────
        st.markdown(
            '<div style="font-size:11px; color:#5c6bc0; text-transform:uppercase; '
            'letter-spacing:1px; margin:8px 0 4px 0;">⏱ Entry Time (ET)</div>',
            unsafe_allow_html=True,
        )
        _tc1, _tc2 = st.columns([1, 1])
        _now_et = datetime.now(EASTERN)
        _entry_date = _tc1.date_input(
            "Entry date", value=_now_et.date(),
            key="journal_entry_date", label_visibility="collapsed",
        )
        _entry_time = _tc2.time_input(
            "Entry time (ET)", value=_now_et.time().replace(second=0, microsecond=0),
            key="journal_entry_time", label_visibility="collapsed",
            step=60,
        )

        notes = st.text_input(
            "Mental State / Notes",
            placeholder="e.g. Calm, FOMO, Greed, Hesitated...",
            key="journal_notes_input",
        )
        if st.button("💾 LOG ENTRY", use_container_width=True, key="journal_log_btn"):
            grade, reason = compute_trade_grade(
                state.get("rvol"), state.get("tcs"), state.get("price"),
                state.get("ib_high"), state.get("ib_low"), state.get("structure"),
            )
            _log_ticker = st.session_state.get("_fetched_symbol") or state.get("ticker", "")
            _entry_dt = datetime.combine(_entry_date, _entry_time)
            entry = {
                "timestamp": _entry_dt.strftime("%Y-%m-%d %H:%M:%S"),
                "ticker":    _log_ticker,
                "price":     round(float(price), 4),
                "structure": state.get("structure", ""),
                "tcs":       round(state.get("tcs", 0.0), 1),
                "rvol":      round(state.get("rvol") or 0.0, 2),
                "ib_high":   round(state.get("ib_high") or 0.0, 4),
                "ib_low":    round(state.get("ib_low") or 0.0, 4),
                "notes":     notes,
                "grade":     grade,
                "grade_reason": reason,
            }
            save_journal_entry(entry, user_id=st.session_state.get("auth_user_id", ""))
            # Clear fetched price state so next log starts fresh
            for _ck in ("_fetched_price", "_fetched_volume", "_fetched_symbol"):
                st.session_state.pop(_ck, None)
            gc = _GRADE_COLORS.get(grade, "#aaa")
            st.success(f"Logged! **Grade {grade}** — {reason}")
            st.markdown(
                f'<div style="display:inline-block; background:{gc}22; border:2px solid {gc}; '
                f'border-radius:50%; width:52px; height:52px; line-height:52px; '
                f'text-align:center; font-size:24px; font-weight:900; color:{gc};">'
                f'{grade}</div>',
                unsafe_allow_html=True,
            )

    # ── Recent Trades preview (last 10 from Supabase) ─────────────────────────
    _recent_df = load_journal(user_id=st.session_state.get("auth_user_id", ""))
    if not _recent_df.empty:
        _cols = [c for c in ["timestamp", "ticker", "price", "structure", "grade"]
                 if c in _recent_df.columns]
        _show = _recent_df[_cols].head(10).copy()

        # Format price column
        if "price" in _show.columns:
            _show["price"] = _show["price"].apply(
                lambda x: f"${float(x):.2f}" if x not in (None, "", "nan") else "—"
            )

        # Grade → colored badge via styled HTML
        _grade_row_colors = {"A": "#4caf50", "B": "#26a69a", "C": "#ffa726", "F": "#ef5350"}
        rows_html = ""
        for _, row in _show.iterrows():
            g  = str(row.get("grade", ""))
            gc = _grade_row_colors.get(g, "#555")
            ts = str(row.get("timestamp", ""))[:16]   # trim seconds
            rows_html += (
                f'<tr>'
                f'<td style="color:#888; font-size:11px; padding:5px 8px; white-space:nowrap;">{ts}</td>'
                f'<td style="color:#e0e0e0; font-weight:700; padding:5px 8px;">{row.get("ticker","")}</td>'
                f'<td style="color:#90caf9; padding:5px 8px;">{row.get("price","")}</td>'
                f'<td style="color:#aaa; font-size:11px; padding:5px 8px;">{row.get("structure","")}</td>'
                f'<td style="padding:5px 8px; text-align:center;">'
                f'<span style="background:{gc}22; border:1px solid {gc}; color:{gc}; '
                f'border-radius:4px; padding:2px 8px; font-weight:700; font-size:12px;">{g}</span>'
                f'</td>'
                f'</tr>'
            )

        st.markdown(
            f'<div style="margin-top:12px;">'
            f'<div style="font-size:12px; color:#5c6bc0; text-transform:uppercase; '
            f'letter-spacing:1px; margin-bottom:6px;">📋 Recent Trades</div>'
            f'<table style="width:100%; border-collapse:collapse; background:#12122a; '
            f'border-radius:6px; overflow:hidden;">'
            f'<thead><tr style="background:#1a1a3e; border-bottom:1px solid #2a2a4a;">'
            f'<th style="text-align:left; color:#5c6bc0; font-size:10px; padding:6px 8px; '
            f'text-transform:uppercase; letter-spacing:1px;">Time</th>'
            f'<th style="text-align:left; color:#5c6bc0; font-size:10px; padding:6px 8px; '
            f'text-transform:uppercase; letter-spacing:1px;">Ticker</th>'
            f'<th style="text-align:left; color:#5c6bc0; font-size:10px; padding:6px 8px; '
            f'text-transform:uppercase; letter-spacing:1px;">Price</th>'
            f'<th style="text-align:left; color:#5c6bc0; font-size:10px; padding:6px 8px; '
            f'text-transform:uppercase; letter-spacing:1px;">Structure</th>'
            f'<th style="text-align:center; color:#5c6bc0; font-size:10px; padding:6px 8px; '
            f'text-transform:uppercase; letter-spacing:1px;">Grade</th>'
            f'</tr></thead>'
            f'<tbody>{rows_html}</tbody>'
            f'</table></div>',
            unsafe_allow_html=True,
        )


def render_journal_tab(api_key: str = "", secret_key: str = ""):
    """Render the 📖 My Journal tab."""
    _uid = st.session_state.get("auth_user_id", "")
    df = load_journal(user_id=_uid)

    with st.expander("📋 How to use this tab — read this first", expanded=df.empty):
        st.markdown(
            """
**This is your personal trade journal. It is the source of truth for your analytics.**

---

**STEP 1 — Import your trades from Webull**
- In Webull: go to **Orders → History → Export CSV**
- Upload that file using the **"Import Trades from Webull CSV"** section below
- The system auto-pairs your Buy → Sell orders and grades each trade by P&L
- Open positions (no matching sell) are skipped automatically

**STEP 2 — Fix any "Unknown" structures** *(if the button appears)*
- After importing, if you see a **"🔄 Fix X Unknown Structures"** button, click it
- This pulls historical bar data from Alpaca for each trade and fills in the correct structure label (Trend Day, Normal, etc.)
- Requires your Alpaca credentials to be entered in the sidebar

**STEP 3 — Sync to Analytics** *(only needed once after first import)*
- Go to the **📊 Analytics** tab
- If you see a **"🔄 Sync Journal → Analytics"** button, click it to backfill your accuracy data
- After that, new imports sync automatically

**STEP 4 — Review your journal cards below**
- Each card shows: Ticker · Entry price → Exit price · P&L · Shares · Hold time badge
- Grades: **A/B = winner**, **C = breakeven/scratch**, **D/F = loss**
- You can manually add notes or change the grade on any entry

---

⚠️ **What this tab is NOT for:**
- Do not enter your watchlist or scan tickers here — that's the sidebar / Scanner tab
- Do not manually type fabricated trades — the analytics are only useful if the data is real
            """,
        )

    cola, colb, colc = st.columns([2, 1, 1])
    with cola:
        st.subheader("📖 My Trade Journal")
    with colb:
        if not df.empty:
            _unknown_count = (
                df["structure"].isin(["Unknown", "", None]) |
                df["structure"].isna()
            ).sum() if "structure" in df.columns else 0
            _bf_label = (
                f"🔄 Fix {_unknown_count} Unknown Structures"
                if _unknown_count > 0 else "✅ All Structures Enriched"
            )
            _bf_disabled = _unknown_count == 0
            if st.button(
                _bf_label,
                disabled=_bf_disabled,
                use_container_width=True,
                key="backfill_structures_btn",
                help="Re-fetches bar data from Alpaca for any journal entry showing 'Unknown' structure and fills in the correct Trend Day / Normal / Neutral etc. label.",
            ):
                _bf_api  = st.session_state.get("_sb_api_key", "")
                _bf_sec  = st.session_state.get("_sb_secret_key", "")
                _bf_uid  = st.session_state.get("auth_user_id", "")
                _bf_feed = st.session_state.get("data_feed", "iex")
                if not _bf_api or not _bf_sec:
                    st.error("Enter your Alpaca credentials in the sidebar first.")
                else:
                    with st.spinner(
                        f"Fetching bar data for {_unknown_count} entries… "
                        "This may take a minute."
                    ):
                        _bf_result = backfill_unknown_structures(
                            _bf_api, _bf_sec, _bf_uid, feed=_bf_feed
                        )
                    if _bf_result["updated"] > 0:
                        st.success(
                            f"✅ Fixed **{_bf_result['updated']}** entries. "
                            f"{_bf_result['failed']} failed. Refresh to see updates."
                        )
                        if _bf_result["errors"]:
                            with st.expander("Details"):
                                for _e in _bf_result["errors"]:
                                    st.caption(_e)
                    elif _bf_result["failed"] > 0:
                        st.warning(
                            f"Could not enrich {_bf_result['failed']} entries. "
                            "Check that your Alpaca key has market data access."
                        )
                        for _e in _bf_result["errors"][:5]:
                            st.caption(_e)
                    else:
                        st.info("No Unknown structures found — journal is fully enriched.")
    with colc:
        if not df.empty:
            csv_bytes = df.to_csv(index=False).encode()
            st.download_button(
                "⬇️ Download Journal (CSV)",
                data=csv_bytes,
                file_name=f"trade_journal_{date.today()}.csv",
                mime="text/csv",
                use_container_width=True,
            )

    # ── Webull CSV Import ──────────────────────────────────────────────────────
    with st.expander("📥 Import Trades from Webull CSV", expanded=df.empty):
        st.markdown(
            '<div style="font-size:12px; color:#546e7a; margin-bottom:10px;">'
            'In Webull: <b>Orders → History → Export CSV</b>. '
            'Upload your file below — all closed round-trips are auto-detected, '
            'paired buy→sell, graded by P&L, and saved to your journal instantly. '
            'Open positions are skipped automatically.'
            '</div>',
            unsafe_allow_html=True,
        )
        _wb_file = st.file_uploader(
            "Drop your Webull order history CSV here",
            type=["csv"],
            key="webull_csv_uploader",
            label_visibility="collapsed",
        )
        if _wb_file is not None:
            try:
                _wb_df = pd.read_csv(_wb_file)
                _wb_trades = parse_webull_csv(_wb_df)
                if not _wb_trades:
                    st.warning(
                        "Could not detect any closed round-trip trades in this file. "
                        "Make sure you exported **Order History** (not Account History) "
                        "and that the file contains both Buy and Sell filled orders."
                    )
                    st.caption(f"Columns found: {', '.join(_wb_df.columns.tolist())}")
                else:
                    _wb_preview = pd.DataFrame([{
                        "Ticker":      t["ticker"],
                        "Entry Date":  str(t["timestamp"])[:10],
                        "Entry Price": f"${t['price']:.4f}",
                        "Grade":       t["grade"],
                        "Notes":       t["notes"],
                    } for t in _wb_trades])
                    st.success(f"Found **{len(_wb_trades)} closed trades** ready to import:")
                    st.dataframe(_wb_preview, use_container_width=True, height=220)

                    _wb_col1, _wb_col2 = st.columns([1, 1])
                    with _wb_col1:
                        _wb_skip_dups = st.checkbox(
                            "Skip duplicates (same ticker + date already in journal)",
                            value=True, key="wb_skip_dups",
                        )
                    with _wb_col2:
                        _wb_import_btn = st.button(
                            f"💾 IMPORT {len(_wb_trades)} TRADES",
                            type="primary", use_container_width=True,
                            key="wb_import_btn",
                        )

                    if _wb_import_btn:
                        _existing_keys: set = set()
                        if _wb_skip_dups and not df.empty:
                            for _, _erow in df.iterrows():
                                _ekey = (
                                    str(_erow.get("ticker", "")).upper(),
                                    str(_erow.get("timestamp", ""))[:10],
                                )
                                _existing_keys.add(_ekey)

                        # Filter to only trades that need saving
                        _to_save = []
                        _skipped = 0
                        for _t in _wb_trades:
                            _key = (_t["ticker"].upper(), str(_t["timestamp"])[:10])
                            if _wb_skip_dups and _key in _existing_keys:
                                _skipped += 1
                            else:
                                _to_save.append(_t)

                        if _to_save:
                            _enrich_status = st.empty()
                            _enrich_status.info(
                                f"Enriching {len(_to_save)} trade(s) with TCS, RVOL, IB levels "
                                f"and structure — this may take a moment..."
                            )

                            _ak  = st.session_state.get("_sb_api_key", "")
                            _ask = st.session_state.get("_sb_secret_key", "")

                            def _enrich_one(trade):
                                ctx = enrich_trade_context(
                                    _ak, _ask,
                                    trade["ticker"],
                                    trade.get("timestamp", ""),
                                    feed="iex",
                                )
                                enriched = dict(trade)
                                for field in ("tcs", "rvol", "ib_high", "ib_low", "structure"):
                                    if ctx.get(field) is not None and not enriched.get(field):
                                        enriched[field] = ctx[field]
                                return enriched

                            from concurrent.futures import ThreadPoolExecutor, as_completed
                            _enriched_trades = [None] * len(_to_save)
                            with ThreadPoolExecutor(max_workers=min(6, len(_to_save))) as _ex:
                                _futs = {_ex.submit(_enrich_one, t): i for i, t in enumerate(_to_save)}
                                for _f in as_completed(_futs):
                                    _enriched_trades[_futs[_f]] = _f.result()

                            _enrich_status.empty()

                            _imported = 0
                            for _t in _enriched_trades:
                                if _t is not None:
                                    save_journal_entry(_t, user_id=_uid)
                                    # Also write to accuracy_tracker so Analytics tab
                                    # shows real P&L stats from your Webull history
                                    _entry_p = float(_t.get("price", 0) or 0)
                                    _exit_p  = float(_t.get("exit_price", 0) or 0)
                                    _mfe_v   = float(_t.get("mfe", 0) or 0)
                                    if _entry_p > 0 and _exit_p > 0:
                                        log_accuracy_entry(
                                            symbol=_t.get("ticker", ""),
                                            predicted=_t.get("structure", "Unknown"),
                                            actual=_t.get("structure", "Unknown"),
                                            compare_key="webull_import",
                                            entry_price=_entry_p,
                                            exit_price=_exit_p,
                                            mfe=_mfe_v,
                                            user_id=_uid,
                                        )
                                    _imported += 1
                        else:
                            _imported = 0

                        st.success(
                            f"Imported **{_imported} trades** into your journal"
                            + (f" ({_skipped} skipped as duplicates)" if _skipped else "")
                            + " — each entry includes TCS, RVOL, IB levels, and structure. "
                            "Refresh the page to see them below."
                        )
                        if _imported > 0:
                            st.balloons()
            except Exception as _wb_err:
                st.error(f"Could not parse CSV: {_wb_err}. Make sure you uploaded an unmodified Webull export.")

    st.markdown("---")

    if df.empty:
        st.info("No entries yet. Run an analysis and click **💾 LOG ENTRY** under the chart.")

    # ── Journal entries (only when not empty) ─────────────────────────────────
    if not df.empty:
        import re as _re_j
        # Grade badges + table
        st.markdown("---")
        for _, row in df.iterrows():
            grade = str(row.get("grade", "?"))
            gc = _GRADE_COLORS.get(grade, "#aaaaaa")
            reason = row.get("grade_reason", "")
            ts = row.get("timestamp", "")
            sym = row.get("ticker", "")
            price = row.get("price", "")
            struct = row.get("structure", "")
            tcs_v = row.get("tcs", "")
            rvol_v = row.get("rvol", "")
            notes_v = str(row.get("notes", "") or "")

            # Parse exit price, P&L, shares, and exit timestamp from notes
            _ex_m   = _re_j.search(r"Exit:\s*\$([0-9.]+)", notes_v)
            _pnl_m  = _re_j.search(r"P&L:\s*\$([+-]?[0-9.]+)\s*\(([+-]?[0-9.]+)%\)", notes_v)
            _sh_m   = _re_j.search(r"Shares:\s*([0-9]+)", notes_v)
            # ExitTS: new format; also handle old "Exit: YYYY-MM-DD HH:MM"
            _ets_m  = _re_j.search(r"ExitTS:\s*([0-9]{4}-[0-9]{2}-[0-9]{2}[T\s][0-9:]+)", notes_v)
            if not _ets_m:
                _ets_m = _re_j.search(r"Exit:\s*([0-9]{4}-[0-9]{2}-[0-9]{2}\s[0-9:]+)", notes_v)

            _exit_str   = f"${float(_ex_m.group(1)):.4f}" if _ex_m else ""
            _pnl_val    = float(_pnl_m.group(1)) if _pnl_m else 0.0
            _pnl_pct    = _pnl_m.group(2) if _pnl_m else ""
            _pnl_str    = f"${_pnl_val:+.2f} ({_pnl_pct}%)" if _pnl_m else ""
            _pnl_color  = "#4caf50" if _pnl_val >= 0 else "#ef5350"
            _shares_str = _sh_m.group(1) if _sh_m else ""
            _entry_fmt  = f"${float(price):.4f}" if price not in (None, "", "nan") else "—"

            # Compute hold time from entry → exit timestamps
            _hold_badge = ""
            if _ets_m and ts:
                try:
                    import pandas as _pd_j
                    _entry_dt = _pd_j.to_datetime(str(ts), errors="coerce")
                    _exit_dt  = _pd_j.to_datetime(_ets_m.group(1).strip(), errors="coerce")
                    if _pd_j.notna(_entry_dt) and _pd_j.notna(_exit_dt):
                        _hold_days = (_exit_dt.date() - _entry_dt.date()).days
                        if _hold_days == 0:
                            _hold_mins = max(0, int((_exit_dt - _entry_dt).total_seconds() / 60))
                            _hold_label = f"Intraday · {_hold_mins}m" if _hold_mins > 0 else "Intraday"
                            _hold_color = "#29b6f6"
                        elif _hold_days == 1:
                            _hold_label = "Overnight"
                            _hold_color = "#ffa726"
                        else:
                            _hold_label = f"Multi-day · {_hold_days}d"
                            _hold_color = "#ce93d8"
                        _hold_badge = (
                            f'<span style="background:{_hold_color}22;border:1px solid {_hold_color}66;'
                            f'color:{_hold_color};font-size:10px;font-weight:600;padding:2px 7px;'
                            f'border-radius:10px;margin-left:6px;white-space:nowrap;">'
                            f'{_hold_label}</span>'
                        )
                except Exception:
                    pass

            if _exit_str:
                _price_line = (
                    f'<span style="color:#888;font-size:11px;">Entry</span> '
                    f'<span style="color:#90caf9;">{_entry_fmt}</span>'
                    f'<span style="color:#555;margin:0 5px;">→</span>'
                    f'<span style="color:#888;font-size:11px;">Exit</span> '
                    f'<span style="color:#90caf9;">{_exit_str}</span>'
                )
                if _pnl_str:
                    _price_line += (
                        f'<span style="color:#555;margin:0 6px;">·</span>'
                        f'<span style="color:#888;font-size:11px;">P&amp;L</span> '
                        f'<span style="color:{_pnl_color};font-weight:700;">{_pnl_str}</span>'
                    )
                if _shares_str:
                    _price_line += (
                        f'<span style="color:#666;font-size:11px;margin-left:6px;">{_shares_str} sh</span>'
                    )
            else:
                _price_line = (
                    f'<span style="color:#888;font-size:11px;">Entry</span> '
                    f'<span style="color:#90caf9;">{_entry_fmt}</span>'
                )

            # Strip Webull boilerplate from display notes
            _clean_notes = _re_j.sub(
                r"Webull import\s*\|?\s*|Exit:\s*\$[0-9.]+\s*\|?\s*"
                r"|P&L:\s*\$[+-]?[0-9.]+\s*\([+-]?[0-9.]+%\)\s*\|?\s*"
                r"|Shares:\s*[0-9]+\s*\|?\s*"
                r"|ExitTS:\s*[0-9]{4}-[0-9]{2}-[0-9]{2}[T\s][0-9:]+\s*\|?\s*"
                r"|Exit:\s*[0-9]{4}-[0-9]{2}-[0-9]{2}[^|]*\|?\s*",
                "", notes_v
            ).strip(" |·").strip()

            _j_cols = st.columns([8, 1])
            with _j_cols[0]:
                st.markdown(
                    f'<div style="display:flex;gap:16px;align-items:center;background:#12122288;'
                    f'border:1px solid #2a2a4a;border-radius:10px;padding:12px 18px;margin:8px 0;">'
                    f'<div style="flex-shrink:0;width:52px;height:52px;border-radius:50%;'
                    f'background:{gc}22;border:2.5px solid {gc};display:flex;'
                    f'align-items:center;justify-content:center;'
                    f'font-size:24px;font-weight:900;color:{gc};">{grade}</div>'
                    f'<div style="flex:1;min-width:0;">'
                    f'<div style="display:flex;gap:10px;flex-wrap:wrap;align-items:center;">'
                    f'<span style="font-size:20px;font-weight:800;color:#e0e0e0;">{sym}</span>'
                    f'{_hold_badge}'
                    f'<span style="font-size:11px;color:#666;">{ts}</span>'
                    f'</div>'
                    f'<div style="font-size:13px;margin:3px 0;">{_price_line}</div>'
                    f'<div style="font-size:12px;color:#90caf9;margin:2px 0;">{struct}</div>'
                    f'<div style="font-size:11px;color:#888;">'
                    f'TCS {tcs_v}%  ·  RVOL {rvol_v}x'
                    f'{("  ·  <em>" + _clean_notes + "</em>") if _clean_notes else ""}'
                    f'</div>'
                    f'<div style="font-size:12px;color:{gc};margin-top:4px;">{reason}</div>'
                    f'</div></div>',
                    unsafe_allow_html=True,
                )
            with _j_cols[1]:
                st.markdown("<div style='height:20px'></div>", unsafe_allow_html=True)
                _ts_str = str(ts)[:10] if ts else ""
                _replay_key = f"journal_replay_{_}_{sym}"
                if st.button("📈 Replay", key=_replay_key, use_container_width=True,
                             help=f"Load {sym} on {_ts_str} in the Main Chart tab"):
                    try:
                        from datetime import date as _date_cls
                        _replay_dt = _date_cls.fromisoformat(_ts_str) if _ts_str else None
                    except Exception:
                        _replay_dt = None
                    st.session_state["ticker_input"]   = str(sym).upper().strip()
                    st.session_state["_load_ticker"]   = str(sym).upper().strip()
                    if _replay_dt:
                        st.session_state["_replay_date"] = _replay_dt
                    st.success(f"✅ {sym} loaded — switch to Main Chart tab and click Fetch & Analyze")

    if not df.empty:
        # Equity curve — grade average over entries
        st.markdown("---")
        st.markdown("**Grade Discipline Curve**")
        df2 = df.copy()
        df2["grade_score"] = df2["grade"].map(_GRADE_SCORE).fillna(1)
        df2["entry_num"]   = range(1, len(df2) + 1)
        df2["rolling_avg"] = df2["grade_score"].expanding().mean()
    
        import plotly.graph_objects as _go
        fig = _go.Figure()
        fig.add_trace(_go.Scatter(
            x=df2["entry_num"], y=df2["rolling_avg"],
            mode="lines+markers",
            line=dict(color="#00bcd4", width=2.5),
            marker=dict(size=7, color=df2["grade_score"].map(
                {4: "#4caf50", 3: "#26a69a", 2: "#ffa726", 1: "#ef5350"}
            ).fillna("#aaa")),
            name="Grade Average",
            hovertemplate="Entry %{x} — Avg %{y:.2f}<extra></extra>",
        ))
        fig.add_hline(y=3.0, line=dict(color="rgba(76,175,80,0.4)", dash="dot"),
                      annotation_text="B threshold", annotation_font_color="#4caf50")
        fig.update_layout(
            paper_bgcolor="#1a1a2e", plot_bgcolor="#16213e",
            font=dict(color="#e0e0e0"), height=220,
            xaxis=dict(title="Entry #", gridcolor="#2a2a4a"),
            yaxis=dict(title="Avg Grade (F=1 \u2013 A=4)", gridcolor="#2a2a4a",
                       tickvals=[1, 2, 3, 4], ticktext=["F", "C", "B", "A"],
                       range=[0.5, 4.5]),
            margin=dict(l=10, r=10, t=20, b=40),
            showlegend=False,
        )
        st.plotly_chart(fig, use_container_width=True)
    
        # ── Review Trades ────────────────────────────────────────────────────────
        st.markdown("---")
        with st.expander("🔍 Review Trades — Log Actual Outcome", expanded=False):
            st.markdown(
                '<div style="font-size:12px; color:#90caf9; margin-bottom:8px;">'
                'Pick a logged trade, enter your actual exit price and what structure '
                'the day turned out to be, and save the result to the Accuracy Tracker.'
                '</div>', unsafe_allow_html=True,
            )
    
            _STRUCTURES = [
                "Trend Day", "Non-Trend", "Normal", "Normal Variation",
                "Neutral", "Neutral Extreme", "Double Distribution",
            ]
    
            # Build display labels for the selectbox
            _trade_labels = []
            for _, _r in df.iterrows():
                _ts  = str(_r.get("timestamp", ""))[:16]
                _sym = str(_r.get("ticker", "?"))
                _px  = _r.get("price", 0.0)
                _st  = str(_r.get("structure", ""))[:20]
                _trade_labels.append(f"{_ts}  ·  {_sym}  @${_px:.2f}  [{_st}]")
    
            _sel_idx = st.selectbox(
                "Select a trade to review",
                options=range(len(_trade_labels)),
                format_func=lambda i: _trade_labels[i],
                key="review_trade_select",
            )
    
            _sel_row = df.iloc[_sel_idx].to_dict()
            _entry_px = float(_sel_row.get("price", 0.0))
            _pred_struct = str(_sel_row.get("structure", ""))
    
            # Summary card
            _gc = _GRADE_COLORS.get(str(_sel_row.get("grade", "?")), "#aaa")
            st.markdown(
                f'<div style="background:#12122288; border:1px solid #2a2a4a; border-radius:8px; '
                f'padding:10px 16px; margin:8px 0; display:flex; gap:20px; align-items:center;">'
                f'<div style="color:{_gc}; font-weight:900; font-size:20px;">'
                f'{_sel_row.get("grade","?")} Grade</div>'
                f'<div><span style="color:#e0e0e0; font-weight:700;">{_sel_row.get("ticker","")}</span>'
                f'&nbsp;<span style="color:#90caf9;">Entry @ ${_entry_px:.2f}</span></div>'
                f'<div style="color:#888; font-size:11px;">Predicted: '
                f'<span style="color:#ffcc80;">{_pred_struct}</span></div>'
                f'</div>',
                unsafe_allow_html=True,
            )
    
            _rc1, _rc2, _rc3 = st.columns([2, 2, 1])
            with _rc1:
                _exit_price = st.number_input(
                    "Actual Exit Price ($)", min_value=0.01, value=float(_entry_px),
                    step=0.01, format="%.4f", key="review_exit_price",
                )
            with _rc2:
                # Pre-select predicted structure if it exists in list
                _def_idx = 0
                for _si, _sl in enumerate(_STRUCTURES):
                    if _strip_emoji(_pred_struct.lower()) in _strip_emoji(_sl.lower()):
                        _def_idx = _si; break
                _actual_struct = st.selectbox(
                    "Actual Market Structure",
                    options=_STRUCTURES,
                    index=_def_idx,
                    key="review_actual_structure",
                )
            with _rc3:
                _direction = st.radio(
                    "Direction", options=["Long", "Short"],
                    key="review_direction", horizontal=False,
                )
    
            _submit_review = st.button(
                "💾 Save Review to Accuracy Tracker",
                use_container_width=True, key="review_submit_btn",
            )
    
            if _submit_review:
                if _exit_price <= 0:
                    st.error("Exit price must be greater than zero.")
                else:
                    with st.spinner("Saving review…"):
                        _res = save_trade_review(
                            journal_row=_sel_row,
                            exit_price=_exit_price,
                            actual_structure=_actual_struct,
                            direction=_direction,
                            user_id=_uid,
                        )
                    if _res.get("error"):
                        st.error(f"Error: {_res['error']}")
                    else:
                        _wl       = _res["win_loss"]
                        _pnl_d    = _res["pnl_dollars"]
                        _pnl_p    = _res["pnl_pct"]
                        _corr_s   = _res["correct_structure"]
                        _wl_color = "#4caf50" if _wl == "Win" else ("#ef5350" if _wl == "Loss" else "#ffa726")
                        _wl_icon  = "✅" if _wl == "Win" else ("❌" if _wl == "Loss" else "➖")
                        _pnl_sign = "+" if _pnl_d >= 0 else ""
                        _struct_badge = (
                            '<span style="color:#4caf50;">✅ Structure Correct</span>'
                            if _corr_s else
                            '<span style="color:#ef5350;">❌ Structure Wrong</span>'
                        )
                        st.markdown(
                            f'<div style="background:#0a0a1a; border:2px solid {_wl_color}; '
                            f'border-radius:10px; padding:16px 22px; margin:10px 0;">'
                            f'<div style="font-size:22px; font-weight:900; color:{_wl_color};">'
                            f'{_wl_icon} {_wl}</div>'
                            f'<div style="font-size:14px; color:#e0e0e0; margin-top:6px;">'
                            f'P&L: <b style="color:{_wl_color};">'
                            f'{_pnl_sign}${_pnl_d:.4f} ({_pnl_sign}{_pnl_p:.2f}%)</b>'
                            f'&nbsp;&nbsp;·&nbsp;&nbsp;{_struct_badge}</div>'
                            f'<div style="font-size:11px; color:#666; margin-top:4px;">'
                            f'Saved to Accuracy Tracker · '
                            f'{_direction} {_sel_row.get("ticker","")} '
                            f'${_entry_px:.4f} → ${_exit_price:.4f}</div>'
                            f'</div>',
                            unsafe_allow_html=True,
                        )
    
        # ── Sync from Alpaca ─────────────────────────────────────────────────────
        st.markdown("---")
        with st.expander("📥 Sync from Alpaca — Auto-Import Closed Trades", expanded=False):
            st.markdown(
                '<div style="font-size:12px; color:#90caf9; margin-bottom:10px;">'
                'Pulls your actual filled orders from Alpaca, matches buy+sell pairs '
                'into round-trip trades, calculates real P&amp;L, and saves directly '
                'to the Accuracy Tracker — no manual entry needed.'
                '</div>', unsafe_allow_html=True,
            )
            if not api_key or not secret_key:
                st.warning("Enter your Alpaca API Key and Secret Key in the sidebar first.")
            else:
                _sc1, _sc2, _sc3 = st.columns([2, 1, 1])
                with _sc1:
                    _sync_date = st.date_input(
                        "Trade Date", value=date.today(), key="sync_alpaca_date",
                    )
                with _sc2:
                    _is_paper = st.radio(
                        "Account", ["Paper", "Live"],
                        key="sync_alpaca_mode", horizontal=True,
                    ) == "Paper"
                with _sc3:
                    st.markdown("<div style='height:28px'></div>", unsafe_allow_html=True)
                    _sync_btn = st.button("🔄 Fetch Orders", use_container_width=True,
                                          key="sync_alpaca_btn")
    
                if _sync_btn:
                    with st.spinner("Connecting to Alpaca…"):
                        _fills, _err = fetch_alpaca_fills(
                            api_key, secret_key,
                            is_paper=_is_paper,
                            trade_date=str(_sync_date),
                        )
                    if _err:
                        st.error(f"Alpaca error: {_err}")
                    elif not _fills:
                        st.info(f"No filled orders found for {_sync_date} "
                                f"({'paper' if _is_paper else 'live'} account).")
                    else:
                        _trips = match_fills_to_roundtrips(_fills)
                        st.session_state["_alpaca_roundtrips"] = _trips
                        st.session_state["_alpaca_date"]       = str(_sync_date)
                        if not _trips:
                            st.info(f"Found {len(_fills)} fills but no complete round-trips "
                                    "(need both a buy and a sell for the same ticker).")
    
                _trips = st.session_state.get("_alpaca_roundtrips", [])
                if _trips:
                    st.markdown(
                        f'<div style="font-size:11px; color:#5c6bc0; text-transform:uppercase; '
                        f'letter-spacing:1px; margin:8px 0 4px 0;">'
                        f'Found {len(_trips)} round-trip trade(s) — '
                        f'{st.session_state.get("_alpaca_date","")}</div>',
                        unsafe_allow_html=True,
                    )
                    for _ti, _t in enumerate(_trips):
                        _tw_color = ("#4caf50" if _t["win_loss"] == "Win"
                                     else "#ef5350" if _t["win_loss"] == "Loss"
                                     else "#ffa726")
                        _pnl_sign = "+" if _t["pnl_dollars"] >= 0 else ""
                        st.markdown(
                            f'<div style="background:#0a0a1a; border:1px solid {_tw_color}44; '
                            f'border-radius:8px; padding:10px 16px; margin:6px 0; '
                            f'display:flex; gap:20px; align-items:center; flex-wrap:wrap;">'
                            f'<span style="font-weight:800; color:#e0e0e0; font-size:16px;">'
                            f'{_t["symbol"]}</span>'
                            f'<span style="color:#888; font-size:11px;">Entry '
                            f'<b style="color:#90caf9;">${_t["avg_entry"]:.4f}</b></span>'
                            f'<span style="color:#888; font-size:11px;">Exit '
                            f'<b style="color:#90caf9;">${_t["avg_exit"]:.4f}</b></span>'
                            f'<span style="color:#888; font-size:11px;">Qty '
                            f'<b style="color:#e0e0e0;">{int(_t["qty"])}</b></span>'
                            f'<span style="font-weight:700; color:{_tw_color};">'
                            f'{_t["win_loss"]} &nbsp;'
                            f'{_pnl_sign}${_t["pnl_dollars"]:.2f} '
                            f'({_pnl_sign}{_t["pnl_pct"]:.2f}%)</span>'
                            f'<span style="color:#555; font-size:10px;">{_t["fill_time"]}</span>'
                            f'</div>',
                            unsafe_allow_html=True,
                        )
    
                        # Per-trade save button
                        _imp_key = f"import_alpaca_{_ti}"
                        if st.session_state.get(f"_imported_{_imp_key}"):
                            st.markdown(
                                '<span style="color:#4caf50; font-size:11px;">'
                                '✅ Saved to Accuracy Tracker</span>',
                                unsafe_allow_html=True,
                            )
                        else:
                            _imp_col1, _imp_col2 = st.columns([3, 1])
                            with _imp_col2:
                                if st.button(f"💾 Save", key=_imp_key,
                                             use_container_width=True):
                                    # Find matching journal row for predicted structure
                                    _jrow = {"ticker": _t["symbol"],
                                             "price":  _t["avg_entry"],
                                             "structure": ""}
                                    if not df.empty:
                                        _mask = df["ticker"].str.upper() == _t["symbol"]
                                        _match = df[_mask]
                                        if not _match.empty:
                                            _jrow = _match.iloc[-1].to_dict()
                                    log_accuracy_entry(
                                        symbol      = _t["symbol"],
                                        predicted   = str(_jrow.get("structure", "")),
                                        actual      = "",
                                        compare_key = "alpaca_sync",
                                        entry_price = _t["avg_entry"],
                                        exit_price  = _t["avg_exit"],
                                        mfe         = _t["pnl_dollars"],
                                        user_id     = _uid,
                                    )
                                    st.session_state[f"_imported_{_imp_key}"] = True
                                    st.rerun()
    
                    if st.button("💾 Save ALL to Accuracy Tracker",
                                 use_container_width=True, key="sync_alpaca_save_all"):
                        _saved = 0
                        for _ti2, _t2 in enumerate(_trips):
                            _ak2 = f"_imported_import_alpaca_{_ti2}"
                            if not st.session_state.get(_ak2):
                                _jrow2 = {"ticker": _t2["symbol"], "price": _t2["avg_entry"],
                                          "structure": ""}
                                if not df.empty:
                                    _mask2 = df["ticker"].str.upper() == _t2["symbol"]
                                    _match2 = df[_mask2]
                                    if not _match2.empty:
                                        _jrow2 = _match2.iloc[-1].to_dict()
                                log_accuracy_entry(
                                    symbol      = _t2["symbol"],
                                    predicted   = str(_jrow2.get("structure", "")),
                                    actual      = "",
                                    compare_key = "alpaca_sync",
                                    entry_price = _t2["avg_entry"],
                                    exit_price  = _t2["avg_exit"],
                                    mfe         = _t2["pnl_dollars"],
                                    user_id     = _uid,
                                )
                                st.session_state[f"_imported_import_alpaca_{_ti2}"] = True
                                _saved += 1
                        if _saved > 0:
                            st.success(f"Saved {_saved} trade(s) to Accuracy Tracker.")
                            st.session_state["_alpaca_roundtrips"] = []
                            st.rerun()
                        else:
                            st.info("All trades already saved.")

    # ── End-of-Day Review ─────────────────────────────────────────────────────
    st.markdown("---")
    st.header("📸 End-of-Day Review")
    st.caption("Chart screenshots, trendline notes, and watchlist for tomorrow — all saved per day.")

    # ── Pre-market watchlist prediction panel ─────────────────────────────────
    _pm_preds_df = load_watchlist_predictions(user_id=_uid, pred_date=date.today())
    if not _pm_preds_df.empty:
        _pm_tickers = _pm_preds_df["ticker"].tolist()
        _pm_verified_count = int(_pm_preds_df["verified"].sum()) if "verified" in _pm_preds_df.columns else 0
        _pm_pending  = len(_pm_tickers) - _pm_verified_count
        _pm_color    = "#29b6f6"

        st.markdown(
            f'<div style="background:#071b2e;border:1px solid #1e3a5f;border-left:4px solid {_pm_color};'
            f'border-radius:8px;padding:12px 18px;margin-bottom:14px;">'
            f'<div style="display:flex;align-items:center;gap:12px;margin-bottom:8px;">'
            f'<span style="font-size:13px;font-weight:700;color:{_pm_color};">📋 PRE-MARKET WATCHLIST</span>'
            f'<span style="background:#0d2a42;border:1px solid {_pm_color};border-radius:10px;'
            f'padding:2px 10px;font-size:11px;color:{_pm_color};">'
            f'{len(_pm_tickers)} ticker{"s" if len(_pm_tickers)!=1 else ""} on watch</span>'
            f'<span style="font-size:11px;color:#555;margin-left:auto;">'
            f'These predictions were saved pre-market and will be auto-verified against '
            f'today\'s EOD structure — they feed brain recalibration.</span></div>'
            f'<div style="display:flex;flex-wrap:wrap;gap:8px;">',
            unsafe_allow_html=True,
        )

        _struct_colors = {
            "Trending Up":       ("#4caf50", "▲"),
            "Trending Down":     ("#ef5350", "▼"),
            "At IB High":        ("#ffa726", "◆"),
            "At IB Low":         ("#29b6f6", "◆"),
            "Inside IB":         ("#9e9e9e", "◼"),
            "Extended Above IB": ("#7c4dff", "▲"),
            "Extended Below IB": ("#ff5252", "▼"),
        }
        _conf_colors = {
            "HIGH":     ("#4caf50", "🟢"),
            "MODERATE": ("#ffa726", "🟡"),
            "LOW":      ("#9e9e9e", "⚪"),
        }
        _has_brief = (
            "entry_zone_low" in _pm_preds_df.columns and
            _pm_preds_df["entry_zone_low"].notna().any()
        )

        if _has_brief:
            # Full setup brief cards — one per row
            st.markdown("</div></div>", unsafe_allow_html=True)
            for _, _pr in _pm_preds_df.iterrows():
                _ptk  = _pr.get("ticker", "")
                _pstr = _pr.get("predicted_structure", "—")
                _pver = bool(_pr.get("verified", False))
                _pcor = str(_pr.get("correct", ""))
                _pclr, _pico = _struct_colors.get(_pstr, ("#888", "●"))
                _conf = str(_pr.get("confidence_label") or "LOW")
                _cclr, _cico = _conf_colors.get(_conf, ("#9e9e9e", "⚪"))
                _elo  = _pr.get("entry_zone_low")
                _ehi  = _pr.get("entry_zone_high")
                _stop = _pr.get("stop_level")
                _tgts = _pr.get("targets") or []
                _trig = str(_pr.get("entry_trigger") or "—")
                _pat  = str(_pr.get("pattern") or "")
                _nl   = _pr.get("pattern_neckline")
                _wrc  = str(_pr.get("win_rate_context") or "No win rate data yet.")
                _wrp  = _pr.get("win_rate_pct")
                _vstamp = ("✅ Correct" if _pver and _pcor == "✅"
                           else "❌ Incorrect" if _pver
                           else "⏳ Unverified")
                _vstamp_clr = "#4caf50" if "Correct" in _vstamp else "#ef5350" if "Incorrect" in _vstamp else "#555"
                _entry_str = (f"${_elo:.4f} – ${_ehi:.4f}"
                              if _elo is not None and _ehi is not None else "—")
                _stop_str  = f"${_stop:.4f}" if _stop is not None else "—"
                _tgt_str   = "  ·  ".join(f"R{i+1} ${t:.4f}" for i, t in enumerate(_tgts[:3]))
                _pat_str   = f"{_pat}  neckline ${_nl:.4f}" if _pat and _nl else (_pat or "")
                _wr_display = f"  ·  {_cico} {_conf} confidence ({_wrp:.0f}%)" if _wrp else f"  ·  {_cico} {_conf} confidence"
                st.markdown(
                    f'<div style="background:#071b2e;border:1px solid #1e3a5f;border-left:4px solid {_pclr};'
                    f'border-radius:8px;padding:12px 16px;margin-bottom:10px;">'
                    f'<div style="display:flex;align-items:center;gap:10px;margin-bottom:8px;">'
                    f'<span style="font-size:15px;font-weight:800;color:#fff;">{_ptk}</span>'
                    f'<span style="background:{_pclr}22;border:1px solid {_pclr}66;border-radius:5px;'
                    f'padding:2px 8px;font-size:11px;color:{_pclr};">{_pico} {_pstr}</span>'
                    + (f'<span style="background:#1a1a1a;border:1px solid #333;border-radius:5px;'
                       f'padding:2px 8px;font-size:10px;color:#aaa;">{_pat_str}</span>' if _pat_str else "")
                    + f'<span style="margin-left:auto;font-size:10px;color:{_vstamp_clr};">{_vstamp}</span>'
                    f'</div>'
                    f'<div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:8px;margin-bottom:8px;">'
                    f'<div style="background:#0d2a42;border-radius:5px;padding:6px 10px;">'
                    f'<div style="font-size:9px;color:#555;text-transform:uppercase;margin-bottom:3px;">Entry Zone</div>'
                    f'<div style="font-size:12px;color:#29b6f6;font-weight:600;">{_entry_str}</div></div>'
                    f'<div style="background:#0d2a42;border-radius:5px;padding:6px 10px;">'
                    f'<div style="font-size:9px;color:#555;text-transform:uppercase;margin-bottom:3px;">Stop</div>'
                    f'<div style="font-size:12px;color:#ef5350;font-weight:600;">{_stop_str}</div></div>'
                    f'<div style="background:#0d2a42;border-radius:5px;padding:6px 10px;">'
                    f'<div style="font-size:9px;color:#555;text-transform:uppercase;margin-bottom:3px;">Targets</div>'
                    f'<div style="font-size:11px;color:#4caf50;font-weight:600;">{_tgt_str or "—"}</div></div></div>'
                    f'<div style="font-size:10px;color:#aaa;margin-bottom:4px;line-height:1.4;">'
                    f'<span style="color:#ffa726;font-weight:600;">Trigger:</span> {_trig}</div>'
                    f'<div style="font-size:10px;color:#7986cb;line-height:1.4;">'
                    f'<span style="font-weight:600;">Win Rate:</span> {_wrc}{_wr_display}</div>'
                    f'</div>',
                    unsafe_allow_html=True,
                )
        else:
            # Legacy: simple chips (schema not yet migrated)
            _chips_html = ""
            for _, _pr in _pm_preds_df.iterrows():
                _ptk  = _pr.get("ticker", "")
                _pstr = _pr.get("predicted_structure", "—")
                _pver = bool(_pr.get("verified", False))
                _pcor = str(_pr.get("correct", ""))
                _pclr, _pico = _struct_colors.get(_pstr, ("#888", "●"))
                _vstamp = (f' <span style="color:#4caf50;font-size:10px;">✅</span>' if _pver and _pcor == "✅"
                           else f' <span style="color:#ef5350;font-size:10px;">❌</span>' if _pver
                           else "")
                _chips_html += (
                    f'<div style="background:#0d2a42;border:1px solid {_pclr}44;border-radius:6px;'
                    f'padding:5px 12px;font-size:12px;">'
                    f'<span style="font-weight:700;color:#fff;">{_ptk}</span>'
                    f'<span style="color:{_pclr};margin-left:6px;">{_pico} {_pstr}</span>'
                    f'{_vstamp}</div>'
                )
            st.markdown(_chips_html + "</div></div>", unsafe_allow_html=True)

        _pm_col1, _pm_col2 = st.columns([1, 1])
        with _pm_col1:
            if _pm_col1.button(
                f"🔍 Verify EOD Outcomes ({_pm_pending} pending)",
                use_container_width=True,
                key="eod_verify_premarket_btn",
                disabled=(_pm_pending == 0),
            ):
                _vak  = st.session_state.get("api_key", "")
                _vask = st.session_state.get("secret_key", "")
                if not _vak or not _vask:
                    st.warning("Enter your Alpaca API keys in Settings first.")
                else:
                    with st.spinner("Verifying predictions against today's EOD bar data..."):
                        _vr = verify_watchlist_predictions(
                            api_key=_vak, secret_key=_vask,
                            user_id=_uid, pred_date=date.today(),
                        )
                    _vc = _vr.get("correct", 0)
                    _vt = _vr.get("verified", 0)
                    _va = _vr.get("accuracy", 0)
                    if _vt > 0:
                        _vcol = "#4caf50" if _va >= 60 else "#ffa726" if _va >= 40 else "#ef5350"
                        st.success(f"Verified {_vt} predictions — {_vc}/{_vt} correct ({_va:.0f}% accuracy). Brain recalibration queued.")
                    else:
                        st.info(_vr.get("error", "No predictions to verify for today."))
                    st.rerun()
        with _pm_col2:
            if _pm_col2.button(
                "📋 Use These Tickers in EOD Note",
                use_container_width=True,
                key="eod_use_pm_tickers_btn",
            ):
                st.session_state["eod_watch_tickers"] = ", ".join(_pm_tickers)
                st.rerun()
    else:
        st.info(
            "📋 **No pre-market watchlist predictions on file for today.** "
            "Run the Gap Scanner, expand any ticker, and save a prediction — "
            "it will appear here at end of day for one-click verification.",
            icon=None,
        )

    # ── One-time Supabase schema helper ──────────────────────────────────────
    with st.expander("⚙️ First-time Supabase setup (run once in your Supabase SQL editor)", expanded=False):
        st.markdown(
            "If images or multi-ticker entries aren't saving to the cloud, "
            "paste this SQL into your **Supabase → SQL Editor** and click **Run**. "
            "You only need to do this once."
        )
        st.warning(
            "**Run each block separately** in the SQL editor — paste one, click Run, then paste the next."
        )
        st.caption("**Step 1 — Drop old constraint** (run this first on its own)")
        st.code(
            "ALTER TABLE eod_notes DROP CONSTRAINT IF EXISTS eod_notes_user_id_note_date_key;",
            language="sql",
        )
        st.caption("**Step 2 — Add correct constraint** (run after Step 1 succeeds)")
        st.code(
            "ALTER TABLE eod_notes ADD CONSTRAINT eod_notes_unique_ticker\n"
            "    UNIQUE (user_id, note_date, watch_tickers);",
            language="sql",
        )
        st.caption("**Step 3 — Add outcome column**")
        st.code(
            "ALTER TABLE eod_notes ADD COLUMN IF NOT EXISTS outcome JSONB DEFAULT '{}';",
            language="sql",
        )
        st.caption("**Step 4 — User preferences table**")
        st.code(
            "CREATE TABLE IF NOT EXISTS user_preferences (\n"
            "    user_id TEXT PRIMARY KEY,\n"
            "    prefs   JSONB DEFAULT '{}',\n"
            "    updated_at TIMESTAMPTZ DEFAULT NOW()\n"
            ");",
            language="sql",
        )

    # ── Edit-mode prefill: copy pending values into widget keys before render ──
    if st.session_state.get("_eod_prefill_pending"):
        _pf = st.session_state.pop("_eod_prefill_pending")
        st.session_state["eod_note_date"]         = _pf["date"]
        st.session_state["eod_watch_tickers"]     = _pf["ticker"]
        st.session_state["eod_notes_text"]        = _pf["notes"]
        st.session_state["_eod_edit_images"]      = _pf["images"]
        st.session_state["_eod_edit_orig_date"]   = str(_pf["date"])
        st.session_state["_eod_edit_orig_ticker"] = _pf["ticker"]
        # Reset the uploader so stale files from a previous edit don't carry over
        st.session_state["_eod_upload_gen"] = st.session_state.get("_eod_upload_gen", 0) + 1

    # ── Edit-mode banner ──────────────────────────────────────────────────────
    _edit_imgs = st.session_state.get("_eod_edit_images", [])
    if _edit_imgs or st.session_state.get("_eod_edit_active"):
        st.info("✏️ **Edit mode** — modify the fields below and hit Save Review to update this entry. "
                "Existing images are kept unless you clear them.")

    _eod_col1, _eod_col2 = st.columns([1, 2])
    with _eod_col1:
        _eod_date = st.date_input("Review Date", value=date.today(), key="eod_note_date")
    with _eod_col2:
        _eod_watch = st.text_input(
            "👀 Watch Tomorrow",
            placeholder="NVDA, GME, AMC — tickers to monitor at open",
            key="eod_watch_tickers",
        )

    _eod_notes = st.text_area(
        "📝 Notes — what happened today / key levels / thesis for tomorrow",
        height=130,
        placeholder="e.g. NVDA rejected VWAP twice, watching $118.50 reclaim. "
                    "GME broke out of balance — watch for continuation above $22.",
        key="eod_notes_text",
    )

    _upload_gen = st.session_state.get("_eod_upload_gen", 0)
    _eod_uploads = st.file_uploader(
        "📷 Chart Images (up to 5, PNG/JPG) — leave blank to keep existing images",
        type=["png", "jpg", "jpeg"],
        accept_multiple_files=True,
        key=f"eod_image_uploader_{_upload_gen}",
    )

    # Show existing images that will be kept (edit mode)
    if _edit_imgs:
        st.caption(f"📎 {len(_edit_imgs)} existing image(s) attached — uploading new ones replaces them:")
        _prev_cols = st.columns(min(len(_edit_imgs), 3))
        for _pi, _pimg in enumerate(_edit_imgs):
            if _pimg.get("data"):
                _prev_cols[_pi % 3].image(
                    f"data:image/jpeg;base64,{_pimg['data']}",
                    caption=_pimg.get("filename", ""),
                    use_container_width=True,
                )
        if st.button("🗑 Clear existing images", key="eod_clear_imgs"):
            st.session_state["_eod_edit_images"] = []
            st.rerun()

    _eod_save_col, _eod_load_col = st.columns(2)
    if _eod_save_col.button("💾 Save Review", use_container_width=True, key="eod_save_btn"):
        # New uploads override existing; if no new uploads, keep existing
        if _eod_uploads:
            _imgs_payload = []
            for _f in _eod_uploads[:5]:
                try:
                    _b64 = _compress_image_b64(_f.read())
                    _imgs_payload.append({"filename": _f.name, "data": _b64, "caption": ""})
                except Exception as _img_err:
                    import traceback as _tb
                    print(f"Image compress error for {_f.name}: {_img_err}\n{_tb.format_exc()}")
            print(f"EOD save: {len(_eod_uploads)} uploads → {len(_imgs_payload)} compressed")
        else:
            _imgs_payload = st.session_state.get("_eod_edit_images", [])
            print(f"EOD save: no new uploads, using {len(_imgs_payload)} existing images from session")

        # If ticker or date changed during edit, delete the old entry first
        _orig_date   = st.session_state.get("_eod_edit_orig_date", "")
        _orig_ticker = st.session_state.get("_eod_edit_orig_ticker", "")
        if _orig_date:
            _new_ticker_str = _eod_watch.strip() if _eod_watch else ""
            if (_orig_ticker.strip() != _new_ticker_str
                    or _orig_date != str(_eod_date)):
                delete_eod_note(_orig_date, _orig_ticker, user_id=_uid)

        _ok, _src = save_eod_note(
            note_date     = _eod_date,
            notes         = _eod_notes,
            watch_tickers = _eod_watch,
            images_b64    = _imgs_payload,
            user_id       = _uid,
        )
        if _ok:
            for _k in ("_eod_edit_images", "_eod_edit_active",
                       "_eod_edit_orig_date", "_eod_edit_orig_ticker"):
                st.session_state.pop(_k, None)
            # Bump upload gen so the file uploader resets completely
            st.session_state["_eod_upload_gen"] = st.session_state.get("_eod_upload_gen", 0) + 1
            if _src == "supabase":
                st.success(f"✅ Review saved for {_eod_date}")
            else:
                st.warning("⚠️ Saved locally — will sync to cloud on next load when Supabase is available.")
            # Auto-reload so changes appear immediately without manual button click
            _raw_notes = load_eod_notes(user_id=_uid, limit=100)
            st.session_state["_eod_notes_loaded"] = enrich_eod_from_journal(_raw_notes, df)
            st.rerun()
        else:
            st.error("❌ Save failed completely. Contact support.")

    if _eod_load_col.button("📂 Load Past Reviews", use_container_width=True, key="eod_load_btn"):
        _raw_notes = load_eod_notes(user_id=_uid, limit=100)
        st.session_state["_eod_notes_loaded"] = enrich_eod_from_journal(_raw_notes, df)

    # ── Display loaded notes ──────────────────────────────────────────────────
    import re as _re
    _loaded_notes = st.session_state.get("_eod_notes_loaded")
    if _loaded_notes is not None:
        if not _loaded_notes:
            st.info("No reviews found. Any reviews saved before today's database setup weren't persisted — re-enter them above and hit Save Review.")
        else:
            # ── Accuracy summary ──────────────────────────────────────────────
            _verified_notes = [_n for _n in _loaded_notes if _n.get("outcome")]
            if _verified_notes:
                _total_hits = 0
                _total_checks = 0
                for _vn in _verified_notes:
                    import json as _j
                    _oc = _vn["outcome"]
                    if isinstance(_oc, str):
                        try: _oc = _j.loads(_oc)
                        except: _oc = {}
                    for _tk, _tr in _oc.items():
                        if isinstance(_tr, dict) and "above_hit" in _tr:
                            if _tr.get("above_hit") is not None:
                                _total_checks += 1
                                if _tr["above_hit"]: _total_hits += 1
                        if isinstance(_tr, dict) and "below_hit" in _tr:
                            if _tr.get("below_hit") is not None:
                                _total_checks += 1
                                if _tr["below_hit"]: _total_hits += 1
                _hit_pct = (_total_hits / _total_checks * 100) if _total_checks else 0
                _hit_color = "#4caf50" if _hit_pct >= 60 else "#ffa726" if _hit_pct >= 40 else "#ef5350"
                st.markdown(
                    f'<div style="background:#12122299;border:1px solid #2a2a4a;border-radius:8px;'
                    f'padding:12px 18px;margin-bottom:14px;display:flex;gap:32px;align-items:center;">'
                    f'<div><span style="font-size:11px;color:#888;text-transform:uppercase;'
                    f'letter-spacing:1px;">Level Hit Rate</span><br>'
                    f'<span style="font-size:26px;font-weight:800;color:{_hit_color};">'
                    f'{_hit_pct:.0f}%</span>'
                    f'<span style="font-size:12px;color:#666;margin-left:6px;">'
                    f'{_total_hits}/{_total_checks} levels touched</span></div>'
                    f'<div><span style="font-size:11px;color:#888;text-transform:uppercase;'
                    f'letter-spacing:1px;">Reviews Verified</span><br>'
                    f'<span style="font-size:22px;font-weight:700;color:#90caf9;">'
                    f'{len(_verified_notes)}</span>'
                    f'<span style="font-size:12px;color:#666;"> / {len(_loaded_notes)}</span></div>'
                    f'</div>',
                    unsafe_allow_html=True,
                )

            for _ni_idx, _n in enumerate(_loaded_notes):
                _nd  = _n.get("note_date", "")
                _nw  = _n.get("watch_tickers", "")
                _nt  = _n.get("notes", "")
                _nim = _n.get("images", [])
                _noc = _n.get("outcome", {})
                if isinstance(_noc, str):
                    try:
                        import json as _j2; _noc = _j2.loads(_noc)
                    except: _noc = {}
                _has_outcome = bool(_noc)

                # Build header status badge
                _outcome_badge = ""
                if _has_outcome:
                    _hits = sum(1 for _r in _noc.values()
                                if isinstance(_r, dict) and (_r.get("above_hit") or _r.get("below_hit")))
                    _outcome_badge = f"  ✅ Verified ({_hits} hit)" if _hits else "  🔍 Verified"

                with st.expander(
                    f"📅 {_nd}" + (f"  ·  👀 {_nw}" if _nw else "") + _outcome_badge,
                    expanded=True
                ):
                    # ── Journal merge badge (shown when journal data found) ────
                    _jctx = _n.get("_journal_ctx", {})
                    if _jctx:
                        _jbadges = []
                        for _jtk, _jd in _jctx.items():
                            _parts = []
                            if _jd.get("tcs") is not None:
                                _parts.append(f"TCS {float(_jd['tcs']):.0f}")
                            if _jd.get("rvol") is not None:
                                _parts.append(f"RVOL {float(_jd['rvol']):.1f}x")
                            if _jd.get("structure"):
                                _parts.append(str(_jd["structure"]))
                            if _jd.get("grade"):
                                _gc = {"A":"#4caf50","B":"#26a69a","C":"#ffa726","F":"#ef5350"}.get(str(_jd["grade"]),"#888")
                                _parts.append(f'<span style="color:{_gc};font-weight:800;">Grade {_jd["grade"]}</span>')
                            if _parts:
                                _jbadges.append(
                                    f'<span style="font-weight:700;color:#90caf9;">{_jtk}</span>'
                                    f' &nbsp;{"  ·  ".join(_parts)}'
                                )
                        if _jbadges:
                            st.markdown(
                                f'<div style="background:#0d1b2a;border:1px solid #1e3a5f;'
                                f'border-left:3px solid #29b6f6;border-radius:6px;'
                                f'padding:7px 14px;margin-bottom:10px;font-size:12px;color:#aaa;">'
                                f'<span style="font-size:10px;text-transform:uppercase;'
                                f'letter-spacing:1px;color:#555;">📊 Journal data auto-merged</span><br>'
                                + "<br>".join(_jbadges)
                                + "</div>",
                                unsafe_allow_html=True,
                            )
                    if _nw:
                        _above = _re.findall(r'[Pp]rice\s+[Aa]bove\s+([\$]?[\d\.]+)', _nt)
                        _below = _re.findall(r'[Pp]rice\s+[Bb]elow\s+([\$]?[\d\.]+)', _nt)
                        _price_chips = "".join([
                            f'<span style="display:inline-block;background:#1e1e3a;border:1px solid #5c6bc0;'
                            f'color:#9fa8da;font-size:11px;font-weight:600;padding:2px 8px;'
                            f'border-radius:10px;margin-left:6px;">Above {v}</span>'
                            for v in _above
                        ] + [
                            f'<span style="display:inline-block;background:#1e1e3a;border:1px solid #5c6bc0;'
                            f'color:#9fa8da;font-size:11px;font-weight:600;padding:2px 8px;'
                            f'border-radius:10px;margin-left:6px;">Below {v}</span>'
                            for v in _below
                        ])
                        st.markdown(
                            f'<div style="background:#12122299;border-left:3px solid #90caf9;'
                            f'padding:8px 14px;border-radius:4px;margin-bottom:10px;">'
                            f'<span style="font-size:11px;color:#888;text-transform:uppercase;'
                            f'letter-spacing:1px;">Watch Tomorrow</span><br>'
                            f'<span style="color:#90caf9;font-weight:700;">{_nw}</span>'
                            f'{_price_chips}</div>',
                            unsafe_allow_html=True,
                        )
                    if _nt:
                        st.markdown(
                            f'<div style="white-space:pre-wrap;font-size:13px;'
                            f'color:#e0e0e0;line-height:1.6;">{_nt}</div>',
                            unsafe_allow_html=True,
                        )
                    if _nim:
                        _img_cols = st.columns(min(len(_nim), 3))
                        for _ic, _img in enumerate(_nim):
                            _img_data = _img.get("data", "")
                            if _img_data:
                                _col = _img_cols[_ic % 3]
                                _thumb, _ = _col.columns([1, 1])
                                _thumb.image(
                                    f"data:image/jpeg;base64,{_img_data}",
                                    caption=_img.get("filename", ""),
                                    use_container_width=True,
                                )
                                import base64 as _b64mod
                                _thumb.download_button(
                                    label="⬇ Download",
                                    data=_b64mod.b64decode(_img_data),
                                    file_name=_img.get("filename", f"chart_{_ic+1}.jpg"),
                                    mime="image/jpeg",
                                    key=f"dl_img_{_ni_idx}_{_ic}",
                                    use_container_width=True,
                                )

                    # ── Outcome verification panel ────────────────────────────
                    st.markdown("<div style='margin-top:10px;'></div>", unsafe_allow_html=True)
                    _vkey = f"eod_verify_{_nd}_{_nw.replace(' ','_')}_{_ni_idx}"
                    # Parse individual tickers for the selector
                    _ticker_list = [t.strip().upper() for t in
                                    _re.split(r"[,\s]+", _nw) if t.strip()] if _nw else []
                    _sel_tickers = st.multiselect(
                        "Select tickers to verify",
                        options=_ticker_list,
                        default=_ticker_list,
                        key=f"sel_{_vkey}",
                        label_visibility="collapsed",
                        placeholder="Choose tickers…",
                    ) if _ticker_list else []
                    _vcol1, _vcol2 = st.columns([1, 1])
                    if _vcol1.button("📊 Verify Next Day", key=f"btn_{_vkey}",
                                     use_container_width=True,
                                     help="Fetch next trading day's actual price action"):
                        if not _sel_tickers:
                            st.warning("Select at least one ticker above.")
                        else:
                            _sel_str = ", ".join(_sel_tickers)
                            with st.spinner(f"Fetching next-day data for {_sel_str}…"):
                                _vresult = verify_eod_predictions(
                                    _nd, _sel_str, _nt,
                                    st.session_state.get("alpaca_key", ""),
                                    st.session_state.get("alpaca_secret", ""),
                                )
                            st.session_state[_vkey] = _vresult

                    # Show stored outcome OR freshly fetched result
                    _show_outcome = st.session_state.get(_vkey) or (_noc if _noc else None)
                    if _show_outcome and isinstance(_show_outcome, dict):
                        for _vticker, _vr in _show_outcome.items():
                            if not isinstance(_vr, dict): continue
                            if _vr.get("no_data") or _vr.get("error"):
                                st.warning(f"**{_vticker}**: No data for {_vr.get('next_date','?')} — market closed or pre-market.")
                                continue
                            _v_nd   = _vr.get("next_date", "")
                            _v_h    = _vr.get("high", 0)
                            _v_l    = _vr.get("low", 0)
                            _v_o    = _vr.get("open", 0)
                            _v_c    = _vr.get("close", 0)
                            _v_la   = _vr.get("levels_above", [])
                            _v_lb   = _vr.get("levels_below", [])
                            _v_ah   = _vr.get("above_hit")
                            _v_bh   = _vr.get("below_hit")
                            # Build level result chips
                            _lchips = ""
                            for _lv in _v_la:
                                _hit = _v_h >= _lv
                                _c = "#4caf50" if _hit else "#ef5350"
                                _lchips += (f'<span style="display:inline-block;background:{_c}22;'
                                            f'border:1px solid {_c};color:{_c};font-size:11px;'
                                            f'font-weight:600;padding:2px 8px;border-radius:10px;'
                                            f'margin:2px 4px;">Above {_lv} {"✓" if _hit else "✗"}</span>')
                            for _lv in _v_lb:
                                _hit = _v_l <= _lv
                                _c = "#4caf50" if _hit else "#ef5350"
                                _lchips += (f'<span style="display:inline-block;background:{_c}22;'
                                            f'border:1px solid {_c};color:{_c};font-size:11px;'
                                            f'font-weight:600;padding:2px 8px;border-radius:10px;'
                                            f'margin:2px 4px;">Below {_lv} {"✓" if _hit else "✗"}</span>')
                            st.markdown(
                                f'<div style="background:#0d1117;border:1px solid #2a2a4a;'
                                f'border-radius:8px;padding:10px 14px;margin:6px 0;">'
                                f'<span style="font-size:14px;font-weight:700;color:#e0e0e0;">'
                                f'{_vticker}</span>'
                                f'<span style="font-size:11px;color:#666;margin-left:8px;">'
                                f'{_v_nd}</span><br>'
                                f'<span style="font-size:12px;color:#aaa;">'
                                f'O {_v_o}  H <b style="color:#4caf50">{_v_h}</b>  '
                                f'L <b style="color:#ef5350">{_v_l}</b>  C {_v_c}</span><br>'
                                f'<div style="margin-top:6px;">{_lchips}</div>'
                                f'</div>',
                                unsafe_allow_html=True,
                            )
                        # Save outcome button
                        if _vcol2.button("💾 Save Outcome", key=f"save_{_vkey}",
                                         use_container_width=True):
                            _saved_oc = save_eod_outcome(_nd, _show_outcome, user_id=_uid)
                            if _saved_oc:
                                # ── Feed predictive probability engine ────────────
                                try:
                                    _oc_hits = sum(
                                        1 for _rr in _show_outcome.values()
                                        if isinstance(_rr, dict)
                                        and (_rr.get("above_hit") or _rr.get("below_hit"))
                                    )
                                    _oc_win = _oc_hits > 0
                                    # Pick first ticker from the watch list
                                    _first_tk = (str(_nw or "").split(",")[0].strip().upper()
                                                 if _nw else "")
                                    if _first_tk and _uid:
                                        log_signal_outcome(
                                            user_id=_uid,
                                            ticker=_first_tk,
                                            trade_date=_nd,
                                            outcome_win=_oc_win,
                                            outcome_pct=0.0,
                                        )
                                except Exception:
                                    pass
                                st.success("Outcome saved — contributes to your hit rate!")
                                st.session_state["_eod_notes_loaded"] = None
                                st.rerun()
                            else:
                                st.warning("Save failed — check Supabase connection.")

                    # ── Edit this entry ────────────────────────────────────────
                    st.markdown("<div style='margin-top:6px;'></div>", unsafe_allow_html=True)
                    if st.button("✏️ Edit this entry", key=f"edit_entry_{_ni_idx}",
                                 use_container_width=False,
                                 help="Load this review into the form above to edit it"):
                        import datetime as _dtmod
                        try:
                            _edit_date = _dtmod.date.fromisoformat(str(_nd))
                        except Exception:
                            _edit_date = date.today()
                        st.session_state["_eod_prefill_pending"] = {
                            "date":   _edit_date,
                            "ticker": _nw or "",
                            "notes":  _nt or "",
                            "images": _nim or [],
                        }
                        st.session_state["_eod_edit_active"] = True
                        st.rerun()

    # ── Supabase setup SQL ────────────────────────────────────────────────────
    with st.expander("⚙️ First-time setup — create eod_notes table", expanded=False):
        st.code(
            "CREATE TABLE IF NOT EXISTS eod_notes (\n"
            "  id           BIGSERIAL PRIMARY KEY,\n"
            "  user_id      TEXT,\n"
            "  note_date    DATE,\n"
            "  notes        TEXT DEFAULT '',\n"
            "  watch_tickers TEXT DEFAULT '',\n"
            "  images       JSONB DEFAULT '[]',\n"
            "  updated_at   TIMESTAMPTZ DEFAULT NOW(),\n"
            "  UNIQUE(user_id, note_date)\n"
            ");",
            language="sql",
        )
        st.caption("Run this once in your Supabase SQL editor.")


# ══════════════════════════════════════════════════════════════════════════════
# CHART & RENDER
# ══════════════════════════════════════════════════════════════════════════════

def build_chart(df, ib_high, ib_low, bin_centers, vap, poc_price, title,
                target_zones=None, position=None):
    # ── Reindex to a full 9:30–16:00 minute grid so the chart ALWAYS
    #    anchors at 9:30 ET, even for thinly-traded small-caps whose first
    #    real trade doesn't occur until 9:31 or later.
    def _et_label(ts):
        try:
            return pd.Timestamp(ts).tz_convert(EASTERN).strftime("%H:%M ET")
        except Exception:
            return str(ts)[-8:]

    # Keep a handle to the original (real) bars before we expand the index
    _real_df = df.copy()
    _current_price = float(_real_df["close"].dropna().iloc[-1]) if not _real_df.empty else None

    try:
        _first = df.index[0]
        _last_real = df.index[-1]
        _d = _first.date()
        _open_et  = EASTERN.localize(datetime(_d.year, _d.month, _d.day,  9, 30))
        _close_et = EASTERN.localize(datetime(_d.year, _d.month, _d.day, 16,  0))
        _grid_end = min(_last_real, _close_et)
        _full_idx = pd.date_range(_open_et, _grid_end, freq="1min")
        df = df.reindex(_full_idx)
    except Exception:
        pass

    x_labels = [_et_label(ts) for ts in df.index]
    x0, x1   = x_labels[0], x_labels[-1]

    # ── Value Area (70 % of session volume) ──────────────────────────────────
    val_price, vah_price = _compute_value_area(bin_centers, vap)

    fig = make_subplots(rows=1, cols=2, column_widths=[0.75, 0.25],
                        shared_yaxes=True, horizontal_spacing=0.01)

    # ── Candlestick ───────────────────────────────────────────────────────────
    fig.add_trace(go.Candlestick(
        x=x_labels, open=df["open"], high=df["high"], low=df["low"], close=df["close"],
        name="Price", increasing_line_color="#26a69a", decreasing_line_color="#ef5350",
        increasing_fillcolor="#26a69a", decreasing_fillcolor="#ef5350",
        showlegend=False,
    ), row=1, col=1)

    # ── Value Area shaded band on price chart (very subtle) ───────────────────
    if val_price is not None and vah_price is not None:
        fig.add_hrect(
            y0=val_price, y1=vah_price,
            fillcolor="rgba(92, 107, 192, 0.06)",
            line_width=0,
            row=1, col=1,
        )

    # ── Key Level lines — all with right-edge price labels ────────────────────
    # POC — gold solid, thickest
    fig.add_trace(go.Scatter(
        x=[x0, x1], y=[poc_price, poc_price],
        mode="lines+text",
        name="POC",
        line=dict(color="rgba(255,215,0,1)", width=2.5),
        text=["", f"  POC  ${poc_price:.2f}"],
        textposition="middle right",
        textfont=dict(color="rgba(255,215,0,0.95)", size=11, family="monospace"),
        legendrank=10,
    ), row=1, col=1)

    # IB High — solid green
    if ib_high is not None and ib_low is not None:
        fig.add_trace(go.Scatter(
            x=[x0, x1], y=[ib_high, ib_high],
            mode="lines+text",
            name="IB High",
            line=dict(color="#00e676", width=2.0),
            text=["", f"  IB Hi ${ib_high:.2f}"],
            textposition="middle right",
            textfont=dict(color="#00e676", size=11, family="monospace"),
            legendrank=20,
        ), row=1, col=1)
        fig.add_trace(go.Scatter(
            x=[x0, x1], y=[ib_low, ib_low],
            mode="lines+text",
            name="IB Low",
            line=dict(color="#ff5252", width=2.0),
            text=["", f"  IB Lo ${ib_low:.2f}"],
            textposition="middle right",
            textfont=dict(color="#ff5252", size=11, family="monospace"),
            legendrank=30,
        ), row=1, col=1)

    # VAH / VAL — thin blue dashed, clearly labelled
    if vah_price is not None:
        fig.add_trace(go.Scatter(
            x=[x0, x1], y=[vah_price, vah_price],
            mode="lines+text",
            name="VAH",
            line=dict(color="#64b5f6", width=1.2, dash="dot"),
            text=["", f"  VAH  ${vah_price:.2f}"],
            textposition="middle right",
            textfont=dict(color="#64b5f6", size=10, family="monospace"),
            legendrank=40,
        ), row=1, col=1)
    if val_price is not None:
        fig.add_trace(go.Scatter(
            x=[x0, x1], y=[val_price, val_price],
            mode="lines+text",
            name="VAL",
            line=dict(color="#64b5f6", width=1.2, dash="dot"),
            text=["", f"  VAL  ${val_price:.2f}"],
            textposition="middle right",
            textfont=dict(color="#64b5f6", size=10, family="monospace"),
            legendrank=50,
        ), row=1, col=1)

    # Current Price — white dotted
    if _current_price is not None:
        fig.add_trace(go.Scatter(
            x=[x0, x1], y=[_current_price, _current_price],
            mode="lines+text",
            name="Last Price",
            line=dict(color="rgba(220,220,220,0.8)", width=1.0, dash="dot"),
            text=["", f"  ▶ ${_current_price:.2f}"],
            textposition="middle right",
            textfont=dict(color="#e0e0e0", size=11, family="monospace"),
            legendrank=60,
        ), row=1, col=1)

    # ── VWAP line — bright orange dashed, with right-edge label ──────────────
    if "vwap" in _real_df.columns:
        try:
            # Reindex VWAP onto the full minute grid (NaN gaps stay NaN — no fill)
            _vwap_series = _real_df["vwap"].reindex(df.index)
            _vwap_vals   = _vwap_series.tolist()
            _vwap_last   = _vwap_series.dropna().iloc[-1] if not _vwap_series.dropna().empty else None
            # Label only at the last real bar; blanks elsewhere keep the line clean
            _vwap_text   = [""] * len(x_labels)
            if _vwap_last is not None:
                _vwap_text[-1] = f"  VWAP ${_vwap_last:.2f}"
            fig.add_trace(go.Scatter(
                x=x_labels,
                y=_vwap_vals,
                mode="lines+text",
                name="VWAP",
                line=dict(color="#ce93d8", width=1.6),
                text=_vwap_text,
                textposition="middle right",
                textfont=dict(color="#ce93d8", size=11, family="monospace"),
                connectgaps=False,
                legendrank=55,
            ), row=1, col=1)
        except Exception:
            pass

    # ── Dynamic Target Zone overlay ───────────────────────────────────────────
    lvn_idx_to_highlight = None
    if target_zones:
        for tz in target_zones:
            tp = tz["price"]
            tc = tz["color"]
            tl = tz["label"]
            fig.add_trace(go.Scatter(
                x=[x0, x1], y=[tp, tp], mode="lines+text",
                name=tl,
                line=dict(color=tc, width=1.4, dash="dot"),
                text=["", f"  {tl}"],
                textposition="top right",
                textfont=dict(color=tc, size=10),
                showlegend=False,
            ), row=1, col=1)
            if tz["type"] == "trend_extension":
                band = tp * 0.005
                fig.add_shape(
                    type="rect", xref="paper", x0=0, x1=0.75,
                    y0=tp - band, y1=tp + band,
                    fillcolor=tc + "28",
                    line=dict(width=0),
                    row=1, col=1,
                )
            if tz["type"] == "gap_fill" and "lvn_idx" in tz:
                lvn_idx_to_highlight = tz["lvn_idx"]

    # ── Volume Profile — intensity-based gradient coloring ────────────────────
    bw = float(bin_centers[1] - bin_centers[0]) if len(bin_centers) > 1 else 0.01
    max_vap = float(np.max(vap)) if len(vap) > 0 and np.max(vap) > 0 else 1.0
    colors = []
    for i, (p, v) in enumerate(zip(bin_centers, vap)):
        norm = v / max_vap
        is_poc = abs(p - poc_price) < bw * 0.5
        is_lvn = (lvn_idx_to_highlight is not None and i == lvn_idx_to_highlight)
        in_va  = (val_price is not None and vah_price is not None
                  and val_price <= p <= vah_price)

        if is_poc:
            colors.append("rgba(255,215,0,1.0)")         # bright gold
        elif is_lvn:
            colors.append("rgba(255,235,59,0.88)")       # yellow LVN marker
        elif norm > 0.55:
            # High Volume Node — amber → deep orange
            g = int(165 - (norm - 0.55) / 0.45 * 90)
            a = min(1.0, 0.80 + norm * 0.20)
            colors.append(f"rgba(255,{max(75,g)},10,{a:.2f})")
        elif in_va:
            # Inside Value Area — blue-indigo, brighter with more volume
            r = int(80 + norm * 80)
            g = int(120 + norm * 50)
            b = int(210 - norm * 30)
            a = 0.60 + norm * 0.30
            colors.append(f"rgba({r},{g},{b},{a:.2f})")
        else:
            # Outside Value Area — muted slate, barely visible
            b_ch = int(115 + norm * 30)
            a = 0.28 + norm * 0.30
            colors.append(f"rgba(55,70,{b_ch},{a:.2f})")

    fig.add_trace(go.Bar(
        x=vap, y=bin_centers, orientation="h",
        name="Vol Profile", marker_color=colors, opacity=0.95,
        showlegend=False,
    ), row=1, col=2)

    # ── POC tick on the volume profile panel ──────────────────────────────────
    fig.add_trace(go.Scatter(
        x=[max_vap * 1.02], y=[poc_price],
        mode="text",
        text=["◀ POC"],
        textfont=dict(color="rgba(255,215,0,0.85)", size=10, family="monospace"),
        showlegend=False,
    ), row=1, col=2)

    # ── Position overlay ──────────────────────────────────────────────────────
    if position and position.get("in"):
        avg_entry  = position["avg_entry"]
        peak_price = position["peak_price"]
        price_now  = float(df["close"].iloc[-1])
        shares     = position.get("shares", 0)
        pnl_pct    = (price_now - avg_entry) / avg_entry * 100 if avg_entry > 0 else 0
        pnl_dol    = (price_now - avg_entry) * shares if shares > 0 else 0
        pnl_color  = "#4caf50" if pnl_pct >= 0 else "#ef5350"

        fig.add_trace(go.Scatter(
            x=[x0, x1], y=[avg_entry, avg_entry], mode="lines+text",
            name=f"Entry ${avg_entry:.2f}",
            line=dict(color="#ffffff", width=2.0, dash="solid"),
            text=["", f"  📍 ENTRY ${avg_entry:.2f}"],
            textposition="top right",
            textfont=dict(color="#ffffff", size=12),
            showlegend=False,
        ), row=1, col=1)

        if peak_price > avg_entry:
            fig.add_trace(go.Scatter(
                x=[x0, x1], y=[peak_price, peak_price], mode="lines+text",
                name=f"MFE ${peak_price:.2f}",
                line=dict(color="#00bcd4", width=1.5, dash="dash"),
                text=["", f"  ⬆ MFE ${peak_price:.2f}"],
                textposition="top right",
                textfont=dict(color="#00bcd4", size=11),
                showlegend=False,
            ), row=1, col=1)

        pnl_txt = (f"{'▲' if pnl_pct>=0 else '▼'} {abs(pnl_pct):.1f}%"
                   f"  (${pnl_dol:+.0f})" if shares > 0 else
                   f"{'▲' if pnl_pct>=0 else '▼'} {abs(pnl_pct):.1f}%")
        fig.add_annotation(
            xref="paper", yref="y",
            x=0.74, y=avg_entry,
            text=f"<b>{pnl_txt}</b>",
            showarrow=False,
            font=dict(color=pnl_color, size=13),
            bgcolor=pnl_color + "22",
            bordercolor=pnl_color,
            borderwidth=1,
            borderpad=4,
        )

    # ── Chart layout ──────────────────────────────────────────────────────────
    fig.update_layout(
        title=dict(text=title, font=dict(size=16, color="#e0e0e0")),
        paper_bgcolor="#1a1a2e", plot_bgcolor="#16213e",
        font=dict(color="#c0c0d8"),
        height=660,
        xaxis=dict(
            rangeslider=dict(visible=False),
            gridcolor="#1c2040",
            showgrid=True,
            type="category",
        ),
        yaxis=dict(
            gridcolor="#1c2040",
            showgrid=True,
            tickformat=".2f",
            tickfont=dict(family="monospace", size=11, color="#8888aa"),
        ),
        xaxis2=dict(
            gridcolor="#1c2040",
            showgrid=False,
            title="",
            showticklabels=False,
        ),
        # ── Clean legend box — key levels only ────────────────────────────────
        legend=dict(
            bgcolor="rgba(8, 12, 40, 0.88)",
            bordercolor="rgba(80, 90, 160, 0.6)",
            borderwidth=1,
            font=dict(color="#c8c8e0", size=11, family="monospace"),
            x=0.01, y=0.99,
            xanchor="left", yanchor="top",
            title=dict(
                text="KEY LEVELS",
                font=dict(size=9, color="#5c6bc0"),
            ),
            tracegroupgap=1,
            itemsizing="constant",
        ),
        margin=dict(l=10, r=130, t=55, b=40),
    )
    fig.update_xaxes(nticks=16, tickangle=-45, row=1, col=1)
    return fig


def render_structure_banner(label, color, detail, probs, tcs,
                            is_runner=False, sector_bonus=0.0, insight=None):
    top3 = sorted(probs.items(), key=lambda x: x[1], reverse=True)[:3]
    prob_pills = "".join(
        f'<span style="display:inline-block; background:{color}33; border:1px solid {color}66; '
        f'border-radius:4px; padding:2px 8px; margin:2px 4px; font-size:13px; color:#eee;">'
        f'<b>{n}</b> {p}%</span>'
        for n, p in top3
    )

    # ── TCS gauge colour logic ─────────────────────────────────────────────────
    if is_runner:
        # Gold → Electric Blue gradient for MULTI-DAY RUNNER / STOCK IN PLAY
        gauge_fill = "linear-gradient(90deg,#FFD700,#00BFFF)"
        gauge_color = "#FFD700"
        badge = ('<span style="background:#FFD70033; border:1px solid #FFD700; border-radius:4px; '
                 'padding:2px 10px; font-size:12px; font-weight:700; color:#FFD700; '
                 'text-transform:uppercase; letter-spacing:1px; '
                 'box-shadow:0 0 8px #FFD70066;">⚡ RUNNER MODE</span>')
    elif tcs >= 70:
        gauge_fill = f"linear-gradient(90deg,#4caf5099,#4caf50)"
        gauge_color = "#4caf50"
        badge = ('<span style="background:#4caf5033; border:1px solid #4caf50; border-radius:4px; '
                 'padding:2px 10px; font-size:12px; font-weight:700; color:#4caf50; '
                 'text-transform:uppercase; letter-spacing:1px;">🔥 HIGH CONVICTION</span>')
    elif tcs <= 30:
        gauge_fill = f"linear-gradient(90deg,#ef535099,#ef5350)"
        gauge_color = "#ef5350"
        badge = ('<span style="background:#ef535033; border:1px solid #ef5350; border-radius:4px; '
                 'padding:2px 10px; font-size:12px; font-weight:700; color:#ef5350; '
                 'text-transform:uppercase; letter-spacing:1px;">⚠ CHOP RISK</span>')
    else:
        gauge_fill = f"linear-gradient(90deg,#ffa72699,#ffa726)"
        gauge_color = "#ffa726"
        badge = ""

    # Sector tailwind badge
    sector_badge = ""
    if sector_bonus > 0:
        sector_badge = ('<span style="background:#26a69a33; border:1px solid #26a69a; '
                        'border-radius:4px; padding:2px 10px; font-size:12px; font-weight:700; '
                        'color:#26a69a; text-transform:uppercase; letter-spacing:1px; '
                        'margin-left:6px;">🌊 SECTOR TAILWIND +10</span>')

    tcs_label = f"{tcs:.0f}%"
    if sector_bonus > 0:
        tcs_label += f" (+{sector_bonus:.0f} sector)"

    tcs_bar = f"""
    <div style="margin-top:10px; display:flex; align-items:center; gap:10px; flex-wrap:wrap;">
        <span style="font-size:11px; color:#888; text-transform:uppercase; letter-spacing:1px; white-space:nowrap;">
            Trend Confidence
        </span>
        <div style="flex:1; min-width:120px; max-width:220px; background:#2a2a4a;
                    border-radius:6px; height:12px; overflow:hidden;">
            <div style="width:{min(tcs,100)}%; background:{gauge_fill};
                        height:100%; border-radius:6px; transition:width 0.4s;"></div>
        </div>
        <span style="font-size:18px; font-weight:800; color:{gauge_color}; min-width:44px;">{tcs_label}</span>
        {badge}{sector_badge}
    </div>
    """

    # Runner glow border
    glow = f"box-shadow:0 0 18px {gauge_color}55;" if is_runner else ""

    st.markdown(f"""
    <div style="background:linear-gradient(135deg,{color}22,{color}0a);
                border-left:5px solid {color}; border-radius:8px;
                padding:14px 22px; margin:10px 0 4px 0; {glow}">
        <div style="display:flex; justify-content:space-between; align-items:flex-start; flex-wrap:wrap; gap:8px;">
            <div>
                <div style="font-size:26px; font-weight:800; color:{color}; letter-spacing:0.5px;">{label}</div>
                <div style="font-size:13px; color:#cccccc; margin-top:4px;">{detail}</div>
            </div>
            <div style="text-align:right;">
                <div style="font-size:11px; color:#888; text-transform:uppercase;
                            letter-spacing:1px; margin-bottom:4px;">Structure Probability</div>
                <div>{prob_pills}</div>
            </div>
        </div>
        {tcs_bar}
    </div>
    """, unsafe_allow_html=True)

    # Key Insights box — separate call so Streamlit's markdown parser doesn't escape inner HTML
    if insight:
        st.markdown(
            f'<div style="margin-top:6px; background:#1a2744; border-left:3px solid {color}99;'
            f' border-radius:5px; padding:9px 14px;">'
            f'<span style="font-size:10px; color:#888; text-transform:uppercase;'
            f' letter-spacing:1px; font-weight:600;">KEY INSIGHTS</span><br>'
            f'<span style="font-size:13px; color:#d0d8f0; line-height:1.55;">{insight}</span>'
            f'</div>',
            unsafe_allow_html=True,
        )


def render_rvol_widget(rvol_val, label_str, label_color, is_runner):
    """Show the RVOL reading with appropriate colour and optional glow for runner stocks."""
    if rvol_val is None:
        return
    display_label = label_str if label_str else f"RVOL {rvol_val:.1f}×  — Normal Activity"
    if label_str is None:
        label_color = "#aaaaaa"

    runner_style = ""
    if is_runner:
        runner_style = ("box-shadow:0 0 16px #FFD70077; "
                        "border-color:#FFD700 !important; "
                        "animation:rvol-pulse 1.8s ease-in-out infinite;")

    st.markdown(f"""
    <style>
    @keyframes rvol-pulse {{
        0%   {{ box-shadow: 0 0 8px #FFD70044; }}
        50%  {{ box-shadow: 0 0 22px #FFD700cc; }}
        100% {{ box-shadow: 0 0 8px #FFD70044; }}
    }}
    </style>
    <div style="display:inline-flex; align-items:center; background:{label_color}11;
                border:2px solid {label_color}77; border-radius:8px;
                padding:8px 20px; margin:4px 0 6px 0; gap:16px; {runner_style}">
        <span style="font-size:12px; color:#888; text-transform:uppercase; letter-spacing:0.8px;">RVOL</span>
        <span style="font-size:24px; font-weight:900; color:{label_color};">{rvol_val:.1f}×</span>
        <span style="font-size:14px; font-weight:700; color:{label_color};">{display_label}</span>
    </div>
    """, unsafe_allow_html=True)


def render_buy_sell_widget(bsp, rvol_val=None):
    """Buy/Sell Volume Pressure oscillator — 0-100 gauge with momentum arrow.

    Uses the blended CLV+Tick formula (same as ThinkScript Blended split).
    Fires a HIGH CONVICTION alert when RVOL > 3 AND buy pressure is ramping.
    """
    if bsp is None:
        return
    buy_pct    = bsp["buy_pct"]
    trend_now  = bsp["trend_now"]
    trend_prev = bsp["trend_prev"]
    delta      = trend_now - trend_prev

    if buy_pct >= 65:
        bar_color, label = "#4caf50", "🔼 BUY DOMINANT"
    elif buy_pct >= 57:
        bar_color, label = "#8bc34a", "↑ Buy Leaning"
    elif buy_pct >= 43:
        bar_color, label = "#ffa726", "⇔ Balanced"
    elif buy_pct >= 35:
        bar_color, label = "#ef9a9a", "↓ Sell Leaning"
    else:
        bar_color, label = "#ef5350", "🔽 SELL DOMINANT"

    if delta > 3:
        momentum, mom_color = f"▲ Ramping +{delta:.0f}%", "#4caf50"
    elif delta < -3:
        momentum, mom_color = f"▼ Cooling {delta:.0f}%", "#ef5350"
    else:
        momentum, mom_color = "→ Flat", "#aaaaaa"

    # ── High-conviction signal: RVOL ≥ 5 + buy/sell pressure ramping ─────────
    rvol_gt5     = rvol_val is not None and rvol_val >= 5.0
    buy_ramping  = delta > 3 and buy_pct >= 55
    sell_ramping = delta < -3 and buy_pct <= 45
    hc_alert     = ""
    if rvol_gt5 and buy_ramping:
        hc_alert = (
            f'<div style="background:#4caf5022; border:1px solid #4caf5088; '
            f'border-radius:6px; padding:6px 12px; margin-bottom:6px; '
            f'font-size:12px; font-weight:700; color:#4caf50; text-align:center;">'
            f'🚀 HIGH CONVICTION BUY — RVOL {rvol_val:.1f}× + Buy Ramping'
            f'</div>'
        )
        st.session_state["_hc_alert_state"] = {
            "ticker": st.session_state.get("ticker_input", ""),
            "rvol": rvol_val, "direction": "BUY",
        }
    elif rvol_gt5 and sell_ramping:
        hc_alert = (
            f'<div style="background:#ef535022; border:1px solid #ef535088; '
            f'border-radius:6px; padding:6px 12px; margin-bottom:6px; '
            f'font-size:12px; font-weight:700; color:#ef5350; text-align:center;">'
            f'🔻 HIGH CONVICTION SELL — RVOL {rvol_val:.1f}× + Sell Ramping'
            f'</div>'
        )
        st.session_state["_hc_alert_state"] = {
            "ticker": st.session_state.get("ticker_input", ""),
            "rvol": rvol_val, "direction": "SELL",
        }
    else:
        st.session_state.pop("_hc_alert_state", None)

    st.markdown(f"""
    <div style="background:#1a1a2e; border:1px solid {bar_color}55; border-radius:8px;
                padding:10px 16px; margin:4px 0 6px 0;">
      {hc_alert}
      <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:6px;">
        <span style="font-size:11px; color:#888; text-transform:uppercase; letter-spacing:0.8px;">
          Buy / Sell Pressure &nbsp;<span style="color:#555;">(CLV+Tick Blended)</span>
        </span>
        <span style="font-size:12px; font-weight:700; color:{bar_color};">{label}</span>
        <span style="font-size:11px; color:{mom_color};">{momentum}</span>
      </div>
      <div style="background:#333; border-radius:4px; height:14px; width:100%;
                  position:relative; overflow:hidden;">
        <div style="position:absolute; left:0; top:0; height:100%; width:{buy_pct:.1f}%;
                    background:{bar_color}; border-radius:4px;"></div>
        <div style="position:absolute; left:50%; top:0; height:100%;
                    width:2px; background:#ffffff44;"></div>
      </div>
      <div style="display:flex; justify-content:space-between; margin-top:5px;">
        <span style="font-size:11px; color:#ef5350;">🔴 Sell {bsp["sell_pct"]:.0f}%</span>
        <span style="font-size:11px; color:{bar_color}; font-weight:700;">🟢 Buy {buy_pct:.0f}%</span>
      </div>
    </div>
    """, unsafe_allow_html=True)


def render_order_flow_widget(ofs):
    """Tier 2 order flow panel — pressure acceleration, bar quality, vol surge, streak."""
    if ofs is None:
        return

    # ── Color helpers ─────────────────────────────────────────────────────────
    _sig = ofs["composite_signal"]
    _score = ofs["composite_score"]
    if _sig == "Strong Buy Flow":
        _sig_color, _sig_icon = "#4caf50", "🟢"
    elif _sig == "Moderate Buy Flow":
        _sig_color, _sig_icon = "#8bc34a", "↑"
    elif _sig == "Strong Sell Flow":
        _sig_color, _sig_icon = "#ef5350", "🔴"
    elif _sig == "Moderate Sell Flow":
        _sig_color, _sig_icon = "#ef9a9a", "↓"
    else:
        _sig_color, _sig_icon = "#ffa726", "⇔"

    _accel_color = (
        "#4caf50" if ofs["pressure_accel"] == "Accelerating"
        else "#ef5350" if ofs["pressure_accel"] == "Decelerating"
        else "#aaaaaa"
    )
    _accel_arrow = (
        "▲" if ofs["pressure_accel"] == "Accelerating"
        else "▼" if ofs["pressure_accel"] == "Decelerating"
        else "→"
    )

    _bq = ofs["bar_quality"]
    _bq_color = (
        "#4caf50" if _bq >= 65
        else "#ef5350" if _bq <= 35
        else "#ffa726"
    )

    _vsr = ofs["vol_surge_ratio"]
    _vs_color = (
        "#4caf50" if _vsr >= 2.0
        else "#8bc34a" if _vsr >= 1.3
        else "#aaaaaa" if _vsr >= 0.7
        else "#ef5350"
    )

    _streak = ofs["streak"]
    _stk_color = "#4caf50" if _streak > 0 else "#ef5350" if _streak < 0 else "#aaaaaa"
    _stk_sign  = "+" if _streak > 0 else ""

    # ── IB proximity badge ────────────────────────────────────────────────────
    _ib_html = ""
    if ofs["ib_proximity"] and ofs["ib_proximity"] != "Mid-Range":
        _ib_c  = "#FFD700" if ofs["ib_vol_confirm"] else "#ffa72666"
        _ib_bd = "#FFD70088" if ofs["ib_vol_confirm"] else "#ffa72644"
        _ib_confirm_txt = " ✓ Vol Confirmed" if ofs["ib_vol_confirm"] else " (low vol)"
        _ib_html = (
            f'<div style="background:{_ib_c}18; border:1px solid {_ib_bd}; '
            f'border-radius:5px; padding:3px 10px; display:inline-block; '
            f'font-size:11px; font-weight:700; color:{_ib_c}; margin-bottom:6px;">'
            f'⚡ {ofs["ib_proximity"]}{_ib_confirm_txt}'
            f'</div>'
        )

    # ── Composite score bar (centered at 0) ───────────────────────────────────
    _abs_score  = abs(_score)
    _bar_left   = 50.0 if _score >= 0 else 50.0 - _abs_score / 2.0
    _bar_width  = _abs_score / 2.0
    _bar_left   = max(0.0, min(50.0, _bar_left))
    _bar_width  = max(0.0, min(50.0, _bar_width))

    _streak_short = (
        ofs["streak_label"]
        .replace(" Tape", "")
        .replace(" Upward", " \u25b2")
        .replace(" Downward", " \u25bc")
    )
    _of_html = (
        f'<div style="background:#1a1a2e; border:1px solid {_sig_color}44;'
        f' border-radius:8px; padding:10px 16px; margin:4px 0 6px 0;">'
        f'{_ib_html}'
        f'<div style="display:flex; justify-content:space-between; align-items:center;'
        f' margin-bottom:8px;">'
        f'<span style="font-size:11px; color:#888; text-transform:uppercase; letter-spacing:0.8px;">'
        f'Order Flow Signals <span style="color:#555;">(Tier 2)</span></span>'
        f'<span style="font-size:12px; font-weight:700; color:{_sig_color};">'
        f'{_sig_icon}&nbsp;{_sig}</span>'
        f'<span style="font-size:11px; color:{_sig_color};">{_score:+.0f}</span>'
        f'</div>'
        f'<div style="background:#333; border-radius:4px; height:10px; width:100%;'
        f' position:relative; overflow:hidden; margin-bottom:8px;">'
        f'<div style="position:absolute; left:50%; top:0; height:100%;'
        f' width:2px; background:#ffffff44;"></div>'
        f'<div style="position:absolute; left:{_bar_left:.1f}%; top:0; height:100%;'
        f' width:{_bar_width:.1f}%; background:{_sig_color}; border-radius:4px;"></div>'
        f'</div>'
        f'<div style="display:grid; grid-template-columns:1fr 1fr 1fr 1fr; gap:6px;">'
        f'<div style="background:rgba(18,18,34,0.4); border:1px solid rgba(255,255,255,0.05);'
        f' border-radius:6px; padding:6px 8px; text-align:center;">'
        f'<div style="font-size:9px; color:#555; text-transform:uppercase;'
        f' letter-spacing:0.8px; margin-bottom:3px;">Pressure</div>'
        f'<div style="font-size:13px; font-weight:700; color:{_accel_color};">'
        f'{_accel_arrow} {ofs["pressure_accel"]}</div>'
        f'<div style="font-size:10px; color:#666; margin-top:2px;">'
        f'3b:{ofs["pressure_short"]:.0f}% | 10b:{ofs["pressure_medium"]:.0f}%</div>'
        f'</div>'
        f'<div style="background:rgba(18,18,34,0.4); border:1px solid rgba(255,255,255,0.05);'
        f' border-radius:6px; padding:6px 8px; text-align:center;">'
        f'<div style="font-size:9px; color:#555; text-transform:uppercase;'
        f' letter-spacing:0.8px; margin-bottom:3px;">Bar Quality</div>'
        f'<div style="font-size:13px; font-weight:700; color:{_bq_color};">{_bq:.0f}%</div>'
        f'<div style="font-size:10px; color:#666; margin-top:2px;">{ofs["bar_quality_label"]}</div>'
        f'</div>'
        f'<div style="background:rgba(18,18,34,0.4); border:1px solid rgba(255,255,255,0.05);'
        f' border-radius:6px; padding:6px 8px; text-align:center;">'
        f'<div style="font-size:9px; color:#555; text-transform:uppercase;'
        f' letter-spacing:0.8px; margin-bottom:3px;">Vol Surge</div>'
        f'<div style="font-size:13px; font-weight:700; color:{_vs_color};">{_vsr:.1f}x</div>'
        f'<div style="font-size:10px; color:#666; margin-top:2px;">{ofs["vol_surge_label"]}</div>'
        f'</div>'
        f'<div style="background:rgba(18,18,34,0.4); border:1px solid rgba(255,255,255,0.05);'
        f' border-radius:6px; padding:6px 8px; text-align:center;">'
        f'<div style="font-size:9px; color:#555; text-transform:uppercase;'
        f' letter-spacing:0.8px; margin-bottom:3px;">Tape Streak</div>'
        f'<div style="font-size:13px; font-weight:700; color:{_stk_color};">'
        f'{_stk_sign}{_streak} bars</div>'
        f'<div style="font-size:10px; color:#666; margin-top:2px;">{_streak_short}</div>'
        f'</div>'
        f'</div>'
        f'</div>'
    )
    st.markdown(_of_html, unsafe_allow_html=True)


def render_pattern_widget(patterns):
    """Tier 3 — Chart Pattern Detection panel rendered below Tier 2 order flow."""
    dir_colors = {"Bullish": "#4caf50", "Bearish": "#ef5350"}
    dir_icons  = {"Bullish": "▲", "Bearish": "▼"}
    tf_colors  = {"1hr": "#90caf9", "5m": "#b0bec5"}

    if not patterns:
        st.markdown(
            '<div style="background:#1a1a2e; border:1px solid #2a2a4a; border-radius:8px; '
            'padding:8px 16px; margin:4px 0 6px 0; display:flex; align-items:center; gap:12px;">'
            '<span style="font-size:11px; color:#888; text-transform:uppercase; letter-spacing:0.8px;">'
            'Chart Patterns <span style="color:#555;">(Tier 3)</span></span>'
            '<span style="font-size:12px; color:#555;">No patterns detected yet — '
            'more bars needed or no classic setup forming</span>'
            '</div>',
            unsafe_allow_html=True
        )
        return

    top = patterns[0]
    top_color = dir_colors.get(top["direction"], "#aaaaaa")
    top_icon  = dir_icons.get(top["direction"], "")
    extra_lbl = f" + {len(patterns) - 1} more" if len(patterns) > 1 else ""

    rows_html = ""
    for p in patterns:
        dc = dir_colors.get(p["direction"], "#aaaaaa")
        di = dir_icons.get(p["direction"], "")
        tfc = tf_colors.get(p["timeframe"], "#b0bec5")
        pct = int(p["score"] * 100)
        sc  = "#4caf50" if pct >= 80 else "#ffa726" if pct >= 65 else "#ef9a9a"
        conf_str = " &middot; ".join(p["confluence"]) if p["confluence"] else ""
        nl = p.get("neckline")
        nl_html = (f'&nbsp;&middot;&nbsp;Neckline <b style="color:#FFD700;">'
                   f'${nl:.2f}</b>') if nl else ""
        conf_html = (f'<div style="font-size:10px; color:#FFD700; margin-top:2px;">'
                     f'&#9889; {conf_str}</div>') if conf_str else ""
        rows_html += (
            f'<div style="border-bottom:1px solid #1e1e3a; padding:7px 0 5px 0;">'
            f'<div style="display:flex; justify-content:space-between; align-items:center;">'
            f'<span style="font-size:12px; font-weight:700; color:{dc};">{di}&nbsp;{p["name"]}</span>'
            f'<span style="font-size:11px; color:{tfc}; margin:0 8px;">{p["timeframe"]}</span>'
            f'<span style="font-size:12px; font-weight:700; color:{sc};">{pct}%</span>'
            f'</div>'
            f'<div style="font-size:11px; color:#888; margin-top:2px;">'
            f'{p["description"]}{nl_html}</div>'
            f'{conf_html}'
            f'</div>'
        )

    st.markdown(
        f'<div style="background:#1a1a2e; border:1px solid {top_color}44;'
        f' border-radius:8px; padding:10px 16px; margin:4px 0 6px 0;">'
        f'<div style="display:flex; justify-content:space-between; align-items:center;'
        f' margin-bottom:8px;">'
        f'<span style="font-size:11px; color:#888; text-transform:uppercase; letter-spacing:0.8px;">'
        f'Chart Patterns <span style="color:#555;">(Tier 3)</span></span>'
        f'<span style="font-size:12px; font-weight:700; color:{top_color};">'
        f'{top_icon}&nbsp;{top["name"]}{extra_lbl}</span>'
        f'</div>'
        f'{rows_html}'
        f'</div>',
        unsafe_allow_html=True
    )


def render_model_prediction(outcome, reasoning):
    """Show the volume-price divergence model prediction in a styled text box.

    'Market Closed' outcome → shows a blue sleep-mode info box instead of
    a directional warning so stale/historical analysis isn't misread as live signal.
    """
    # ── Sleep mode: market is closed, suppress directional warnings ───────────
    if outcome == "Market Closed":
        st.markdown("""
        <div style="background:#0d47a114; border:1px solid #1565c066;
                    border-radius:8px; padding:12px 20px; margin:8px 0 4px 0;">
            <div style="font-size:10px; color:#5c8ecc; text-transform:uppercase;
                        letter-spacing:1.2px; margin-bottom:6px;">
                🤖 Model Prediction — Volume-Price Divergence
            </div>
            <div style="font-size:20px; font-weight:800; color:#64b5f6; margin-bottom:4px;">
                💤 MARKET CLOSED — Analyzing Historical Data
            </div>
            <div style="font-size:13px; color:#90caf9; line-height:1.6;">
                Live pattern alerts are suppressed outside 9:30 AM – 4:00 PM EST.
                Use the volume profile structure and TCS score for session-level context.
            </div>
        </div>
        """, unsafe_allow_html=True)
        return

    # ── Live / historical session directional signal ───────────────────────────
    _colors = {"Fake-out": "#ef5350", "High Conviction": "#4caf50", "Consolidation": "#ffa726"}
    _icons  = {"Fake-out": "⚠️", "High Conviction": "🎯", "Consolidation": "📊"}
    c    = _colors.get(outcome, "#aaaaaa")
    icon = _icons.get(outcome, "📊")
    st.markdown(f"""
    <div style="background:{c}0e; border:1px solid {c}44; border-radius:8px;
                padding:12px 20px; margin:8px 0 4px 0;">
        <div style="font-size:10px; color:#666; text-transform:uppercase;
                    letter-spacing:1.2px; margin-bottom:6px;">
            🤖 Model Prediction — Volume-Price Divergence
        </div>
        <div style="font-size:20px; font-weight:800; color:{c}; margin-bottom:4px;">
            {icon}&nbsp;{outcome}
        </div>
        <div style="font-size:13px; color:#c0c0c0; line-height:1.6;">
            {reasoning}
        </div>
    </div>
    """, unsafe_allow_html=True)


def render_velocity_widget(df):
    vol, chg, direction = compute_volume_velocity(df)
    if vol is None:
        return
    color = "#26a69a" if direction == "↑" else "#ef5350" if direction == "↓" else "#aaa"
    chg_str = f"{direction} {chg:.1f}%" if chg is not None else "—"

    intensity = ""
    if chg is not None:
        if chg > 50:
            intensity = " — 🔥 Surging"
        elif chg > 20:
            intensity = " — ⬆ Accelerating"
        elif chg < -50:
            intensity = " — 🧊 Drying up"
        elif chg < -20:
            intensity = " — ⬇ Fading"

    st.markdown(f"""
    <div style="display:inline-flex; align-items:center; background:#16213e;
                border:1px solid #2a2a4a; border-radius:6px; padding:8px 18px; margin:4px 0 8px 0; gap:14px;">
        <span style="font-size:12px; color:#888; text-transform:uppercase; letter-spacing:0.8px;">⚡ Vol Velocity</span>
        <span style="font-size:19px; font-weight:700; color:#e0e0e0;">{vol:,.0f}/min</span>
        <span style="font-size:16px; font-weight:600; color:{color};">{chg_str}{intensity}</span>
    </div>
    """, unsafe_allow_html=True)


def render_analysis(df, num_bins, ticker, chart_title, is_ib_live=False,
                    avg_daily_vol=None, sector_bonus=0.0, sector_etf="IWM",
                    intraday_curve=None, is_live=False):
    ib_high, ib_low = compute_initial_balance(df)

    # ── IB override: user can correct from their broker ───────────────────────
    _ib_ovr_key = f"ib_override_{ticker}"
    _ib_ovr = st.session_state.get(_ib_ovr_key)
    if _ib_ovr:
        ib_high = _ib_ovr.get("high") or ib_high
        ib_low  = _ib_ovr.get("low")  or ib_low

    bin_centers, vap, poc_price = compute_volume_profile(df, num_bins)
    # ── Cache raw bars + VP data for Small Account Challenge tab ─────────────
    st.session_state.last_bars      = df.copy()
    st.session_state.sa_bin_centers = bin_centers
    st.session_state.sa_vap         = vap
    _sa_val, _sa_vah = _compute_value_area(bin_centers, vap)
    label, color, detail, insight = classify_day_structure(
        df, bin_centers, vap, ib_high, ib_low, poc_price, avg_daily_vol=avg_daily_vol
    )
    probs = compute_structure_probabilities(df, bin_centers, vap, ib_high, ib_low, poc_price)
    tcs = compute_tcs(df, ib_high, ib_low, poc_price, sector_bonus=sector_bonus)
    target_zones = compute_target_zones(df, ib_high, ib_low, bin_centers, vap, tcs)

    # ── Edge Score (live, for this chart) ─────────────────────────────────────
    _top_struct_key  = max(probs, key=probs.get) if probs else ""
    _top_struct_conf = round(float(probs.get(_top_struct_key, 0.0)), 1) if probs else 0.0
    try:
        _chart_weights  = compute_adaptive_weights(_AUTH_USER_ID)
        _chart_env      = get_recent_env_stats(_AUTH_USER_ID, days=5)
        _chart_edge, _chart_edge_bkd = compute_edge_score(
            tcs=tcs,
            structure_conf=_top_struct_conf,
            env_long_rate=_chart_env["long_rate"],
            recent_false_brk_rate=_chart_env["false_brk_rate"],
            weights=_chart_weights,
        )
    except Exception:
        _chart_edge, _chart_edge_bkd = None, {}

    # ── High Conviction logger ─────────────────────────────────────────────────
    try:
        _top_struct, _top_prob = max(probs.items(), key=lambda x: x[1])
        if _top_prob >= HICONS_THRESHOLD and ib_high is not None and ib_low is not None:
            log_high_conviction(ticker, selected_date, _top_struct, _top_prob,
                                ib_high=ib_high, ib_low=ib_low, poc_price=poc_price)
    except Exception:
        pass
    audio_enabled = st.session_state.get("audio_alerts_enabled", True)
    check_tcs_alerts(tcs, audio_enabled)

    # ── Signal conditions snapshot (predictive engine feed) ─────────────────────
    # Save conditions every time the chart runs so EOD verification can pair them
    # with outcomes later and build your personal win-rate probability database.
    try:
        if _chart_edge is not None and _AUTH_USER_ID and rvol_pre is not None:
            _bp, _ = compute_buy_sell_pressure(df)
            save_signal_conditions(
                user_id=_AUTH_USER_ID,
                ticker=ticker,
                trade_date=selected_date,
                edge_score=float(_chart_edge),
                rvol=float(rvol_pre),
                structure=label,
                tcs=float(tcs),
                buy_pressure=float(_bp) if _bp is not None else 0.0,
            )
    except Exception:
        pass

    # ── MarketBrain — real-time structure prediction ───────────────────────────
    brain = MarketBrain()
    brain.load_from_session()
    rvol_pre = compute_rvol(df, intraday_curve=intraday_curve, avg_daily_vol=avg_daily_vol)
    try:
        _brain_ivp, _ = compute_ib_volume_stats(df, ib_high, ib_low) if (
            ib_high is not None and ib_low is not None) else (None, None)
    except Exception:
        _brain_ivp = None
    _brain_has_dd = _detect_double_distribution(bin_centers, vap) is not None
    brain.update(df, rvol=rvol_pre, ib_vol_pct=_brain_ivp,
                 poc_price=poc_price, has_double_dist=_brain_has_dd)
    st.session_state.brain_predicted = brain.prediction

    # ── Time context ───────────────────────────────────────────────────────────
    # elapsed_bars = minutes of session captured so far (used for time-seg RVOL + Fuel Check)
    elapsed_bars = len(df)
    # market_open:
    #   • Live mode  → check actual clock (suppress fake-out if market is closed)
    #   • Historical → True — session data is self-contained, show all signals
    market_open = is_market_open() if is_live else True

    # ── RVOL + Pattern Label ───────────────────────────────────────────────────
    price_start = float(df["open"].iloc[0]) if len(df) else 0.0
    price_now   = float(df["close"].iloc[-1]) if len(df) else 0.0
    pct_chg_today = (price_now - price_start) / price_start * 100.0 if price_start > 0 else 0.0

    rvol_val = compute_rvol(df, intraday_curve=intraday_curve, avg_daily_vol=avg_daily_vol)
    rvol_lbl, rvol_color, is_runner, is_play = rvol_classify(
        rvol_val, pct_chg_today,
        elapsed_bars=elapsed_bars if is_live else None,   # open-window check only in live mode
        price_now=price_now
    )

    # ── Model prediction ───────────────────────────────────────────────────────
    pred_outcome, pred_reasoning = compute_model_prediction(
        df, rvol_val, tcs, sector_bonus, market_open=market_open
    )

    day_high = float(df["high"].max())
    day_low  = float(df["low"].min())
    ib_range = (ib_high - ib_low) if ib_high and ib_low else 0.0

    # IB status badge for live mode
    if is_ib_live and ib_high and ib_low:
        now_est = datetime.now(EASTERN)
        mins_left = max(0, int((datetime.combine(date.today(), dtime(10, 30)) -
                                now_est.replace(tzinfo=None)).total_seconds() // 60))
        st.markdown(
            f'<div style="display:inline-block; background:#ff980033; border:1px solid #ff9800; '
            f'border-radius:4px; padding:3px 10px; font-size:13px; color:#ff9800; margin-bottom:8px;">'
            f'📐 IB FORMING — {mins_left} min remaining until 10:30 EST</div>',
            unsafe_allow_html=True
        )

    # ── Top metrics row ───────────────────────────────────────────────────────
    rvol_display = f"{rvol_val:.1f}×" if rvol_val is not None else "—"
    sector_display = (f"{sector_etf} +{sector_bonus:.0f}pts" if sector_bonus > 0
                      else f"{sector_etf} —")
    col1, col2, col3, col4, col5, col6, col7, col8 = st.columns(8)
    col1.metric("Bars", len(df))
    col2.metric("IB High", f"${ib_high:.2f}" if ib_high else "—")
    col3.metric("IB Low",  f"${ib_low:.2f}"  if ib_low  else "—")
    col4.metric("IB Range", f"${ib_range:.2f}")
    col5.metric("Day Range", f"${day_high - day_low:.2f}")
    col6.metric("POC", f"${poc_price:.2f}" if poc_price is not None else "—")
    col7.metric("RVOL", rvol_display)
    col8.metric("Sector", sector_display)

    # ── IB Manual Override ────────────────────────────────────────────────────
    _ib_ovr_key = f"ib_override_{ticker}"
    _has_override = bool(st.session_state.get(_ib_ovr_key))
    _ovr_label = "✏️ IB Override — ACTIVE" if _has_override else "✏️ Override IB Levels (broker correction)"
    with st.expander(_ovr_label, expanded=_has_override):
        st.caption("Type your broker's IB values and click **Apply**. "
                   "Leave at 0 to keep the auto-computed value.")
        with st.form(key=f"ib_override_form_{ticker}", clear_on_submit=False):
            _fc1, _fc2, _fc3 = st.columns([2, 2, 1])
            _curr_high = float(st.session_state.get(_ib_ovr_key, {}).get("high") or ib_high or 0.0)
            _curr_low  = float(st.session_state.get(_ib_ovr_key, {}).get("low")  or ib_low  or 0.0)
            _ovr_high = _fc1.number_input("IB High", value=_curr_high,
                                           min_value=0.0, step=0.001, format="%.3f")
            _ovr_low  = _fc2.number_input("IB Low",  value=_curr_low,
                                           min_value=0.0, step=0.001, format="%.3f")
            _fc3.markdown("<div style='height:28px'></div>", unsafe_allow_html=True)
            _sub_cols = _fc3.columns(2)
            _submitted = _sub_cols[0].form_submit_button("✓", use_container_width=True,
                                                          help="Apply override")
            _cleared   = _sub_cols[1].form_submit_button("✕", use_container_width=True,
                                                          help="Clear override")
        if _submitted:
            st.session_state[_ib_ovr_key] = {
                "high": _ovr_high if _ovr_high > 0 else None,
                "low":  _ovr_low  if _ovr_low  > 0 else None,
            }
            st.rerun()
        if _cleared:
            st.session_state.pop(_ib_ovr_key, None)
            st.rerun()

    # ── IB Volume Stats widget ─────────────────────────────────────────────────
    ib_vol_pct_disp, ib_range_ratio_disp = compute_ib_volume_stats(df, ib_high, ib_low)
    _ivp_pct = (ib_vol_pct_disp or 0.0) * 100
    _irr_pct = (ib_range_ratio_disp or 0.0) * 100
    # Color coding: balanced (green) vs directional (orange/red)
    _ivp_color = ("#4caf50" if _ivp_pct >= 60 else "#ffa726" if _ivp_pct >= 35 else "#ef5350")
    _irr_color = ("#4caf50" if _irr_pct >= 50 else "#ffa726" if _irr_pct >= 25 else "#ef5350")
    _ivp_label = "Balanced" if _ivp_pct >= 60 else ("Neutral" if _ivp_pct >= 35 else "Directional")
    _irr_label = "Contained" if _irr_pct >= 50 else ("Moderate" if _irr_pct >= 25 else "Expanded")
    _ib_high_str  = f"${ib_high:.2f}"   if ib_high   is not None else "—"
    _ib_low_str   = f"${ib_low:.2f}"    if ib_low    is not None else "—"
    _poc_str      = f"${poc_price:.2f}" if poc_price  is not None else "—"
    st.markdown(
        f'<div style="background:#0f3460; border:1px solid #1a3a6e; border-radius:6px; '
        f'padding:8px 16px; margin:4px 0 6px 0; display:flex; align-items:center; gap:20px; flex-wrap:wrap;">'
        f'<span style="font-size:11px; color:#5c6bc0; text-transform:uppercase; '
        f'letter-spacing:1px; white-space:nowrap;">📐 IB Structure</span>'
        f'<span style="font-size:12px; color:#aaa;">IB Vol%: '
        f'<b style="color:{_ivp_color};">{_ivp_pct:.0f}%</b> '
        f'<span style="color:{_ivp_color}; font-size:11px;">({_ivp_label})</span></span>'
        f'<span style="color:#2a2a4a;">|</span>'
        f'<span style="font-size:12px; color:#aaa;">IB/Day Range: '
        f'<b style="color:{_irr_color};">{_irr_pct:.0f}%</b> '
        f'<span style="color:{_irr_color}; font-size:11px;">({_irr_label})</span></span>'
        f'<span style="color:#2a2a4a;">|</span>'
        f'<span style="font-size:11px; color:#555; white-space:nowrap;">'
        f'IB {_ib_high_str} – {_ib_low_str} &nbsp;|&nbsp; POC {_poc_str}</span>'
        f'</div>',
        unsafe_allow_html=True,
    )

    render_velocity_widget(df)
    render_rvol_widget(rvol_val, rvol_lbl, rvol_color, is_runner)
    render_buy_sell_widget(compute_buy_sell_pressure(df), rvol_val=rvol_val)
    render_order_flow_widget(
        compute_order_flow_signals(df, ib_high=ib_high, ib_low=ib_low)
    )
    render_pattern_widget(
        detect_chart_patterns(df, poc_price=poc_price, ib_high=ib_high, ib_low=ib_low)
    )
    render_structure_banner(label, color, detail, probs, tcs,
                            is_runner=is_runner, sector_bonus=sector_bonus,
                            insight=insight)
    render_model_prediction(pred_outcome, pred_reasoning)

    # ── MarketBrain: compare prediction vs actual + running counter ───────────
    bc = brain.color()
    _brain_correct_now = False
    _brain_newly_logged = False

    # Auto-compare once IB is complete and brain has a real prediction
    if brain.ib_set and brain.prediction != "Analyzing IB…" \
            and ib_high is not None and ib_low is not None \
            and ib_high != float("inf") and ib_low != float("inf"):
        _today_str   = datetime.now(EASTERN).strftime("%Y-%m-%d")
        _compare_key = f"{ticker}_{_today_str}_{float(ib_high):.4f}_{float(ib_low):.4f}"

        # Dedup: check both session state AND the CSV (survives reloads)
        _already_in_csv = False
        if st.session_state.brain_last_compared != _compare_key:
            try:
                _chk = pd.read_csv(TRACKER_FILE) if os.path.exists(TRACKER_FILE) else pd.DataFrame()
                if "compare_key" in _chk.columns:
                    _already_in_csv = (_chk["compare_key"] == _compare_key).any()
            except Exception:
                pass

        if st.session_state.brain_last_compared != _compare_key and not _already_in_csv:
            st.session_state.brain_last_compared = _compare_key
            # Fuzzy match: strip emojis/punctuation and compare core words
            _pred_clean   = _strip_emoji(brain.prediction)
            _actual_clean = _strip_emoji(label)
            _brain_correct_now = (
                _pred_clean in _actual_clean or _actual_clean in _pred_clean
                or any(w in _actual_clean for w in _pred_clean.split() if len(w) > 4)
            )
            st.session_state.brain_session_total   += 1
            if _brain_correct_now:
                st.session_state.brain_session_correct += 1
            # Log to CSV with the compare_key stored for reload dedup
            log_accuracy_entry(ticker, brain.prediction, label,
                               compare_key=_compare_key,
                               user_id=st.session_state.get("auth_user_id", ""))
            _brain_newly_logged = True
        elif st.session_state.brain_last_compared != _compare_key and _already_in_csv:
            # Already in CSV from a previous session — just sync the session key
            st.session_state.brain_last_compared = _compare_key

    _b_corr  = st.session_state.brain_session_correct
    _b_total = st.session_state.brain_session_total
    _b_rate  = (_b_corr / _b_total * 100) if _b_total > 0 else 0
    _counter_str = (f"Today: {_b_corr}/{_b_total} ({_b_rate:.0f}%)"
                    if _b_total > 0 else "Today: —")
    _counter_col = "#4caf50" if _b_rate >= 60 else "#ffa726" if _b_rate >= 40 else "#ef5350"

    # ── All-time win rate — reads directly from CSV, never resets ─────────────
    _at_total, _at_correct, _at_rate = 0, 0, None
    try:
        if os.path.exists(TRACKER_FILE):
            _at_df = pd.read_csv(TRACKER_FILE)
            _at_total = int(len(_at_df))
            if "correct" in _at_df.columns and _at_total > 0:
                _at_correct = int((_at_df["correct"] == "✅").sum())
                _at_rate    = round(float(_at_correct) / float(_at_total) * 100.0, 1)
    except Exception:
        _at_total, _at_correct, _at_rate = 0, 0, None

    _at_is_valid = (_at_rate is not None and isinstance(_at_rate, (int, float))
                    and _at_rate == _at_rate)   # NaN check
    _at_col = ("#4caf50" if _at_is_valid and _at_rate >= 60
               else "#ffa726" if _at_is_valid and _at_rate >= 40
               else "#ef5350" if _at_is_valid else "#555")
    _at_str  = f"{_at_rate:.0f}%" if _at_is_valid else "—"
    _at_lbl  = f"All-time: <b style='font-size:18px; color:{_at_col};'>{_at_str}</b>"
    if _at_is_valid:
        _at_lbl += f" <span style='font-size:10px; color:#555;'>({_at_correct}/{_at_total})</span>"

    st.markdown(
        f'<div style="background:{bc}11; border-left:3px solid {bc}; border-radius:6px; '
        f'padding:10px 16px; margin:6px 0 4px 0; display:flex; align-items:center; gap:16px; flex-wrap:wrap;">'
        f'<span style="font-size:11px; color:#888; text-transform:uppercase; '
        f'letter-spacing:1px; white-space:nowrap;">🧠 Brain</span>'
        f'<span style="font-size:15px; font-weight:700; color:{bc};">{brain.prediction}</span>'
        f'<span style="font-size:11px; color:#555;">vs <span style="color:{color};">{label}</span></span>'
        f'<span style="font-size:11px; color:#444; margin-left:auto;">|</span>'
        f'<span style="font-size:12px; color:#aaa;">{_at_lbl}</span>'
        f'<span style="font-size:11px; font-weight:600; color:{_counter_col}; '
        f'background:{_counter_col}22; padding:2px 8px; border-radius:4px; '
        f'border:1px solid {_counter_col}44; white-space:nowrap;">{_counter_str}</span>'
        f'</div>',
        unsafe_allow_html=True,
    )

    # ── Flash notification when brain is newly correct / newly wrong ──────────
    if _brain_newly_logged:
        if _brain_correct_now:
            st.markdown(
                f'<div style="background:#4caf5022; border:1px solid #4caf50; border-radius:6px; '
                f'padding:8px 16px; margin:4px 0; font-size:13px; font-weight:700; color:#4caf50;">'
                f'✅ Brain Correct! Predicted <em>{brain.prediction}</em> — matches <em>{label}</em>. '
                f'Running accuracy: {_b_corr}/{_b_total} ({_b_rate:.0f}%)</div>',
                unsafe_allow_html=True,
            )
        else:
            st.markdown(
                f'<div style="background:#ffa72622; border:1px solid #ffa726; border-radius:6px; '
                f'padding:8px 16px; margin:4px 0; font-size:13px; color:#ffa726;">'
                f'🔄 Brain predicted <em>{brain.prediction}</em> — actual was <em>{label}</em>. '
                f'Data logged for learning. Running: {_b_corr}/{_b_total} ({_b_rate:.0f}%)</div>',
                unsafe_allow_html=True,
            )

    # ── Persist snapshot for Live Pulse header + Log Entry ────────────────────
    st.session_state.last_analysis_state = {
        "ticker":      ticker,
        "price":       price_now,
        "structure":   label,
        "tcs":         tcs,
        "rvol":        rvol_val,
        "ib_high":     ib_high,
        "ib_low":      ib_low,
        "poc_price":   poc_price,
        "val_price":   _sa_val,
        "vah_price":   _sa_vah,
        "pct_change":  pct_chg_today,
        "rvol_color":  rvol_color,
        "is_runner":   is_runner,
        "label_color": color,
        "vol_velocity_str": "",
        "brain_predicted": brain.prediction,
        "edge_score":       _chart_edge,
        "edge_breakdown":   _chart_edge_bkd,
        "struct_conf":      _top_struct_conf,
    }

    # ── Update peak price + auto-alerts for open position ────────────────────
    if st.session_state.position_in and st.session_state.position_ticker == ticker:
        avg_entry = st.session_state.position_avg_entry

        # Track MFE
        if price_now > st.session_state.position_peak_price:
            st.session_state.position_peak_price = price_now
            save_position_state()

        # 1. Breakeven alert — price reached +2% from entry
        if avg_entry > 0 and price_now >= avg_entry * 1.02:
            be_pct = (price_now - avg_entry) / avg_entry * 100
            st.markdown(
                f'<div style="background:#ff980022; border:1px solid #ff9800; border-radius:6px; '
                f'padding:10px 18px; margin:6px 0; font-size:14px; font-weight:700; color:#ff9800;">'
                f'⚡ MOVE STOP TO BREAKEVEN — Price is +{be_pct:.1f}% from entry '
                f'(${avg_entry:.2f} → ${price_now:.2f}). '
                f'Set stop at ${avg_entry:.2f} to lock in a risk-free trade.</div>',
                unsafe_allow_html=True,
            )

        # 2. Auto Take-Profit — price hit IB High on Neutral or Normal structure
        _tp_structures = {"Neutral", "Neutral Extreme", "Normal", "Normal Variation"}
        _label_base    = label.split(" ")[0] if label else ""
        _tp_triggered  = (
            avg_entry > 0
            and ib_high is not None
            and price_now >= ib_high
            and any(s in label for s in _tp_structures)
        )
        if _tp_triggered:
            _mfe      = st.session_state.position_peak_price   # capture before exit clears it
            _realized = exit_position(price_now, actual_structure=label)
            _pnl_col  = "#4caf50" if _realized >= 0 else "#ef5350"
            st.markdown(
                f'<div style="background:{_pnl_col}22; border:1px solid {_pnl_col}; '
                f'border-radius:6px; padding:10px 18px; margin:6px 0; font-size:14px; '
                f'font-weight:700; color:{_pnl_col};">'
                f'🎯 AUTO TAKE PROFIT — Price reached IB High ${ib_high:.2f} on a '
                f'<em>{label}</em> day. '
                f'Position closed at ${price_now:.2f}. '
                f'Realized: ${_realized:+.2f} | MFE: ${_mfe:.2f}</div>',
                unsafe_allow_html=True,
            )
            time.sleep(0.5)
            st.rerun()

    # ── Target zone alerts + sidebar "Distance to Target" ─────────────────────
    check_target_alerts(price_now, target_zones, audio_enabled)
    if target_zones:
        with st.sidebar:
            st.markdown("---")
            st.markdown("**🎯 Distance to Target**")
            for tz in target_zones:
                dist_pct = abs(price_now - tz["price"]) / price_now * 100
                arrow = "▲" if tz["price"] > price_now else "▼"
                tc = tz["color"]
                st.markdown(
                    f'<div style="background:#1a2744; border-left:3px solid {tc}; '
                    f'border-radius:4px; padding:6px 10px; margin:4px 0; font-size:12px;">'
                    f'<span style="color:{tc}; font-weight:700;">{tz["label"]}</span> '
                    f'<span style="color:#ccc;">${tz["price"]:.2f}</span> '
                    f'<span style="color:#888;">{arrow} {dist_pct:.1f}% away</span></div>',
                    unsafe_allow_html=True,
                )

    pos_state = {
        "in":         st.session_state.position_in,
        "avg_entry":  st.session_state.position_avg_entry,
        "peak_price": st.session_state.position_peak_price,
        "shares":     st.session_state.position_shares,
    }
    fig = build_chart(df, ib_high, ib_low, bin_centers, vap, poc_price, chart_title,
                      target_zones=target_zones, position=pos_state)
    st.plotly_chart(fig, use_container_width=True)

    # ── RVOL Trend Subplot (T007) ──────────────────────────────────────────────
    try:
        if avg_daily_vol and avg_daily_vol > 0 and intraday_curve is not None:
            _rvol_times, _rvol_vals = [], []
            _cum_vol = 0.0
            for _bar_ts, _bar in df.iterrows():
                _cum_vol += float(_bar["volume"])
                _bar_min = int(_bar_ts.hour * 60 + _bar_ts.minute - 9 * 60 - 30)
                _bar_min = max(0, min(_bar_min, len(intraday_curve) - 1))
                _expected_frac = intraday_curve[_bar_min] if _bar_min < len(intraday_curve) else 1.0
                _expected_vol  = avg_daily_vol * max(_expected_frac, 0.001)
                _rv = round(_cum_vol / _expected_vol, 2)
                _rvol_times.append(_bar_ts.strftime("%H:%M"))
                _rvol_vals.append(_rv)

            _rv_colors = [
                "rgba(76,175,80,0.85)"  if v >= 5 else
                "rgba(255,167,38,0.75)" if v >= 2 else
                "rgba(84,110,122,0.6)"
                for v in _rvol_vals
            ]
            _fig_rv = go.Figure()
            _fig_rv.add_trace(go.Bar(
                x=_rvol_times, y=_rvol_vals,
                marker_color=_rv_colors,
                name="RVOL",
                hovertemplate="<b>%{x}</b><br>RVOL: %{y:.2f}×<extra></extra>",
            ))
            _fig_rv.add_hline(y=2.0, line=dict(color="rgba(255,167,38,0.5)", dash="dot", width=1),
                              annotation_text="2× floor", annotation_font_color="#ffa726",
                              annotation_font_size=9)
            _fig_rv.add_hline(y=5.0, line=dict(color="rgba(76,175,80,0.5)", dash="dot", width=1),
                              annotation_text="5× conviction", annotation_font_color="#4caf50",
                              annotation_font_size=9)
            _fig_rv.update_layout(
                paper_bgcolor="#0d1117", plot_bgcolor="#0d1117",
                font=dict(color="#e0e0e0", size=10),
                height=140,
                margin=dict(l=40, r=10, t=6, b=30),
                showlegend=False,
                xaxis=dict(gridcolor="#1e2a3a", showgrid=False,
                           tickfont=dict(size=9, color="#546e7a")),
                yaxis=dict(title="RVOL ×", gridcolor="#1e2a3a",
                           tickfont=dict(size=9, color="#546e7a")),
                bargap=0.1,
            )
            st.plotly_chart(_fig_rv, use_container_width=True)
    except Exception:
        pass

    with st.expander("📋 Raw Bar Data"):
        disp = df[["open", "high", "low", "close", "volume"]].copy()
        disp.index = disp.index.strftime("%H:%M")
        disp.columns = ["Open", "High", "Low", "Close", "Volume"]
        st.dataframe(disp, use_container_width=True)


# ══════════════════════════════════════════════════════════════════════════════
# PRE-MARKET GAP SCANNER
# ══════════════════════════════════════════════════════════════════════════════

_DEFAULT_WATCHLIST = (
    "MSTR,COIN,SOFI,LCID,SIRI,SPCE,FFIE,WKHS,NKLA,MVIS,"
    "CLOV,BB,MMAT,SNDL,TLRY,AFRM,UPST,DKNG,BYND,PLTR,"
    "RIVN,CHPT,BLNK,ASTS,ACHR,JOBY,HOOD,OPEN,PSFE,NRDS"
)


# ══════════════════════════════════════════════════════════════════════════════
# MAIN AREA
# ══════════════════════════════════════════════════════════════════════════════

# ══════════════════════════════════════════════════════════════════════════════
# SIDEBAR
# ══════════════════════════════════════════════════════════════════════════════

with st.sidebar:
    st.header("🔑 Alpaca Credentials")
    api_key = st.text_input(
        "API Key", type="password", placeholder="Alpaca API Key",
        value=st.session_state.get("_pref_alpaca_key", ""),
        key="_sb_api_key",
    )
    secret_key = st.text_input(
        "Secret Key", type="password", placeholder="Alpaca Secret Key",
        value=st.session_state.get("_pref_alpaca_secret", ""),
        key="_sb_secret_key",
    )
    # Auto-save credentials whenever they're filled in
    _sb_uid = st.session_state.get("auth_user_id", "")
    if api_key and secret_key and _sb_uid:
        _cur_prefs = st.session_state.get("_cached_prefs", {})
        if (_cur_prefs.get("alpaca_key") != api_key or
                _cur_prefs.get("alpaca_secret") != secret_key):
            _new_prefs = {**_cur_prefs, "alpaca_key": api_key, "alpaca_secret": secret_key}
            save_user_prefs(_sb_uid, _new_prefs)
            st.session_state["_cached_prefs"]       = _new_prefs
            st.session_state["_pref_alpaca_key"]    = api_key
            st.session_state["_pref_alpaca_secret"] = secret_key

    st.markdown("---")
    st.header("🔔 Discord Alerts")
    _dw_input = st.text_input(
        "Webhook URL",
        type="password",
        placeholder="https://discord.com/api/webhooks/…",
        value=st.session_state.get("discord_webhook_url", ""),
        key="_sb_discord_webhook",
        help="Paste your Discord webhook URL. Alerts fire automatically when a ticker scores TCS ≥ 80 and Edge Score ≥ 75 during Playbook scoring. Each ticker only alerts once per day.",
    )
    if _dw_input:
        st.session_state["discord_webhook_url"] = _dw_input
        if _sb_uid:
            _cur_prefs = st.session_state.get("_cached_prefs", {})
            if _cur_prefs.get("discord_webhook") != _dw_input:
                _new_prefs = {**_cur_prefs, "discord_webhook": _dw_input}
                save_user_prefs(_sb_uid, _new_prefs)
                st.session_state["_cached_prefs"] = _new_prefs
    discord_webhook_url = st.session_state.get("discord_webhook_url", "")
    if discord_webhook_url:
        st.success("✅ Alerts active", icon="🔔")

    st.markdown("---")
    mode = st.radio("Mode", ["📅 Historical", "🎬 Replay", "🔴 Live Stream"], index=0)

    st.markdown("---")
    st.header("📈 Settings")
    _pending_ticker = st.session_state.get("_load_ticker", "")
    if _pending_ticker:
        st.session_state["ticker_input"] = _pending_ticker
        try:
            del st.session_state["_load_ticker"]
        except Exception:
            st.session_state["_load_ticker"] = ""
    ticker = st.text_input("Ticker Symbol", key="ticker_input",
                           placeholder="e.g. AAPL, GME").upper().strip()
    num_bins = st.slider("Volume Profile Bins", min_value=20, max_value=200, value=100, step=10)
    sector_etf = st.selectbox(
        "Sector ETF (for Tailwind)",
        ["IWM", "XBI", "SMH", "QQQ", "SPY", "XLF", "XLE"],
        index=0,
        help="If this ETF is up > 1% on the day, TCS gets a +10 pt Sector Tailwind bonus."
    )

    run_button = start_live = stop_live = scan_button = replay_load = False
    selected_date = date.today()
    data_feed = "sip"
    watchlist_raw = ""
    scan_feed = "iex"

    if mode == "📅 Historical":
        today = date.today()
        # Default to today if it's a weekday, otherwise roll back to last Friday
        if today.weekday() < 5:
            def_d = today
        elif today.weekday() == 5:   # Saturday → Friday
            def_d = today - timedelta(days=1)
        else:                         # Sunday → Friday
            def_d = today - timedelta(days=2)
        selected_date = st.date_input("Trading Date", value=def_d, max_value=today,
                                       help="Pick a weekday (Mon–Fri). Today's intraday data is supported.")
        data_feed = st.selectbox("Data Feed", ["iex", "sip"], index=0,
                                  help="IEX = free, works on all accounts. SIP = full tape, requires a paid Alpaca data subscription.")
        run_button = st.button("🚀 Fetch & Analyze", use_container_width=True, type="primary")

    elif mode == "🎬 Replay":
        today = date.today()
        if today.weekday() < 5:
            def_d = today
        elif today.weekday() == 5:
            def_d = today - timedelta(days=1)
        else:
            def_d = today - timedelta(days=2)
        selected_date = st.date_input("Trading Date", value=def_d, max_value=today,
                                       help="Pick a trading day to replay.", key="replay_date_input")
        data_feed = st.selectbox("Data Feed", ["iex", "sip"], index=0,
                                  help="IEX = free. SIP = full tape, needs subscription.", key="replay_feed_sel")
        replay_load = st.button("📥 Load Day for Replay", use_container_width=True, type="primary")

        # ── Replay controls (shown once bars are loaded) ───────────────────────
        if st.session_state.replay_bars is not None:
            _rb      = st.session_state.replay_bars
            _max_idx = len(_rb) - 1
            _cur_idx = st.session_state.replay_bar_idx

            # Current bar's ET time
            _cur_ts  = _rb.index[_cur_idx]
            _cur_et  = pd.Timestamp(_cur_ts).tz_convert(EASTERN)
            _total_et = pd.Timestamp(_rb.index[_max_idx]).tz_convert(EASTERN)

            st.markdown(
                f'<div style="background:#16213e; border:1px solid #5c6bc0; border-radius:6px; '
                f'padding:8px 14px; margin:6px 0; font-family:monospace; font-size:16px; '
                f'color:#90caf9; text-align:center; letter-spacing:1px;">'
                f'🕐 {_cur_et.strftime("%H:%M")} ET &nbsp;|&nbsp; '
                f'Bar {_cur_idx + 1} / {_max_idx + 1}</div>',
                unsafe_allow_html=True,
            )

            # Bar slider
            replay_bar_idx = st.slider(
                "Bar (time)", min_value=0, max_value=_max_idx,
                value=_cur_idx, step=1,
                format="%d",
                key="replay_slider",
            )
            if replay_bar_idx != _cur_idx:
                st.session_state.replay_bar_idx = replay_bar_idx
                st.session_state.replay_playing = False
                st.rerun()

            # Playback controls
            _sp_label = {"Slow (1 bar/step)": 1, "Normal (2 bars/step)": 2,
                         "Fast (5 bars/step)": 5, "Turbo (10 bars/step)": 10}
            _sp_sel = st.selectbox("Speed", list(_sp_label.keys()), index=1,
                                    key="replay_speed_sel")
            st.session_state.replay_speed = _sp_label[_sp_sel]

            rc1, rc2, rc3, rc4 = st.columns(4)
            if rc1.button("⏮", help="Jump to start"):
                st.session_state.replay_bar_idx = 0
                st.session_state.replay_playing = False
                st.rerun()
            if rc2.button("◀", help="Step back"):
                st.session_state.replay_bar_idx = max(0, _cur_idx - st.session_state.replay_speed)
                st.session_state.replay_playing = False
                st.rerun()
            if rc3.button("▶" if not st.session_state.replay_playing else "⏸",
                          help="Play / Pause"):
                st.session_state.replay_playing = not st.session_state.replay_playing
                st.rerun()
            if rc4.button("▶▶", help="Step forward"):
                st.session_state.replay_bar_idx = min(_max_idx, _cur_idx + st.session_state.replay_speed)
                st.session_state.replay_playing = False
                st.rerun()

            if st.button("🗑 Clear / Load new day", use_container_width=True):
                st.session_state.replay_bars    = None
                st.session_state.replay_bar_idx = 0
                st.session_state.replay_playing = False
                st.rerun()

    else:
        live_feed = st.selectbox("Data Feed", ["iex", "sip"], index=0,
                                  help="IEX works on all accounts. SIP needs a subscription.")
        if not st.session_state.live_active:
            start_live = st.button("▶ Start Live Stream", use_container_width=True, type="primary")
        else:
            stop_live = st.button("⏹ Stop", use_container_width=True)
            st.success(f"🔴 Live: **{st.session_state.live_ticker}**")

    st.markdown("---")

    # ── Position Management ────────────────────────────────────────────────────
    st.header("📍 Position")
    _snap   = st.session_state.get("last_analysis_state") or {}
    _p_in   = st.session_state.position_in
    _p_tkr  = st.session_state.position_ticker
    _p_ent  = st.session_state.position_avg_entry
    _p_mfe  = st.session_state.position_peak_price
    _p_shr  = st.session_state.position_shares
    _p_strc = st.session_state.position_structure
    _cur    = _snap.get("price", 0.0)

    if _p_in:
        pnl_pct = (_cur - _p_ent) / _p_ent * 100 if _p_ent > 0 else 0
        pnl_dol = (_cur - _p_ent) * _p_shr if _p_shr > 0 else 0
        pnl_col = "#4caf50" if pnl_pct >= 0 else "#ef5350"
        st.markdown(
            f'<div style="background:{pnl_col}11; border:1px solid {pnl_col}55; '
            f'border-radius:6px; padding:10px 14px; margin-bottom:8px;">'
            f'<div style="font-size:11px; color:#888; margin-bottom:4px;">OPEN — {_p_tkr} × {_p_shr} sh</div>'
            f'<div style="font-size:13px; color:#ccc;">Entry: <b>${_p_ent:.2f}</b> &nbsp;|&nbsp; '
            f'MFE: <b>${_p_mfe:.2f}</b></div>'
            f'<div style="font-size:20px; font-weight:800; color:{pnl_col}; margin-top:4px;">'
            f'{"▲" if pnl_pct>=0 else "▼"} {abs(pnl_pct):.2f}%'
            f'{"  ($" + f"{pnl_dol:+.0f}" + ")" if _p_shr > 0 else ""}</div>'
            f'</div>',
            unsafe_allow_html=True,
        )
        exit_px = st.number_input("Exit Price", value=_cur if _cur else _p_ent,
                                   step=0.01, format="%.2f", key="pos_exit_px")
        exit_struct = st.text_input("Actual Structure (opt.)", value="", key="pos_exit_struct",
                                    placeholder="e.g. Trend Day")
        if st.button("🔴 Exit Position", use_container_width=True, key="pos_exit_btn"):
            _realized = exit_position(exit_px, actual_structure=exit_struct or _p_strc)
            st.success(f"✅ Exited — Realized P&L: ${_realized:+.2f}" if _p_shr > 0
                       else "✅ Position closed.")
            st.rerun()
    else:
        _default_tkr   = _snap.get("ticker", "")
        _default_strc  = _snap.get("structure", "")
        _default_price = _snap.get("price", 0.0)

        e_tkr  = st.text_input("Ticker", value=_default_tkr, key="pos_entry_tkr")
        e_px   = st.number_input("Entry Price",
                                  value=float(_default_price) if _default_price else 0.0,
                                  step=0.01, format="%.2f", key="pos_entry_px")
        e_strc = st.text_input("Structure at Entry", value=_default_strc, key="pos_entry_strc")

        # ── Auto-Size to Risk ─────────────────────────────────────────────────
        _auto_size = st.checkbox(
            "⚡ Auto-Size to Risk",
            value=False,
            key="pos_auto_size",
            help=(
                "Calculates shares from your SA Challenge account size & risk %.\n"
                "Risk Amount = Account Balance × Risk %\n"
                "Risk per Share = Entry Price − Stop Loss Price\n"
                "Shares = Risk Amount ÷ Risk per Share (rounded down)"
            ),
        )

        _acct_bal = float(st.session_state.get("sa_account_bal", 5000.0))
        _risk_pct = float(st.session_state.get("sa_risk_pct", 2.0))

        if _auto_size:
            # Stop Loss Price input replaces Shares input
            _sl_default = round(e_px - 0.10, 2) if e_px > 0 else 0.0
            e_sl = st.number_input(
                "Stop Loss Price",
                value=_sl_default,
                step=0.01,
                format="%.2f",
                key="pos_entry_sl",
                help="Your hard stop. Risk per share = Entry Price − Stop Loss Price.",
            )
            _risk_amt      = _acct_bal * (_risk_pct / 100.0)
            _risk_per_share = e_px - e_sl if e_px > e_sl else 0.0
            _calc_shares   = max(1, int(_risk_amt / _risk_per_share)) if _risk_per_share > 0 else 1
            # Live sizing card
            _sl_color = "#ef5350" if _risk_per_share <= 0 else "#4caf50"
            st.markdown(
                f'<div style="background:#0a0f1e; border:1px solid #1a2744; border-radius:6px; '
                f'padding:9px 13px; margin:4px 0 6px 0; font-size:12px; color:#90caf9; line-height:1.7;">'
                f'💰 Risk&nbsp;$: <b>${_risk_amt:.0f}</b> &nbsp;|&nbsp; '
                f'Risk/sh: <b style="color:{_sl_color};">'
                f'{"$" + f"{_risk_per_share:.2f}" if _risk_per_share > 0 else "⚠ entry ≤ stop"}'
                f'</b> &nbsp;|&nbsp; '
                f'<span style="font-size:14px; font-weight:800; color:#4caf50;">'
                f'Shares: {_calc_shares if _risk_per_share > 0 else "—"}</span>'
                f'</div>',
                unsafe_allow_html=True,
            )
            e_shr = _calc_shares
        else:
            e_sl  = None
            e_shr = st.number_input("Shares", value=100, step=1, min_value=1, key="pos_entry_shr")

        # ── Enter Position button ─────────────────────────────────────────────
        if st.button("🟢 Enter Position", use_container_width=True,
                     key="pos_enter_btn", type="primary"):
            if not e_tkr:
                st.error("Enter a ticker symbol.")
            elif e_px <= 0:
                st.error("Enter a valid entry price.")
            elif _auto_size and e_sl is not None and e_sl >= e_px:
                st.error("Stop Loss must be below Entry Price.")
            elif api_key and secret_key:
                # ── Alpaca first — local state only updates on confirmed fill ─
                with st.spinner(f"Submitting Limit order to Alpaca — {e_tkr.upper()} × {e_shr} sh…"):
                    _alp = execute_alpaca_trade(
                        api_key=api_key,
                        secret_key=secret_key,
                        is_paper=True,
                        ticker=e_tkr.upper(),
                        qty=int(e_shr),
                        side="buy",
                        limit_price=round(e_px, 2),
                    )
                if _alp["success"]:
                    enter_position(e_tkr.upper(), e_px, e_shr, e_strc)
                    st.success(
                        f"✅ Limit order placed — {e_tkr.upper()} × {e_shr} sh @ ${e_px:.2f}  "
                        f"| Alpaca ID: `{_alp['order_id']}`"
                    )
                    st.rerun()
                else:
                    st.error(f"❌ Alpaca rejected the order: {_alp['message']}")
            else:
                # No API keys — log locally only
                st.warning("⚠️ No Alpaca keys — logging position locally only (no real order placed).")
                enter_position(e_tkr.upper(), e_px, e_shr, e_strc)
                st.success(f"✅ Logged {e_tkr.upper()} × {e_shr} sh @ ${e_px:.2f} (local only)")
                st.rerun()

    st.markdown("---")

    # ── Audio alert controls ───────────────────────────────────────────────────
    st.header("🔔 Alerts")
    audio_alerts_enabled = st.checkbox(
        "Enable Audio Alerts",
        value=True,
        key="audio_alerts_enabled",
        help="Play sounds when TCS crosses 80% (chime) or drops below 30% (low tone)."
    )

    if audio_alerts_enabled:
        import streamlit.components.v1 as _comp
        _comp.html(
            """
            <style>
              .ab{background:#16213e;border:1px solid #5c6bc0;color:#aaa;
                  padding:5px 12px;border-radius:5px;cursor:pointer;
                  font-size:12px;width:100%;margin:2px 0;transition:all 0.2s;}
              .ab:hover{border-color:#90caf9;color:#e0e0e0;}
              .ab.ok{border-color:#4caf50!important;color:#4caf50!important;}
              small{color:#555;font-size:10px;line-height:1.4;display:block;margin-top:4px;}
            </style>
            <button class="ab" id="ab" onclick="
              var C=new(window.AudioContext||window.webkitAudioContext)();
              var o=C.createOscillator(),g=C.createGain();
              o.type='sine'; o.frequency.value=880;
              o.connect(g); g.connect(C.destination);
              g.gain.setValueAtTime(0.12,C.currentTime);
              g.gain.exponentialRampToValueAtTime(0.001,C.currentTime+0.3);
              o.start(); o.stop(C.currentTime+0.3);
              this.textContent='✓ Audio Ready';
              this.classList.add('ok');
            ">🔊 Enable Browser Audio</button>
            <small>Browsers block auto-play until you click above once per session.</small>
            """,
            height=68,
            scrolling=False,
        )

    st.markdown("---")

    # ── Gap Scanner Controls ───────────────────────────────────────────────────
    st.header("🔍 Gap Scanner")
    st.caption("Enter tickers to watch. Scan fetches pre-market volume and gap data.")
    # Use saved watchlist if available, fall back to default
    _scanner_default = (
        st.session_state.get("_watchlist_tickers")
        or _DEFAULT_WATCHLIST
    )
    watchlist_raw = st.text_area(
        "Watchlist (comma-separated)",
        value=_scanner_default,
        height=110,
        help="Tickers priced $1–$50 at scan time will be analysed.",
        key="watchlist_raw",
    )
    scan_feed = st.selectbox("Scanner Feed", ["iex", "sip"], index=0, key="scan_feed_select",
                             help="IEX = free tier, works for all accounts. SIP = full tape with PM RVOL (requires paid Alpaca SIP subscription).")
    if scan_feed == "iex":
        st.info("ℹ️ IEX (free tier): scanner shows Gap % ranked results. "
                "PM Volume will be blank. Switch to SIP if you have a paid Alpaca data subscription.")
    _price_cols = st.columns(2)
    scan_min_price = _price_cols[0].number_input(
        "Min Price ($)", min_value=0.01, max_value=999.0, value=0.10,
        step=0.10, format="%.2f", key="scan_min_price",
        help="Exclude tickers below this price"
    )
    scan_max_price = _price_cols[1].number_input(
        "Max Price ($)", min_value=0.10, max_value=9999.0, value=50.0,
        step=5.0, format="%.2f", key="scan_max_price",
        help="Exclude tickers above this price"
    )
    scan_button = st.button("🔍 Scan Gap Plays", use_container_width=True)

    st.markdown("---")
    st.caption("SIP = full national tape + pre-market data. IEX = regular hours (9:30–4 PM) only.")

    # ── Saved Watchlist (T008) ────────────────────────────────────────────────
    st.markdown("---")
    st.header("⭐ My Watchlist")
    if not st.session_state.get("_watchlist_loaded"):
        _saved_wl = load_watchlist(st.session_state.get("auth_user_id", ""))
        if _saved_wl:
            st.session_state["_watchlist_tickers"] = ", ".join(_saved_wl)
        st.session_state["_watchlist_loaded"] = True
    _wl_raw = st.text_area(
        "Tickers (comma-separated)",
        value=st.session_state.get("_watchlist_tickers", ""),
        height=80, key="watchlist_textarea",
        placeholder="AAPL, GME, AMC, MSTR",
    )
    _wl_cols = st.columns(2)
    if _wl_cols[0].button("💾 Save", use_container_width=True, key="wl_save_btn"):
        _wl_list = [t.strip().upper() for t in _wl_raw.replace("\n", ",").split(",")
                    if t.strip()]
        _ok = save_watchlist(_wl_list, st.session_state.get("auth_user_id", ""))
        st.session_state["_watchlist_tickers"] = ", ".join(_wl_list)
        if _ok:
            st.success(f"Saved {len(_wl_list)} tickers")
        else:
            st.warning("Saved locally (Supabase unavailable)")
    if _wl_cols[1].button("▶ Next Ticker", use_container_width=True, key="wl_load_btn"):
        _wl_list = [t.strip().upper() for t in _wl_raw.replace("\n", ",").split(",")
                    if t.strip()]
        if _wl_list:
            _wl_idx = st.session_state.get("_wl_cycle_idx", 0) % len(_wl_list)
            _sym = _wl_list[_wl_idx]
            st.session_state["_load_ticker"] = _sym
            st.session_state["_wl_cycle_idx"] = (_wl_idx + 1) % len(_wl_list)
            st.caption(f"{_wl_idx + 1}/{len(_wl_list)}: {_sym}")

    # ── Account & Sign Out ────────────────────────────────────────────────────
    st.markdown("---")
    _auth_email_disp = st.session_state.get("auth_email", "")
    if _auth_email_disp:
        st.markdown(
            f'<div style="font-size:11px; color:#90caf9; margin-bottom:6px;">'
            f'👤 {_auth_email_disp}</div>',
            unsafe_allow_html=True,
        )
        if st.button("🚪 Sign Out", use_container_width=True, key="signout_btn"):
            auth_signout()
            for _k in ("auth_user", "auth_user_id", "auth_email"):
                st.session_state[_k] = "" if _k != "auth_user" else None
            st.rerun()
    else:
        st.markdown(
            '<div style="font-size:11px; color:#555;">Not logged in</div>',
            unsafe_allow_html=True,
        )


# ── Auto-restore session from disk (survives server restarts) ─────────────────
if not st.session_state.get("auth_user") and not st.session_state.get("_restore_tried"):
    st.session_state["_restore_tried"] = True
    _restored = try_restore_session()
    if _restored.get("user"):
        _ru = _restored["user"]
        st.session_state["auth_user"]    = _ru
        st.session_state["auth_user_id"] = str(_ru.id)
        st.session_state["auth_email"]   = _restored.get("email", "")
        st.rerun()

# ── Auth gate: show login page if not authenticated ───────────────────────────
if not st.session_state.get("auth_user"):
    render_login_page()
    st.stop()

_AUTH_USER_ID = st.session_state.get("auth_user_id", "")

# ── Auto-load user preferences once per session after login ───────────────────
if _AUTH_USER_ID and not st.session_state.get("_prefs_loaded"):
    _prefs = load_user_prefs(_AUTH_USER_ID)
    if _prefs.get("alpaca_key"):
        st.session_state["_pref_alpaca_key"]    = _prefs["alpaca_key"]
    if _prefs.get("alpaca_secret"):
        st.session_state["_pref_alpaca_secret"] = _prefs["alpaca_secret"]
    if _prefs.get("discord_webhook"):
        st.session_state["discord_webhook_url"] = _prefs["discord_webhook"]
    st.session_state["_prefs_loaded"] = True

# ── Cross-tab High Conviction alert (T005) ────────────────────────────────────
_hc_alert_state = st.session_state.get("_hc_alert_state")
if _hc_alert_state:
    _hc_sym  = _hc_alert_state.get("ticker", "")
    _hc_rvol = _hc_alert_state.get("rvol", 0)
    _hc_dir  = _hc_alert_state.get("direction", "BUY")
    _hc_clr  = "#4caf50" if _hc_dir == "BUY" else "#ef5350"
    _hc_icon = "🚀" if _hc_dir == "BUY" else "🔻"
    st.markdown(
        f'<div style="background:{_hc_clr}22; border:1.5px solid {_hc_clr}; border-radius:6px; '
        f'padding:7px 16px; margin-bottom:6px; font-size:13px; font-weight:800; color:{_hc_clr};">'
        f'{_hc_icon} HIGH CONVICTION {_hc_dir} SIGNAL ACTIVE — {_hc_sym} | '
        f'RVOL {_hc_rvol:.1f}× | Go to Main Chart to trade</div>',
        unsafe_allow_html=True,
    )

# ── Schema migration reminder ─────────────────────────────────────────────────
if not st.session_state.get("_migration_checked"):
    _col_ok = check_user_id_column_exists()
    st.session_state["_migration_checked"] = True
    st.session_state["_migration_needed"] = not _col_ok

if st.session_state.get("_migration_needed"):
    with st.expander("⚠️ Database Migration Required — click to expand", expanded=True):
        st.error(
            "Your Supabase tables are missing the **user_id** column needed for "
            "multi-user data isolation. Run the following SQL in your Supabase SQL editor:"
        )
        st.code(
            "ALTER TABLE trade_journal ADD COLUMN IF NOT EXISTS user_id TEXT;\n"
            "ALTER TABLE accuracy_tracker ADD COLUMN IF NOT EXISTS user_id TEXT;",
            language="sql",
        )
        st.caption(
            "Go to app.supabase.com → your project → SQL Editor → paste + run. "
            "This banner disappears once the columns exist."
        )

st.title("📊 Volume Profile Dashboard — Small Cap Stocks")

# ── Live Pulse Header ──────────────────────────────────────────────────────────
_las = st.session_state.get("last_analysis_state")
if _las:
    _lbl    = _las.get("structure", "")
    _tcs    = _las.get("tcs", 0.0)
    _rvol   = _las.get("rvol")
    _sym    = _las.get("ticker", "")
    _pr     = _las.get("price", 0.0)
    _lc     = _las.get("label_color", "#90caf9")
    _rc     = _las.get("rvol_color", "#aaa")
    _runner = _las.get("is_runner", False)
    _edge   = _las.get("edge_score")
    _e_bkd  = _las.get("edge_breakdown", {})

    _rvol_str = f"{_rvol:.1f}×" if _rvol is not None else "—"
    _tcs_fill = ("linear-gradient(90deg,#FFD700,#00BFFF)" if _runner
                 else "linear-gradient(90deg,#4caf50,#4caf50)" if _tcs >= 70
                 else "linear-gradient(90deg,#ef5350,#ef5350)" if _tcs <= 30
                 else "linear-gradient(90deg,#ffa726,#ffa726)")
    if _edge is None:
        _edge_str, _edge_col = "—", "#37474f"
    elif _edge >= 75:
        _edge_str, _edge_col = f"{_edge:.0f}", "#4caf50"
    elif _edge >= 50:
        _edge_str, _edge_col = f"{_edge:.0f}", "#ffa726"
    else:
        _edge_str, _edge_col = f"{_edge:.0f}", "#ef5350"
    _edge_fill = (
        "linear-gradient(90deg,#4caf50,#26a69a)" if (_edge or 0) >= 75
        else "linear-gradient(90deg,#ffa726,#ff7043)" if (_edge or 0) >= 50
        else "linear-gradient(90deg,#ef5350,#b71c1c)"
    ) if _edge is not None else "linear-gradient(90deg,#37474f,#37474f)"
    _edge_sub = (
        f"TCS {_e_bkd.get('tcs_pts',0):.0f} + "
        f"Struct {_e_bkd.get('struct_pts',0):.0f} + "
        f"Env {_e_bkd.get('env_pts',0):.0f} + "
        f"Tape {_e_bkd.get('fb_pts',0):.0f}"
    ) if _e_bkd else "Run analysis to compute"

    st.markdown(f"""
    <div style="display:flex; gap:12px; flex-wrap:wrap; margin:0 0 4px 0;">
        <div style="flex:1.2; min-width:200px; background:linear-gradient(135deg,{_lc}22,{_lc}0a);
                    border-left:4px solid {_lc}; border-radius:8px; padding:12px 18px;">
            <div style="font-size:10px; color:#888; text-transform:uppercase;
                        letter-spacing:1px; margin-bottom:4px;">Structure</div>
            <div style="font-size:20px; font-weight:800; color:{_lc};">{_lbl}</div>
            <div style="font-size:12px; color:#aaa; margin-top:2px;">{_sym} · ${_pr:.2f}</div>
        </div>
        <div style="flex:1; min-width:160px; background:#12122288;
                    border-left:4px solid #90caf9; border-radius:8px; padding:12px 18px;">
            <div style="font-size:10px; color:#888; text-transform:uppercase;
                        letter-spacing:1px; margin-bottom:6px;">TCS</div>
            <div style="background:#2a2a4a; border-radius:6px; height:8px; overflow:hidden; margin-bottom:6px;">
                <div style="width:{min(_tcs,100):.0f}%; background:{_tcs_fill};
                            height:100%; border-radius:6px;"></div>
            </div>
            <div style="font-size:22px; font-weight:900; color:{'#FFD700' if _runner else '#90caf9'};">{_tcs:.0f}%</div>
        </div>
        <div style="flex:1; min-width:140px; background:#12122288;
                    border-left:4px solid {_rc}; border-radius:8px; padding:12px 18px;">
            <div style="font-size:10px; color:#888; text-transform:uppercase;
                        letter-spacing:1px; margin-bottom:4px;">RVOL</div>
            <div style="font-size:22px; font-weight:900; color:{_rc};">{_rvol_str}</div>
            <div style="font-size:11px; color:#666; margin-top:2px;">
                {'⚡ RUNNER' if _runner else ('🔥 In Play' if _rvol and _rvol > 3 else '— Normal')}
            </div>
        </div>
        <div style="flex:1; min-width:160px; background:linear-gradient(135deg,{_edge_col}18,{_edge_col}08);
                    border-left:4px solid {_edge_col}; border-radius:8px; padding:12px 18px;">
            <div style="font-size:10px; color:#888; text-transform:uppercase;
                        letter-spacing:1px; margin-bottom:6px;">Edge Score</div>
            <div style="background:#2a2a4a; border-radius:6px; height:8px; overflow:hidden; margin-bottom:6px;">
                <div style="width:{min((_edge or 0),100):.0f}%; background:{_edge_fill};
                            height:100%; border-radius:6px;"></div>
            </div>
            <div style="font-size:24px; font-weight:900; color:{_edge_col}; font-family:monospace;">{_edge_str}</div>
            <div style="font-size:9px; color:#546e7a; margin-top:3px;">{_edge_sub}</div>
        </div>
    </div>
    """, unsafe_allow_html=True)

    # ── Predictive context — your personal historical win rate for this setup ───
    try:
        if _AUTH_USER_ID and _edge is not None and _rvol is not None:
            _pred_ctx = get_predictive_context(
                _AUTH_USER_ID, float(_edge), float(_rvol), str(_lbl)
            )
            _pe = _pred_ctx.get("exact", {})
            _pb = _pred_ctx.get("by_struct", {})
            _po = _pred_ctx.get("overall", {})
            _show_pred = _pe or (_pb and _pb.get("n", 0) >= 3) or (_po and _po.get("n", 0) >= 5)
            if _show_pred:
                if _pe and _pe.get("n", 0) >= 3:
                    _wr = _pe["win_rate"] * 100
                    _wn = _pe["n"]
                    _wlbl = f"Exact setup: {_wr:.0f}% win rate ({_wn} trades)"
                    _wcol = "#4caf50" if _wr >= 60 else "#ffa726" if _wr >= 45 else "#ef5350"
                elif _pb and _pb.get("n", 0) >= 3:
                    _wr = _pb["win_rate"] * 100
                    _wn = _pb["n"]
                    _wlbl = f"{_lbl}: {_wr:.0f}% win rate ({_wn} trades)"
                    _wcol = "#4caf50" if _wr >= 60 else "#ffa726" if _wr >= 45 else "#ef5350"
                elif _po and _po.get("n", 0) >= 5:
                    _wr = _po["win_rate"] * 100
                    _wn = _po["n"]
                    _wlbl = f"Overall: {_wr:.0f}% win rate ({_wn} trades logged)"
                    _wcol = "#4caf50" if _wr >= 60 else "#ffa726" if _wr >= 45 else "#ef5350"
                else:
                    _show_pred = False
                if _show_pred:
                    st.markdown(
                        f'<div style="background:{_wcol}18; border:1px solid {_wcol}55; '
                        f'border-radius:6px; padding:7px 16px; font-size:13px; '
                        f'font-weight:600; color:{_wcol}; margin:4px 0 6px 0;">'
                        f'📊 Your historical data: {_wlbl}</div>',
                        unsafe_allow_html=True
                    )
    except Exception:
        pass

    # Alert Banner
    if _runner or _tcs >= 80:
        st.markdown(
            '<div style="background:#FFD70022; border:1px solid #FFD700; border-radius:6px; '
            'padding:8px 18px; font-size:14px; font-weight:700; color:#FFD700; margin:4px 0 8px 0;">'
            f'🚀 STOCK IN PLAY — {_sym} | TCS {_tcs:.0f}% | RVOL {_rvol_str}</div>',
            unsafe_allow_html=True
        )
    elif _tcs <= 30:
        st.markdown(
            '<div style="background:#ef535022; border:1px solid #ef5350; border-radius:6px; '
            'padding:8px 18px; font-size:14px; font-weight:700; color:#ef5350; margin:4px 0 8px 0;">'
            f'⚠ CAUTION — Low Conviction | TCS {_tcs:.0f}% | Chop Risk Active</div>',
            unsafe_allow_html=True
        )

_STRUCTURE_COLORS_MAP = {
    "trend":       "#ff9800",
    "bear":        "#ff5722",
    "double":      "#00bcd4",
    "non":         "#78909c",
    "normal var":  "#aed581",
    "variation":   "#aed581",
    "neutral ext": "#7e57c2",
    "neutral":     "#80cbc4",
    "normal":      "#66bb6a",
    "balanced":    "#66bb6a",
}

def _structure_color(label_str):
    """Return a color for a structure label string."""
    s = label_str.lower()
    for key, col in _STRUCTURE_COLORS_MAP.items():
        if key in s:
            return col
    return "#5c6bc0"


# ── Live Playbook Screener Tab ──────────────────────────────────────────────────
def render_playbook_tab(api_key: str = "", secret_key: str = ""):
    """Render the 📋 Playbook tab — live small-cap screener with one-click journal routing."""

    # ── Header ─────────────────────────────────────────────────────────────────
    st.markdown(
        '<div style="margin-bottom:4px;">'
        '<span style="font-size:22px; font-weight:800; color:#e0e0e0;">📋 Live Playbook</span>'
        '<span style="font-size:12px; color:#5c6bc0; margin-left:14px; text-transform:uppercase; '
        'letter-spacing:1px;">Small-Cap Screener · $2 – $20 · Alpaca Market Data</span>'
        '</div>',
        unsafe_allow_html=True,
    )
    st.markdown(
        '<div style="font-size:12px; color:#607d8b; margin-bottom:16px;">'
        'Combines <b>Most Active</b> (by volume) and <b>Top Gainers</b> from Alpaca. '
        'Filtered to your target range. Click <b>📝 Log</b> on any row to pre-load '
        'the ticker &amp; price in your Chart → Log Entry form.'
        '</div>',
        unsafe_allow_html=True,
    )

    # ── No credentials guard ────────────────────────────────────────────────────
    if not api_key or not secret_key:
        st.warning("Enter your **Alpaca API Key** and **Secret Key** in the sidebar to enable the Playbook scanner.")
        return

    # ── Scan controls ───────────────────────────────────────────────────────────
    _pb_c1, _pb_c2, _pb_c3 = st.columns([2, 1, 1])
    with _pb_c1:
        _pb_top = st.slider("Candidates to scan per source", 20, 100, 50, step=10,
                            key="playbook_top_slider")
    with _pb_c2:
        st.markdown("<div style='height:28px'></div>", unsafe_allow_html=True)
        _pb_refresh = st.button("🔄 Refresh Scan", use_container_width=True,
                                key="playbook_refresh_btn")
    with _pb_c3:
        st.markdown("<div style='height:28px'></div>", unsafe_allow_html=True)
        _pb_auto = st.checkbox("Auto-refresh (60 s)", value=False, key="playbook_auto_refresh")

    # ── Quant scoring controls ───────────────────────────────────────────────────
    st.markdown(
        '<div style="background:#0a0f1e; border:1px solid #1a2744; border-radius:8px; '
        'padding:12px 16px; margin:12px 0;">'
        '<span style="font-size:12px; font-weight:700; color:#7c4dff; text-transform:uppercase; '
        'letter-spacing:1px;">🧠 Quant Engine Scoring</span>'
        '<span style="font-size:11px; color:#607d8b; margin-left:12px;">'
        'Fetches intraday bars for each ticker and runs TCS + Structure prediction</span>'
        '</div>',
        unsafe_allow_html=True,
    )
    _qs_c1, _qs_c2, _qs_c3 = st.columns([1.5, 1, 1])
    with _qs_c1:
        _pb_feed = st.radio("Bar data feed", ["IEX (free)", "SIP (paid)"],
                            horizontal=True, key="playbook_feed_radio")
        _pb_feed_str = "iex" if "IEX" in _pb_feed else "sip"
    with _qs_c2:
        _pb_max_score = st.number_input("Max tickers to score", min_value=5, max_value=100,
                                        value=30, step=5, key="playbook_max_score")
    with _qs_c3:
        st.markdown("<div style='height:28px'></div>", unsafe_allow_html=True)
        _pb_score_btn = st.button("🧠 Run Quant Score", use_container_width=True,
                                  key="playbook_score_btn")

    # ── Cache keys ───────────────────────────────────────────────────────────────
    _pb_cache_key  = "playbook_results_cache"
    _pb_time_key   = "playbook_last_fetch"
    _pb_score_key  = "playbook_scored_cache"

    # ── Fetch raw scan ───────────────────────────────────────────────────────────
    _should_fetch = (
        _pb_refresh
        or _pb_cache_key not in st.session_state
        or (
            _pb_auto
            and (time.time() - st.session_state.get(_pb_time_key, 0)) > 60
        )
    )

    _RVOL_MIN = 2.0   # minimum pre-market RVOL to appear in Playbook

    if _should_fetch:
        with st.spinner("Scanning Alpaca market data…"):
            _rows, _err = scan_playbook(api_key, secret_key, top=_pb_top)
        # Filter out low-RVOL stocks when SIP data is available.
        # IEX rows have pm_rvol=None — keep those since we can't measure them.
        _before = len(_rows)
        _rows = [r for r in _rows
                 if r.get("pm_rvol") is None or r.get("pm_rvol", 0) >= _RVOL_MIN]
        _filtered_out = _before - len(_rows)
        if _filtered_out:
            st.session_state["_pb_filtered_count"] = _filtered_out
        else:
            st.session_state.pop("_pb_filtered_count", None)
        st.session_state[_pb_cache_key] = (_rows, _err)
        st.session_state[_pb_time_key]  = time.time()
        st.session_state.pop(_pb_score_key, None)   # invalidate old scores
    else:
        _rows, _err = st.session_state.get(_pb_cache_key, ([], ""))

    # ── Weekend/holiday/after-hours notice ───────────────────────────────────────
    import datetime as _dt
    _today = _dt.date.today()
    _market_closed_today = not is_trading_day(_today)
    if _market_closed_today:
        _last_td = get_last_trading_day(as_of=_today, api_key=api_key, secret_key=secret_key)
        _reason  = "weekend" if _today.weekday() >= 5 else "holiday"
        st.info(
            f"📅 Market is closed ({_reason}). Quant Score will use the most recent "
            f"trading day: **{_last_td.strftime('%A, %b %d')}**."
        )
    elif _dt.datetime.now().hour < 9 or (_dt.datetime.now().hour == 9 and _dt.datetime.now().minute < 30):
        st.info("⏰ Pre-market — Quant Score will use yesterday's intraday bars.")

    # ── Run quant scoring ────────────────────────────────────────────────────────
    if _pb_score_btn and _rows:
        with st.spinner(
            f"Running quant engine on top {min(int(_pb_max_score), len(_rows))} tickers "
            f"(fetching intraday bars via {_pb_feed_str.upper()})…"
        ):
            import copy as _copy
            _rows_to_score = _copy.deepcopy(_rows)
            _scored_rows = score_playbook_tickers(
                _rows_to_score, api_key, secret_key,
                feed=_pb_feed_str, max_tickers=int(_pb_max_score),
                user_id=_AUTH_USER_ID,
                discord_webhook_url=st.session_state.get("discord_webhook_url", ""),
            )
        st.session_state[_pb_score_key] = _scored_rows
        _rows = _scored_rows
    elif _pb_score_key in st.session_state:
        _rows = st.session_state[_pb_score_key]

    _scores_loaded = any(r.get("tcs") is not None for r in _rows) if _rows else False

    # ── Pre-load success banner ─────────────────────────────────────────────────
    _pb_loaded = st.session_state.pop("_playbook_just_loaded", None)
    if _pb_loaded:
        st.success(
            f"✅ **{_pb_loaded['ticker']}** pre-loaded at **${_pb_loaded['price']:.2f}** — "
            f"click the **📈 Main Chart** tab and scroll down to the "
            f"**Log This Trade Entry** form to complete your journal."
        )

    # ── Error handling ──────────────────────────────────────────────────────────
    if _err and _err != "market_closed":
        st.error(f"Screener error: {_err}")
    elif _err == "market_closed" and not _market_closed_today:
        st.warning("⏰ Screener returned no data — market may not be open yet. Try again after 9:30 AM ET.")

    if not _rows:
        if not _err:
            st.info("No small-cap stocks in the $2–$20 range found right now. Try refreshing after market open.")
        return

    # ── Last fetch timestamp + score hint ───────────────────────────────────────
    _ts = st.session_state.get(_pb_time_key, 0)
    if _ts:
        _ago     = int(time.time() - _ts)
        _ago_str = f"{_ago}s ago" if _ago < 120 else f"{_ago // 60}m ago"
        _scored_badge = (
            f' · <span style="color:#7c4dff;">🧠 Quant scored</span>'
            if _scores_loaded else
            f' · <span style="color:#546e7a;">Click <b>🧠 Run Quant Score</b> to add TCS & Setup</span>'
        )
        _filt_n = st.session_state.get("_pb_filtered_count", 0)
        _filt_note = (
            f' · <span style="color:#ef5350;">{_filt_n} low-RVOL (&lt;2×) removed</span>'
            if _filt_n else ""
        )
        st.markdown(
            f'<div style="font-size:11px; color:#546e7a; margin-bottom:12px;">'
            f'Last fetched: <b>{_ago_str}</b> · {len(_rows)} stocks in range'
            f'{_filt_note}{_scored_badge}</div>',
            unsafe_allow_html=True,
        )

    # ── Column layout ───────────────────────────────────────────────────────────
    # ── Calibration status banner ────────────────────────────────────────────────
    if _scores_loaded:
        _w_info = compute_adaptive_weights(_AUTH_USER_ID)
        _rows_used = _w_info.get("rows_used", 0)
        if _w_info.get("calibrated"):
            st.markdown(
                f'<div style="background:#0a1628; border:1px solid #1565c0; border-radius:6px; '
                f'padding:8px 16px; margin-bottom:10px; font-size:11px; color:#90caf9; '
                f'font-family:monospace;">🧠 EDGE SCORE AUTO-CALIBRATED · '
                f'{_rows_used} historical rows · '
                f'TCS weight {_w_info["tcs"]*100:.0f}% · '
                f'Structure {_w_info["structure"]*100:.0f}% · '
                f'Environment {_w_info["environment"]*100:.0f}% · '
                f'False Break {_w_info["false_break"]*100:.0f}% · '
                f'Sorted by Edge Score ↓</div>',
                unsafe_allow_html=True,
            )
        else:
            st.markdown(
                f'<div style="background:#0a1628; border:1px solid #37474f; border-radius:6px; '
                f'padding:8px 16px; margin-bottom:10px; font-size:11px; color:#546e7a; '
                f'font-family:monospace;">⚙ EDGE SCORE using DEFAULT weights '
                f'(TCS 35% · Structure 25% · Environment 25% · False Break 15%) · '
                f'Run backtests to auto-calibrate · {_rows_used} rows saved so far</div>',
                unsafe_allow_html=True,
            )

    _COL_W = [0.85, 0.75, 0.8, 1.0, 0.8, 0.7, 0.85, 1.1, 0.7]
    _COL_LABELS = ["Ticker", "Price", "% Change", "Volume", "Source",
                   "TCS", "Edge Score", "Predicted Setup", "Action"]

    # ── Column headers ──────────────────────────────────────────────────────────
    _hdr = st.columns(_COL_W)
    for _col, _lbl in zip(_hdr, _COL_LABELS):
        _hdr_clr = "#4caf50" if _lbl == "Edge Score" else "#7c4dff" if _lbl in ("TCS", "Predicted Setup") else "#90caf9"
        _col.markdown(
            f'<div style="font-size:11px; font-weight:700; color:{_hdr_clr}; '
            f'text-transform:uppercase; letter-spacing:0.8px; padding:4px 0 8px 0; '
            f'border-bottom:1px solid #1e2a3a;">{_lbl}</div>',
            unsafe_allow_html=True,
        )

    # ── Data rows ───────────────────────────────────────────────────────────────
    for _i, _row in enumerate(_rows):
        _sym   = _row["ticker"]
        _price = _row["price"]
        _chg   = _row["change_pct"]
        _vol   = _row["volume"]
        _src   = _row["source"]
        _tcs   = _row.get("tcs")
        _setup = _row.get("structure", "—")

        _chg_color = "#4caf50" if _chg >= 0 else "#ef5350"
        _chg_sign  = "+" if _chg >= 0 else ""
        _vol_str   = f"{_vol:,}" if _vol else "—"

        _src_color = (
            "#4caf50" if _src == "Active + Gainer"
            else "#66bb6a" if _src == "Gainer"
            else "#5c6bc0"
        )

        # TCS color-coding
        if _tcs is None:
            _tcs_color = "#37474f"
            _tcs_str   = "—"
        elif _tcs >= 70:
            _tcs_color = "#4caf50"
            _tcs_str   = f"{_tcs:.0f}"
        elif _tcs >= 40:
            _tcs_color = "#ffa726"
            _tcs_str   = f"{_tcs:.0f}"
        else:
            _tcs_color = "#ef5350"
            _tcs_str   = f"{_tcs:.0f}"

        _row_cols = st.columns(_COL_W)

        _row_cols[0].markdown(
            f'<div style="padding:10px 0; font-size:15px; font-weight:800; color:#e0e0e0;">'
            f'{_sym}</div>', unsafe_allow_html=True,
        )
        _row_cols[1].markdown(
            f'<div style="padding:10px 0; font-size:14px; color:#cfd8dc;">'
            f'${_price:.2f}</div>', unsafe_allow_html=True,
        )
        _row_cols[2].markdown(
            f'<div style="padding:10px 0; font-size:14px; font-weight:700; color:{_chg_color};">'
            f'{_chg_sign}{_chg:.2f}%</div>', unsafe_allow_html=True,
        )
        _row_cols[3].markdown(
            f'<div style="padding:10px 0; font-size:13px; color:#90a4ae;">'
            f'{_vol_str}</div>', unsafe_allow_html=True,
        )
        _row_cols[4].markdown(
            f'<div style="padding:10px 0;">'
            f'<span style="background:{_src_color}22; color:{_src_color}; '
            f'font-size:10px; font-weight:700; padding:2px 8px; border-radius:10px; '
            f'border:1px solid {_src_color}55; text-transform:uppercase;">'
            f'{_src}</span></div>', unsafe_allow_html=True,
        )
        # TCS cell
        _row_cols[5].markdown(
            f'<div style="padding:8px 0;">'
            f'<span style="background:{_tcs_color}22; color:{_tcs_color}; '
            f'font-size:13px; font-weight:800; padding:3px 10px; border-radius:12px; '
            f'border:1px solid {_tcs_color}55;">{_tcs_str}</span>'
            f'</div>', unsafe_allow_html=True,
        )
        # Edge Score cell
        _edge = _row.get("edge_score")
        _bkd  = _row.get("edge_breakdown", {})
        if _edge is None:
            _edge_str   = "—"
            _edge_color = "#37474f"
            _edge_bg    = "#37474f"
        elif _edge >= 75:
            _edge_str   = f"{_edge:.0f}"
            _edge_color = "#4caf50"
            _edge_bg    = "#4caf50"
        elif _edge >= 50:
            _edge_str   = f"{_edge:.0f}"
            _edge_color = "#ffa726"
            _edge_bg    = "#ffa726"
        else:
            _edge_str   = f"{_edge:.0f}"
            _edge_color = "#ef5350"
            _edge_bg    = "#ef5350"
        _bkd_tip = (
            f"TCS {_bkd.get('tcs_pts',0):.0f} + "
            f"Struct {_bkd.get('struct_pts',0):.0f} + "
            f"Env {_bkd.get('env_pts',0):.0f} + "
            f"Tape {_bkd.get('fb_pts',0):.0f}"
        ) if _bkd else ""
        _row_cols[6].markdown(
            f'<div style="padding:8px 0;" title="{_bkd_tip}">'
            f'<span style="background:{_edge_bg}22; color:{_edge_color}; '
            f'font-size:14px; font-weight:900; padding:3px 12px; border-radius:12px; '
            f'border:2px solid {_edge_bg}66; font-family:monospace;">{_edge_str}</span>'
            f'</div>', unsafe_allow_html=True,
        )
        # Predicted Setup cell
        _setup_short = (_setup[:16] + "…") if len(str(_setup)) > 16 else _setup
        _row_cols[7].markdown(
            f'<div style="padding:10px 0; font-size:12px; color:#ce93d8; font-weight:600;">'
            f'{_setup_short}</div>', unsafe_allow_html=True,
        )
        with _row_cols[8]:
            if st.button("📝 Log", key=f"playbook_log_{_i}_{_sym}",
                         use_container_width=True):
                st.session_state["_fetched_price"]        = _price
                st.session_state["_fetched_volume"]        = _vol
                st.session_state["_fetched_symbol"]        = _sym
                st.session_state["_playbook_just_loaded"] = {
                    "ticker": _sym, "price": _price,
                }
                st.rerun()

        st.markdown(
            '<div style="border-bottom:1px solid #0d1520; margin:0;"></div>',
            unsafe_allow_html=True,
        )

    # ── Auto-refresh trigger ────────────────────────────────────────────────────
    if _pb_auto:
        _remaining = max(0, 60 - int(time.time() - st.session_state.get(_pb_time_key, 0)))
        st.markdown(
            f'<div style="font-size:11px; color:#37474f; margin-top:12px;">'
            f'Auto-refresh in {_remaining}s</div>',
            unsafe_allow_html=True,
        )

def _clean_structure_label(raw):
    """Strip emojis + extra words for a readable short label."""
    import re
    s = re.sub(r"[^\w\s()/\-]", "", str(raw)).strip()
    return s[:30] if len(s) > 30 else s


# ── Historical Backtester Tab ───────────────────────────────────────────────────
_BT_DEFAULT_TICKERS = (
    "GME,AMC,SOFI,SPCE,SNDL,TLRY,XELA,OCGN,CLOV,MVIS,"
    "WKHS,NKLA,RIDE,WISH,BBIG,SENS,CIDM,FFIE,MULN,PHUN,"
    "ATER,PROG,BIOR,CTRM,SIGA,GFAI,ONDS,ATNM,CTXR,PAVS"
)

_CALIBRATION_TICKERS = [
    "GME", "AMC", "SOFI", "SPCE", "SNDL", "TLRY", "OCGN", "CLOV", "MVIS",
    "WKHS", "NKLA", "RIDE", "BBIG", "SENS", "FFIE", "MULN",
    "ATER", "PROG", "CTRM", "GFAI", "ONDS", "ATNM", "CTXR", "PAVS",
    "PHUN", "CIDM", "WISH", "XELA",
]

_BT_WIN_CLR   = "#4caf50"
_BT_LOSS_CLR  = "#ef5350"
_BT_NEUT_CLR  = "#546e7a"


def _bt_tcs_color(tcs):
    if tcs is None:  return _BT_NEUT_CLR
    if tcs >= 70:    return "#4caf50"
    if tcs >= 40:    return "#ffa726"
    return "#ef5350"


def _bt_outcome_color(outcome):
    return {
        "Bullish Break": "#4caf50",
        "Bearish Break": "#ef5350",
        "Both Sides":    "#ffa726",
        "Range-Bound":   "#5c6bc0",
    }.get(outcome, _BT_NEUT_CLR)


def render_backtest_tab(api_key: str = "", secret_key: str = ""):
    """Render the 🔬 Backtest Engine tab — institutional backtesting terminal."""

    with st.expander("📋 What each section does — read before running anything", expanded=False):
        st.markdown(
            """
**This tab has two separate tools. They serve different purposes and write to different places.**

---

### 🧠 SECTION 1 — One-Click Calibration Run  *(top of this tab)*
**What it does:** Runs the quant model across a broad list of small-cap stocks over a historical date range.
Measures how accurately the 7-structure framework classified those days in hindsight.

**Who enters the tickers?** The system uses a pre-built training universe. You should leave it alone unless you have a specific reason to change it.

**⚠️ Do NOT paste your personal watchlist into the calibration ticker box.**

**Where results go:** A separate Supabase table called `backtest_sim_runs`. This does **NOT** affect your personal win rate, journal, or Analytics data in any way.

**When to run it:** Once per week or after adding new tickers to your watchlist, to keep the model calibrated on recent market behavior.

---

### 🔬 SECTION 2 — Single-Ticker / Multi-Ticker Simulation  *(below Calibration)*
**What it does:** Lets you test any ticker on any date or date range to see how the model would have traded it.

**Who enters the tickers?** You do — for research purposes. You can test a ticker you're considering adding to your watchlist, or check how the model did on a specific date.

**Where results go:** Also saved to `backtest_sim_runs`. Does NOT affect your personal analytics.

**When to use it:** When you want to audit a specific ticker or date before trading it live.

---

### 📊 Your personal data lives in:
- **📖 Journal tab** → your real Webull imports
- **📊 Analytics tab** → your real win rates derived from the journal
- Neither is touched by anything in this tab.
            """,
        )

    # ── Terminal header ─────────────────────────────────────────────────────────
    st.markdown(
        '<div style="background:#020813; border:1px solid #0d2137; border-radius:10px; '
        'padding:16px 22px; margin-bottom:18px;">'
        '<div style="font-size:11px; color:#1565c0; text-transform:uppercase; '
        'letter-spacing:2px; margin-bottom:4px;">QUANT RESEARCH TERMINAL v2</div>'
        '<div style="font-size:24px; font-weight:900; color:#e0e0e0; '
        'font-family:monospace;">🔬 Historical Backtest Engine</div>'
        '<div style="font-size:12px; color:#455a64; margin-top:4px;">'
        'Simulates your quant model on historical morning data → measures afternoon accuracy. '
        'Engine sees only 9:30–10:30 AM, then we check what actually happened 10:30 AM–4:00 PM.'
        '</div>'
        '</div>',
        unsafe_allow_html=True,
    )

    # ── Supabase migration reminder ──────────────────────────────────────────────
    if supabase:
        _bt_table_ok = False
        _bt_cols_missing = []
        try:
            _bt_probe = supabase.table("backtest_sim_runs").select("id").limit(1).execute()
            _bt_table_ok = True
        except Exception:
            pass

        if not _bt_table_ok:
            st.info(
                "**One-time setup:** Run this SQL in your Supabase SQL editor to enable "
                "automatic backtest history saving:\n\n"
                "```sql\n"
                "CREATE TABLE IF NOT EXISTS backtest_sim_runs (\n"
                "  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,\n"
                "  user_id TEXT,\n"
                "  sim_date DATE,\n"
                "  ticker TEXT,\n"
                "  open_price NUMERIC,\n"
                "  ib_low NUMERIC,\n"
                "  ib_high NUMERIC,\n"
                "  tcs NUMERIC,\n"
                "  predicted TEXT,\n"
                "  actual_outcome TEXT,\n"
                "  win_loss TEXT,\n"
                "  follow_thru_pct NUMERIC,\n"
                "  false_break_up BOOLEAN DEFAULT FALSE,\n"
                "  false_break_down BOOLEAN DEFAULT FALSE,\n"
                "  run_at TIMESTAMPTZ DEFAULT NOW()\n"
                ");\n"
                "```",
                icon="🗄️",
            )
        else:
            # Check whether key analytic columns exist (table may pre-date them)
            for _col in ["tcs", "ib_high", "ib_low"]:
                try:
                    supabase.table("backtest_sim_runs").select(_col).limit(1).execute()
                except Exception:
                    _bt_cols_missing.append(_col)

            if _bt_cols_missing:
                _alter_sql = "\n".join(
                    f"ALTER TABLE backtest_sim_runs ADD COLUMN IF NOT EXISTS {c} NUMERIC;"
                    for c in _bt_cols_missing
                )
                st.warning(
                    f"**Schema upgrade needed.** Your `backtest_sim_runs` table is missing "
                    f"column(s): `{'`, `'.join(_bt_cols_missing)}`. "
                    f"Run the SQL below in your **Supabase SQL editor**, then re-run calibration "
                    f"once to populate the new columns.\n\n"
                    f"```sql\n{_alter_sql}\n```",
                    icon="⚠️",
                )

    if not api_key or not secret_key:
        st.warning("Enter your **Alpaca API Key** and **Secret Key** in the sidebar to run backtests.")
        return

    # ══════════════════════════════════════════════════════════════════════════
    # BRAIN CALIBRATION RUN — uses YOUR journal tickers, falls back to defaults
    # Build calibration ticker list: journal tickers first, fallback to defaults
    # ══════════════════════════════════════════════════════════════════════════
    _cal_uid = st.session_state.get("auth_user_id", "")
    _cal_journal_df = load_journal(user_id=_cal_uid)
    if not _cal_journal_df.empty and "ticker" in _cal_journal_df.columns:
        _journal_tickers = sorted(set(
            str(t).upper().strip()
            for t in _cal_journal_df["ticker"].dropna().unique()
            if str(t).strip()
        ))
        _cal_ticker_pool = _journal_tickers
        _cal_source_label = f"your journal ({len(_cal_ticker_pool)} tickers)"
    else:
        _cal_ticker_pool = _CALIBRATION_TICKERS
        _cal_source_label = f"default list ({len(_cal_ticker_pool)} tickers)"

    st.markdown(
        f'<div style="background:#0a1628; border:1px solid #1565c044; border-radius:10px; '
        f'padding:14px 20px; margin-bottom:14px;">'
        f'<div style="font-size:11px; color:#1565c0; text-transform:uppercase; '
        f'letter-spacing:2px; margin-bottom:4px;">🧠 BRAIN CALIBRATION</div>'
        f'<div style="font-size:15px; font-weight:700; color:#e0e0e0; margin-bottom:4px;">'
        f'One-Click Calibration Run</div>'
        f'<div style="font-size:12px; color:#546e7a;">'
        f'Runs the quant model across <b style="color:#90caf9">{_cal_source_label}</b> '
        f'over your chosen lookback window. '
        f'Saves all results to Supabase so the structure probability model can recalibrate '
        f'against correctly-classified historical sessions.'
        f'</div>'
        f'</div>',
        unsafe_allow_html=True,
    )

    st.warning(
        "⚠️ **CALIBRATION TICKERS ≠ YOUR WATCHLIST.**  "
        "The tickers below are a broad small-cap universe used to train the model's "
        "structure recognition on historical data. "
        "**Do NOT paste your personal watchlist here.** "
        "Your watchlist goes in the sidebar (Gap Scanner) and the ⭐ My Watchlist section — not here.",
        icon="⚠️",
    )

    with st.expander(
        f"📋 Calibration ticker list ({len(_cal_ticker_pool)}) — click to view or edit",
        expanded=False,
    ):
        st.markdown(
            '<div style="background:#1a0000;border:1px solid #b71c1c;border-radius:6px;'
            'padding:10px 14px;margin-bottom:10px;font-size:12px;color:#ef9a9a;">'
            '<b>🚫 DO NOT put your personal watchlist here.</b><br>'
            'These tickers are the model\'s training universe — small-cap stocks used to '
            'teach the algorithm what each structure type looks like historically. '
            'Results are saved to a separate simulation table and do NOT affect your personal '
            'win rate or Analytics data.'
            '</div>',
            unsafe_allow_html=True,
        )
        _cal_ticker_edit = st.text_area(
            "One ticker per line or comma-separated — edits apply to this run only:",
            value="\n".join(_cal_ticker_pool),
            height=160,
            key="cal_ticker_edit",
        )
        _cal_ticker_pool = [
            t.strip().upper() for t in
            _cal_ticker_edit.replace(",", "\n").splitlines()
            if t.strip()
        ]
        st.caption(f"{len(_cal_ticker_pool)} tickers queued for calibration")

    _cal_feed_col, _cal_btn_col = st.columns([2, 1])
    with _cal_feed_col:
        _cal_days = st.slider(
            "Trading days to look back", min_value=1, max_value=22,
            value=5, step=1, key="cal_lookback_days",
            help="1 day = yesterday only. 5 = last full week. 22 = ~1 month."
        )
        _cal_feed = st.radio(
            "Feed", ["SIP (paid — accurate)", "IEX (free)"],
            key="cal_feed_radio", horizontal=True,
        )
        _cal_feed_str = "sip" if "SIP" in _cal_feed else "iex"
        _cal_confirmed = st.checkbox(
            f"✅ I confirm: these are calibration tickers, NOT my personal watchlist",
            key="cal_confirm_check",
        )
    with _cal_btn_col:
        st.markdown("<div style='height:12px'></div>", unsafe_allow_html=True)
        _cal_run = st.button(
            f"🧠 RUN ({len(_cal_ticker_pool)} tickers)", use_container_width=True,
            key="cal_run_btn", type="primary",
            disabled=not _cal_confirmed,
        )

    if _cal_run:
        _cal_end = get_last_trading_day(as_of=date.today())
        import math as _math
        _cal_days_back = _math.ceil(_cal_days * 7 / 5) + 3
        _cal_start = _cal_end - timedelta(days=_cal_days_back)
        _cal_label = f"{_cal_start} → {_cal_end}"
        st.info(
            f"Running {len(_cal_ticker_pool)} tickers · {_cal_start} → {_cal_end} "
            f"· Feed: {_cal_feed_str.upper()} · Saving to Supabase…"
        )
        with st.spinner(
            f"⏳ Calibrating model on {len(_cal_ticker_pool)} tickers × "
            f"{_cal_days} days ({_cal_label}) — this may take a few minutes…"
        ):
            try:
                _cal_results, _cal_summary, _cal_daily = run_backtest_range(
                    api_key, secret_key,
                    start_date=_cal_start,
                    end_date=_cal_end,
                    tickers=_cal_ticker_pool,
                    feed=_cal_feed_str,
                    price_min=0.10,
                    price_max=500.0,
                    slippage_pct=0.5,
                )
                if _cal_results:
                    try:
                        save_backtest_sim_runs(_cal_results, user_id=_AUTH_USER_ID)
                        _saved_ok = True
                    except Exception:
                        _saved_ok = False
                    _wins    = sum(1 for r in _cal_results if r.get("win_loss") == "Win")
                    _losses  = sum(1 for r in _cal_results if r.get("win_loss") == "Loss")
                    _total_r = len(_cal_results)
                    _wr = _wins / _total_r * 100 if _total_r else 0
                    _save_msg = "✅ Saved to Supabase" if _saved_ok else "⚠️ Supabase save failed"
                    st.success(
                        f"Calibration complete — {_total_r} sessions processed · "
                        f"Win rate: {_wr:.1f}% ({_wins}W / {_losses}L) · {_save_msg}"
                    )
                    _cal_struct_counts: dict = {}
                    for _r in _cal_results:
                        _s = _r.get("predicted", "Unknown")
                        _cal_struct_counts[_s] = _cal_struct_counts.get(_s, 0) + 1
                    _struct_parts = [f"{k}: {v}" for k, v in
                                     sorted(_cal_struct_counts.items(), key=lambda x: -x[1])]
                    st.caption("Structure distribution: " + " · ".join(_struct_parts))
                else:
                    st.warning("No results returned — check tickers or date range. "
                               "Tickers not in the price range or with no data are skipped.")
            except Exception as _cal_err:
                st.error(f"Calibration run failed: {_cal_err}")

    st.markdown("---")

    # ── Configuration panel ─────────────────────────────────────────────────────
    st.markdown(
        '<div style="font-size:11px; color:#1565c0; text-transform:uppercase; '
        'letter-spacing:1.5px; margin-bottom:10px; font-weight:700;">⚙ Simulation Parameters</div>',
        unsafe_allow_html=True,
    )
    _bt_col1, _bt_col2, _bt_col3, _bt_col4 = st.columns([1.2, 1.2, 1, 1])
    with _bt_col1:
        yesterday = date.today() - timedelta(days=1)
        _bt_date  = st.date_input(
            "Backtest Date", value=yesterday,
            max_value=date.today() - timedelta(days=1),
            key="bt_date_picker",
            help="Select any past trading day. Weekends/holidays will return no data.",
        )
    with _bt_col2:
        _bt_feed = st.radio(
            "Bar Data Feed", ["SIP (paid — accurate)", "IEX (free — limited)"],
            key="bt_feed_radio", horizontal=True,
        )
        _bt_feed_str = "sip" if "SIP" in _bt_feed else "iex"
    with _bt_col3:
        _bt_price_range = st.slider(
            "Price Range ($)", min_value=1.0, max_value=50.0,
            value=(2.0, 20.0), step=0.5, key="bt_price_range",
        )
    with _bt_col4:
        _bt_end_date = st.date_input(
            "To Date (range)",
            value=yesterday,
            max_value=date.today() - timedelta(days=1),
            key="bt_end_date_picker",
            help="Same as From Date = single day. Earlier From Date = multi-day range (max 10 weekdays). "
                 "Use a full week to see market bias patterns.",
        )
    _bt_is_range = _bt_end_date > _bt_date

    st.markdown(
        '<div style="font-size:11px; color:#37474f; margin:10px 0 2px 0;">'
        '🔬 <b>SIMULATION TICKERS</b> — Research use only. '
        'Enter any tickers you want to test on the selected date(s). '
        'This is separate from calibration and does not affect your personal analytics.'
        '</div>'
        '<div style="font-size:10px; color:#546e7a; margin-bottom:6px;">'
        'comma-separated · engine keeps only tickers in your price range on that date'
        '</div>',
        unsafe_allow_html=True,
    )
    _bt_tickers_raw = st.text_area(
        "Simulation Tickers", value=_BT_DEFAULT_TICKERS,
        height=68, key="bt_tickers_input", label_visibility="collapsed",
    )

    _bt_adv_cols = st.columns([2, 2, 1])
    with _bt_adv_cols[0]:
        _bt_slippage = st.slider(
            "Slippage % (each side)",
            min_value=0.0, max_value=2.0, value=0.5, step=0.1,
            key="bt_slippage_pct",
            help=(
                "Real-world cost of entering and exiting a trade. "
                "Applied once on entry + once on exit. "
                "0.5% each side = 1% total drag per trade. "
                "Small caps typically need 0.3–0.8%."
            ),
        )
    with _bt_adv_cols[1]:
        _bt_monte_equity = st.number_input(
            "Monte Carlo Starting Equity ($)",
            min_value=1000, max_value=1_000_000, value=10_000, step=1000,
            key="bt_mc_equity",
            help="Simulated starting account size for equity curve projection.",
        )
    with _bt_adv_cols[2]:
        _bt_monte_risk = st.slider(
            "Risk per Trade (%)",
            min_value=0.5, max_value=5.0, value=2.0, step=0.5,
            key="bt_mc_risk",
            help="What % of equity is risked per trade in the Monte Carlo simulation.",
        )

    _bt_run = st.button(
        "▶ RUN SIMULATION", use_container_width=True, key="backtest_sim_run_btn",
        type="primary",
    )

    st.markdown(
        f'<div style="font-size:10px; color:#263238; margin-top:6px;">'
        f'IB fixed at 9:30–10:30 AM · Set From = To for single day · '
        f'Set a date range (max 22 weekdays ≈ 1 month) for walk-forward analysis · '
        f'Results auto-saved · Slippage {_bt_slippage:.1f}% each side applied'
        f'</div>',
        unsafe_allow_html=True,
    )
    # ── Load Saved Results ──────────────────────────────────────────────────────
    with st.expander("📂 Load Saved Simulation Results", expanded=False):
        st.caption("Load any previous simulation run from your history without re-fetching Alpaca data.")
        _ls_col1, _ls_col2 = st.columns([1, 1])
        with _ls_col1:
            if st.button("🔄 Fetch My Saved Dates", use_container_width=True, key="bt_ls_fetch"):
                _ls_hist = load_backtest_sim_history(user_id=_AUTH_USER_ID)
                if _ls_hist.empty or "sim_date" not in _ls_hist.columns:
                    st.session_state["_bt_ls_dates"]   = []
                    st.session_state["_bt_ls_hist_all"] = pd.DataFrame()
                else:
                    _ls_avail = sorted(_ls_hist["sim_date"].astype(str).unique(), reverse=True)
                    st.session_state["_bt_ls_dates"]   = _ls_avail
                    st.session_state["_bt_ls_hist_all"] = _ls_hist

        _ls_dates_avail = st.session_state.get("_bt_ls_dates", [])
        if _ls_dates_avail:
            _ls_sel = st.multiselect(
                "Select date(s) to load",
                options=_ls_dates_avail,
                default=_ls_dates_avail[:1],
                key="bt_ls_date_sel",
                help="Select one date for a single-day view, or multiple to reconstruct a range.",
            )
            with _ls_col2:
                _ls_load_btn = st.button(
                    "📂 Load Selected", use_container_width=True,
                    key="bt_ls_load_btn",
                    disabled=not _ls_sel,
                )
            if _ls_load_btn and _ls_sel:
                _ls_all_df = st.session_state.get("_bt_ls_hist_all", pd.DataFrame())
                _ls_rows_df = _ls_all_df[_ls_all_df["sim_date"].astype(str).isin([str(d) for d in _ls_sel])]

                def _icon_for(outcome: str) -> str:
                    _lc = (outcome or "").lower()
                    if "bull" in _lc:   return "+"
                    if "bear" in _lc:   return "↓"
                    if "both" in _lc:   return "⇅"
                    if "range" in _lc:  return "—"
                    return "·"

                _ls_results = []
                for _, _lrow in _ls_rows_df.iterrows():
                    _ls_results.append({
                        "ticker":         str(_lrow.get("ticker", "")),
                        "sim_date":       str(_lrow.get("sim_date", "")),
                        "open_price":     float(_lrow.get("open_price") or 0),
                        "close_price":    float(_lrow.get("close_price") or 0),
                        "ib_low":         float(_lrow.get("ib_low") or 0),
                        "ib_high":        float(_lrow.get("ib_high") or 0),
                        "tcs":            float(_lrow.get("tcs") or 0),
                        "predicted":      str(_lrow.get("predicted", "")),
                        "actual_outcome": str(_lrow.get("actual_outcome", "")),
                        "actual_icon":    _icon_for(str(_lrow.get("actual_outcome", ""))),
                        "win_loss":       str(_lrow.get("win_loss", "")),
                        "aft_move_pct":   float(_lrow.get("follow_thru_pct") or _lrow.get("aft_move_pct") or 0),
                        "false_break_up":   bool(_lrow.get("false_break_up", False)),
                        "false_break_down": bool(_lrow.get("false_break_down", False)),
                    })

                if _ls_results:
                    _ls_wins   = sum(1 for r in _ls_results if r["win_loss"] == "Win")
                    _ls_losses = sum(1 for r in _ls_results if r["win_loss"] == "Loss")
                    _ls_total  = len(_ls_results)
                    _ls_wr     = round(_ls_wins / _ls_total * 100, 1) if _ls_total > 0 else 0.0
                    _ls_tcs_vals  = [r["tcs"] for r in _ls_results if r["tcs"] > 0]
                    _ls_bull_ft   = [r["aft_move_pct"] for r in _ls_results
                                     if "bull" in r["actual_outcome"].lower() and r["aft_move_pct"] > 0]
                    _ls_bear_ft   = [abs(r["aft_move_pct"]) for r in _ls_results
                                     if "bear" in r["actual_outcome"].lower() and r["aft_move_pct"] < 0]
                    _ls_bull_breaks  = sum(1 for r in _ls_results if "bull" in r["actual_outcome"].lower())
                    _ls_bear_breaks  = sum(1 for r in _ls_results if "bear" in r["actual_outcome"].lower())
                    _ls_both_breaks  = sum(1 for r in _ls_results if "both" in r["actual_outcome"].lower())
                    _ls_range_bound  = sum(1 for r in _ls_results if "range" in r["actual_outcome"].lower())
                    _ls_long_wins    = sum(1 for r in _ls_results
                                         if "bull" in r["actual_outcome"].lower() and r["win_loss"] == "Win")
                    _ls_long_total   = _ls_bull_breaks or 1
                    _ls_fb_count     = sum(1 for r in _ls_results if r["false_break_up"] or r["false_break_down"])
                    _ls_summary = {
                        "win_rate":       _ls_wr,
                        "total":          _ls_total,
                        "wins":           _ls_wins,
                        "losses":         _ls_losses,
                        "highest_tcs":    max(_ls_tcs_vals) if _ls_tcs_vals else 0,
                        "avg_tcs":        sum(_ls_tcs_vals) / len(_ls_tcs_vals) if _ls_tcs_vals else 0,
                        "avg_bull_ft":    sum(_ls_bull_ft) / len(_ls_bull_ft) if _ls_bull_ft else 0,
                        "avg_bear_ft":    sum(_ls_bear_ft) / len(_ls_bear_ft) if _ls_bear_ft else 0,
                        "bull_breaks":    _ls_bull_breaks,
                        "bear_breaks":    _ls_bear_breaks,
                        "both_breaks":    _ls_both_breaks,
                        "range_bound":    _ls_range_bound,
                        "long_win_rate":  round(_ls_long_wins / _ls_long_total * 100, 1),
                        "false_break_rate": round(_ls_fb_count / _ls_total * 100, 1) if _ls_total > 0 else 0,
                    }
                    _ls_date_label = (
                        f"{min(_ls_sel)} → {max(_ls_sel)}" if len(_ls_sel) > 1 else _ls_sel[0]
                    )
                    _ls_is_range = len(_ls_sel) > 1
                    st.session_state["bt_results_cache"] = (
                        _ls_results, _ls_summary, _ls_date_label, _ls_is_range, None
                    )
                    st.success(f"Loaded {_ls_total} rows from {len(_ls_sel)} date(s). Scroll down to view results.")
                    st.rerun()
                else:
                    st.warning("No data found for the selected date(s).")
        elif not _ls_dates_avail and st.session_state.get("_bt_ls_dates") is not None:
            st.info("No saved simulation runs found for your account.")

    st.markdown("---")

    # ── Run simulation ──────────────────────────────────────────────────────────
    _bt_cache = "bt_results_cache"

    if _bt_run:
        _tickers = [t.strip().upper() for t in _bt_tickers_raw.replace("\n", ",").split(",")
                    if t.strip() and t.strip().isalpha()]
        if not _tickers:
            st.error("No valid tickers found. Check your watchlist.")
            st.stop()

        _pmin, _pmax = float(_bt_price_range[0]), float(_bt_price_range[1])
        _total = len(_tickers)

        if _bt_is_range:
            _range_label = f"{_bt_date} → {_bt_end_date}"
            with st.spinner(
                f"⏳ Range simulation {_range_label} · {_total} tickers — "
                f"this may take 30–60 seconds…"
            ):
                _results, _summary, _daily_list = run_backtest_range(
                    api_key, secret_key,
                    start_date=_bt_date,
                    end_date=_bt_end_date,
                    tickers=_tickers,
                    feed=_bt_feed_str,
                    price_min=_pmin,
                    price_max=_pmax,
                    slippage_pct=_bt_slippage,
                )
            _date_label = _range_label
        else:
            _daily_list  = None
            _range_label = str(_bt_date)
            with st.spinner(
                f"⏳ Simulating {_total} tickers on {_bt_date} — "
                f"fetching bars & running quant engine concurrently…"
            ):
                _results, _summary = run_historical_backtest(
                    api_key, secret_key,
                    trade_date=_bt_date,
                    tickers=_tickers,
                    feed=_bt_feed_str,
                    price_min=_pmin,
                    price_max=_pmax,
                    slippage_pct=_bt_slippage,
                )
            _date_label = str(_bt_date)

        # Auto-save to Supabase
        if _results and not _summary.get("error"):
            _rows_to_save = _results if _bt_is_range else [
                dict(r, sim_date=str(_bt_date)) for r in _results
            ]
            try:
                save_backtest_sim_runs(_rows_to_save, user_id=_AUTH_USER_ID)
            except Exception:
                pass

        st.session_state[_bt_cache] = (
            _results, _summary, _date_label,
            _bt_is_range, _daily_list if _bt_is_range else None,
        )

    # ── Load cached results ─────────────────────────────────────────────────────
    if _bt_cache not in st.session_state:
        st.markdown(
            '<div style="text-align:center; color:#263238; font-size:13px; '
            'padding:40px 0; font-family:monospace;">'
            '[ SELECT DATE + TICKERS → PRESS RUN SIMULATION ]'
            '</div>',
            unsafe_allow_html=True,
        )
        return

    _bt_cached = st.session_state[_bt_cache]
    if len(_bt_cached) == 5:
        _results, _summary, _sim_date, _sim_is_range, _sim_daily = _bt_cached
    elif len(_bt_cached) == 4:
        _results, _summary, _sim_date, _ = _bt_cached
        _sim_is_range, _sim_daily = False, None
    else:
        _results, _summary, _sim_date = _bt_cached
        _sim_is_range, _sim_daily = False, None

    if _summary.get("error"):
        st.error(_summary["error"])
        return

    # ── Summary KPI header ──────────────────────────────────────────────────────
    _wr = _summary["win_rate"]
    _wr_color = (
        _BT_WIN_CLR  if _wr >= 60 else
        "#ffa726"    if _wr >= 45 else
        _BT_LOSS_CLR
    )

    st.markdown(
        f'<div style="background:#020813; border:1px solid #0d2137; border-radius:10px; '
        f'padding:18px 24px; margin-bottom:20px;">'
        f'<div style="font-size:10px; color:#1565c0; letter-spacing:2px; '
        f'text-transform:uppercase; margin-bottom:12px; font-family:monospace;">'
        f'SIMULATION RESULTS — {str(_sim_date).upper()}'
        f'{" · " + str(_summary.get("days_run", "")) + " TRADING DAYS" if _sim_is_range else ""}'
        f'</div>'
        f'<div style="display:flex; gap:40px; flex-wrap:wrap;">'

        f'<div>'
        f'<div style="font-size:10px; color:#546e7a; text-transform:uppercase; '
        f'letter-spacing:1px; margin-bottom:2px;">Simulated Win Rate</div>'
        f'<div style="font-size:42px; font-weight:900; color:{_wr_color}; '
        f'font-family:monospace;">{_wr:.1f}%</div>'
        f'</div>'

        f'<div style="border-left:1px solid #0d2137; padding-left:32px;">'
        f'<div style="font-size:10px; color:#546e7a; text-transform:uppercase; '
        f'letter-spacing:1px; margin-bottom:2px;">Setups Found</div>'
        f'<div style="font-size:36px; font-weight:800; color:#e0e0e0; '
        f'font-family:monospace;">{_summary["total"]}</div>'
        f'</div>'

        f'<div style="border-left:1px solid #0d2137; padding-left:32px;">'
        f'<div style="font-size:10px; color:#546e7a; text-transform:uppercase; '
        f'letter-spacing:1px; margin-bottom:2px;">Wins / Losses</div>'
        f'<div style="font-size:28px; font-weight:800; font-family:monospace;">'
        f'<span style="color:{_BT_WIN_CLR};">{_summary["wins"]}</span>'
        f'<span style="color:#37474f;"> / </span>'
        f'<span style="color:{_BT_LOSS_CLR};">{_summary["losses"]}</span>'
        f'</div>'
        f'</div>'

        f'<div style="border-left:1px solid #0d2137; padding-left:32px;">'
        f'<div style="font-size:10px; color:#546e7a; text-transform:uppercase; '
        f'letter-spacing:1px; margin-bottom:2px;">Highest TCS</div>'
        f'<div style="font-size:36px; font-weight:800; color:#7c4dff; '
        f'font-family:monospace;">{_summary["highest_tcs"]:.0f}</div>'
        f'</div>'

        f'<div style="border-left:1px solid #0d2137; padding-left:32px;">'
        f'<div style="font-size:10px; color:#546e7a; text-transform:uppercase; '
        f'letter-spacing:1px; margin-bottom:2px;">Avg TCS</div>'
        f'<div style="font-size:36px; font-weight:800; color:#5c6bc0; '
        f'font-family:monospace;">{_summary["avg_tcs"]:.0f}</div>'
        f'</div>'

        f'</div></div>',
        unsafe_allow_html=True,
    )

    # ── Directional breakdown row ────────────────────────────────────────────────
    _bull_ft_str = f"+{_summary['avg_bull_ft']:.1f}%" if _summary["avg_bull_ft"] else "—"
    _bear_ft_str = f"-{_summary['avg_bear_ft']:.1f}%" if _summary["avg_bear_ft"] else "—"
    _lr          = _summary["long_win_rate"]
    _lr_clr      = "#4caf50" if _lr >= 50 else "#ffa726" if _lr >= 35 else "#ef5350"
    st.markdown(
        f'<div style="background:#020813; border:1px solid #0d2137; border-radius:8px; '
        f'padding:12px 24px; margin-bottom:20px; display:flex; gap:32px; flex-wrap:wrap;">'

        f'<div style="font-size:10px; color:#546e7a; text-transform:uppercase; '
        f'letter-spacing:1px; margin-top:4px; align-self:center; min-width:90px;">'
        f'DIRECTIONAL BREAKDOWN</div>'

        f'<div style="border-left:1px solid #0d2137; padding-left:24px;">'
        f'<div style="font-size:9px; color:#546e7a; letter-spacing:1px; '
        f'text-transform:uppercase; margin-bottom:2px;">↑ Bull Breaks</div>'
        f'<div style="font-size:22px; font-weight:800; color:#4caf50; '
        f'font-family:monospace;">{_summary["bull_breaks"]}'
        f'<span style="font-size:13px; color:#37474f;"> / {_summary["total"]}</span></div>'
        f'</div>'

        f'<div style="border-left:1px solid #0d2137; padding-left:24px;">'
        f'<div style="font-size:9px; color:#546e7a; letter-spacing:1px; '
        f'text-transform:uppercase; margin-bottom:2px;">Avg Bull Follow-Thru</div>'
        f'<div style="font-size:22px; font-weight:800; color:#4caf50; '
        f'font-family:monospace;">{_bull_ft_str}</div>'
        f'</div>'

        f'<div style="border-left:1px solid #0d2137; padding-left:24px;">'
        f'<div style="font-size:9px; color:#546e7a; letter-spacing:1px; '
        f'text-transform:uppercase; margin-bottom:2px;">↓ Bear Breaks</div>'
        f'<div style="font-size:22px; font-weight:800; color:#ef5350; '
        f'font-family:monospace;">{_summary["bear_breaks"]}'
        f'<span style="font-size:13px; color:#37474f;"> / {_summary["total"]}</span></div>'
        f'</div>'

        f'<div style="border-left:1px solid #0d2137; padding-left:24px;">'
        f'<div style="font-size:9px; color:#546e7a; letter-spacing:1px; '
        f'text-transform:uppercase; margin-bottom:2px;">Avg Bear Follow-Thru</div>'
        f'<div style="font-size:22px; font-weight:800; color:#ef5350; '
        f'font-family:monospace;">{_bear_ft_str}</div>'
        f'</div>'

        f'<div style="border-left:1px solid #0d2137; padding-left:24px;">'
        f'<div style="font-size:9px; color:#546e7a; letter-spacing:1px; '
        f'text-transform:uppercase; margin-bottom:2px;">Long-Only Hit Rate</div>'
        f'<div style="font-size:22px; font-weight:800; color:{_lr_clr}; '
        f'font-family:monospace;">{_lr:.1f}%</div>'
        f'<div style="font-size:9px; color:#37474f;">% setups went bullish</div>'
        f'</div>'

        f'<div style="border-left:1px solid #0d2137; padding-left:24px;">'
        f'<div style="font-size:9px; color:#546e7a; letter-spacing:1px; '
        f'text-transform:uppercase; margin-bottom:2px;">Both Sides</div>'
        f'<div style="font-size:22px; font-weight:800; color:#ffa726; '
        f'font-family:monospace;">{_summary["both_breaks"]}</div>'
        f'</div>'

        f'<div style="border-left:1px solid #0d2137; padding-left:24px;">'
        f'<div style="font-size:9px; color:#546e7a; letter-spacing:1px; '
        f'text-transform:uppercase; margin-bottom:2px;">Range-Bound</div>'
        f'<div style="font-size:22px; font-weight:800; color:#546e7a; '
        f'font-family:monospace;">{_summary["range_bound"]}</div>'
        f'</div>'

        f'<div style="border-left:1px solid #0d2137; padding-left:24px;">'
        f'<div style="font-size:9px; color:#ffa726; letter-spacing:1px; '
        f'text-transform:uppercase; margin-bottom:2px;">⚠ False Break Rate</div>'
        f'<div style="font-size:22px; font-weight:800; color:#ffa726; '
        f'font-family:monospace;">{_summary.get("false_break_rate", 0.0):.1f}%</div>'
        f'<div style="font-size:9px; color:#37474f;">'
        f'↑{_summary.get("fb_up_count", 0)} ↓{_summary.get("fb_down_count", 0)} traps</div>'
        f'</div>'

        f'</div>',
        unsafe_allow_html=True,
    )

    # ── Walk-forward train / test comparison (range only) ───────────────────────
    _wf_train = _summary.get("train", {})
    _wf_test  = _summary.get("test", {})
    if _sim_is_range and _wf_train and _wf_test and _wf_test.get("total", 0) > 0:
        st.markdown(
            '<div style="font-size:10px; color:#7c4dff; text-transform:uppercase; '
            'letter-spacing:1.5px; margin-bottom:8px; font-weight:700;">'
            '🔬 Walk-Forward Validation — Train (70%) vs Test (30%)</div>',
            unsafe_allow_html=True,
        )
        _wf_cols = st.columns(2)
        for _wf_d, _wf_col in [(_wf_train, _wf_cols[0]), (_wf_test, _wf_cols[1])]:
            _wfn  = _wf_d.get("total", 0)
            _wfwr = _wf_d.get("win_rate", 0.0)
            _wflb = _wf_d.get("label", "?")
            _wfc  = "#4caf50" if _wfwr >= 60 else "#ffa726" if _wfwr >= 45 else "#ef5350"
            _is_test = "out-of-sample" in _wflb.lower()
            _bg   = "#0d1b0d" if not _is_test else "#1a0d26"
            _bd   = "#4caf50" if not _is_test else "#7c4dff"
            _wf_col.markdown(
                f'<div style="background:{_bg}; border:1px solid {_bd}44; border-left:4px solid {_bd}; '
                f'border-radius:8px; padding:14px 18px;">'
                f'<div style="font-size:10px; color:{_bd}; text-transform:uppercase; '
                f'letter-spacing:1px; margin-bottom:6px; font-weight:700;">{_wflb}</div>'
                f'<div style="font-size:32px; font-weight:900; color:{_wfc}; font-family:monospace;">'
                f'{_wfwr:.1f}%</div>'
                f'<div style="font-size:12px; color:#546e7a; margin-top:4px;">'
                f'{_wf_d.get("wins",0)}W / {_wf_d.get("losses",0)}L · {_wfn} setups · '
                f'Avg TCS {_wf_d.get("avg_tcs",0):.0f}</div>'
                f'</div>',
                unsafe_allow_html=True,
            )
        _oos_wr = _wf_test.get("win_rate", 0.0)
        _is_wr  = _wf_train.get("win_rate", 0.0)
        _drift  = _oos_wr - _is_wr
        _drift_msg = (
            f"Out-of-sample win rate is {abs(_drift):.1f}% {'better' if _drift >= 0 else 'worse'} "
            f"than in-sample ({'good — model generalises' if abs(_drift) <= 10 else 'large gap — check overfitting'})."
        )
        st.caption(f"📐 {_drift_msg}")
        st.markdown("<div style='margin:8px 0;'></div>", unsafe_allow_html=True)

    # ── Monte Carlo equity simulation ────────────────────────────────────────────
    if _results and len(_results) >= 3:
        _mc_risk_frac = st.session_state.get("bt_mc_risk", 2.0) / 100.0
        _mc_eq        = float(st.session_state.get("bt_mc_equity", 10_000))
        _mc_slip      = st.session_state.get("bt_slippage_pct", 0.5) / 100.0
        _mc = monte_carlo_equity_curves(
            _results,
            starting_equity=float(_mc_eq),
            n_simulations=1000,
            risk_pct=_mc_risk_frac,
            slippage_drag_pct=_mc_slip,
        )
        if _mc:
            st.markdown(
                '<div style="font-size:10px; color:#00bcd4; text-transform:uppercase; '
                'letter-spacing:1.5px; margin-bottom:8px; font-weight:700;">'
                '🎲 Monte Carlo Equity Simulation — 1,000 Trade Sequence Shuffles</div>',
                unsafe_allow_html=True,
            )
            _mc_x = list(range(len(_mc["p50"])))
            fig_mc = go.Figure()
            fig_mc.add_trace(go.Scatter(
                x=_mc_x + _mc_x[::-1],
                y=_mc["p90"] + _mc["p10"][::-1],
                fill="toself", fillcolor="rgba(0,188,212,0.08)",
                line=dict(color="rgba(0,0,0,0)"),
                name="P10–P90 range", showlegend=True,
            ))
            fig_mc.add_trace(go.Scatter(
                x=_mc_x, y=_mc["p90"],
                line=dict(color="#4caf50", dash="dot", width=1),
                name="P90 (best 10%)", showlegend=True,
            ))
            fig_mc.add_trace(go.Scatter(
                x=_mc_x, y=_mc["p50"],
                line=dict(color="#00bcd4", width=2.5),
                name="Median outcome", showlegend=True,
            ))
            fig_mc.add_trace(go.Scatter(
                x=_mc_x, y=_mc["p10"],
                line=dict(color="#ef5350", dash="dot", width=1),
                name="P10 (worst 10%)", showlegend=True,
            ))
            fig_mc.add_hline(
                y=float(_mc_eq), line_dash="dash",
                line_color="#546e7a", opacity=0.6,
                annotation_text="Starting equity",
                annotation_font_color="#546e7a",
            )
            fig_mc.update_layout(
                paper_bgcolor="#0a0a1a", plot_bgcolor="#0d1117",
                font=dict(color="#e0e0e0"), height=300,
                margin=dict(t=20, b=40, l=60, r=20),
                legend=dict(orientation="h", yanchor="bottom", y=1.02, x=0),
                xaxis=dict(title="Trade #", gridcolor="#1a1a2e", zeroline=False),
                yaxis=dict(title="Equity ($)", gridcolor="#1a1a2e", zeroline=False,
                           tickformat="$,.0f"),
            )
            st.plotly_chart(fig_mc, use_container_width=True)
            _mc_kpi_cols = st.columns(4)
            _mc_kpi_cols[0].metric("Median Final", f"${_mc['median_final']:,.0f}",
                                   f"{(_mc['median_final']/_mc_eq - 1)*100:+.1f}%")
            _mc_kpi_cols[1].metric("P90 Final (best)", f"${_mc['p90_final']:,.0f}")
            _mc_kpi_cols[2].metric("P10 Final (worst)", f"${_mc['p10_final']:,.0f}")
            _mc_kpi_cols[3].metric("% Simulations Profitable",
                                   f"{_mc['pct_profitable']:.1f}%")
            st.markdown("<div style='margin:10px 0;'></div>", unsafe_allow_html=True)

    # ── Day-by-day breakdown (range only) ───────────────────────────────────────
    if _sim_is_range and _sim_daily:
        st.markdown(
            '<div style="font-size:10px; color:#1565c0; text-transform:uppercase; '
            'letter-spacing:1.5px; margin-bottom:8px; font-weight:700;">📅 Day-by-Day Breakdown</div>',
            unsafe_allow_html=True,
        )
        _d_cols = st.columns([0.9, 0.6, 0.6, 0.6, 0.7, 0.7, 0.7, 0.8, 0.8])
        _d_hdrs = ["Date", "Setups", "Wins", "Losses", "Win %",
                   "Long Hit %", "Bull FT", "Bear FT", "False Brk%"]
        for _c, _h in zip(_d_cols, _d_hdrs):
            _c.markdown(
                f'<div style="font-size:9px; font-weight:700; color:#1565c0; '
                f'text-transform:uppercase; letter-spacing:1px; padding:4px 6px;">{_h}</div>',
                unsafe_allow_html=True,
            )
        for _dd, _dr, _ds in _sim_daily:
            _dwr   = _ds.get("win_rate", 0)
            _dlhr  = _ds.get("long_win_rate", 0)
            _dbft  = _ds.get("avg_bull_ft", 0)
            _dbear = _ds.get("avg_bear_ft", 0)
            _dfbr  = _ds.get("false_break_rate", 0)
            _dwr_c = "#4caf50" if _dwr >= 60 else "#ffa726" if _dwr >= 40 else "#ef5350"
            _dlr_c = "#4caf50" if _dlhr >= 50 else "#ffa726" if _dlhr >= 35 else "#ef5350"
            _row_d = st.columns([0.9, 0.6, 0.6, 0.6, 0.7, 0.7, 0.7, 0.8, 0.8])
            _row_d[0].markdown(
                f'<div style="font-size:11px; font-weight:700; color:#e0e0e0; '
                f'padding:6px 6px; font-family:monospace;">'
                f'{_dd.strftime("%a %b %d")}</div>', unsafe_allow_html=True)
            _row_d[1].markdown(
                f'<div style="font-size:11px; color:#90a4ae; padding:6px 6px;">'
                f'{_ds.get("total", 0)}</div>', unsafe_allow_html=True)
            _row_d[2].markdown(
                f'<div style="font-size:11px; color:#4caf50; padding:6px 6px;">'
                f'{_ds.get("wins", 0)}</div>', unsafe_allow_html=True)
            _row_d[3].markdown(
                f'<div style="font-size:11px; color:#ef5350; padding:6px 6px;">'
                f'{_ds.get("losses", 0)}</div>', unsafe_allow_html=True)
            _row_d[4].markdown(
                f'<div style="font-size:12px; font-weight:800; color:{_dwr_c}; '
                f'padding:6px 6px; font-family:monospace;">{_dwr:.1f}%</div>',
                unsafe_allow_html=True)
            _row_d[5].markdown(
                f'<div style="font-size:12px; font-weight:800; color:{_dlr_c}; '
                f'padding:6px 6px; font-family:monospace;">{_dlhr:.1f}%</div>',
                unsafe_allow_html=True)
            _row_d[6].markdown(
                f'<div style="font-size:11px; color:#4caf50; padding:6px 6px; '
                f'font-family:monospace;">+{_dbft:.1f}%</div>', unsafe_allow_html=True)
            _row_d[7].markdown(
                f'<div style="font-size:11px; color:#ef5350; padding:6px 6px; '
                f'font-family:monospace;">-{_dbear:.1f}%</div>', unsafe_allow_html=True)
            _row_d[8].markdown(
                f'<div style="font-size:11px; color:#ffa726; padding:6px 6px; '
                f'font-family:monospace;">{_dfbr:.1f}%</div>', unsafe_allow_html=True)
        st.markdown("---")

    # ── Column headers ──────────────────────────────────────────────────────────
    # ── Deduplicate by (ticker, sim_date) ────────────────────────────────────────
    _seen_keys: set = set()
    _results_deduped = []
    for _r in _results:
        _dedup_key = (
            _r.get("ticker", ""),
            str(_r.get("sim_date", _r.get("trade_date", ""))),
        )
        if _dedup_key not in _seen_keys:
            _seen_keys.add(_dedup_key)
            _results_deduped.append(_r)
    _dupes_removed = len(_results) - len(_results_deduped)
    if _dupes_removed > 0:
        st.caption(f"ℹ️ {_dupes_removed} duplicate row(s) removed from log.")
    _results = _results_deduped

    # ── Per-Ticker Breakdown ──────────────────────────────────────────────────
    import pandas as _pd_bt
    _bt_df = _pd_bt.DataFrame(_results)
    if not _bt_df.empty and "ticker" in _bt_df.columns:
        with st.expander(
            f"📊 Per-Ticker Breakdown — {_bt_df['ticker'].nunique()} tickers across all dates",
            expanded=True,
        ):
            _tkr_rows = []
            for _tk, _tgrp in _bt_df.groupby("ticker"):
                _tw   = (_tgrp["win_loss"] == "Win").sum()
                _tl   = (_tgrp["win_loss"] == "Loss").sum()
                _twr  = round(_tw / len(_tgrp) * 100, 1) if len(_tgrp) > 0 else 0
                _tavg_tcs = round(_tgrp["tcs"].mean(), 0) if "tcs" in _tgrp else 0
                _tft  = round(_tgrp["aft_move_pct"].mean(), 1) if "aft_move_pct" in _tgrp else 0
                _top_struct = (
                    _tgrp["predicted"].value_counts().index[0]
                    if "predicted" in _tgrp.columns and not _tgrp["predicted"].empty
                    else "—"
                )
                _top_struct = _clean_structure_label(_top_struct)
                _fb_count = (
                    _tgrp.get("false_break_up", _pd_bt.Series(dtype=bool)).sum()
                    + _tgrp.get("false_break_down", _pd_bt.Series(dtype=bool)).sum()
                ) if "false_break_up" in _tgrp else 0
                _fb_rate = round(_fb_count / len(_tgrp) * 100) if len(_tgrp) > 0 else 0
                _dates = sorted(_tgrp["sim_date"].astype(str).unique()) if "sim_date" in _tgrp else []
                _tkr_rows.append({
                    "Ticker":         _tk,
                    "Setups":         len(_tgrp),
                    "Win %":          f"{'🟢' if _twr >= 60 else '🟡' if _twr >= 45 else '🔴'} {_twr}%",
                    "W/L":            f"{_tw}/{_tl}",
                    "Avg TCS":        int(_tavg_tcs),
                    "Top Structure":  _top_struct,
                    "Avg Follow-Thru": f"{'+' if _tft >= 0 else ''}{_tft}%",
                    "False Brk %":    f"{'🔴' if _fb_rate > 35 else '🟡' if _fb_rate > 20 else '🟢'} {_fb_rate}%",
                    "Dates Seen":     ", ".join(d[:5] for d in _dates[-3:]) + ("…" if len(_dates) > 3 else ""),
                })
            _tkr_summary_df = _pd_bt.DataFrame(_tkr_rows).sort_values("Win %", ascending=False)
            st.dataframe(_tkr_summary_df, use_container_width=True, hide_index=True)
            st.caption(
                "🟢 Win % ≥ 60% — model reads this ticker well  · "
                "🟡 45–60% — mixed signal, paper trade first  · "
                "🔴 < 45% — IB framework doesn't fit this ticker · "
                "False Brk % = how often IB breakouts reversed within 30 min"
            )

    st.markdown("---")
    st.markdown(
        '<div style="font-size:10px; color:#1565c0; text-transform:uppercase; '
        'letter-spacing:1.5px; margin-bottom:10px; font-weight:700;">'
        '📋 Trade-by-Trade Simulation Log</div>',
        unsafe_allow_html=True,
    )

    _BT_COLS  = [0.55, 0.6, 0.65, 0.75, 0.55, 1.1, 1.2, 1.0, 0.75, 0.45, 0.55]
    _BT_HDRS  = ["Date", "Ticker", "Open", "IB Range", "TCS", "Morning Prediction",
                 "EOD Reality", "Close", "Follow-Thru", "⚠", "Result"]

    _hdr_row = st.columns(_BT_COLS)
    for _col, _lbl in zip(_hdr_row, _BT_HDRS):
        _hdr_clr = "#1565c0"
        _col.markdown(
            f'<div style="font-size:10px; font-weight:700; color:{_hdr_clr}; '
            f'text-transform:uppercase; letter-spacing:0.8px; padding:4px 0 8px 0; '
            f'border-bottom:1px solid #0d2137; font-family:monospace;">{_lbl}</div>',
            unsafe_allow_html=True,
        )

    # ── Data rows ───────────────────────────────────────────────────────────────
    for _r in _results:
        _wl         = _r["win_loss"]
        _tcs        = _r["tcs"]
        _tcs_clr    = _bt_tcs_color(_tcs)
        _out_clr    = _bt_outcome_color(_r["actual_outcome"])
        _wl_clr     = _BT_WIN_CLR if _wl == "Win" else _BT_LOSS_CLR
        _move       = _r["aft_move_pct"]
        _move_sign  = "+" if _move >= 0 else ""
        _move_clr   = "#4caf50" if _move >= 0 else "#ef5350"
        _pred_short = (_r["predicted"][:18] + "…") if len(_r["predicted"]) > 18 else _r["predicted"]
        _pred_clean = _clean_structure_label(_r["predicted"])
        _sim_date_raw = str(_r.get("sim_date", _r.get("trade_date", "")))
        _sim_date_disp = _sim_date_raw[:10] if len(_sim_date_raw) >= 10 else _sim_date_raw

        _row_bg = "#051015" if _wl == "Win" else "#120508"

        _row = st.columns(_BT_COLS)
        _row[0].markdown(
            f'<div style="background:{_row_bg}; padding:10px 6px; '
            f'font-size:10px; color:#546e7a; font-family:monospace;">'
            f'{_sim_date_disp}</div>',
            unsafe_allow_html=True,
        )
        _row[1].markdown(
            f'<div style="background:{_row_bg}; padding:10px 6px; '
            f'font-size:14px; font-weight:900; color:#e0e0e0; '
            f'font-family:monospace;">{_r["ticker"]}</div>',
            unsafe_allow_html=True,
        )
        _row[2].markdown(
            f'<div style="background:{_row_bg}; padding:10px 6px; '
            f'font-size:12px; color:#90a4ae; font-family:monospace;">'
            f'${_r["open_price"]:.2f}</div>',
            unsafe_allow_html=True,
        )
        _row[3].markdown(
            f'<div style="background:{_row_bg}; padding:10px 6px; '
            f'font-size:11px; color:#607d8b; font-family:monospace;">'
            f'${_r["ib_low"]:.2f}–${_r["ib_high"]:.2f}</div>',
            unsafe_allow_html=True,
        )
        _row[4].markdown(
            f'<div style="background:{_row_bg}; padding:8px 6px;">'
            f'<span style="background:{_tcs_clr}22; color:{_tcs_clr}; '
            f'font-size:13px; font-weight:800; padding:2px 8px; border-radius:10px; '
            f'border:1px solid {_tcs_clr}55; font-family:monospace;">'
            f'{_tcs:.0f}</span></div>',
            unsafe_allow_html=True,
        )
        _row[5].markdown(
            f'<div style="background:{_row_bg}; padding:10px 6px; '
            f'font-size:11px; color:#ce93d8; font-weight:600;">'
            f'{_pred_clean}</div>',
            unsafe_allow_html=True,
        )
        _row[6].markdown(
            f'<div style="background:{_row_bg}; padding:8px 6px;">'
            f'<span style="background:{_out_clr}22; color:{_out_clr}; '
            f'font-size:11px; font-weight:700; padding:3px 10px; border-radius:10px; '
            f'border:1px solid {_out_clr}55;">'
            f'{_r["actual_icon"]} {_r["actual_outcome"]}</span></div>',
            unsafe_allow_html=True,
        )
        _row[7].markdown(
            f'<div style="background:{_row_bg}; padding:10px 6px; '
            f'font-size:12px; color:#90a4ae; font-family:monospace;">'
            f'${_r["close_price"]:.2f}</div>',
            unsafe_allow_html=True,
        )
        _row[8].markdown(
            f'<div style="background:{_row_bg}; padding:10px 6px; '
            f'font-size:12px; font-weight:700; color:{_move_clr}; font-family:monospace;">'
            f'{_move_sign}{_move:.1f}%</div>',
            unsafe_allow_html=True,
        )
        _fb_icon = ""
        if _r.get("false_break_up"):
            _fb_icon = '<span title="False bullish break — reversed within 30 min" ' \
                       'style="color:#ffa726; font-size:14px;">⚠↑</span>'
        elif _r.get("false_break_down"):
            _fb_icon = '<span title="False bearish break — reversed within 30 min" ' \
                       'style="color:#ffa726; font-size:14px;">⚠↓</span>'
        _row[9].markdown(
            f'<div style="background:{_row_bg}; padding:10px 4px; text-align:center;">'
            f'{_fb_icon}</div>',
            unsafe_allow_html=True,
        )
        _row[10].markdown(
            f'<div style="background:{_row_bg}; padding:8px 6px;">'
            f'<span style="background:{_wl_clr}22; color:{_wl_clr}; '
            f'font-size:11px; font-weight:800; padding:3px 10px; border-radius:10px; '
            f'border:1px solid {_wl_clr}55; text-transform:uppercase;">'
            f'{_wl}</span></div>',
            unsafe_allow_html=True,
        )
        st.markdown(
            '<div style="border-bottom:1px solid #060f18; margin:0;"></div>',
            unsafe_allow_html=True,
        )

    # ── Footer legend ────────────────────────────────────────────────────────────
    st.markdown(
        '<div style="margin-top:20px; font-size:10px; color:#263238; font-family:monospace;">'
        'WIN LOGIC: Trend/Nrml Var → one IB side breaks · '
        'Ntrl Extreme → any IB break (high-vol) · '
        'Non-Trend/Normal → stays inside IB · '
        'Neutral/Dbl Dist → any break · '
        'Follow-Thru = (Best post-IB point − IB boundary broken) / IB boundary · IB = 9:30–10:30 AM ET'
        '</div>',
        unsafe_allow_html=True,
    )


_BATCH_DEFAULT = """\
3/30: ANNA, SST, ASTC, BFRG, UGRO, JCSE, EEIQ, ELAB
3/27: VSA, ARTL, GVH, GCTK
3/26: AIFF, EEIQ, GLND, FCHL, VSA
3/25: VCX, RMSG, UGRO, SATL, CODX, QNRX, FEED
3/24: SATL, FEED, RBNE, PAVS, VCX, UGRO, ANNA
3/23: AHMA, UGRO, VCX, BIAF, PTLE
3/20: ARTL, ANNA, CODX
3/19: LNKS, SWMR, ACXP, GOAI, SER, VCX, CHNR
3/18: ARTL, AIM, SWMR, MTVA
3/17: UCAR, LNAI, BIAF, CREG, EDSA, SWMR
3/16: WNW, HCWB"""


def render_analytics_tab():
    """Render the 📊 Analytics & Edge dashboard tab."""
    import plotly.graph_objects as _go
    from plotly.subplots import make_subplots as _make_subplots

    st.markdown("## 📊 Analytics & Edge")
    st.caption("Live edge stats computed from your trade journal and accuracy tracker.")

    with st.expander("📋 What this tab shows and how to read it", expanded=False):
        st.markdown(
            """
**This tab is read-only. It shows your personal edge data derived from your real trades.**

Nothing here requires any input from you. All numbers update automatically as you add trades in the Journal tab.

---

**What you'll find here:**

| Section | What it shows |
|---|---|
| **KPI cards** (top) | Total trades, win rate, avg P&L, avg TCS — your headline stats |
| **Pattern Correlation** | How your win rate varies by structure type, TCS range, and IB entry position |
| **Saved Predictions** | Your Predict All outputs grouped by date — what the model said vs what happened |
| **Trade Timing & Ticker Edge** | Win rate by entry hour, day of week, and ticker — tells you WHEN and WHERE you perform best |
| **Win Rate by Hold Type** | Intraday vs Overnight vs Multi-day — tells you which style you're actually good at |
| **Hold-Type Signal Profile** | For each hold style, the TCS/RVOL/structure fingerprint of your winning vs losing trades |

---

**When should you act on this data?**
- With fewer than 20 trades, treat it as directional only — not statistically reliable yet
- At 30+ trades, the timing and structure breakdowns start to be genuinely useful
- At 50+ trades, the hold-type fingerprint becomes an actual decision rule

**How to get more data in here:**
→ Go to the **📖 Journal** tab → import your Webull CSV → click "🔄 Sync Journal → Analytics" if prompted
            """,
        )

    _uid = st.session_state.get("auth_user_id", "")
    journal_df = load_journal(user_id=_uid)
    tracker_df = load_accuracy_tracker(user_id=_uid)

    with st.spinner("Computing edge analytics…"):
        ana = compute_edge_analytics(journal_df, tracker_df)

    s = ana["summary"]
    no_data = s["total_trades"] == 0

    # ── KPI CARDS ──────────────────────────────────────────────────────────
    def _kpi(label, value, color="#e0e0e0", sub=""):
        _sub_html = (
            '<div style="font-size:10px;color:#666;margin-top:2px;">' + sub + '</div>'
            if sub else ""
        )
        return (
            f'<div style="background:#12122288; border:1px solid #2a2a4a; '
            f'border-radius:10px; padding:14px 18px; text-align:center;">'
            f'<div style="font-size:10px; color:#5c6bc0; text-transform:uppercase; '
            f'letter-spacing:1px; margin-bottom:4px;">{label}</div>'
            f'<div style="font-size:28px; font-weight:900; color:{color};">{value}</div>'
            f'{_sub_html}'
            f'</div>'
        )

    wr        = s["win_rate"]
    wr_color  = "#4caf50" if wr >= 55 else ("#ffa726" if wr >= 45 else "#ef5350")
    pnl_color = "#4caf50" if s["total_pnl"] >= 0 else "#ef5350"
    pf_color  = "#4caf50" if s["profit_factor"] >= 1.5 else ("#ffa726" if s["profit_factor"] >= 1.0 else "#ef5350")
    pnl_sign  = "+" if s["total_pnl"] >= 0 else ""

    kc1, kc2, kc3, kc4 = st.columns(4)
    with kc1:
        st.markdown(_kpi("Win Rate", f"{wr}%", wr_color,
                         f"{s['total_trades']} trades · {s['trade_days']} days"),
                    unsafe_allow_html=True)
    with kc2:
        st.markdown(_kpi("Total P&L",
                         f"{pnl_sign}${s['total_pnl']:.2f}", pnl_color,
                         f"avg win ${s['avg_win']:.2f} / avg loss ${s['avg_loss']:.2f}"),
                    unsafe_allow_html=True)
    with kc3:
        pf_str = f"{s['profit_factor']:.2f}" if s['profit_factor'] < 99 else "∞"
        st.markdown(_kpi("Profit Factor", pf_str, pf_color,
                         "gross win / gross loss"),
                    unsafe_allow_html=True)
    with kc4:
        j_count = len(journal_df) if not journal_df.empty else 0
        st.markdown(_kpi("Journal Entries", str(j_count), "#90caf9",
                         f"{s['total_trades']} synced to tracker"),
                    unsafe_allow_html=True)

    # ── JOURNAL × MODEL CROSS-REFERENCE (runs regardless of tracker state) ────
    st.markdown("---")
    st.markdown("### 🔬 Personal Trades × Model Predictions — Cross-Reference")
    st.caption(
        "Joins your journal trades to the model's structure call on that same day & ticker. "
        "Shows whether the model was warning you on days you lost."
    )

    _xref_bt_df = load_backtest_sim_history(user_id=_uid)

    _xref = compute_journal_model_crossref(journal_df, _xref_bt_df)

    if not _xref["by_structure"] and _xref["unmatched_n"] == 0 and journal_df.empty:
        st.info("Import your trades and run Brain Calibration first — both datasets are needed.")
    elif not _xref["by_structure"]:
        _total_j = len(journal_df) if not journal_df.empty else 0
        st.warning(
            f"Your journal has {_total_j} entries but none matched to a model prediction yet. "
            f"Run Brain Calibration (22 days) so the model has predictions for the same "
            f"ticker/date combinations as your trades."
        )
        if _xref["unmatched_n"] > 0:
            st.caption(f"{_xref['unmatched_n']} journal trades have no matching model session.")
    else:
        _xr_al = _xref["alignment"]
        _al_color = "#4caf50" if _xr_al >= 70 else ("#ffa726" if _xr_al >= 40 else "#ef5350")
        _al_label = "Model was correctly warning you" if _xr_al >= 60 else (
            "Partial alignment" if _xr_al >= 40 else "Model missed these losses")
        _fs = _xref["filter_sim"]
        _blocked_n = _fs.get("blocked_n", 0)
        _allowed_n = _fs.get("allowed_n", 0)
        _total_matched = _blocked_n + _allowed_n
        _block_pct = round(_blocked_n / _total_matched * 100) if _total_matched else 0

        _xc1, _xc2, _xc3 = st.columns(3)
        with _xc1:
            st.markdown(
                f'<div style="background:#12122288; border:1px solid #2a2a4a; '
                f'border-radius:10px; padding:14px 18px; text-align:center;">'
                f'<div style="font-size:10px; color:#5c6bc0; text-transform:uppercase; '
                f'letter-spacing:1px; margin-bottom:4px;">Model Alignment on Losses</div>'
                f'<div style="font-size:32px; font-weight:900; color:{_al_color};">{_xr_al}%</div>'
                f'<div style="font-size:10px; color:#666; margin-top:2px;">{_al_label}</div>'
                f'</div>',
                unsafe_allow_html=True,
            )
        with _xc2:
            st.markdown(
                f'<div style="background:#12122288; border:1px solid #2a2a4a; '
                f'border-radius:10px; padding:14px 18px; text-align:center;">'
                f'<div style="font-size:10px; color:#5c6bc0; text-transform:uppercase; '
                f'letter-spacing:1px; margin-bottom:4px;">Trades Filter Would Block</div>'
                f'<div style="font-size:32px; font-weight:900; color:#ef5350;">'
                f'{_blocked_n}<span style="font-size:14px; color:#666;"> / {_total_matched}</span></div>'
                f'<div style="font-size:10px; color:#666; margin-top:2px;">'
                f'{_block_pct}% of matched trades · non-Neutral + TCS≥75 filter</div>'
                f'</div>',
                unsafe_allow_html=True,
            )
        with _xc3:
            _pnl_blocked = _fs.get("pnl_blocked", 0.0)
            _pnl_color = "#4caf50" if _pnl_blocked >= 0 else "#ef5350"
            _pnl_sign  = "+" if _pnl_blocked >= 0 else ""
            _df_blk = _fs.get("d_f_blocked_pct", 0.0)
            st.markdown(
                f'<div style="background:#12122288; border:1px solid #2a2a4a; '
                f'border-radius:10px; padding:14px 18px; text-align:center;">'
                f'<div style="font-size:10px; color:#5c6bc0; text-transform:uppercase; '
                f'letter-spacing:1px; margin-bottom:4px;">P&L of Blocked Trades</div>'
                f'<div style="font-size:32px; font-weight:900; color:{_pnl_color};">'
                f'{_pnl_sign}${abs(_pnl_blocked):.0f}</div>'
                f'<div style="font-size:10px; color:#666; margin-top:2px;">'
                f'{_df_blk}% of blocked were D/F grade</div>'
                f'</div>',
                unsafe_allow_html=True,
            )

        st.markdown("<div style='height:10px'></div>", unsafe_allow_html=True)

        _xref_rows = []
        for _s in _xref["by_structure"]:
            _gc  = _s["grade_counts"]
            _grade_order = ["A", "B", "C", "D", "F", "?"]
            _grade_str = " · ".join(
                f'{g}: {_gc[g]}' for g in _grade_order if g in _gc
            )
            _pnl_disp = f"${_s['avg_pnl_est']:+.2f}" if _s["avg_pnl_est"] is not None else "N/A"
            _xref_rows.append({
                "Model Called":    _s["structure"],
                "Your Trades":     _s["trades"],
                "Grade Breakdown": _grade_str,
                "D/F Rate":        f"{_s['d_f_pct']}%",
                "Avg P&L":         _pnl_disp,
            })
        st.dataframe(pd.DataFrame(_xref_rows), use_container_width=True, hide_index=True)

        _df_allowed = _fs.get("d_f_allowed_pct", 0.0)
        _df_blk2 = _fs.get("d_f_blocked_pct", 0.0)
        st.markdown(
            f'<div style="background:#0a1628; border-left:4px solid #1565c0; '
            f'padding:12px 16px; border-radius:4px; margin-top:8px; font-size:12px; color:#b0bec5;">'
            f'<b style="color:#90caf9;">Filter Simulation:</b> '
            f'If the non-Neutral + TCS≥75 filter had been active — '
            f'<b>{_blocked_n} trades would have been blocked</b> ({_df_blk2}% D/F grade) · '
            f'<b>{_allowed_n} would have been allowed</b> ({_df_allowed}% D/F grade). '
            f'Model alignment on your losing trades: '
            f'<b style="color:{_al_color};">{_xr_al}%</b> — '
            f'{"it was correctly flagging Neutral on most of your worst sessions." if _xr_al >= 60 else "filter needs further tuning before autonomous use."}'
            f'</div>',
            unsafe_allow_html=True,
        )
        if _xref["unmatched_n"] > 0:
            st.caption(
                f"⚠️ {_xref['unmatched_n']} journal trades had no matching model prediction. "
                f"Re-run calibration with more days to close this gap."
            )

        # ── Within-Neutral Quality Filter ─────────────────────────────────
        _nq = _xref.get("neutral_quality", {})
        if _nq.get("tcs_buckets") or _nq.get("ib_position"):
            st.markdown("---")
            st.markdown("#### 🎯 Within-Neutral Quality Filter")
            st.caption(
                "Since your tickers live almost entirely in Neutral/Ntrl Extreme days, "
                "the edge isn't in the structure — it's in the conditions *within* that structure. "
                "This shows what actually separated your wins from your losses."
            )

            _nq_col1, _nq_col2 = st.columns(2)

            # Detect if TCS data is entirely missing (table schema gap)
            _all_no_tcs = (
                _nq.get("tcs_buckets")
                and len(_nq["tcs_buckets"]) == 1
                and _nq["tcs_buckets"][0]["bucket"] == "No TCS"
            )
            if _all_no_tcs:
                st.warning(
                    "All trades are landing in **No TCS** — this means your "
                    "`backtest_sim_runs` table is missing the `tcs` column. "
                    "Go to the **Backtest tab** for the exact SQL to run in your "
                    "Supabase SQL editor, then re-run calibration once.",
                    icon="⚠️",
                )

            with _nq_col1:
                st.markdown("**By TCS Score (session conviction)**")
                if _nq.get("tcs_buckets"):
                    _tcs_rows = []
                    for _b in _nq["tcs_buckets"]:
                        _gc = _b["grade_counts"]
                        _grade_order = ["A", "B", "C", "D", "F", "?"]
                        _gs = " · ".join(f'{g}:{_gc[g]}' for g in _grade_order if g in _gc)
                        _ab_color = (
                            "🟢" if _b["ab_pct"] >= 60 else
                            "🟡" if _b["ab_pct"] >= 40 else "🔴"
                        )
                        _tcs_rows.append({
                            "TCS Range":     _b["bucket"],
                            "Trades":        _b["trades"],
                            "A/B Rate":      f"{_ab_color} {_b['ab_pct']}%",
                            "D/F Rate":      f"{_b['df_pct']}%",
                            "Grades":        _gs,
                        })
                    st.dataframe(pd.DataFrame(_tcs_rows),
                                 use_container_width=True, hide_index=True)
                else:
                    st.caption("No TCS data available for matched trades.")

            with _nq_col2:
                st.markdown("**By Entry Position vs IB Range**")
                if _nq.get("ib_position"):
                    _ib_rows = []
                    for _p in _nq["ib_position"]:
                        _gc = _p["grade_counts"]
                        _grade_order = ["A", "B", "C", "D", "F", "?"]
                        _gs = " · ".join(f'{g}:{_gc[g]}' for g in _grade_order if g in _gc)
                        _ab_color = (
                            "🟢" if _p["ab_pct"] >= 60 else
                            "🟡" if _p["ab_pct"] >= 40 else "🔴"
                        )
                        _ib_rows.append({
                            "Entry Position": _p["position"],
                            "Trades":         _p["trades"],
                            "A/B Rate":       f"{_ab_color} {_p['ab_pct']}%",
                            "D/F Rate":       f"{_p['df_pct']}%",
                            "Grades":         _gs,
                        })
                    st.dataframe(pd.DataFrame(_ib_rows),
                                 use_container_width=True, hide_index=True)
                else:
                    st.caption(
                        "IB position data not available — re-run calibration to populate "
                        "IB high/low for your tickers."
                    )

            if _nq.get("recommendation"):
                st.markdown(
                    f'<div style="background:#0d2137; border-left:4px solid #00e5ff; '
                    f'padding:12px 16px; border-radius:4px; margin-top:10px; '
                    f'font-size:13px; color:#e0e0e0;">'
                    f'<b style="color:#00e5ff;">Derived Rule:</b> {_nq["recommendation"]}'
                    f'</div>',
                    unsafe_allow_html=True,
                )

    if no_data:
        # If journal has entries but tracker is empty, offer one-click backfill
        _j_count = len(journal_df) if not journal_df.empty else 0
        if _j_count > 0:
            st.warning(
                f"Your journal has **{_j_count} entries** from your Webull import, but they haven't "
                f"been linked to the analytics engine yet. Click below to sync them now — this is a "
                f"one-time step for previously imported trades."
            )
            if st.button("🔄 Sync Journal → Analytics", type="primary",
                         key="analytics_backfill_btn"):
                _backfill_uid = st.session_state.get("auth_user_id", "")
                _backfill_count = 0
                _backfill_fail  = 0
                for _, _jrow in journal_df.iterrows():
                    try:
                        _bp   = float(str(_jrow.get("price", 0)).replace("$","") or 0)
                        # Try to extract exit price from notes ("Exit: $X.XXXX")
                        _bnotes = str(_jrow.get("notes", ""))
                        import re as _re
                        _ex_m = _re.search(r"Exit:\s*\$([0-9.]+)", _bnotes)
                        _bex  = float(_ex_m.group(1)) if _ex_m else 0.0
                        # Try to extract P&L ("P&L: $+X.XX")
                        _pnl_m = _re.search(r"P&L:\s*\$([+-]?[0-9.]+)", _bnotes)
                        _bmfe  = float(_pnl_m.group(1)) if _pnl_m else 0.0
                        if _bp > 0 and _bex > 0:
                            log_accuracy_entry(
                                symbol=str(_jrow.get("ticker", "")),
                                predicted=str(_jrow.get("structure", "Unknown")),
                                actual=str(_jrow.get("structure", "Unknown")),
                                compare_key="webull_import",
                                entry_price=_bp,
                                exit_price=_bex,
                                mfe=_bmfe,
                                user_id=_backfill_uid,
                            )
                            _backfill_count += 1
                        else:
                            _backfill_fail += 1
                    except Exception:
                        _backfill_fail += 1
                st.success(
                    f"Synced **{_backfill_count} trades** to analytics."
                    + (f" {_backfill_fail} entries skipped (missing P&L data)." if _backfill_fail else "")
                    + " Refresh the page to see your stats."
                )
                st.rerun()
        else:
            st.info(
                "No synced trades yet. Import your Webull CSV in the **Journal** tab, "
                "then return here to see your edge stats. "
                "The Pattern Correlation section below is still available."
            )

    st.markdown("---")

    # ── EQUITY CURVE ──────────────────────────────────────────────────────
    eq = ana["equity_curve"]
    if not eq.empty:
        st.markdown("**Cumulative P&L — Equity Curve**")
        _colors_eq = ["#ef5350" if v < 0 else "#4caf50"
                      for v in eq["cumulative_pnl"]]
        fig_eq = _go.Figure()
        # Zero line fill area
        fig_eq.add_trace(_go.Scatter(
            x=eq["timestamp"], y=eq["cumulative_pnl"],
            mode="lines+markers",
            line=dict(color="#00e5ff", width=2.5),
            marker=dict(size=6, color=_colors_eq,
                        line=dict(color="#1a1a2e", width=1)),
            fill="tozeroy",
            fillcolor="rgba(0,229,255,0.08)",
            name="Cumulative P&L",
            hovertemplate=(
                "<b>%{customdata}</b><br>"
                "Trade P&L: $%{text}<br>"
                "Cumulative: $%{y:.2f}<extra></extra>"
            ),
            customdata=eq["symbol"],
            text=eq["mfe"].round(2).astype(str),
        ))
        fig_eq.add_hline(y=0, line=dict(color="rgba(255,255,255,0.15)", dash="dot"))
        fig_eq.update_layout(
            paper_bgcolor="#1a1a2e", plot_bgcolor="#16213e",
            font=dict(color="#e0e0e0"), height=280,
            xaxis=dict(title="", gridcolor="#2a2a4a", showgrid=True),
            yaxis=dict(title="Cumulative P&L ($)", gridcolor="#2a2a4a"),
            margin=dict(l=10, r=10, t=20, b=30),
            showlegend=False,
            hoverlabel=dict(bgcolor="#1a1a2e", font_color="#e0e0e0"),
        )
        st.plotly_chart(fig_eq, use_container_width=True)

    # ── WIN RATE BY STRUCTURE + GRADE DONUT ──────────────────────────────
    col_a, col_b = st.columns([3, 2])

    with col_a:
        wr_s = ana["win_rate_by_struct"]
        if not wr_s.empty:
            st.markdown("**Win Rate by Predicted Structure**")
            _bar_colors = [
                "#4caf50" if r >= 60 else ("#ffa726" if r >= 45 else "#ef5350")
                for r in wr_s["win_rate"]
            ]
            fig_wr = _go.Figure()
            fig_wr.add_trace(_go.Bar(
                x=wr_s["structure"], y=wr_s["win_rate"],
                marker_color=_bar_colors,
                text=[f"{r}%<br>{t}T" for r, t in
                      zip(wr_s["win_rate"], wr_s["trades"])],
                textposition="outside",
                textfont=dict(size=10, color="#e0e0e0"),
                hovertemplate=(
                    "<b>%{x}</b><br>"
                    "Win Rate: %{y:.1f}%<br>"
                    "Avg P&L: $%{customdata:.2f}<extra></extra>"
                ),
                customdata=wr_s["avg_pnl"],
                name="Win Rate",
            ))
            fig_wr.add_hline(y=50, line=dict(color="rgba(255,255,255,0.2)", dash="dot"),
                             annotation_text="50%", annotation_font_color="#888")
            fig_wr.update_layout(
                paper_bgcolor="#1a1a2e", plot_bgcolor="#16213e",
                font=dict(color="#e0e0e0"), height=300,
                xaxis=dict(gridcolor="#2a2a4a"),
                yaxis=dict(title="Win Rate (%)", gridcolor="#2a2a4a",
                           range=[0, max(wr_s["win_rate"].max() + 15, 70)]),
                margin=dict(l=10, r=10, t=20, b=40),
                showlegend=False,
            )
            st.plotly_chart(fig_wr, use_container_width=True)

    with col_b:
        gd = ana["grade_distribution"]
        if gd:
            st.markdown("**Grade Distribution**")
            _gd_order  = [g for g in ["A", "B", "C", "F"] if g in gd]
            _gd_vals   = [gd[g] for g in _gd_order]
            _gd_colors = [_GRADE_COLORS.get(g, "#aaa") for g in _gd_order]
            fig_pie = _go.Figure(_go.Pie(
                labels=_gd_order, values=_gd_vals,
                marker=dict(colors=_gd_colors,
                            line=dict(color="#1a1a2e", width=2)),
                hole=0.55,
                textinfo="label+percent",
                textfont=dict(size=12, color="#e0e0e0"),
                hovertemplate="<b>Grade %{label}</b><br>Count: %{value}<extra></extra>",
            ))
            fig_pie.update_layout(
                paper_bgcolor="#1a1a2e", plot_bgcolor="#1a1a2e",
                font=dict(color="#e0e0e0"), height=300,
                margin=dict(l=0, r=0, t=20, b=0),
                showlegend=False,
                annotations=[dict(
                    text=f"<b>{sum(_gd_vals)}</b><br>trades",
                    x=0.5, y=0.5, font_size=14,
                    font_color="#e0e0e0", showarrow=False,
                )],
            )
            st.plotly_chart(fig_pie, use_container_width=True)

    # ── DAILY P&L BAR + TCS EDGE ─────────────────────────────────────────
    col_c, col_d = st.columns([3, 2])

    with col_c:
        dp = ana["daily_pnl"]
        if not dp.empty:
            st.markdown("**Daily P&L**")
            _day_colors = ["#4caf50" if v >= 0 else "#ef5350" for v in dp["pnl"]]
            fig_day = _go.Figure()
            fig_day.add_trace(_go.Bar(
                x=dp["date"].astype(str), y=dp["pnl"],
                marker_color=_day_colors,
                text=[f"${v:+.2f}" for v in dp["pnl"]],
                textposition="outside",
                textfont=dict(size=9, color="#e0e0e0"),
                hovertemplate="<b>%{x}</b><br>P&L: $%{y:.2f}<extra></extra>",
                name="Daily P&L",
            ))
            fig_day.add_hline(y=0, line=dict(color="rgba(255,255,255,0.2)"))
            fig_day.update_layout(
                paper_bgcolor="#1a1a2e", plot_bgcolor="#16213e",
                font=dict(color="#e0e0e0"), height=250,
                xaxis=dict(gridcolor="#2a2a4a", tickangle=-30),
                yaxis=dict(title="P&L ($)", gridcolor="#2a2a4a"),
                margin=dict(l=10, r=10, t=20, b=50),
                showlegend=False,
            )
            st.plotly_chart(fig_day, use_container_width=True)

    with col_d:
        tcs_df = ana["tcs_edge"]
        if not tcs_df.empty:
            st.markdown("**Win Rate by TCS Score**")
            _tcs_colors = [
                "#4caf50" if r >= 60 else ("#ffa726" if r >= 45 else "#ef5350")
                for r in tcs_df["win_rate"]
            ]
            fig_tcs = _go.Figure(_go.Bar(
                x=tcs_df["tcs_bucket"], y=tcs_df["win_rate"],
                marker_color=_tcs_colors,
                text=[f"{r}%<br>{t}T" for r, t in
                      zip(tcs_df["win_rate"], tcs_df["trades"])],
                textposition="outside",
                textfont=dict(size=10, color="#e0e0e0"),
                hovertemplate="<b>TCS %{x}</b><br>Win Rate: %{y:.1f}%<extra></extra>",
            ))
            fig_tcs.add_hline(y=50, line=dict(color="rgba(255,255,255,0.2)", dash="dot"))
            fig_tcs.update_layout(
                paper_bgcolor="#1a1a2e", plot_bgcolor="#16213e",
                font=dict(color="#e0e0e0"), height=250,
                xaxis=dict(title="TCS Range", gridcolor="#2a2a4a"),
                yaxis=dict(title="Win Rate (%)", gridcolor="#2a2a4a",
                           range=[0, 100]),
                margin=dict(l=10, r=10, t=20, b=30),
                showlegend=False,
            )
            st.plotly_chart(fig_tcs, use_container_width=True)

    # ── BACKTEST STRUCTURE WIN RATE (from sim history) ────────────────────
    st.markdown("---")
    st.markdown("**📊 Backtest Structure Win Rates** *(from your saved simulation history)*")
    _bk_stats = compute_backtest_structure_stats(_uid)
    if _bk_stats.empty:
        st.caption("Run backtests in the Backtest tab to populate this chart. "
                   "Each unique ticker/date pair you simulate builds this dataset.")
    else:
        import plotly.graph_objects as _go2
        _bk_win_colors = [
            "#4caf50" if r >= 60 else ("#ffa726" if r >= 45 else "#ef5350")
            for r in _bk_stats["win_rate"]
        ]
        _bcols = st.columns([3, 2])
        with _bcols[0]:
            fig_bk = _go2.Figure()
            fig_bk.add_trace(_go2.Bar(
                x=_bk_stats["structure"], y=_bk_stats["win_rate"],
                marker_color=_bk_win_colors,
                text=[f"{r}%<br>{t}T · FT {ft:.1f}%"
                      for r, t, ft in zip(_bk_stats["win_rate"],
                                          _bk_stats["trades"],
                                          _bk_stats["avg_follow_thru"])],
                textposition="outside",
                textfont=dict(size=9, color="#e0e0e0"),
                hovertemplate=(
                    "<b>%{x}</b><br>Win Rate: %{y:.1f}%<br>"
                    "Trades: %{customdata[0]}<br>"
                    "Avg Follow-Thru: %{customdata[1]:.1f}%<br>"
                    "False Break Rate: %{customdata[2]:.1f}%<extra></extra>"
                ),
                customdata=list(zip(
                    _bk_stats["trades"],
                    _bk_stats["avg_follow_thru"],
                    _bk_stats["false_brk_rate"],
                )),
            ))
            fig_bk.add_hline(y=50, line=dict(color="rgba(255,255,255,0.2)", dash="dot"),
                             annotation_text="50% baseline", annotation_font_color="#888")
            fig_bk.update_layout(
                paper_bgcolor="#1a1a2e", plot_bgcolor="#16213e",
                font=dict(color="#e0e0e0"), height=300,
                xaxis=dict(gridcolor="#2a2a4a", tickangle=-20),
                yaxis=dict(title="Win Rate (%)", gridcolor="#2a2a4a", range=[0, 100]),
                margin=dict(l=10, r=10, t=20, b=60),
                showlegend=False,
            )
            st.plotly_chart(fig_bk, use_container_width=True)

        with _bcols[1]:
            st.markdown("**False Break Rate by Structure**")
            _fb_colors = [
                "#4caf50" if r <= 15 else ("#ffa726" if r <= 30 else "#ef5350")
                for r in _bk_stats["false_brk_rate"]
            ]
            fig_fb = _go2.Figure(_go2.Bar(
                x=_bk_stats["structure"], y=_bk_stats["false_brk_rate"],
                marker_color=_fb_colors,
                text=[f"{r}%" for r in _bk_stats["false_brk_rate"]],
                textposition="outside",
                textfont=dict(size=10, color="#e0e0e0"),
                hovertemplate="<b>%{x}</b><br>False Break: %{y:.1f}%<extra></extra>",
            ))
            fig_fb.add_hline(y=20, line=dict(color="rgba(255,255,255,0.2)", dash="dot"),
                             annotation_text="20% danger", annotation_font_color="#ffa726")
            fig_fb.update_layout(
                paper_bgcolor="#1a1a2e", plot_bgcolor="#16213e",
                font=dict(color="#e0e0e0"), height=300,
                xaxis=dict(gridcolor="#2a2a4a", tickangle=-20),
                yaxis=dict(title="False Break (%)", gridcolor="#2a2a4a", range=[0, 80]),
                margin=dict(l=10, r=10, t=20, b=60),
                showlegend=False,
            )
            st.plotly_chart(fig_fb, use_container_width=True)

        total_unique = _bk_stats["trades"].sum()
        st.caption(
            f"Based on {total_unique} unique ticker/date simulations · "
            "Duplicates removed · Hover bars for full breakdown"
        )

    # ── RAW TRACKER TABLE ─────────────────────────────────────────────────
    with st.expander("🗂 Raw Synced Trades", expanded=False):
        eq_disp = ana["equity_curve"].copy()
        if not eq_disp.empty:
            eq_disp["timestamp"] = eq_disp["timestamp"].dt.strftime("%Y-%m-%d %H:%M")
            eq_disp["mfe"]       = eq_disp["mfe"].map(lambda v: f"{'+'if v>=0 else''}{v:.2f}")
            eq_disp["cumulative_pnl"] = eq_disp["cumulative_pnl"].map(
                lambda v: f"{'+'if v>=0 else''}{v:.2f}")
            eq_disp.columns = ["Time", "Symbol", "Trade P&L", "Cumulative P&L"]
            st.dataframe(eq_disp, use_container_width=True, hide_index=True)

    # ══════════════════════════════════════════════════════════════════════════
    # SECTION — Journal-Based Edge Analytics (time, day, ticker)
    # ══════════════════════════════════════════════════════════════════════════
    if not journal_df.empty:
        st.markdown("---")
        st.markdown("### 📅 Trade Timing & Ticker Edge")
        st.caption("Based on your full journal history — grades A/B = win, C/D/F = loss.")

        import pandas as _pd_an
        _jdf = journal_df.copy()

        # Coerce timestamp
        _jdf["_ts"] = _pd_an.to_datetime(_jdf.get("timestamp", _pd_an.NaT), errors="coerce")
        _jdf["_hour"] = _jdf["_ts"].dt.hour
        _jdf["_dow"]  = _jdf["_ts"].dt.dayofweek   # 0=Mon … 4=Fri
        _jdf["_win"]  = _jdf["grade"].isin(["A", "B"]).astype(int)

        # Drop rows with no timestamp
        _jdf = _jdf.dropna(subset=["_ts"])

        _timing_col1, _timing_col2 = st.columns(2)

        # ── Time-of-Day win rate ──────────────────────────────────────────────
        with _timing_col1:
            _hour_grp = (
                _jdf.groupby("_hour")["_win"]
                .agg(trades="count", wins="sum")
                .reset_index()
            )
            _hour_grp = _hour_grp[_hour_grp["trades"] >= 1].copy()
            _hour_grp["win_rate"] = (_hour_grp["wins"] / _hour_grp["trades"] * 100).round(1)
            _hour_grp["label"]    = _hour_grp["_hour"].apply(
                lambda h: f"{h % 12 or 12}{'am' if h < 12 else 'pm'}"
            )

            if not _hour_grp.empty:
                _hr_colors = [
                    "#4caf50" if r >= 55 else "#ffa726" if r >= 40 else "#ef5350"
                    for r in _hour_grp["win_rate"]
                ]
                fig_hr = _go.Figure()
                fig_hr.add_trace(_go.Bar(
                    x=_hour_grp["label"],
                    y=_hour_grp["win_rate"],
                    marker_color=_hr_colors,
                    text=[f"{r}%<br>({t}T)" for r, t in
                          zip(_hour_grp["win_rate"], _hour_grp["trades"])],
                    textposition="outside",
                    textfont=dict(size=9, color="#e0e0e0"),
                    hovertemplate="<b>%{x}</b><br>Win Rate: %{y:.1f}%<extra></extra>",
                ))
                fig_hr.add_hline(y=50, line=dict(color="rgba(255,255,255,0.2)", dash="dot"))
                fig_hr.update_layout(
                    paper_bgcolor="#1a1a2e", plot_bgcolor="#16213e",
                    font=dict(color="#e0e0e0"), height=260,
                    title=dict(text="Win Rate by Entry Hour (EST)", font=dict(size=13)),
                    xaxis=dict(gridcolor="#2a2a4a"),
                    yaxis=dict(gridcolor="#2a2a4a", range=[0, 110], title="Win %"),
                    margin=dict(l=10, r=10, t=40, b=30),
                    showlegend=False,
                )
                st.plotly_chart(fig_hr, use_container_width=True)
            else:
                st.info("Not enough timestamped entries for time-of-day analysis.")

        # ── Day-of-Week win rate ──────────────────────────────────────────────
        with _timing_col2:
            _dow_names = {0: "Mon", 1: "Tue", 2: "Wed", 3: "Thu", 4: "Fri"}
            _dow_grp = (
                _jdf[_jdf["_dow"].isin(range(5))]
                .groupby("_dow")["_win"]
                .agg(trades="count", wins="sum")
                .reset_index()
            )
            _dow_grp["win_rate"] = (_dow_grp["wins"] / _dow_grp["trades"] * 100).round(1)
            _dow_grp["label"]    = _dow_grp["_dow"].map(_dow_names)

            if not _dow_grp.empty:
                _dw_colors = [
                    "#4caf50" if r >= 55 else "#ffa726" if r >= 40 else "#ef5350"
                    for r in _dow_grp["win_rate"]
                ]
                fig_dw = _go.Figure()
                fig_dw.add_trace(_go.Bar(
                    x=_dow_grp["label"],
                    y=_dow_grp["win_rate"],
                    marker_color=_dw_colors,
                    text=[f"{r}%<br>({t}T)" for r, t in
                          zip(_dow_grp["win_rate"], _dow_grp["trades"])],
                    textposition="outside",
                    textfont=dict(size=9, color="#e0e0e0"),
                    hovertemplate="<b>%{x}</b><br>Win Rate: %{y:.1f}%<extra></extra>",
                ))
                fig_dw.add_hline(y=50, line=dict(color="rgba(255,255,255,0.2)", dash="dot"))
                fig_dw.update_layout(
                    paper_bgcolor="#1a1a2e", plot_bgcolor="#16213e",
                    font=dict(color="#e0e0e0"), height=260,
                    title=dict(text="Win Rate by Day of Week", font=dict(size=13)),
                    xaxis=dict(gridcolor="#2a2a4a",
                               categoryorder="array",
                               categoryarray=["Mon","Tue","Wed","Thu","Fri"]),
                    yaxis=dict(gridcolor="#2a2a4a", range=[0, 110], title="Win %"),
                    margin=dict(l=10, r=10, t=40, b=30),
                    showlegend=False,
                )
                st.plotly_chart(fig_dw, use_container_width=True)
            else:
                st.info("Not enough entries for day-of-week analysis.")

        # ── Intraday vs Multi-Day hold type win rate ─────────────────────────
        st.markdown("---")
        import re as _re_an
        def _hold_type(row):
            _notes = str(row.get("notes", "") or "")
            _entry_ts = str(row.get("timestamp", "") or "")
            _ets_m2 = _re_an.search(
                r"ExitTS:\s*([0-9]{4}-[0-9]{2}-[0-9]{2}[T\s][0-9:]+)"
                r"|Exit:\s*([0-9]{4}-[0-9]{2}-[0-9]{2}\s[0-9:]+)", _notes
            )
            if not _ets_m2 or not _entry_ts:
                return None
            _exit_raw = (_ets_m2.group(1) or _ets_m2.group(2) or "").strip()
            try:
                import pandas as _pd_ht
                _edt = _pd_ht.to_datetime(_entry_ts, errors="coerce")
                _xdt = _pd_ht.to_datetime(_exit_raw, errors="coerce")
                if _pd_ht.isna(_edt) or _pd_ht.isna(_xdt):
                    return None
                _days = (_xdt.date() - _edt.date()).days
                if _days == 0:
                    return "Intraday"
                elif _days == 1:
                    return "Overnight"
                else:
                    return "Multi-day"
            except Exception:
                return None

        _jdf["_hold_type"] = _jdf.apply(_hold_type, axis=1)
        _hold_df = _jdf.dropna(subset=["_hold_type"])

        if not _hold_df.empty and len(_hold_df) >= 3:
            _hold_grp = (
                _hold_df.groupby("_hold_type")["_win"]
                .agg(trades="count", wins="sum")
                .reset_index()
            )
            _hold_grp["win_rate"] = (_hold_grp["wins"] / _hold_grp["trades"] * 100).round(1)
            _hold_order = ["Intraday", "Overnight", "Multi-day"]
            _hold_grp["_ord"] = _hold_grp["_hold_type"].map(
                {t: i for i, t in enumerate(_hold_order)}
            )
            _hold_grp = _hold_grp.sort_values("_ord")
            _hold_colors_map = {"Intraday": "#29b6f6", "Overnight": "#ffa726", "Multi-day": "#ce93d8"}
            _hold_colors_list = [_hold_colors_map.get(t, "#90caf9") for t in _hold_grp["_hold_type"]]

            _hold_left, _hold_right = st.columns([2, 1])
            with _hold_left:
                fig_hold = _go.Figure(_go.Bar(
                    x=_hold_grp["_hold_type"],
                    y=_hold_grp["win_rate"],
                    marker_color=_hold_colors_list,
                    text=[f"{r}%<br>({t} trades)" for r, t in
                          zip(_hold_grp["win_rate"], _hold_grp["trades"])],
                    textposition="outside",
                    textfont=dict(size=10, color="#e0e0e0"),
                    hovertemplate="<b>%{x}</b><br>Win Rate: %{y:.1f}%<extra></extra>",
                ))
                fig_hold.add_hline(y=50, line=dict(color="rgba(255,255,255,0.2)", dash="dot"))
                fig_hold.update_layout(
                    paper_bgcolor="#1a1a2e", plot_bgcolor="#16213e",
                    font=dict(color="#e0e0e0"), height=260,
                    title=dict(text="Win Rate by Hold Type (from your actual Webull exits)",
                               font=dict(size=13)),
                    xaxis=dict(gridcolor="#2a2a4a"),
                    yaxis=dict(gridcolor="#2a2a4a", range=[0, 120], title="Win %"),
                    margin=dict(l=10, r=10, t=40, b=30),
                    showlegend=False,
                )
                st.plotly_chart(fig_hold, use_container_width=True)
            with _hold_right:
                st.markdown("<div style='height:20px'></div>", unsafe_allow_html=True)
                for _, _hrow in _hold_grp.iterrows():
                    _hc = _hold_colors_map.get(_hrow["_hold_type"], "#90caf9")
                    st.markdown(
                        f'<div style="background:{_hc}11;border:1px solid {_hc}44;'
                        f'border-radius:8px;padding:10px 14px;margin:6px 0;">'
                        f'<div style="font-size:11px;color:{_hc};font-weight:700;">'
                        f'{_hrow["_hold_type"]}</div>'
                        f'<div style="font-size:22px;font-weight:900;color:#e0e0e0;">'
                        f'{_hrow["win_rate"]}%</div>'
                        f'<div style="font-size:10px;color:#666;">'
                        f'{int(_hrow["wins"])}/{int(_hrow["trades"])} trades</div>'
                        f'</div>',
                        unsafe_allow_html=True,
                    )

        # ── Multi-Day Setup Profile ───────────────────────────────────────────
        if not _hold_df.empty and len(_hold_df) >= 3:
            st.markdown("---")
            st.markdown("### 🔎 Hold-Type Signal Profile")
            st.caption(
                "For each hold type, what did your winning trades have in common? "
                "Use this to predict whether tomorrow's setup is an intraday trade or a multi-day hold."
            )

            _hold_types_present = [t for t in ["Intraday", "Overnight", "Multi-day"]
                                   if t in _hold_df["_hold_type"].values]

            for _ht in _hold_types_present:
                _ht_color = {"Intraday": "#29b6f6", "Overnight": "#ffa726",
                             "Multi-day": "#ce93d8"}.get(_ht, "#90caf9")
                _ht_df = _hold_df[_hold_df["_hold_type"] == _ht].copy()
                _ht_wins  = _ht_df[_ht_df["_win"] == 1]
                _ht_loss  = _ht_df[_ht_df["_win"] == 0]
                _ht_wr    = round(len(_ht_wins) / len(_ht_df) * 100, 1) if len(_ht_df) > 0 else 0

                with st.expander(
                    f"{_ht}  ·  {_ht_wr}% win rate  ·  {len(_ht_df)} trades",
                    expanded=(_ht == "Intraday"),
                ):
                    _sp_col1, _sp_col2 = st.columns(2)

                    # ── Winning trade fingerprint ──────────────────────────
                    with _sp_col1:
                        st.markdown(
                            f'<div style="color:{_ht_color};font-weight:700;'
                            f'font-size:12px;margin-bottom:8px;">✅ A/B WIN FINGERPRINT</div>',
                            unsafe_allow_html=True,
                        )
                        if _ht_wins.empty:
                            st.caption("Not enough winning trades yet.")
                        else:
                            # Avg TCS
                            _tcs_vals = _pd_an.to_numeric(
                                _ht_wins.get("tcs", _pd_an.Series()), errors="coerce"
                            ).dropna()
                            _rvol_vals = _pd_an.to_numeric(
                                _ht_wins.get("rvol", _pd_an.Series()), errors="coerce"
                            ).dropna()

                            _stat_rows = []
                            if not _tcs_vals.empty:
                                _stat_rows.append(("Avg TCS", f"{_tcs_vals.mean():.0f}",
                                                   f"range {_tcs_vals.min():.0f}–{_tcs_vals.max():.0f}"))
                            if not _rvol_vals.empty:
                                _stat_rows.append(("Avg RVOL", f"{_rvol_vals.mean():.1f}×",
                                                   f"min {_rvol_vals.min():.1f}×"))

                            # Most common entry hours
                            if "_hour" in _ht_wins.columns:
                                _hr_counts = _ht_wins["_hour"].value_counts().head(3)
                                _hr_labels = ", ".join(
                                    f"{h % 12 or 12}{'am' if h < 12 else 'pm'}"
                                    for h in _hr_counts.index
                                )
                                _stat_rows.append(("Best entry hours", _hr_labels, "most frequent"))

                            # Most common structures
                            if "structure" in _ht_wins.columns:
                                _struct_counts = (
                                    _ht_wins["structure"]
                                    .astype(str)
                                    .replace({"Unknown": None, "nan": None, "": None})
                                    .dropna()
                                    .value_counts()
                                    .head(3)
                                )
                                if not _struct_counts.empty:
                                    _struct_labels = ", ".join(
                                        f"{s} ({c})" for s, c in _struct_counts.items()
                                    )
                                    _stat_rows.append(("Top structures", _struct_labels, ""))

                            for _lbl, _val, _sub in _stat_rows:
                                _sub_html = (
                                    '<div style="font-size:9px;color:#555;text-align:right;">'
                                    + _sub + "</div>"
                                ) if _sub else ""
                                st.markdown(
                                    f'<div style="display:flex;justify-content:space-between;'
                                    f'align-items:center;padding:5px 0;'
                                    f'border-bottom:1px solid #1e1e3a;">'
                                    f'<span style="color:#888;font-size:11px;">{_lbl}</span>'
                                    f'<span style="color:#e0e0e0;font-weight:700;font-size:13px;">'
                                    f'{_val}</span>'
                                    f'</div>{_sub_html}',
                                    unsafe_allow_html=True,
                                )

                    # ── Losing trade fingerprint ───────────────────────────
                    with _sp_col2:
                        st.markdown(
                            '<div style="color:#ef5350;font-weight:700;'
                            'font-size:12px;margin-bottom:8px;">❌ C/D/F LOSS FINGERPRINT</div>',
                            unsafe_allow_html=True,
                        )
                        if _ht_loss.empty:
                            st.caption("No losing trades in this category — great!")
                        else:
                            _ltcs_vals = _pd_an.to_numeric(
                                _ht_loss.get("tcs", _pd_an.Series()), errors="coerce"
                            ).dropna()
                            _lrvol_vals = _pd_an.to_numeric(
                                _ht_loss.get("rvol", _pd_an.Series()), errors="coerce"
                            ).dropna()

                            _loss_rows = []
                            if not _ltcs_vals.empty:
                                _loss_rows.append(("Avg TCS", f"{_ltcs_vals.mean():.0f}",
                                                   f"range {_ltcs_vals.min():.0f}–{_ltcs_vals.max():.0f}"))
                            if not _lrvol_vals.empty:
                                _loss_rows.append(("Avg RVOL", f"{_lrvol_vals.mean():.1f}×", ""))

                            if "_hour" in _ht_loss.columns:
                                _lhr_counts = _ht_loss["_hour"].value_counts().head(3)
                                _lhr_labels = ", ".join(
                                    f"{h % 12 or 12}{'am' if h < 12 else 'pm'}"
                                    for h in _lhr_counts.index
                                )
                                _loss_rows.append(("Danger hours", _lhr_labels, "most losses"))

                            if "structure" in _ht_loss.columns:
                                _lstruct_counts = (
                                    _ht_loss["structure"]
                                    .astype(str)
                                    .replace({"Unknown": None, "nan": None, "": None})
                                    .dropna()
                                    .value_counts()
                                    .head(3)
                                )
                                if not _lstruct_counts.empty:
                                    _loss_rows.append(("Loss structures",
                                                       ", ".join(f"{s} ({c})"
                                                                 for s, c in _lstruct_counts.items()),
                                                       "avoid these in this hold style"))

                            for _lbl, _val, _sub in _loss_rows:
                                _lsub_html = (
                                    '<div style="font-size:9px;color:#555;text-align:right;">'
                                    + _sub + "</div>"
                                ) if _sub else ""
                                st.markdown(
                                    f'<div style="display:flex;justify-content:space-between;'
                                    f'align-items:center;padding:5px 0;'
                                    f'border-bottom:1px solid #1e1e3a;">'
                                    f'<span style="color:#888;font-size:11px;">{_lbl}</span>'
                                    f'<span style="color:#e0e0e0;font-weight:700;font-size:13px;">'
                                    f'{_val}</span>'
                                    f'</div>{_lsub_html}',
                                    unsafe_allow_html=True,
                                )

                    # ── Derived rule ───────────────────────────────────────
                    st.markdown("<div style='height:6px'></div>", unsafe_allow_html=True)
                    if not _ht_wins.empty and not _tcs_vals.empty:
                        _rule_tcs = f"TCS ≥ {_tcs_vals.mean():.0f}"
                        _rule_rvol = (f" · RVOL ≥ {_rvol_vals.mean():.1f}×"
                                      if not _rvol_vals.empty else "")
                        st.markdown(
                            f'<div style="background:#0d1f2d;border-left:3px solid {_ht_color};'
                            f'padding:8px 14px;border-radius:4px;font-size:12px;color:#cfd8dc;">'
                            f'<b style="color:{_ht_color};">Derived Rule:</b> '
                            f'For {_ht.lower()} trades, your wins cluster at {_rule_tcs}{_rule_rvol}. '
                            f'Entries below these thresholds in this hold style have historically underperformed.'
                            f'</div>',
                            unsafe_allow_html=True,
                        )

        # ── Top / Bottom Tickers ──────────────────────────────────────────────
        st.markdown("---")
        _tkr_grp = (
            _jdf.groupby("ticker")["_win"]
            .agg(trades="count", wins="sum")
            .reset_index()
        )
        _tkr_grp["win_rate"] = (_tkr_grp["wins"] / _tkr_grp["trades"] * 100).round(1)
        _tkr_grp = _tkr_grp[_tkr_grp["trades"] >= 2].sort_values("win_rate", ascending=False)

        # Try to join P&L from equity curve
        _ec = ana.get("equity_curve", _pd_an.DataFrame())
        if not _ec.empty and "symbol" in _ec.columns and "mfe" in _ec.columns:
            _pnl_by_tkr = _ec.groupby("symbol")["mfe"].sum().reset_index()
            _pnl_by_tkr.columns = ["ticker", "total_pnl"]
            _tkr_grp = _tkr_grp.merge(_pnl_by_tkr, on="ticker", how="left")
            _tkr_grp["total_pnl"] = _tkr_grp["total_pnl"].fillna(0.0).round(2)
        else:
            _tkr_grp["total_pnl"] = 0.0

        if not _tkr_grp.empty:
            _tkr_col1, _tkr_col2 = st.columns(2)
            _best  = _tkr_grp.head(8)
            _worst = _tkr_grp.tail(8).sort_values("win_rate")

            with _tkr_col1:
                st.markdown("**🏆 Best Tickers (≥2 trades)**")
                _bc = ["#4caf50" if r >= 55 else "#ffa726" for r in _best["win_rate"]]
                fig_bt = _go.Figure(_go.Bar(
                    x=_best["ticker"], y=_best["win_rate"],
                    marker_color=_bc,
                    text=[f"{r}%<br>({t}T)" for r, t in
                          zip(_best["win_rate"], _best["trades"])],
                    textposition="outside",
                    textfont=dict(size=9, color="#e0e0e0"),
                ))
                fig_bt.update_layout(
                    paper_bgcolor="#1a1a2e", plot_bgcolor="#16213e",
                    font=dict(color="#e0e0e0"), height=240,
                    yaxis=dict(gridcolor="#2a2a4a", range=[0, 120], title="Win %"),
                    xaxis=dict(gridcolor="#2a2a4a"),
                    margin=dict(l=10, r=10, t=10, b=30),
                    showlegend=False,
                )
                st.plotly_chart(fig_bt, use_container_width=True)

            with _tkr_col2:
                st.markdown("**📉 Worst Tickers (≥2 trades)**")
                _wc = ["#ef5350" if r < 40 else "#ffa726" for r in _worst["win_rate"]]
                fig_wt = _go.Figure(_go.Bar(
                    x=_worst["ticker"], y=_worst["win_rate"],
                    marker_color=_wc,
                    text=[f"{r}%<br>({t}T)" for r, t in
                          zip(_worst["win_rate"], _worst["trades"])],
                    textposition="outside",
                    textfont=dict(size=9, color="#e0e0e0"),
                ))
                fig_wt.update_layout(
                    paper_bgcolor="#1a1a2e", plot_bgcolor="#16213e",
                    font=dict(color="#e0e0e0"), height=240,
                    yaxis=dict(gridcolor="#2a2a4a", range=[0, 120], title="Win %"),
                    xaxis=dict(gridcolor="#2a2a4a"),
                    margin=dict(l=10, r=10, t=10, b=30),
                    showlegend=False,
                )
                st.plotly_chart(fig_wt, use_container_width=True)

            # Full ticker table
            with st.expander("📋 All Tickers — Full Breakdown", expanded=False):
                _tkr_disp = _tkr_grp.sort_values("win_rate", ascending=False).copy()
                _tkr_disp.columns = [c.replace("_", " ").title() for c in _tkr_disp.columns]
                if "Total Pnl" in _tkr_disp.columns:
                    _tkr_disp["Total Pnl"] = _tkr_disp["Total Pnl"].apply(
                        lambda v: f"${v:+.2f}" if v != 0 else "—"
                    )
                    _tkr_disp = _tkr_disp.rename(columns={"Total Pnl": "Total P&L"})
                st.dataframe(_tkr_disp, use_container_width=True, hide_index=True)
        else:
            st.info("Need at least 2 trades per ticker to compute ticker stats.")

    # ══════════════════════════════════════════════════════════════════════════
    # SECTION — Webull Pattern Correlation
    # ══════════════════════════════════════════════════════════════════════════
    st.markdown("---")
    st.markdown("### 🔬 Pattern Correlation — Your Trade History")
    st.caption(
        "Scans every trade session in your journal retroactively. "
        "Fetches the day's bar data and detects which chart patterns were present "
        "on your A/B wins vs your C/F losses. Identifies which setups actually work for you."
    )

    _pat_scan_api = st.session_state.get("_sb_api_key", "")
    _pat_scan_sec = st.session_state.get("_sb_secret_key", "")
    _pat_scan_uid = st.session_state.get("auth_user_id", "")
    _pat_result   = st.session_state.get("_pat_scan_result")

    _pat_col1, _pat_col2 = st.columns([3, 1])
    _pat_scan_feed = _pat_col2.selectbox(
        "Feed", ["iex", "sip"], key="pat_scan_feed",
        help="iex = free tier. sip = paid Alpaca subscription."
    )

    if _pat_col1.button("🔬 Scan Trade History for Patterns",
                        use_container_width=True, key="pat_scan_btn"):
        if not _pat_scan_api or not _pat_scan_sec:
            st.error("Add your Alpaca credentials in the sidebar first.")
        else:
            _pat_jdf = load_journal(user_id=_pat_scan_uid)
            if _pat_jdf.empty:
                st.warning("No journal entries found. Import your Webull CSV in the Journal tab first.")
            else:
                _n_uniq = _pat_jdf[["ticker", "timestamp"]].drop_duplicates().shape[0] if "timestamp" in _pat_jdf.columns else len(_pat_jdf)
                with st.spinner(f"Scanning {_n_uniq} trade sessions for patterns — may take 30–60 seconds…"):
                    _pat_result = scan_journal_patterns(
                        _pat_scan_api, _pat_scan_sec, _pat_jdf, feed=_pat_scan_feed
                    )
                st.session_state["_pat_scan_result"] = _pat_result

    if _pat_result and _pat_result.get("scanned", 0) > 0:
        import plotly.graph_objects as _go_pat

        _ps  = _pat_result["summary"]
        _sc  = _pat_result["scanned"]
        _tw  = _pat_result["total_wins"]
        _tl  = _pat_result["total_losses"]
        _err = _pat_result["errors"]

        _pk1, _pk2, _pk3, _pk4 = st.columns(4)
        _pk1.metric("Sessions Scanned", _sc)
        _pk2.metric("A/B Wins", _tw)
        _pk3.metric("C/F Losses", _tl)
        _pk4.metric("No Bar Data", _err, help="Too old or delisted on Alpaca")

        if not _ps:
            st.info("No patterns detected. Try switching to SIP feed or check that trades are recent enough for Alpaca history.")
        else:
            _sorted_pats = sorted(_ps.items(), key=lambda x: x[1]["total"], reverse=True)

            _pat_names  = [p[0] for p in _sorted_pats]
            _pat_wrates = [p[1]["win_rate"] for p in _sorted_pats]
            _pat_totals = [p[1]["total"] for p in _sorted_pats]
            _bar_clrs   = [
                "#4caf50" if wr >= 60 else "#ffa726" if wr >= 45 else "#ef5350"
                for wr in _pat_wrates
            ]
            _fig_pat = _go_pat.Figure(_go_pat.Bar(
                x=_pat_names,
                y=_pat_wrates,
                marker_color=_bar_clrs,
                text=[f"{wr:.0f}%<br>({t} trades)" for wr, t in zip(_pat_wrates, _pat_totals)],
                textposition="outside",
            ))
            _fig_pat.update_layout(
                paper_bgcolor="#1a1a2e", plot_bgcolor="#16213e",
                font=dict(color="#e0e0e0"), height=320,
                title=dict(text="Win Rate When Pattern Present", font=dict(size=14), x=0.0),
                yaxis=dict(range=[0, 115], gridcolor="#2a2a4a", title="Win Rate %", ticksuffix="%"),
                xaxis=dict(gridcolor="#2a2a4a", tickangle=-20),
                margin=dict(t=40, b=80, l=50, r=20),
            )
            _fig_pat.add_hline(y=50, line_dash="dot", line_color="#555",
                               annotation_text="50% baseline", annotation_position="right")
            st.plotly_chart(_fig_pat, use_container_width=True)

            st.markdown("**Pattern breakdown:**")
            _tbl_rows = []
            for pat, data in _sorted_pats:
                _wr = data["win_rate"]
                _signal = "✅ Has Edge" if _wr >= 60 else "⚠️ Neutral" if _wr >= 45 else "🚫 No Edge"
                _tbl_rows.append({
                    "Pattern":         pat,
                    "Total Trades":    data["total"],
                    "On Wins (A/B)":   data["win"],
                    "On Losses (C/F)": data["loss"],
                    "Win Rate":        f"{_wr:.0f}%",
                    "Signal":          _signal,
                })
            st.dataframe(
                _tbl_rows,
                use_container_width=True,
                height=min(420, 40 + 36 * len(_tbl_rows)),
            )

            _win_pats  = _pat_result["by_outcome"]["win"]
            _loss_pats = _pat_result["by_outcome"]["loss"]
            _wp_sorted = sorted(_win_pats.items(), key=lambda x: x[1], reverse=True)[:5]
            _lp_sorted = sorted(_loss_pats.items(), key=lambda x: x[1], reverse=True)[:5]

            _pc1, _pc2 = st.columns(2)
            with _pc1:
                st.markdown("**Most common on your A/B wins:**")
                for _pn, _cnt in _wp_sorted:
                    _wr_v = _ps.get(_pn, {}).get("win_rate", 0)
                    st.markdown(
                        f'<div style="background:#0d2e1a;border:1px solid #2e5c3a;border-radius:6px;'
                        f'padding:6px 12px;margin:4px 0;display:flex;justify-content:space-between;'
                        f'align-items:center;">'
                        f'<span style="color:#4caf50;font-weight:600;">{_pn}</span>'
                        f'<span style="color:#888;font-size:11px;">{_cnt}x present &nbsp;·&nbsp; {_wr_v:.0f}% win rate</span>'
                        f'</div>',
                        unsafe_allow_html=True,
                    )
            with _pc2:
                st.markdown("**Most common on your C/F losses:**")
                for _pn, _cnt in _lp_sorted:
                    _wr_v = _ps.get(_pn, {}).get("win_rate", 0)
                    st.markdown(
                        f'<div style="background:#2e0d0d;border:1px solid #5c2e2e;border-radius:6px;'
                        f'padding:6px 12px;margin:4px 0;display:flex;justify-content:space-between;'
                        f'align-items:center;">'
                        f'<span style="color:#ef5350;font-weight:600;">{_pn}</span>'
                        f'<span style="color:#888;font-size:11px;">{_cnt}x present &nbsp;·&nbsp; {_wr_v:.0f}% win rate</span>'
                        f'</div>',
                        unsafe_allow_html=True,
                    )

            st.caption(
                f"Scan complete — {_sc} sessions analyzed, {_err} skipped (no bar data). "
                "Results cached until you re-run."
            )

    elif _pat_result and _pat_result.get("scanned", 0) == 0:
        st.warning("Scan ran but found no sessions with bar data. "
                   "Make sure your journal has entries and try switching feeds.")

    # ── Brain Accuracy (formerly Tracker tab) ─────────────────────────────
    st.markdown("---")
    render_tracker_tab()


def render_tracker_tab():
    """Render the Accuracy Tracker tab — structure distribution + Predicted vs Actual history."""
    st.markdown("## 🧠 MarketBrain — Accuracy Tracker")
    st.caption("All-time structure distribution and brain prediction accuracy.")

    # ══════════════════════════════════════════════════════════════════════════
    # SECTION 0 — Batch Backtest Runner
    # ══════════════════════════════════════════════════════════════════════════
    with st.expander("🔬 Batch Backtest — Feed Historical Tickers", expanded=False):
        st.caption(
            "Fetches each ticker/date pair via Alpaca, classifies structure, records Brain "
            "prediction vs actual. Uses credentials entered in the sidebar. "
            "Skips any pair already in the tracker. Add more lines in M/D: T1, T2 format."
        )
        _bt_pairs_text = st.text_area(
            "Ticker / Date pairs", value=_BATCH_DEFAULT, height=220, key="bt_pairs_input"
        )
        _bt_feed = st.selectbox(
            "Data feed", ["iex", "sip"], index=0, key="bt_feed_select",
            help="IEX = free tier (recommended for backtests). SIP = full tape."
        )
        _bt_run = st.button("▶ Run Batch Backtest", type="primary",
                            use_container_width=True, key="bt_run_btn")

        if _bt_run:
            # api_key and secret_key come from the outer sidebar scope
            if not api_key or not secret_key:
                st.error("Enter your Alpaca API Key and Secret Key in the sidebar first.")
            else:
                _pairs = _parse_batch_pairs(_bt_pairs_text)
                if not _pairs:
                    st.warning("No valid ticker/date pairs found. Use format: 3/30: ANNA, SST, BFRG")
                else:
                    st.info(f"Processing {len(_pairs)} pairs… this may take 1–2 minutes.")
                    _prog   = st.progress(0.0, text="Starting…")
                    _bt_results = []
                    for _i, (_tk, _dt) in enumerate(_pairs):
                        _prog.progress((_i + 1) / len(_pairs),
                                       text=f"Fetching {_tk} {_dt} ({_i+1}/{len(_pairs)})…")
                        _r = run_single_backtest(api_key, secret_key, _tk, _dt,
                                                 feed=_bt_feed, num_bins=100)
                        _bt_results.append(_r)
                    _prog.empty()
                    # Persist results so they survive the page rerun
                    st.session_state["bt_last_results"] = _bt_results

        # ── Always render results if available ────────────────────────────────
        if st.session_state.get("bt_last_results"):
            _rdf = pd.DataFrame(st.session_state["bt_last_results"])
            _ok      = (_rdf["status"] == "OK").sum()
            _dup     = (_rdf["status"] == "Already logged").sum()
            _no_data = _rdf["status"].str.startswith("No data").sum()
            _no_ib   = _rdf["status"].str.startswith("IB").sum()
            _errs    = len(_rdf) - _ok - _dup - _no_data - _no_ib
            _correct = (_rdf["correct"] == "✅").sum()
            _wrong   = (_rdf["correct"] == "❌").sum()
            _logged  = _ok + _dup

            _acc_str = (f"  •  Batch accuracy: **{_correct}/{_correct+_wrong}** "
                        f"({_correct/((_correct+_wrong) or 1)*100:.0f}%)"
                        if (_correct + _wrong) > 0 else "")
            st.success(
                f"✅ **{_ok}** new logged  •  "
                f"🔁 **{_dup}** already existed  •  "
                f"📭 **{_no_data}** no data  •  "
                f"⏱ **{_no_ib}** IB incomplete  •  "
                f"⚠️ **{_errs}** errors"
                + _acc_str
            )
            st.caption(
                "💡 'No data' means Alpaca IEX doesn't carry historical minute bars for that "
                "ticker on that date. Very small OTC stocks often only appear on SIP. "
                "Try switching the feed to **sip** if you have an Alpaca paid subscription."
            )

            # Color rows by result
            def _bt_style(row):
                s = row.get("correct", "—")
                if s == "✅":  return ["background-color:#4caf5022"] * len(row)
                if s == "❌":  return ["background-color:#ef535022"] * len(row)
                return [""] * len(row)

            try:
                st.dataframe(
                    _rdf[["ticker","date","predicted","actual","correct","status"]]
                      .style.apply(_bt_style, axis=1),
                    use_container_width=True, hide_index=True
                )
            except Exception:
                st.dataframe(
                    _rdf[["ticker","date","predicted","actual","correct","status"]],
                    use_container_width=True, hide_index=True
                )
            if st.button("🗑 Clear batch results", key="bt_clear_btn"):
                st.session_state.pop("bt_last_results", None)
                st.rerun()

    st.markdown("---")

    # ══════════════════════════════════════════════════════════════════════════
    # SECTION 0b — High Conviction Watchlist (top prob ≥ 80%)
    # ══════════════════════════════════════════════════════════════════════════
    _STRUCT_COLORS_HC = {
        "Trend":        "#ff9800",
        "Dbl Dist":     "#00bcd4",
        "Non-Trend":    "#78909c",
        "Normal":       "#66bb6a",
        "Nrml Var":     "#aed581",
        "Neutral":      "#80cbc4",
        "Ntrl Extreme": "#7e57c2",
    }

    st.markdown("### 🎯 High Conviction Calls  <span style='font-size:13px;color:#888;font-weight:400'>≥ 75% structure probability</span>",
                unsafe_allow_html=True)
    _hc_df = load_high_conviction_log()

    if _hc_df.empty:
        st.info(
            "No high-conviction calls logged yet. "
            "Run a historical or live analysis on any ticker — any day where the "
            "top structure probability ≥ 75% is automatically captured here."
        )
    else:
        # ── Summary pills row ─────────────────────────────────────────────────
        _hc_total   = len(_hc_df)
        _hc_structs = _hc_df["structure"].value_counts()
        _pill_html  = ""
        for _s, _cnt in _hc_structs.items():
            _c = _STRUCT_COLORS_HC.get(_s, "#888888")
            _pill_html += (
                f'<span style="background:{_c}33;color:{_c};border:1px solid {_c}66;'
                f'border-radius:12px;padding:3px 10px;margin:3px;'
                f'font-size:13px;font-weight:600;display:inline-block;">'
                f'{_s} ({_cnt})</span>'
            )
        st.markdown(
            f'<div style="margin-bottom:8px;">'
            f'<b style="color:#ccc;">{_hc_total} total</b> &nbsp;·&nbsp; '
            + _pill_html + "</div>",
            unsafe_allow_html=True,
        )

        # ── Table ─────────────────────────────────────────────────────────────
        def _hc_row_style(row):
            _c = _STRUCT_COLORS_HC.get(row.get("structure", ""), "#888888")
            return [f"background-color:{_c}18;"] * len(row)

        _hc_display = _hc_df[["ticker","date","structure","prob_pct",
                               "ib_high","ib_low","poc_price"]].copy()
        _hc_display.columns = ["Ticker","Date","Structure","Probability %",
                                "IB High","IB Low","POC"]
        _hc_display["Probability %"] = _hc_display["Probability %"].apply(
            lambda x: f"{x:.1f}%"
        )

        try:
            st.dataframe(
                _hc_display.style.apply(_hc_row_style, axis=1),
                use_container_width=True, hide_index=True
            )
        except Exception:
            st.dataframe(_hc_display, use_container_width=True, hide_index=True)

        c1, c2 = st.columns([3, 1])
        with c2:
            if st.button("🗑 Clear list", key="hc_clear_btn"):
                try:
                    os.remove(HICONS_FILE)
                except Exception:
                    pass
                st.rerun()

    st.markdown("---")
    df = load_accuracy_tracker()

    # ══════════════════════════════════════════════════════════════════════════
    # SECTION 1 — All-Time Structure Distribution
    # ══════════════════════════════════════════════════════════════════════════
    st.markdown("### 📊 All-Time Structure Distribution")
    st.caption("Every structure classified since you started using the dashboard (from accuracy tracker log).")

    if df.empty or "actual" not in df.columns:
        st.info("No data yet — run analyses to start populating the distribution.")
    else:
        _dist = df["actual"].dropna()
        _dist = _dist[_dist.str.strip() != ""]

        if _dist.empty:
            st.info("No actual structure data logged yet.")
        else:
            # Count + percent
            _counts = _dist.value_counts().reset_index()
            _counts.columns = ["structure", "count"]
            _counts["pct"] = (_counts["count"] / _counts["count"].sum() * 100).round(1)
            _counts["label_clean"] = _counts["structure"].apply(_clean_structure_label)
            _counts["color"] = _counts["structure"].apply(_structure_color)
            _counts = _counts.sort_values("pct", ascending=True)   # horizontal bar → ascending

            # ── Pill badges row ────────────────────────────────────────────────
            pills_html = '<div style="display:flex; flex-wrap:wrap; gap:8px; margin:8px 0 14px 0;">'
            for _, row in _counts.sort_values("pct", ascending=False).iterrows():
                c = row["color"]
                pills_html += (
                    f'<span style="background:{c}22; border:1px solid {c}55; border-radius:20px; '
                    f'padding:4px 12px; font-size:12px; color:{c}; white-space:nowrap;">'
                    f'<b>{row["pct"]:.0f}%</b> {row["label_clean"]} '
                    f'<span style="color:#555; font-size:10px;">({int(row["count"])})</span></span>'
                )
            pills_html += "</div>"
            st.markdown(pills_html, unsafe_allow_html=True)

            # ── Horizontal bar chart ──────────────────────────────────────────
            fig_dist = go.Figure(go.Bar(
                x=_counts["pct"],
                y=_counts["label_clean"],
                orientation="h",
                marker_color=_counts["color"].tolist(),
                text=[f"  {p:.1f}%  ({n})" for p, n in zip(_counts["pct"], _counts["count"])],
                textposition="outside",
                cliponaxis=False,
            ))
            fig_dist.update_layout(
                paper_bgcolor="#1a1a2e", plot_bgcolor="#16213e",
                font=dict(color="#e0e0e0"),
                height=max(240, len(_counts) * 44 + 60),
                xaxis=dict(range=[0, min(100, _counts["pct"].max() * 1.25)],
                           gridcolor="#2a2a4a", title="% of all sessions",
                           ticksuffix="%"),
                yaxis=dict(gridcolor="#2a2a4a", tickfont=dict(size=12)),
                margin=dict(l=10, r=80, t=20, b=40),
            )
            st.plotly_chart(fig_dist, use_container_width=True)

            # ── Trend vs Balance split ────────────────────────────────────────
            _directional_keys = ["trend", "bear", "double", "variation"]
            _balanced_keys    = ["normal", "neutral", "non", "balanced"]

            def _classify_side(s):
                sl = s.lower()
                if any(k in sl for k in _directional_keys):
                    return "Directional"
                if any(k in sl for k in _balanced_keys):
                    return "Balanced"
                return "Other"

            _sides = _dist.apply(_classify_side).value_counts()
            _total_sides = _sides.sum()
            dir_pct = _sides.get("Directional", 0) / _total_sides * 100
            bal_pct = _sides.get("Balanced", 0) / _total_sides * 100

            d1, d2, d3 = st.columns(3)
            d1.metric("📈 Directional Days", f"{dir_pct:.0f}%",
                      help="Trend Day, Trend Bear, Double Distribution, Normal Variation")
            d2.metric("⚖️ Balanced Days",    f"{bal_pct:.0f}%",
                      help="Normal, Neutral, Neutral Extreme, Non-Trend")
            d3.metric("📋 Total Sessions",   int(_total_sides))

    st.markdown("---")

    # ══════════════════════════════════════════════════════════════════════════
    # SECTION 2 — Brain Accuracy
    # ══════════════════════════════════════════════════════════════════════════
    st.markdown("### 🎯 Brain Prediction Accuracy")

    if df.empty:
        st.info("No accuracy data yet — run analyses after 10:30 ET to start logging brain predictions.")
        return

    total    = len(df)
    correct  = (df["correct"] == "✅").sum()
    acc_rate = correct / total * 100 if total > 0 else 0
    wrong    = total - correct

    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Total Predictions", total)
    c2.metric("Correct", f"{correct}  ({acc_rate:.0f}%)")
    c3.metric("Wrong",   wrong)
    c4.metric("Accuracy Rate", f"{acc_rate:.1f}%")

    # ── Accuracy by predicted structure ──────────────────────────────────────
    if "predicted" in df.columns and "correct" in df.columns:
        grouped = df.groupby("predicted").apply(
            lambda g: pd.Series({
                "total":   len(g),
                "correct": (g["correct"] == "✅").sum(),
                "acc":     (g["correct"] == "✅").sum() / len(g) * 100,
            })
        ).reset_index()
        grouped = grouped.sort_values("acc", ascending=False)

        st.markdown("**Accuracy by Predicted Structure**")
        bar_colors = [
            "#4caf50" if a >= 60 else "#ffa726" if a >= 40 else "#ef5350"
            for a in grouped["acc"]
        ]
        fig_acc = go.Figure(go.Bar(
            x=grouped["predicted"].apply(_clean_structure_label),
            y=grouped["acc"].round(1),
            marker_color=bar_colors,
            text=[f"{a:.0f}%<br>({int(c)}/{int(t)})"
                  for a, c, t in zip(grouped["acc"], grouped["correct"], grouped["total"])],
            textposition="outside",
        ))
        fig_acc.update_layout(
            paper_bgcolor="#1a1a2e", plot_bgcolor="#16213e",
            font=dict(color="#e0e0e0"), height=320,
            yaxis=dict(range=[0, 115], gridcolor="#2a2a4a", title="Accuracy %"),
            xaxis=dict(gridcolor="#2a2a4a"),
            margin=dict(t=20, b=60, l=50, r=20),
        )
        st.plotly_chart(fig_acc, use_container_width=True)

    st.markdown("---")

    # ══════════════════════════════════════════════════════════════════════════
    # SECTION 2.5 — Predictive Probability Engine
    # ══════════════════════════════════════════════════════════════════════════
    st.markdown("### 📊 Your Predictive Win Rates")
    st.caption(
        "Based on your logged signal outcomes. Every time you verify an EOD result, "
        "the conditions (Edge Score, RVOL, Structure) are paired with the outcome and "
        "stored here. After 3+ samples per setup, the system shows you your actual "
        "historical win rate for each condition cluster."
    )
    _pred_rates = compute_win_rates(_AUTH_USER_ID, min_samples=1)
    if not _pred_rates:
        st.info(
            "No outcome data yet. Verify predictions in the EOD review panel (Journal tab) "
            "to start building your personal win rate database. Each verification adds a data point."
        )
    else:
        _pred_total = _pred_rates.get("_total", {})
        _pred_by_struct = _pred_rates.get("_by_struct", {})
        _pred_by_edge   = _pred_rates.get("_by_edge", {})

        # Overall stat
        if _pred_total.get("n", 0) > 0:
            _pt_wr = _pred_total["win_rate"] * 100
            _pt_n  = _pred_total["n"]
            _pt_c  = "#4caf50" if _pt_wr >= 60 else "#ffa726" if _pt_wr >= 45 else "#ef5350"
            st.markdown(
                f'<div style="background:{_pt_c}11; border:1px solid {_pt_c}44; '
                f'border-radius:8px; padding:12px 18px; margin-bottom:12px;">'
                f'<span style="font-size:13px; color:#888;">Overall (all setups logged):</span> '
                f'<span style="font-size:22px; font-weight:900; color:{_pt_c};">{_pt_wr:.0f}%</span>'
                f'<span style="font-size:12px; color:#555;"> win rate — {_pt_n} outcomes recorded</span>'
                f'</div>',
                unsafe_allow_html=True,
            )

        # By structure
        if _pred_by_struct:
            st.markdown("**Win Rate by Structure**")
            _struct_rows = sorted(
                [(k, v) for k, v in _pred_by_struct.items() if v.get("n", 0) >= 1],
                key=lambda x: x[1]["win_rate"], reverse=True
            )
            for _sk, _sv in _struct_rows:
                _swr = _sv["win_rate"] * 100
                _sn  = _sv["n"]
                _sc  = "#4caf50" if _swr >= 60 else "#ffa726" if _swr >= 45 else "#ef5350"
                _bar = int(_swr)
                st.markdown(
                    f'<div style="display:flex; align-items:center; gap:10px; '
                    f'margin:3px 0; font-size:12px;">'
                    f'<span style="min-width:160px; color:#ccc;">{_sk}</span>'
                    f'<div style="flex:1; background:#1a1a2e; border-radius:4px; height:12px; '
                    f'position:relative; overflow:hidden;">'
                    f'<div style="width:{_bar}%; background:{_sc}; height:100%; '
                    f'border-radius:4px;"></div></div>'
                    f'<span style="min-width:60px; color:{_sc}; font-weight:700;">'
                    f'{_swr:.0f}% ({_sn})</span>'
                    f'</div>',
                    unsafe_allow_html=True,
                )

        # By edge band
        if _pred_by_edge:
            st.markdown("**Win Rate by Edge Score Band**")
            _edge_order = ["75+", "65-75", "50-65", "<50"]
            _ec_cols = st.columns(len(_edge_order))
            for _ec_i, _eb in enumerate(_edge_order):
                _ev = _pred_by_edge.get(_eb, {})
                if _ev and _ev.get("n", 0) > 0:
                    _ewr = _ev["win_rate"] * 100
                    _en  = _ev["n"]
                    _ec  = "#4caf50" if _ewr >= 60 else "#ffa726" if _ewr >= 45 else "#ef5350"
                    _ec_cols[_ec_i].markdown(
                        f'<div style="background:#12122288; border:1px solid {_ec}44; '
                        f'border-radius:6px; padding:10px; text-align:center;">'
                        f'<div style="font-size:10px; color:#666; text-transform:uppercase; '
                        f'letter-spacing:1px; margin-bottom:4px;">Edge {_eb}</div>'
                        f'<div style="font-size:22px; font-weight:900; color:{_ec};">'
                        f'{_ewr:.0f}%</div>'
                        f'<div style="font-size:11px; color:#555;">{_en} trades</div>'
                        f'</div>',
                        unsafe_allow_html=True,
                    )
                else:
                    _ec_cols[_ec_i].markdown(
                        f'<div style="background:#12122244; border:1px solid #1a1a2e; '
                        f'border-radius:6px; padding:10px; text-align:center; opacity:0.4;">'
                        f'<div style="font-size:10px; color:#555; text-transform:uppercase; '
                        f'letter-spacing:1px;">Edge {_eb}</div>'
                        f'<div style="font-size:16px; color:#333;">—</div>'
                        f'</div>',
                        unsafe_allow_html=True,
                    )

    st.markdown("---")

    # ══════════════════════════════════════════════════════════════════════════
    # SECTION 3 — Adaptive Learning Status
    # ══════════════════════════════════════════════════════════════════════════
    st.markdown("### 🔬 Adaptive Learning Status")
    st.caption(
        f"Brain recalibrates its probability weights every {_RECALIBRATE_EVERY} comparisons. "
        f"Structures with ≥5 samples are eligible. Multiplier > 1.0 = trusted; < 1.0 = confidence reduced."
    )

    _ws_rows = brain_weights_summary(_AUTH_USER_ID)
    _raw_w   = load_brain_weights(_AUTH_USER_ID)

    if not _ws_rows:
        st.info(f"Learning begins once at least 5 comparisons are logged for any structure. "
                f"Full recalibration fires every {_RECALIBRATE_EVERY} entries.")
    else:
        # ── Weight bar chart ──────────────────────────────────────────────────
        _wdf = pd.DataFrame(_ws_rows)
        _bar_colors = [
            "#4caf50" if m >= 1.3 else "#26a69a" if m >= 1.0 else
            "#ffa726" if m >= 0.7 else "#ef5350"
            for m in _wdf["Multiplier"]
        ]
        fig_w = go.Figure(go.Bar(
            x=_wdf["Multiplier"],
            y=_wdf["Structure"].apply(_clean_structure_label),
            orientation="h",
            marker_color=_bar_colors,
            text=[f"  {m:.2f}×  ({a:.0f}% acc / {n} samples)"
                  for m, a, n in zip(_wdf["Multiplier"], _wdf["Accuracy"], _wdf["Samples"])],
            textposition="outside",
            cliponaxis=False,
        ))
        fig_w.add_vline(x=1.0, line_dash="dash", line_color="#5c6bc0",
                        annotation_text="Baseline", annotation_position="top")
        fig_w.update_layout(
            paper_bgcolor="#1a1a2e", plot_bgcolor="#16213e",
            font=dict(color="#e0e0e0"),
            height=max(220, len(_wdf) * 44 + 60),
            xaxis=dict(range=[0.0, 1.8], gridcolor="#2a2a4a",
                       title="Probability Multiplier"),
            yaxis=dict(gridcolor="#2a2a4a"),
            margin=dict(l=10, r=120, t=20, b=40),
        )
        st.plotly_chart(fig_w, use_container_width=True)

        # ── Summary table ──────────────────────────────────────────────────────
        _wdf_disp = _wdf[["Structure", "Samples", "Accuracy", "Multiplier", "Status"]].copy()
        _wdf_disp["Accuracy"] = _wdf_disp["Accuracy"].apply(lambda x: f"{x:.1f}%")
        _wdf_disp["Multiplier"] = _wdf_disp["Multiplier"].apply(lambda x: f"{x:.3f}×")
        st.dataframe(_wdf_disp, use_container_width=True, hide_index=True)

        # ── Next recalibration countdown ──────────────────────────────────────
        _current_n = len(df) if not df.empty else 0
        _next_recal = _RECALIBRATE_EVERY - (_current_n % _RECALIBRATE_EVERY)
        if _next_recal == _RECALIBRATE_EVERY:
            st.success(f"✅ Weights just recalibrated at {_current_n} entries.")
        else:
            _entry_word = "entry" if _next_recal == 1 else "entries"
            st.info(f"🔄 Next recalibration in **{_next_recal}** more {_entry_word} "
                    f"({_current_n} logged so far).")

        # ── Manual recalibrate button ─────────────────────────────────────────
        if st.button("⚡ Recalibrate Now", help="Force immediate weight update from all logged data"):
            _new_w = recalibrate_brain_weights(_AUTH_USER_ID)
            st.success("Weights updated! Brain probabilities will use the new calibration on next analysis.")
            st.rerun()

    st.markdown("---")

    # ══════════════════════════════════════════════════════════════════════════
    # SECTION 4 — Full history table
    # ══════════════════════════════════════════════════════════════════════════
    st.markdown("### 📋 Full History")
    display_cols = ["timestamp", "symbol", "predicted", "actual", "correct",
                    "entry_price", "exit_price", "mfe"]
    disp = df[[c for c in display_cols if c in df.columns]].copy()
    if "timestamp" in disp.columns:
        disp = disp.sort_values("timestamp", ascending=False)

    def _style_row(row):
        color = "#4caf5022" if row.get("correct") == "✅" else "#ef535022"
        return [f"background-color: {color}"] * len(row)

    try:
        styled = disp.style.apply(_style_row, axis=1)
        st.dataframe(styled, use_container_width=True, height=320)
    except Exception:
        st.dataframe(disp, use_container_width=True, height=320)

    csv_str = df.to_csv(index=False)
    st.download_button(
        "⬇ Download Tracker CSV", data=csv_str,
        file_name="accuracy_tracker.csv", mime="text/csv"
    )


# ══════════════════════════════════════════════════════════════════════════════
# SMALL ACCOUNT CHALLENGE TAB
# ══════════════════════════════════════════════════════════════════════════════

def render_sa_tab():
    """Small Account Challenge — Ross Cameron / Warrior Trading methodology.
    Five Pillars | Sniper Entry | Position Sizer | PDT Tracker | Recovery Ratio
    """
    now_et   = datetime.now(EASTERN)
    hour_et  = now_et.hour + now_et.minute / 60.0
    snap     = st.session_state.get("last_analysis_state") or {}
    bars     = st.session_state.get("last_bars")
    ticker   = snap.get("ticker", "")
    price    = snap.get("price", 0.0)
    rvol     = snap.get("rvol")
    ib_high  = snap.get("ib_high")
    ib_low   = snap.get("ib_low")
    poc_p    = snap.get("poc_price")
    val_p    = snap.get("val_price")
    vah_p    = snap.get("vah_price")
    pct_chg  = snap.get("pct_change", 0.0)

    # ── SECTION 1 — TRADING WINDOW + PDT TRACKER ─────────────────────────────
    window_open = 7.0 <= hour_et < 10.0
    mins_left   = max(0, int((10.0 - hour_et) * 60)) if window_open else 0
    if window_open:
        wc, wlbl = "#4caf50", f"✅  SNIPER WINDOW ACTIVE — {mins_left} min remaining"
        wbg = "#1b5e2022"
    elif hour_et < 7.0:
        wc, wlbl = "#ffa726", f"⏳  Pre-market — Window opens at 7:00 AM ET"
        wbg = "#e6510022"
    else:
        wc, wlbl = "#ef5350", "❌  WINDOW CLOSED — Trades after 10 AM carry lower win rate"
        wbg = "#4e111122"

    wcol1, wcol2 = st.columns([3, 1])
    with wcol1:
        st.markdown(
            f'<div style="background:{wbg};border:1px solid {wc};border-radius:8px;'
            f'padding:10px 20px;margin-bottom:8px;">'
            f'<span style="font-size:14px;font-weight:700;color:{wc};">{wlbl}</span>'
            f'<span style="font-size:12px;color:#666;margin-left:18px;">'
            f'{now_et.strftime("%H:%M:%S ET")}</span></div>',
            unsafe_allow_html=True,
        )
    with wcol2:
        pdt_used = st.number_input(
            "Day trades used (this week)", min_value=0, max_value=10,
            value=int(st.session_state.get("sa_pdt_used", 0)),
            step=1, key="sa_pdt_inp",
            help="PDT rule: ≤3 round-trip day trades in 5 days for accounts under $25k"
        )
        st.session_state.sa_pdt_used = pdt_used
        pdt_rem   = max(0, 3 - pdt_used)
        pdt_color = "#ef5350" if pdt_rem == 0 else "#ffa726" if pdt_rem == 1 else "#4caf50"
        st.markdown(
            f'<div style="font-size:18px;font-weight:800;color:{pdt_color};">'
            f'{pdt_rem}/3 trades left</div>'
            + ('<div style="font-size:11px;color:#ef5350;">⛔ PDT LIMIT — no more day trades</div>'
               if pdt_rem == 0 else ''),
            unsafe_allow_html=True,
        )

    # ── SECTION 2 — FIVE PILLARS EVALUATION ──────────────────────────────────
    st.markdown("---")
    st.markdown("### 🏛️ Five Pillars Evaluation")
    if not ticker:
        st.info("Run a Historical Analysis on the Main Chart tab first — "
                "the Five Pillars will auto-populate for the loaded ticker.")
    else:
        c_float, c_news = st.columns(2)
        with c_float:
            float_est = st.number_input(
                "Float estimate (M shares) — check Finviz / Benzinga",
                min_value=0.0, max_value=1000.0,
                value=float(st.session_state.get("sa_float_est", 0.0)),
                step=0.5, format="%.1f", key="sa_float_inp",
            )
            st.session_state.sa_float_est = float_est
        with c_news:
            news_ok = st.checkbox(
                "✅  Catalyst confirmed (FDA, 13D filing, PR, earnings beat, etc.)",
                value=st.session_state.get("sa_news_confirmed", False),
                key="sa_news_chk",
            )
            st.session_state.sa_news_confirmed = news_ok

        # Evaluate pillars
        p_price = 0.25 <= price <= 9.00
        p_chg   = pct_chg >= 50.0
        p_rvol  = (rvol is not None and rvol >= 100.0)
        p_news  = news_ok
        p_f5    = float_est > 0 and float_est <= 5.0
        p_f20   = float_est > 0 and float_est <= 20.0
        p_float = p_f5 or p_f20

        float_note = (
            f"<span style='color:#4caf50;'>Sub-5M ✅ Explosive potential</span> — {float_est:.1f}M" if p_f5 else
            f"<span style='color:#ffa726;'>Sub-20M ⚠️ Acceptable max</span> — {float_est:.1f}M" if p_f20 else
            f"<span style='color:#ef5350;'>&gt;20M ❌ Too big — Algos dominant</span> — {float_est:.1f}M" if float_est > 0 else
            "<span style='color:#555;'>Enter float estimate above</span>"
        )

        def _pill_row(icon, passed, name, note, warn=False):
            c = "#4caf50" if passed else ("#ffa726" if warn else "#ef5350")
            return (
                f'<tr style="border-top:1px solid #1c2040;">'
                f'<td style="padding:6px 10px;font-size:16px;">{icon}</td>'
                f'<td style="padding:6px 10px;font-weight:700;color:{c};white-space:nowrap;">{name}</td>'
                f'<td style="padding:6px 10px;font-size:12px;color:#aaa;">{note}</td>'
                f'</tr>'
            )

        score = sum([p_price, p_chg, p_rvol, p_news, p_float])
        sc    = "#4caf50" if score == 5 else "#ffa726" if score >= 3 else "#ef5350"
        slbl  = ("⭐ A+ — ALL PILLARS MET" if score == 5
                 else "B — Borderline" if score >= 3 else "❌ AVOID — Sub-threshold")

        tbl = (
            '<table style="width:100%;border-collapse:collapse;">'
            + _pill_row("✅" if p_price else "❌", p_price, "Price",
                        f"${price:.2f}  &nbsp;·&nbsp; Target: $0.25 – $9.00")
            + _pill_row("✅" if p_chg else "❌", p_chg, "% Change",
                        f"{pct_chg:+.1f}%  &nbsp;·&nbsp; Need ≥ 50%")
            + _pill_row("✅" if p_rvol else "❌", p_rvol, "RVOL",
                        f"{f'{rvol:.0f}×' if rvol else '—'}  &nbsp;·&nbsp; Need ≥ 100× (institutional prints)")
            + _pill_row("✅" if p_news else "⚠️", p_news, "News Catalyst",
                        "FDA / 13D / PR / earnings beat required — momentum without news fades faster",
                        warn=True)
            + _pill_row("✅" if p_float else ("⚠️" if p_f20 else "❌"), p_float, "Float",
                        float_note, warn=(p_f20 and not p_f5))
            + '</table>'
        )
        st.markdown(
            f'<div style="background:#0c1030;border:1px solid #2a2a4a;border-radius:10px;'
            f'padding:14px 18px;margin:8px 0;">'
            f'<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px;">'
            f'<span style="font-size:17px;font-weight:900;color:#e0e0e0;letter-spacing:1px;">{ticker}</span>'
            f'<span style="background:{sc}22;border:1px solid {sc};border-radius:5px;'
            f'padding:4px 14px;font-size:13px;font-weight:800;color:{sc};">{slbl}</span>'
            f'</div>{tbl}</div>',
            unsafe_allow_html=True,
        )

        # Pre-market float turnover (bonus)
        if float_est > 0:
            pm_row = next(
                (r for r in st.session_state.scanner_results if r.get("ticker") == ticker), None)
            if pm_row and pm_row.get("pm_vol"):
                float_sh = float_est * 1_000_000
                pmv      = pm_row["pm_vol"]
                tover    = pmv / float_sh * 100.0 if float_sh > 0 else 0.0
                tc  = "#ef5350" if tover > 80 else "#ffa726" if tover > 40 else "#4caf50"
                tlb = ("EXTREME — Float nearly traded through" if tover > 80
                       else "HIGH — Supply/demand heavily imbalanced" if tover > 40
                       else "Normal pre-market activity")
                st.markdown(
                    f'<div style="background:#0c1030;border:1px solid #2a2a4a;border-radius:6px;'
                    f'padding:8px 16px;margin:4px 0;font-size:12px;color:#aaa;">'
                    f'📊 PM Float Turnover: <b style="color:{tc};">{tover:.1f}%</b>'
                    f' <span style="color:{tc};">({tlb})</span>'
                    f' — {pmv:,} shares vs ~{float_sh:,.0f} float</div>',
                    unsafe_allow_html=True,
                )

    # ── SECTION 3 — SETUP QUALITY (if bars loaded) ────────────────────────────
    if bars is not None and len(bars) >= 5:
        st.markdown("---")
        st.markdown("### 📡 Setup Quality Analysis")

        atr    = compute_atr(bars)
        greens = count_consecutive_greens(bars)
        mline, sline, hist = compute_macd(bars["close"])
        macd_now  = float(mline.iloc[-1])
        sig_now   = float(sline.iloc[-1])
        hist_now  = float(hist.iloc[-1])
        hist_prev = float(hist.iloc[-2]) if len(hist) >= 2 else hist_now

        # Front Side: MACD above signal AND histogram not yet shrinking
        macd_above  = macd_now > sig_now
        hist_open   = hist_now > 0 and hist_now >= hist_prev * 0.80
        front_side  = macd_above and hist_open

        # VA Breakout
        va_breakout = (vah_p is not None and price is not None
                       and price > vah_p and rvol is not None and rvol >= 100.0)

        # POC shift
        bin_c = st.session_state.get("sa_bin_centers")
        vap_c = st.session_state.get("sa_vap")
        poc_shift_lbl, poc_shift_col = (
            detect_poc_shift(bin_c, vap_c)
            if bin_c is not None and vap_c is not None and len(bin_c) > 0
            else ("—", "#aaa")
        )

        # Whole/Half dollar levels
        try:
            whl = get_whole_half_levels(float(bars["low"].min()), float(bars["high"].max()))
        except Exception:
            whl = []

        # Opening Range (first 5 bars)
        or_hi = float(bars["high"].iloc[:5].max()) if len(bars) >= 5 else None
        or_lo = float(bars["low"].iloc[:5].min())  if len(bars) >= 5 else None

        qa1, qa2, qa3 = st.columns(3)

        with qa1:
            fsc = "#4caf50" if front_side else "#ef5350"
            fsl = "✅ FRONT SIDE" if front_side else "⛔ BACK SIDE"
            fsb = "MACD open & diverging" if front_side else "MACD converging — fade risk"
            st.markdown(
                f'<div style="background:#0c1030;border:1px solid {fsc}55;border-radius:8px;'
                f'padding:14px;text-align:center;">'
                f'<div style="font-size:10px;color:#555;text-transform:uppercase;letter-spacing:1px;margin-bottom:4px;">Trade Side</div>'
                f'<div style="font-size:19px;font-weight:800;color:{fsc};">{fsl}</div>'
                f'<div style="font-size:11px;color:#777;margin-top:3px;">{fsb}</div>'
                f'<div style="font-size:10px;color:#444;margin-top:4px;font-family:monospace;">'
                f'MACD {macd_now:+.4f} · Sig {sig_now:+.4f}</div>'
                f'</div>',
                unsafe_allow_html=True,
            )

        with qa2:
            gc  = "#4caf50" if greens >= 3 else "#ffa726" if greens >= 1 else "#ef5350"
            glb = "🔥 SURGE" if greens >= 3 else "Building" if greens >= 1 else "No Surge"
            st.markdown(
                f'<div style="background:#0c1030;border:1px solid {gc}55;border-radius:8px;'
                f'padding:14px;text-align:center;">'
                f'<div style="font-size:10px;color:#555;text-transform:uppercase;letter-spacing:1px;margin-bottom:4px;">Consecutive Greens</div>'
                f'<div style="font-size:34px;font-weight:900;color:{gc};line-height:1;">{greens}</div>'
                f'<div style="font-size:12px;color:{gc};margin-top:3px;">{glb}</div>'
                f'<div style="font-size:10px;color:#444;margin-top:4px;">Need 3+ for surge confirmation</div>'
                f'</div>',
                unsafe_allow_html=True,
            )

        with qa3:
            vac = "#4caf50" if va_breakout else "#555"
            vat = "✅ BREAKING VA on RVOL ≥ 100" if va_breakout else "Inside Value Area"
            st.markdown(
                f'<div style="background:#0c1030;border:1px solid #2a2a4a;border-radius:8px;'
                f'padding:14px;text-align:center;">'
                f'<div style="font-size:10px;color:#555;text-transform:uppercase;letter-spacing:1px;margin-bottom:4px;">VA / POC</div>'
                f'<div style="font-size:13px;font-weight:700;color:{poc_shift_col};margin:4px 0;">{poc_shift_lbl}</div>'
                f'<div style="font-size:11px;color:{vac};">{vat}</div>'
                + (f'<div style="font-size:10px;color:#555;margin-top:3px;">VAH ${vah_p:.2f} · VAL ${val_p:.2f}</div>'
                   if vah_p and val_p else '')
                + f'</div>',
                unsafe_allow_html=True,
            )

        # Opening Range + ATR
        if or_hi and or_lo:
            st.markdown(
                f'<div style="background:#0c1030;border:1px solid #2a2a4a;border-radius:6px;'
                f'padding:8px 16px;margin:8px 0;font-size:12px;color:#aaa;">'
                f'📐 Opening Range (first 5 bars): '
                f'<b style="color:#00e676;">Hi ${or_hi:.2f}</b> / '
                f'<b style="color:#ef5350;">Lo ${or_lo:.2f}</b> — '
                f'OR Range: <b style="color:#e0e0e0;">${or_hi - or_lo:.2f}</b>'
                f'&nbsp;&nbsp;|&nbsp;&nbsp;ATR(14): <b style="color:#5c6bc0;">${atr:.2f}</b>'
                f'</div>',
                unsafe_allow_html=True,
            )

        # Whole / Half dollar resistance levels
        if whl:
            whole_s = "  ".join(
                f"<b style='color:#ffa726;'>${l:.2f}</b>" if l == int(l)
                else f"<span style='color:#7986cb;'>${l:.2f}</span>"
                for l in whl
            )
            st.markdown(
                f'<div style="background:#0c1030;border:1px solid #2a2a4a;border-radius:6px;'
                f'padding:8px 16px;margin:4px 0;font-size:12px;color:#aaa;">'
                f'🎯 Whole/Half-Dollar Levels: {whole_s}'
                f'&nbsp;&nbsp;<span style="color:#444;font-size:10px;">'
                f'(orange = whole $, blue = half $  — expect resistance, then support once broken)</span>'
                f'</div>',
                unsafe_allow_html=True,
            )

    # ── SECTION 4 — SNIPER ENTRY CHECKLIST ───────────────────────────────────
    st.markdown("---")
    st.markdown("### 🎯 Sniper Entry Checklist — First Candle New High")
    st.caption("All 7 boxes must be ✅ before pulling the trigger. One unchecked = wait.")

    ch1, ch2 = st.columns(2)
    with ch1:
        chk1 = st.checkbox("📈 Surge: 3–5 consecutive green candles on volume spike", key="sa_c1")
        chk2 = st.checkbox("🔽 Pullback: 1–2 red candles on notably lighter volume",   key="sa_c2")
        chk3 = st.checkbox("🔺 Apex: Price approaching high of the pullback candle",   key="sa_c3")
        chk4 = st.checkbox("✅ Trigger: Candle BROKE the apex (confirmed — not anticipated)", key="sa_c4")
    with ch2:
        chk5 = st.checkbox("📊 MACD: Lines still open / histogram not shrinking",       key="sa_c5")
        chk6 = st.checkbox("📋 Level 2: Surge of green orders visible on tape",         key="sa_c6")
        chk7 = st.checkbox("🛡️ PDT: Day trade slot available (not at 3-trade limit)",   key="sa_c7",
                            value=(st.session_state.get("sa_pdt_used", 0) < 3))
        entry_type = st.selectbox(
            "Entry Type",
            ["First Pullback", "ABCD Pattern", "High of Day Break", "Other"],
            key="sa_entry_sel",
        )

    checks_passed = sum([chk1, chk2, chk3, chk4, chk5, chk6, chk7])
    if checks_passed == 7:
        st.markdown(
            '<div style="background:#4caf5022;border:2px solid #4caf50;border-radius:8px;'
            'padding:12px 20px;font-weight:700;color:#4caf50;font-size:15px;margin:8px 0;">'
            '🟢 ALL 7 CHECKS PASSED — VALID SNIPER ENTRY</div>',
            unsafe_allow_html=True,
        )
    elif checks_passed >= 5:
        st.markdown(
            f'<div style="background:#ffa72622;border:1px solid #ffa726;border-radius:8px;'
            f'padding:12px 20px;font-weight:700;color:#ffa726;font-size:14px;margin:8px 0;">'
            f'⚠️ {checks_passed}/7 — Partial. Tighten your criteria before entry.</div>',
            unsafe_allow_html=True,
        )
    else:
        st.markdown(
            f'<div style="background:#ef535022;border:1px solid #ef5350;border-radius:8px;'
            f'padding:12px 20px;font-weight:700;color:#ef5350;font-size:14px;margin:8px 0;">'
            f'🔴 {checks_passed}/7 — DO NOT ENTER. Be the sniper, not the machine gunner.</div>',
            unsafe_allow_html=True,
        )

    # ── SECTION 5 — POSITION SIZER ───────────────────────────────────────────
    st.markdown("---")
    st.markdown("### 💰 Sniper Position Sizer")

    ps1, ps2, ps3 = st.columns(3)
    with ps1:
        acct = st.number_input(
            "Account Balance ($)", min_value=100.0, max_value=1_000_000.0,
            value=float(st.session_state.get("sa_account_bal", 5000.0)),
            step=500.0, format="%.0f", key="sa_acct",
        )
        st.session_state.sa_account_bal = acct
        risk_p = st.number_input(
            "Max Risk per Trade (%)", min_value=0.5, max_value=10.0,
            value=float(st.session_state.get("sa_risk_pct", 2.0)),
            step=0.5, format="%.1f", key="sa_riskp",
        )
        st.session_state.sa_risk_pct = risk_p
    with ps2:
        atr_v = compute_atr(bars) if bars is not None and len(bars) >= 5 else 0.20
        stop_d = st.number_input(
            "Stop Distance ($)",
            min_value=0.01, max_value=20.0,
            value=round(max(0.05, atr_v), 2),
            step=0.01, format="%.2f",
            help="ATR(14) auto-filled. Adjust to your actual stop placement.",
            key="sa_stopd",
        )
        st.markdown(
            f'<div style="font-size:11px;color:#5c6bc0;margin-top:4px;">'
            f'ATR(14) auto-fill: ${atr_v:.2f}</div>',
            unsafe_allow_html=True,
        )
    with ps3:
        risk_dol   = acct * (risk_p / 100.0)
        max_shares = int(risk_dol / stop_d) if stop_d > 0 else 0
        max_pos    = max_shares * price if price > 0 else 0.0
        daily_lim  = acct * 0.25
        st.markdown(
            f'<div style="background:#0c1030;border:1px solid #5c6bc0;border-radius:10px;'
            f'padding:14px;text-align:center;">'
            f'<div style="font-size:10px;color:#5c6bc0;text-transform:uppercase;letter-spacing:1px;">Risk Budget</div>'
            f'<div style="font-size:22px;font-weight:800;color:#e0e0e0;">${risk_dol:.0f}</div>'
            f'<div style="font-size:11px;color:#555;margin:4px 0;">Max Shares</div>'
            f'<div style="font-size:30px;font-weight:900;color:#4caf50;line-height:1;">{max_shares:,}</div>'
            f'<div style="font-size:11px;color:#555;">Position size: ${max_pos:,.0f}</div>'
            f'<div style="font-size:11px;color:#ef5350;margin-top:6px;">Daily loss limit: ${daily_lim:,.0f}</div>'
            f'</div>',
            unsafe_allow_html=True,
        )

    st.markdown(
        f'<div style="background:#0c1030;border:1px solid #2a2a4a;border-radius:6px;'
        f'padding:8px 16px;margin:6px 0;font-size:12px;color:#aaa;">'
        f'💡 <b style="color:#e0e0e0;">Cash Account Rule:</b> Treat every trade as your ONLY trade of the day. '
        f'Settle T+1 before sizing up. Sniper — not machine gunner. '
        f'<b style="color:#ef5350;">Stop trading if daily loss hits ${daily_lim:,.0f}.</b>'
        f'</div>',
        unsafe_allow_html=True,
    )

    # ── SECTION 5b — GOD MODE LIVE EXECUTION ────────────────────────────────
    st.markdown("---")
    st.markdown(
        '<div style="background:linear-gradient(135deg,#1a0a2e,#0d1b2a);'
        'border:2px solid #7c4dff;border-radius:12px;padding:14px 18px;margin-bottom:8px;">'
        '<span style="font-size:18px;font-weight:900;color:#e040fb;letter-spacing:1px;">'
        '⚡ GOD MODE — Live Trade Execution</span>'
        '<span style="font-size:11px;color:#546e7a;margin-left:12px;">'
        'Routes directly to Alpaca broker</span></div>',
        unsafe_allow_html=True,
    )

    _gm_sa_ticker = st.session_state.get("sa_ticker_input", "").strip().upper() or ticker
    _gm_c1, _gm_c2, _gm_c3 = st.columns([1.2, 1.2, 1.6])

    with _gm_c1:
        _gm_ticker = st.text_input(
            "Ticker", value=_gm_sa_ticker, key="gm_ticker",
            placeholder="GME",
        ).strip().upper()
        _gm_side = st.selectbox(
            "Side", ["buy", "sell"], key="gm_side",
            format_func=lambda x: "🟢 BUY" if x == "buy" else "🔴 SELL",
        )

    with _gm_c2:
        _gm_env = st.selectbox(
            "Environment", ["Paper Trading", "Live Trading"], key="gm_env",
        )
        _gm_is_paper = _gm_env == "Paper Trading"
        _gm_order_type = st.selectbox(
            "Order Type", ["Market", "Limit"], key="gm_order_type",
        )

    with _gm_c3:
        _gm_qty = st.number_input(
            "Shares", min_value=1, max_value=10_000,
            value=max(1, max_shares),
            step=1, key="gm_qty",
        )
        _gm_limit_px = None
        if _gm_order_type == "Limit":
            _gm_limit_px = st.number_input(
                "Limit Price ($)", min_value=0.01, max_value=10_000.0,
                value=round(float(price) if price else 1.00, 2),
                step=0.01, format="%.2f", key="gm_limit_px",
            )

    # Safety warning for live mode
    if not _gm_is_paper:
        st.warning(
            "⚠️ **LIVE trading is enabled.** This will send a REAL order with REAL money "
            "to your Alpaca brokerage account. Double-check everything before firing.",
            icon="⚠️",
        )

    _gm_env_badge  = "🔵 PAPER" if _gm_is_paper else "🔴 LIVE"
    _gm_btn_color  = "#5c6bc0" if _gm_is_paper else "#b71c1c"
    _gm_btn_label  = (
        f"🚀 EXECUTE {_gm_env_badge} ORDER — "
        f"{_gm_side.upper()} {_gm_qty} {_gm_ticker or '???'}"
    )

    st.markdown(
        f'<style>.gm-fire-btn button{{background:{_gm_btn_color}!important;'
        f'color:#fff!important;font-size:17px!important;font-weight:900!important;'
        f'border-radius:10px!important;padding:14px!important;'
        f'letter-spacing:1px!important;border:none!important;}}</style>',
        unsafe_allow_html=True,
    )
    with st.container():
        st.markdown('<div class="gm-fire-btn">', unsafe_allow_html=True)
        _gm_fire = st.button(_gm_btn_label, use_container_width=True, key="gm_fire_btn")
        st.markdown('</div>', unsafe_allow_html=True)

    if _gm_fire:
        if not _gm_ticker:
            st.error("Enter a ticker symbol first.")
        elif not api_key or not secret_key:
            st.error("No Alpaca credentials — enter your API Key and Secret in the sidebar.")
        else:
            with st.spinner(f"Sending {'paper' if _gm_is_paper else 'LIVE'} order to Alpaca…"):
                _gm_result = execute_alpaca_trade(
                    api_key=api_key,
                    secret_key=secret_key,
                    is_paper=_gm_is_paper,
                    ticker=_gm_ticker,
                    qty=int(_gm_qty),
                    side=_gm_side,
                    limit_price=_gm_limit_px,
                )
            if _gm_result["success"]:
                st.success(_gm_result["message"])
                st.caption(f"Order ID: `{_gm_result['order_id']}`")
            else:
                st.error(_gm_result["message"])

    # ── SECTION 6 — RECOVERY RATIO ───────────────────────────────────────────
    st.markdown("---")
    st.markdown("### 📉 Recovery Ratio — The Math of Drawdown")
    st.caption("A 25% loss requires a 33% gain just to break even. Protect capital first.")

    rr1, rr2 = st.columns([1, 2])
    with rr1:
        loss_in = st.slider("Simulate a loss of:", 1, 90, 25, format="%d%%", key="sa_rrs")
        rr_val  = compute_recovery_ratio(loss_in)
        rrc     = "#4caf50" if loss_in < 15 else "#ffa726" if loss_in < 35 else "#ef5350"
        st.markdown(
            f'<div style="background:#0c1030;border:2px solid {rrc};border-radius:10px;'
            f'padding:16px;text-align:center;margin:8px 0;">'
            f'<div style="font-size:12px;color:#aaa;">After a <b style="color:{rrc};">{loss_in}%</b> loss</div>'
            f'<div style="font-size:11px;color:#555;margin:4px 0;">you need to gain</div>'
            f'<div style="font-size:38px;font-weight:900;color:{rrc};">{rr_val:.1f}%</div>'
            f'<div style="font-size:11px;color:#aaa;">to return to break-even</div>'
            f'</div>',
            unsafe_allow_html=True,
        )
    with rr2:
        rows_rr = [(10, "Manageable"), (20, "Manageable"), (25, "Dangerous"),
                   (33, "Dangerous"),  (50, "DEATH SPIRAL"), (75, "DEATH SPIRAL")]
        tbl = '<table style="width:100%;border-collapse:collapse;font-size:12px;font-family:monospace;">'
        tbl += ('<tr style="color:#5c6bc0;font-size:10px;text-transform:uppercase;">'
                '<th style="text-align:left;padding:5px 10px;">Loss %</th>'
                '<th style="text-align:left;padding:5px 10px;">Must Gain</th>'
                '<th style="text-align:left;padding:5px 10px;">Verdict</th></tr>')
        for lp, verdict in rows_rr:
            rr_v  = compute_recovery_ratio(lp)
            rc2   = "#4caf50" if lp < 15 else "#ffa726" if lp < 35 else "#ef5350"
            tbl  += (f'<tr style="border-top:1px solid #1c2040;">'
                     f'<td style="padding:5px 10px;color:{rc2};font-weight:700;">−{lp}%</td>'
                     f'<td style="padding:5px 10px;color:{rc2};">+{rr_v:.1f}%</td>'
                     f'<td style="padding:5px 10px;color:{rc2};">{verdict}</td></tr>')
        tbl += '</table>'
        st.markdown(
            f'<div style="background:#0c1030;border:1px solid #2a2a4a;border-radius:8px;'
            f'padding:12px;">{tbl}</div>',
            unsafe_allow_html=True,
        )

    # ── SECTION 7 — SNIPER TRADE LOG ─────────────────────────────────────────
    st.markdown("---")
    st.markdown("### 📋 Sniper Trade Log — Cognitive Audit")
    st.caption(
        "The data doesn't lie: confirmed entries (waited for the break) vs. "
        "anticipated entries (jumped early). Track both — your win rate will show the difference."
    )

    with st.expander("➕ Log a Trade", expanded=False):
        lg1, lg2, lg3 = st.columns(3)
        with lg1:
            lg_tick  = st.text_input("Ticker", value=ticker or "", key="sa_lgt").upper()
            lg_ep    = st.number_input("Entry Price", min_value=0.01,
                                        value=float(price or 1.0), step=0.01,
                                        format="%.2f", key="sa_lgep")
            lg_xp    = st.number_input("Exit Price", min_value=0.01,
                                        value=float(price or 1.0), step=0.01,
                                        format="%.2f", key="sa_lgxp")
        with lg2:
            lg_et    = st.selectbox("Entry Type",
                                     ["First Pullback", "ABCD Pattern",
                                      "High of Day Break", "Other"],
                                     key="sa_lget")
            lg_conf  = st.radio("Entry Discipline",
                                 ["✅ Confirmed (waited for break)",
                                  "⚠️ Anticipated (jumped early)"],
                                 key="sa_lgconf")
            lg_news  = st.checkbox("Catalyst confirmed at entry time", key="sa_lgnews")
        with lg3:
            in_win   = window_open
            ts_str   = now_et.strftime("%H:%M ET")
            if not in_win:
                st.warning(f"⚠️ {ts_str} — Outside sniper window")
            else:
                st.success(f"✅ {ts_str} — Inside window")
            lg_notes = st.text_area("Notes / reason for entry", height=90,
                                     placeholder="Why you took this trade…",
                                     key="sa_lgnotes")

        if st.button("💾 Log Trade", key="sa_log_btn"):
            pnl_p = round((lg_xp - lg_ep) / lg_ep * 100, 2) if lg_ep > 0 else 0.0
            entry = {
                "date":        now_et.strftime("%Y-%m-%d"),
                "time":        ts_str,
                "ticker":      lg_tick,
                "entry_price": round(lg_ep, 2),
                "exit_price":  round(lg_xp, 2),
                "pnl_pct":     pnl_p,
                "entry_type":  lg_et,
                "confirmed":   "Confirmed" if "Confirmed" in lg_conf else "Anticipated",
                "news":        "✅" if lg_news else "❌",
                "in_window":   "✅" if in_win else "❌",
                "notes":       lg_notes,
            }
            journal = load_sa_journal()
            journal.append(entry)
            save_sa_journal(journal)
            st.success(f"Logged: {lg_tick} | {pnl_p:+.2f}%")
            st.rerun()

    # Display journal + cognitive audit split
    journal = load_sa_journal()
    if journal:
        dfj = pd.DataFrame(journal)

        # Win-rate by confirmed vs anticipated
        if "confirmed" in dfj.columns and "pnl_pct" in dfj.columns:
            conf_df = dfj[dfj["confirmed"] == "Confirmed"]
            anti_df = dfj[dfj["confirmed"] == "Anticipated"]
            cwr = (conf_df["pnl_pct"] > 0).mean() * 100 if len(conf_df) else None
            awr = (anti_df["pnl_pct"] > 0).mean() * 100 if len(anti_df) else None

            au1, au2 = st.columns(2)
            with au1:
                cwc = "#4caf50" if (cwr or 0) >= 50 else "#ef5350"
                st.markdown(
                    f'<div style="background:#0c1030;border:1px solid {cwc};border-radius:8px;'
                    f'padding:12px;text-align:center;">'
                    f'<div style="font-size:11px;color:#aaa;">✅ Confirmed Entry Win Rate</div>'
                    f'<div style="font-size:28px;font-weight:800;color:{cwc};">'
                    f'{"%.0f%%" % cwr if cwr is not None else "—"}</div>'
                    f'<div style="font-size:10px;color:#555;">{len(conf_df)} trades</div>'
                    f'</div>',
                    unsafe_allow_html=True,
                )
            with au2:
                awc = "#4caf50" if (awr or 0) >= 50 else "#ef5350"
                st.markdown(
                    f'<div style="background:#0c1030;border:1px solid {awc};border-radius:8px;'
                    f'padding:12px;text-align:center;">'
                    f'<div style="font-size:11px;color:#aaa;">⚠️ Anticipated Entry Win Rate</div>'
                    f'<div style="font-size:28px;font-weight:800;color:{awc};">'
                    f'{"%.0f%%" % awr if awr is not None else "—"}</div>'
                    f'<div style="font-size:10px;color:#555;">{len(anti_df)} trades</div>'
                    f'</div>',
                    unsafe_allow_html=True,
                )

        # Recent trades table
        st.markdown("**Recent Trades**")
        for row in reversed(journal[-15:]):
            pnl = row.get("pnl_pct", 0)
            pc  = "#4caf50" if pnl > 0 else "#ef5350"
            st.markdown(
                f'<div style="background:#0c1030;border:1px solid #2a2a4a;border-radius:6px;'
                f'padding:7px 14px;margin:3px 0;font-size:12px;'
                f'display:flex;gap:14px;align-items:center;flex-wrap:wrap;">'
                f'<span style="color:#e0e0e0;font-weight:700;min-width:48px;">'
                f'{row.get("ticker","")}</span>'
                f'<span style="color:#666;">{row.get("date","")} {row.get("time","")}</span>'
                f'<span style="color:#888;">{row.get("entry_type","")}</span>'
                f'<span style="color:#888;">{row.get("confirmed","")}</span>'
                f'<span style="color:#555;">News: {row.get("news","")}</span>'
                f'<span style="color:#555;">Window: {row.get("in_window","")}</span>'
                f'<span style="font-weight:700;color:{pc};">{pnl:+.2f}%</span>'
                f'</div>',
                unsafe_allow_html=True,
            )

        sa_csv = dfj.to_csv(index=False)
        st.download_button(
            "⬇ Download SA Journal", data=sa_csv,
            file_name="sa_journal.csv", mime="text/csv"
        )
    else:
        st.info("No trades logged yet. Use the expander above to log your first sniper trade.")


def render_paper_trade_tab(api_key: str = "", secret_key: str = ""):
    st.markdown(
        '<div style="font-size:11px; color:#1565c0; text-transform:uppercase; '
        'letter-spacing:2px; font-weight:700; margin-bottom:4px;">📄 AUTO PAPER TRADING</div>'
        '<div style="font-size:12px; color:#546e7a; margin-bottom:18px;">'
        'Run the IB engine on any date with a TCS ≥ filter. Results log automatically '
        'so you build 3 weeks of calibrated paper data without touching Alpaca again.</div>',
        unsafe_allow_html=True,
    )

    _pt_ready = ensure_paper_trades_table()
    if not _pt_ready:
        st.warning(
            "The paper_trades table doesn't exist yet in your Supabase database. "
            "Run the SQL below in your Supabase SQL editor, then reload the page.",
            icon="⚠️",
        )
        st.code(
            "CREATE TABLE IF NOT EXISTS paper_trades (\n"
            "  id SERIAL PRIMARY KEY,\n"
            "  user_id TEXT, trade_date DATE, ticker TEXT, tcs FLOAT,\n"
            "  predicted TEXT, ib_low FLOAT, ib_high FLOAT, open_price FLOAT,\n"
            "  actual_outcome TEXT, follow_thru_pct FLOAT, win_loss TEXT,\n"
            "  false_break_up BOOLEAN DEFAULT FALSE,\n"
            "  false_break_down BOOLEAN DEFAULT FALSE,\n"
            "  min_tcs_filter INT DEFAULT 50,\n"
            "  created_at TIMESTAMPTZ DEFAULT NOW()\n"
            ");",
            language="sql",
        )
        return

    # ── Live Auto-Scan mode ──────────────────────────────────────────────────
    _pt_live_col1, _pt_live_col2, _pt_live_col3 = st.columns([1.2, 1, 1])
    with _pt_live_col1:
        _pt_live_on = st.toggle(
            "🔴 Live Auto-Scan (while browser open)",
            value=st.session_state.get("_pt_live_mode", False),
            key="pt_live_toggle",
            help="When ON, auto-scans every 30 min during market hours (9:30–4:00 PM ET). "
                 "The standalone bot runs 24/7 even when this is OFF.",
        )
        st.session_state["_pt_live_mode"] = _pt_live_on

    _now_et_pt = datetime.now(EASTERN)
    _pt_mkt_open  = _now_et_pt.replace(hour=9,  minute=30, second=0, microsecond=0)
    _pt_mkt_close = _now_et_pt.replace(hour=16, minute=0,  second=0, microsecond=0)
    _pt_in_market = (
        _pt_mkt_open <= _now_et_pt <= _pt_mkt_close
        and _now_et_pt.weekday() < 5
    )

    with _pt_live_col2:
        if _pt_live_on:
            _pt_last = st.session_state.get("_pt_last_auto_scan")
            if _pt_last:
                _pt_elapsed = int((_now_et_pt.timestamp() - _pt_last) / 60)
                _pt_next_in = max(0, 30 - _pt_elapsed)
                st.markdown(
                    f'<div style="font-size:11px; color:#4caf50; padding-top:8px;">'
                    f'✅ Auto-scan active · next in <b>{_pt_next_in} min</b></div>',
                    unsafe_allow_html=True,
                )
            else:
                st.markdown(
                    '<div style="font-size:11px; color:#ff9800; padding-top:8px;">'
                    '⏳ First scan pending…</div>',
                    unsafe_allow_html=True,
                )
    with _pt_live_col3:
        _mkt_str = (
            f'<span style="color:#4caf50;">🟢 Market Open</span>'
            if _pt_in_market else
            f'<span style="color:#546e7a;">⚫ Market Closed</span>'
        )
        st.markdown(
            f'<div style="font-size:11px; padding-top:8px;">{_mkt_str} '
            f'· {_now_et_pt.strftime("%I:%M %p ET")}</div>',
            unsafe_allow_html=True,
        )

    st.markdown("---")

    # ── Section 1: Scan & Log ────────────────────────────────────────────────
    st.markdown(
        '<div style="font-size:10px; color:#1565c0; text-transform:uppercase; '
        'letter-spacing:1.5px; font-weight:700; margin:12px 0 8px 0;">'
        '🔍 SECTION 1 — SCAN & LOG PAPER TRADES</div>',
        unsafe_allow_html=True,
    )
    st.caption(
        "Pick a date, paste your tickers, set a TCS minimum. "
        "Hit Scan — the engine fetches bars, runs the full IB analysis, "
        "filters to TCS ≥ your minimum, and saves qualifying setups automatically. "
        "Best run after 10:30 AM ET so the full IB window is captured."
    )

    _pt_c1, _pt_c2, _pt_c3 = st.columns([1, 1, 1])
    with _pt_c1:
        _pt_date = st.date_input(
            "Trade Date",
            value=date.today(),
            key="pt_scan_date",
            help="Set to today for live paper trades, or any past date to backfill.",
        )
    with _pt_c2:
        _pt_feed = st.radio(
            "Bar Data Feed",
            ["SIP (paid — accurate)", "IEX (free — limited)"],
            key="pt_feed",
            horizontal=True,
        )
        _pt_feed_str = "sip" if "SIP" in _pt_feed else "iex"
    with _pt_c3:
        _pt_min_tcs = st.slider(
            "Min TCS Filter",
            min_value=0, max_value=80, value=50, step=5,
            key="pt_min_tcs",
            help="Only setups with TCS ≥ this value get logged. 50 is the recommended minimum.",
        )

    _pt_price_range = st.slider(
        "Price Range ($)",
        min_value=0.5, max_value=30.0,
        value=(1.0, 20.0), step=0.5,
        key="pt_price_range",
    )

    _pt_default_tickers = "SATL, UGRO, ANNA, VCX, CODX, ARTL, SWMR, FEED, RBNE, PAVS, LNKS, BIAF, ACXP, GOAI"
    _pt_tickers_raw = st.text_area(
        "Tickers to scan (comma-separated)",
        value=_pt_default_tickers,
        height=80,
        key="pt_tickers",
        help="Enter your watchlist. Add gap scanner picks each morning for best coverage.",
    )

    _pt_scan_btn = st.button(
        "🔍 Scan & Log Paper Trades",
        use_container_width=True,
        key="pt_scan_btn",
        type="primary",
    )

    if _pt_scan_btn:
        if not api_key or not secret_key:
            st.error("Add your Alpaca credentials in the sidebar first.")
        else:
            _pt_tickers = [
                t.strip().upper()
                for t in _pt_tickers_raw.replace("\n", ",").split(",")
                if t.strip() and t.strip().isalpha()
            ]
            if not _pt_tickers:
                st.error("No valid tickers found.")
            else:
                _pt_pmin, _pt_pmax = float(_pt_price_range[0]), float(_pt_price_range[1])
                with st.spinner(
                    f"Fetching bars for {len(_pt_tickers)} tickers on {_pt_date} · "
                    f"filtering TCS ≥ {_pt_min_tcs}…"
                ):
                    _pt_results, _pt_summary = run_historical_backtest(
                        api_key, secret_key,
                        trade_date=_pt_date,
                        tickers=_pt_tickers,
                        feed=_pt_feed_str,
                        price_min=_pt_pmin,
                        price_max=_pt_pmax,
                        slippage_pct=0.0,
                    )
                if _pt_summary.get("error"):
                    st.error(_pt_summary["error"])
                elif not _pt_results:
                    st.warning("No setups found for that date / ticker list.")
                else:
                    _pt_qualified = [
                        dict(r, sim_date=str(_pt_date))
                        for r in _pt_results
                        if float(r.get("tcs", 0)) >= _pt_min_tcs
                    ]
                    _pt_total_scanned = len(_pt_results)
                    if not _pt_qualified:
                        st.warning(
                            f"Scanned {_pt_total_scanned} setups — none passed TCS ≥ {_pt_min_tcs}. "
                            f"Try a lower TCS filter or add more tickers."
                        )
                    else:
                        _pt_log_result = log_paper_trades(
                            _pt_qualified,
                            user_id=_AUTH_USER_ID,
                            min_tcs=_pt_min_tcs,
                        )
                        st.session_state["_pt_last_scan"] = _pt_qualified
                        if _pt_log_result.get("error"):
                            st.error(f"Save error: {_pt_log_result['error']}")
                        else:
                            _sv = _pt_log_result["saved"]
                            _sk = _pt_log_result["skipped"]
                            st.success(
                                f"✅ {_sv} paper trade(s) logged for {_pt_date} "
                                f"(TCS ≥ {_pt_min_tcs}) · "
                                f"{_pt_total_scanned - len(_pt_qualified)} below-TCS setups filtered out"
                                + (f" · {_sk} already logged (skipped)" if _sk else "")
                            )

                    _pt_preview = _pt_qualified or _pt_results
                    _pt_preview_df = pd.DataFrame(_pt_preview)[[
                        c for c in ["ticker", "tcs", "predicted", "actual_outcome",
                                    "win_loss", "aft_move_pct", "ib_low", "ib_high"]
                        if c in pd.DataFrame(_pt_preview).columns
                    ]]
                    if not _pt_preview_df.empty and "aft_move_pct" in _pt_preview_df.columns:
                        _pt_preview_df = _pt_preview_df.rename(columns={"aft_move_pct": "follow_thru_%"})
                    st.dataframe(_pt_preview_df, use_container_width=True, hide_index=True)

    st.markdown("---")

    # ── Section 2: 3-Week Performance Tracker ──────────────────────────────
    st.markdown(
        '<div style="font-size:10px; color:#1565c0; text-transform:uppercase; '
        'letter-spacing:1.5px; font-weight:700; margin:12px 0 8px 0;">'
        '📊 SECTION 2 — 3-WEEK PAPER TRADE TRACKER</div>',
        unsafe_allow_html=True,
    )

    _pt_reload = st.button("🔄 Refresh Tracker", key="pt_reload_btn")
    if _pt_reload or "pt_tracker_df" not in st.session_state:
        _pt_df = load_paper_trades(user_id=_AUTH_USER_ID, days=21)
        st.session_state["pt_tracker_df"] = _pt_df
    else:
        _pt_df = st.session_state.get("pt_tracker_df", pd.DataFrame())

    if _pt_df.empty:
        st.info(
            "No paper trades logged yet. Run Section 1 on a few days to build your history.",
            icon="📋",
        )
        return

    _pt_wins   = (_pt_df["win_loss"] == "Win").sum()
    _pt_losses = (_pt_df["win_loss"] == "Loss").sum()
    _pt_total  = len(_pt_df)
    _pt_wr     = round(_pt_wins / _pt_total * 100, 1) if _pt_total > 0 else 0
    _pt_dates  = _pt_df["trade_date"].nunique() if "trade_date" in _pt_df.columns else 0
    _pt_avg_ft = round(_pt_df["follow_thru_pct"].mean(), 1) if "follow_thru_pct" in _pt_df.columns else 0
    _pt_avg_tcs = round(_pt_df["tcs"].mean(), 0) if "tcs" in _pt_df.columns else 0
    _pt_wr_clr = "#4caf50" if _pt_wr >= 60 else "#ff9800" if _pt_wr >= 50 else "#ef5350"

    _pt_kpi_html = (
        f'<div style="display:flex; gap:16px; flex-wrap:wrap; margin-bottom:20px;">'
        f'<div style="background:#0a1929; border:1px solid #1565c055; border-radius:10px; '
        f'padding:14px 22px; text-align:center; min-width:120px;">'
        f'<div style="font-size:10px; color:#546e7a; text-transform:uppercase; letter-spacing:1px; margin-bottom:4px;">Win Rate</div>'
        f'<div style="font-size:30px; font-weight:900; color:{_pt_wr_clr}; font-family:monospace;">{_pt_wr}%</div>'
        f'<div style="font-size:10px; color:#37474f;">{_pt_wins}W / {_pt_losses}L</div></div>'
        f'<div style="background:#0a1929; border:1px solid #1565c055; border-radius:10px; '
        f'padding:14px 22px; text-align:center; min-width:120px;">'
        f'<div style="font-size:10px; color:#546e7a; text-transform:uppercase; letter-spacing:1px; margin-bottom:4px;">Total Setups</div>'
        f'<div style="font-size:30px; font-weight:900; color:#e0e0e0; font-family:monospace;">{_pt_total}</div>'
        f'<div style="font-size:10px; color:#37474f;">across {_pt_dates} day(s)</div></div>'
        f'<div style="background:#0a1929; border:1px solid #1565c055; border-radius:10px; '
        f'padding:14px 22px; text-align:center; min-width:120px;">'
        f'<div style="font-size:10px; color:#546e7a; text-transform:uppercase; letter-spacing:1px; margin-bottom:4px;">Avg TCS</div>'
        f'<div style="font-size:30px; font-weight:900; color:#ce93d8; font-family:monospace;">{int(_pt_avg_tcs)}</div>'
        f'<div style="font-size:10px; color:#37474f;">min filter applied</div></div>'
        f'<div style="background:#0a1929; border:1px solid #1565c055; border-radius:10px; '
        f'padding:14px 22px; text-align:center; min-width:120px;">'
        f'<div style="font-size:10px; color:#546e7a; text-transform:uppercase; letter-spacing:1px; margin-bottom:4px;">Avg Follow-Thru</div>'
        f'<div style="font-size:30px; font-weight:900; color:{"#4caf50" if _pt_avg_ft >= 0 else "#ef5350"}; font-family:monospace;">'
        f'{("+" if _pt_avg_ft >= 0 else "")}{_pt_avg_ft}%</div>'
        f'<div style="font-size:10px; color:#37474f;">best post-IB point</div></div>'
        f'</div>'
    )
    st.markdown(_pt_kpi_html, unsafe_allow_html=True)

    # Daily win rate trend
    if "trade_date" in _pt_df.columns and "win_loss" in _pt_df.columns:
        _pt_daily = (
            _pt_df.groupby("trade_date")
            .apply(lambda g: pd.Series({
                "Win %":   round((g["win_loss"] == "Win").sum() / len(g) * 100, 1),
                "Setups":  len(g),
                "Avg TCS": round(g["tcs"].mean(), 0) if "tcs" in g.columns else 0,
            }))
            .reset_index()
            .sort_values("trade_date")
        )
        import plotly.graph_objects as _pt_go
        _pt_fig = _pt_go.Figure()
        _pt_fig.add_trace(_pt_go.Scatter(
            x=_pt_daily["trade_date"].astype(str),
            y=_pt_daily["Win %"],
            mode="lines+markers+text",
            text=_pt_daily["Win %"].apply(lambda v: f"{v:.0f}%"),
            textposition="top center",
            line=dict(color="#1565c0", width=2),
            marker=dict(size=8, color="#1565c0"),
            name="Daily Win %",
        ))
        _pt_fig.add_hline(
            y=55, line_dash="dot", line_color="#ff9800",
            annotation_text="55% target", annotation_font_color="#ff9800",
        )
        _pt_fig.update_layout(
            paper_bgcolor="#050d18", plot_bgcolor="#050d18",
            font=dict(color="#90a4ae", size=11),
            height=280, margin=dict(l=10, r=10, t=30, b=10),
            xaxis=dict(showgrid=False, title=""),
            yaxis=dict(gridcolor="#0d2137", range=[0, 105], title="Win %"),
            title=dict(text="Daily Win Rate (Paper Trades)", font=dict(color="#1565c0", size=12)),
            showlegend=False,
        )
        st.plotly_chart(_pt_fig, use_container_width=True)

    # Per-ticker summary
    st.markdown(
        '<div style="font-size:10px; color:#546e7a; text-transform:uppercase; '
        'letter-spacing:1px; margin:16px 0 8px 0; font-weight:700;">Per-Ticker Stats</div>',
        unsafe_allow_html=True,
    )
    _pt_tkr_rows = []
    for _ptk, _ptg in _pt_df.groupby("ticker"):
        _ptw = (_ptg["win_loss"] == "Win").sum()
        _ptl = (_ptg["win_loss"] == "Loss").sum()
        _ptwr = round(_ptw / len(_ptg) * 100, 1) if len(_ptg) > 0 else 0
        _pt_top_struct = (
            _ptg["predicted"].value_counts().index[0]
            if "predicted" in _ptg.columns and not _ptg["predicted"].empty
            else "—"
        )
        _pt_tkr_rows.append({
            "Ticker":        _ptk,
            "Setups":        len(_ptg),
            "W/L":           f"{_ptw}/{_ptl}",
            "Win %":         f"{'🟢' if _ptwr >= 60 else '🟡' if _ptwr >= 50 else '🔴'} {_ptwr}%",
            "Avg TCS":       round(_ptg["tcs"].mean(), 0) if "tcs" in _ptg.columns else 0,
            "Top Structure": _pt_top_struct,
            "Avg FT %":      round(_ptg["follow_thru_pct"].mean(), 1) if "follow_thru_pct" in _ptg.columns else 0,
            "Days Seen":     _ptg["trade_date"].nunique() if "trade_date" in _ptg.columns else 0,
        })
    _pt_tkr_df = pd.DataFrame(_pt_tkr_rows).sort_values("Win %", ascending=False)
    st.dataframe(_pt_tkr_df, use_container_width=True, hide_index=True)

    # Full trade log
    with st.expander("📋 Full Paper Trade Log", expanded=False):
        _pt_log_cols = [
            c for c in ["trade_date", "ticker", "tcs", "predicted",
                         "actual_outcome", "follow_thru_pct", "win_loss",
                         "false_break_up", "false_break_down", "min_tcs_filter"]
            if c in _pt_df.columns
        ]
        _pt_log_show = _pt_df[_pt_log_cols].sort_values(
            "trade_date", ascending=False
        ).reset_index(drop=True)
        st.dataframe(_pt_log_show, use_container_width=True, hide_index=True)
        st.caption(
            f"Showing {len(_pt_log_show)} paper trades from last 21 days · "
            "Only TCS-filtered qualifying setups are stored here"
        )

    st.markdown("---")

    # ── Section 3: Manual EOD Outcome Update ────────────────────────────────
    st.markdown(
        '<div style="font-size:10px; color:#1565c0; text-transform:uppercase; '
        'letter-spacing:1.5px; font-weight:700; margin:12px 0 8px 0;">'
        '🔒 SECTION 3 — MANUAL EOD OUTCOME UPDATE</div>',
        unsafe_allow_html=True,
    )
    st.caption(
        "The bot auto-updates outcomes at 4:05 PM ET. Use this if you want to "
        "force-refresh outcomes for a specific date right now (e.g. after market close)."
    )
    _eod_c1, _eod_c2 = st.columns([1, 2])
    with _eod_c1:
        _eod_date = st.date_input(
            "Date to update", value=date.today(), key="pt_eod_date"
        )
    with _eod_c2:
        _eod_tickers_raw = st.text_input(
            "Tickers (leave blank to use same as Section 1)",
            value="",
            key="pt_eod_tickers",
            placeholder="e.g. SATL, UGRO, ANNA — or leave blank",
        )
    if st.button("🔒 Update Outcomes for Selected Date", key="pt_eod_btn", use_container_width=True):
        _eod_tickers = (
            [t.strip().upper() for t in _eod_tickers_raw.split(",") if t.strip()]
            or [t.strip().upper() for t in _pt_tickers_raw.replace("\n", ",").split(",") if t.strip()]
        )
        with st.spinner(f"Fetching full-day bars for {_eod_date} and updating outcomes…"):
            _eod_res, _eod_sum = run_historical_backtest(
                api_key, secret_key,
                trade_date=_eod_date,
                tickers=_eod_tickers,
                feed=_pt_feed_str,
                price_min=float(_pt_price_range[0]),
                price_max=float(_pt_price_range[1]),
                slippage_pct=0.0,
            )
        if _eod_sum.get("error"):
            st.error(_eod_sum["error"])
        elif _eod_res:
            _upd = update_paper_trade_outcomes(str(_eod_date), _eod_res, user_id=_AUTH_USER_ID)
            st.success(f"✅ Updated {_upd.get('updated', 0)} paper trade outcome(s) for {_eod_date}")
            st.session_state.pop("pt_tracker_df", None)
        else:
            st.warning("No data returned for that date.")

    st.markdown("---")

    # ── Section 4: Time Window Comparison ───────────────────────────────────
    st.markdown(
        '<div style="font-size:10px; color:#1565c0; text-transform:uppercase; '
        'letter-spacing:1.5px; font-weight:700; margin:12px 0 8px 0;">'
        '🕐 SECTION 4 — IB WINDOW vs FULL-DAY COMPARISON</div>',
        unsafe_allow_html=True,
    )
    st.caption(
        "Run the same ticker list with three different cutoff windows and compare win rates side by side. "
        "Window A = standard IB (9:30–10:30). Window B = extended morning (to 12:00 PM). "
        "Window C = midday (to 2:00 PM). "
        "Each window uses its bars as the signal, then evaluates what happened after."
    )
    _wc_date = st.date_input(
        "Comparison Date", value=date.today(), key="pt_wc_date"
    )
    _wc_tickers_raw = st.text_input(
        "Tickers for comparison",
        value=_pt_default_tickers,
        key="pt_wc_tickers",
    )
    _wc_run = st.button(
        "▶ Run Window Comparison", key="pt_wc_run", use_container_width=True, type="primary"
    )
    if _wc_run:
        if not api_key or not secret_key:
            st.error("Add Alpaca credentials in the sidebar first.")
        else:
            _wc_tickers = [
                t.strip().upper()
                for t in _wc_tickers_raw.replace("\n", ",").split(",")
                if t.strip() and t.strip().isalpha()
            ]
            _wc_windows = [
                ("A — IB Only (10:30)",      10, 30),
                ("B — Extended AM (12:00)",  12,  0),
                ("C — Midday (14:00)",       14,  0),
            ]
            _wc_results = {}
            with st.spinner("Running 3 time windows in parallel…"):
                from concurrent.futures import ThreadPoolExecutor as _WCTP, as_completed as _wcac
                def _run_window(label, h, m):
                    res, summ = run_historical_backtest(
                        api_key, secret_key,
                        trade_date=_wc_date,
                        tickers=_wc_tickers,
                        feed=_pt_feed_str,
                        price_min=float(_pt_price_range[0]),
                        price_max=float(_pt_price_range[1]),
                        cutoff_hour=h,
                        cutoff_minute=m,
                        slippage_pct=0.0,
                    )
                    return label, res, summ
                with _WCTP(max_workers=3) as _wc_ex:
                    _wc_futs = {
                        _wc_ex.submit(_run_window, label, h, m): label
                        for label, h, m in _wc_windows
                    }
                    for _wc_f in _wcac(_wc_futs):
                        _lbl, _res, _summ = _wc_f.result()
                        _wc_results[_lbl] = (_res, _summ)

            st.session_state["_pt_wc_results"] = _wc_results

    _wc_stored = st.session_state.get("_pt_wc_results", {})
    if _wc_stored:
        _wc_cols = st.columns(3)
        _wc_summary_rows = []
        for _wi, (_wlabel, (_wres, _wsumm)) in enumerate(sorted(_wc_stored.items())):
            _wwr  = _wsumm.get("win_rate", 0)
            _wtot = _wsumm.get("total", 0)
            _wavg = _wsumm.get("avg_tcs", 0)
            _wfb  = _wsumm.get("false_break_rate", 0)
            _wbull_ft = _wsumm.get("avg_bull_ft", 0)
            _wr_clr = "#4caf50" if _wwr >= 60 else "#ff9800" if _wwr >= 50 else "#ef5350"
            _wc_summary_rows.append({
                "Window":         _wlabel,
                "Win Rate":       f"{_wwr}%",
                "Setups":         _wtot,
                "Avg TCS":        int(_wavg),
                "Avg Bull FT":    f"+{_wbull_ft:.1f}%",
                "False Brk %":    f"{_wfb:.1f}%",
            })
            with _wc_cols[_wi]:
                st.markdown(
                    f'<div style="background:#0a1929; border:1px solid #1565c055; '
                    f'border-radius:10px; padding:16px; text-align:center;">'
                    f'<div style="font-size:10px; color:#546e7a; text-transform:uppercase; '
                    f'letter-spacing:1px; margin-bottom:6px;">{_wlabel}</div>'
                    f'<div style="font-size:34px; font-weight:900; color:{_wr_clr}; '
                    f'font-family:monospace;">{_wwr}%</div>'
                    f'<div style="font-size:11px; color:#37474f; margin-top:4px;">'
                    f'{_wsumm.get("wins",0)}W / {_wsumm.get("losses",0)}L · {_wtot} setups</div>'
                    f'<div style="font-size:11px; color:#546e7a; margin-top:8px;">'
                    f'Avg TCS {int(_wavg)} · Bull FT +{_wbull_ft:.1f}% · False Brk {_wfb:.1f}%</div>'
                    f'</div>',
                    unsafe_allow_html=True,
                )
        st.markdown("<br>", unsafe_allow_html=True)
        _best_window = max(_wc_stored.items(), key=lambda x: x[1][1].get("win_rate", 0))
        st.info(
            f"**Best window for {_wc_date}: {_best_window[0]}** with "
            f"{_best_window[1][1].get('win_rate', 0)}% win rate. "
            f"This tells you whether giving the engine more bar data before calling structure "
            f"improves prediction accuracy for your ticker universe."
        )

    st.markdown("---")

    # ── Section 5: Brain Health ──────────────────────────────────────────────
    st.markdown(
        '<div style="font-size:10px; color:#1565c0; text-transform:uppercase; '
        'letter-spacing:1.5px; font-weight:700; margin:12px 0 8px 0;">'
        '🧠 SECTION 5 — BRAIN HEALTH & LIVE WEIGHT CALIBRATION</div>',
        unsafe_allow_html=True,
    )
    st.caption(
        "The bot recalibrates brain weights automatically at 4:10 PM ET every trading day. "
        "It reads all verified journal trades (accuracy_tracker) + all paper trade outcomes "
        "and nudges each structure's weight up or down using a 30% learning rate. "
        "Use the button below to run it right now."
    )

    _bh_c1, _bh_c2 = st.columns([1, 1])
    with _bh_c1:
        _bh_run = st.button(
            "🧠 Recalibrate Now from Live Data",
            key="pt_bh_run",
            use_container_width=True,
            type="primary",
        )
    with _bh_c2:
        _bh_reset = st.button(
            "↺ Reset to Neutral (all weights = 1.0)",
            key="pt_bh_reset",
            use_container_width=True,
        )

    if _bh_reset:
        _neutral = {k: 1.0 for k in [
            "trend_bull", "trend_bear", "double_dist", "non_trend",
            "normal", "neutral", "ntrl_extreme", "nrml_variation"
        ]}
        _save_brain_weights(_neutral, user_id=_AUTH_USER_ID)
        st.session_state.pop("_pt_bh_result", None)
        st.success("✅ All weights reset to 1.0 (neutral). Run 'Recalibrate Now' to re-learn from data.")

    if _bh_run:
        with st.spinner("Reading all Supabase outcome data and updating brain weights…"):
            _bh_result = recalibrate_from_supabase(user_id=_AUTH_USER_ID)
        st.session_state["_pt_bh_result"] = _bh_result

    _bh_stored = st.session_state.get("_pt_bh_result")

    # Always show current weights
    _cur_weights = load_brain_weights(_AUTH_USER_ID)
    _w_default   = 1.0
    _wk_labels   = {
        "trend_bull":    "📈 Trend Bull",
        "trend_bear":    "📉 Trend Bear",
        "double_dist":   "🔁 Double Dist",
        "non_trend":     "↔ Non Trend",
        "normal":        "🔲 Normal",
        "neutral":       "⚖ Neutral",
        "ntrl_extreme":  "⚡ Neutral Extreme",
        "nrml_variation":"〰 Normal Variation",
    }

    # Build display table with delta if calibration was just run
    _bh_deltas_map = {}
    if _bh_stored:
        for d in _bh_stored.get("deltas", []):
            _bh_deltas_map[d["key"]] = d

    _bh_rows = []
    for wk, label in _wk_labels.items():
        cur = _cur_weights.get(wk, 1.0)
        row = {
            "Structure":    label,
            "Weight":       f"{cur:.4f}",
            "vs Default":   f"{cur - _w_default:+.4f}",
            "Status":       "🟢 Boosted" if cur > 1.1 else ("🔴 Penalized" if cur < 0.9 else "⚪ Neutral"),
            "Journal Acc":  "—",
            "Bot Acc":      "—",
            "Blended Acc":  "—",
            "Last Δ":       "—",
        }
        if wk in _bh_deltas_map:
            d = _bh_deltas_map[wk]
            row["Last Δ"]      = f"{d['delta']:+.4f}"
            row["Blended Acc"] = f"{d['blended_acc']}%"
            row["Journal Acc"] = f"{d['journal_acc']}% ({d['journal_n']})" if d.get("journal_acc") is not None else f"< 5 samples ({d.get('journal_n', 0)})"
            row["Bot Acc"]     = f"{d['bot_acc']}% ({d['bot_n']})"        if d.get("bot_acc")     is not None else f"< 5 samples ({d.get('bot_n', 0)})"
        _bh_rows.append(row)

    st.dataframe(
        pd.DataFrame(_bh_rows), use_container_width=True, hide_index=True
    )

    if _bh_stored:
        _src = _bh_stored.get("sources", {})
        _ts  = _bh_stored.get("timestamp", "")[:16].replace("T", " ")
        if _bh_stored.get("calibrated"):
            _n_adj = len(_bh_stored.get("deltas", []))
            st.success(
                f"✅ Calibration complete as of {_ts} — "
                f"{_n_adj} structure(s) adjusted · "
                f"Data: {_src.get('accuracy_tracker', 0)} journal entries + "
                f"{_src.get('paper_trades', 0)} paper trades = "
                f"{_src.get('total', 0)} total outcomes"
            )
        else:
            st.info(
                f"Not enough data yet to update weights (need ≥5 samples per structure). "
                f"Read {_src.get('total', 0)} outcomes so far — keep trading and journaling. "
                f"Weights unchanged."
            )


tab_chart, tab_scan, tab_playbook, tab_backtest, tab_journal, tab_analytics, tab_sa, tab_paper = st.tabs(
    ["📈 Main Chart", "🔍 Scanner", "📋 Playbook", "🔬 Backtest",
     "📖 Journal", "📊 Analytics", "⚡ Small Account", "📄 Paper Trade"]
)

# ── Scanner tab ────────────────────────────────────────────────────────────────
with tab_scan:
    # ── Run scanner if button clicked ──────────────────────────────────────────
    if scan_button:
        if not api_key or not secret_key:
            st.error("Enter your Alpaca credentials in the sidebar first.")
        else:
            watchlist = [t.strip().upper() for t in watchlist_raw.split(",") if t.strip()]
            if not watchlist:
                st.warning("Watchlist is empty — add some tickers and try again.")
            else:
                with st.spinner(f"Scanning {len(watchlist)} tickers for pre-market gaps…"):
                    try:
                        _scan_out = run_gap_scanner(
                            api_key, secret_key, watchlist, date.today(),
                            feed=scan_feed,
                            min_price=scan_min_price,
                            max_price=scan_max_price,
                        )
                        results = _scan_out["rows"]
                        _filtered_out = _scan_out.get("filtered_out", [])
                        st.session_state.scanner_results = results
                        st.session_state.scanner_filtered_out = _filtered_out
                        st.session_state.scanner_last_run = datetime.now(EASTERN)
                        # Pre-trade quality + pattern detection — run in parallel for all tickers
                        if results:
                            from concurrent.futures import ThreadPoolExecutor, as_completed as _asc
                            _quality = {}
                            _patterns_map = {}
                            with ThreadPoolExecutor(max_workers=min(8, len(results))) as _ex:
                                _q_futs = {
                                    _ex.submit(
                                        compute_pretrade_quality,
                                        api_key, secret_key,
                                        r["ticker"], date.today(), scan_feed
                                    ): r["ticker"]
                                    for r in results
                                }
                                _p_futs = {
                                    _ex.submit(
                                        scan_ticker_patterns,
                                        api_key, secret_key,
                                        r["ticker"], date.today(), scan_feed
                                    ): r["ticker"]
                                    for r in results
                                }
                                for _f in _asc(_q_futs):
                                    _quality[_q_futs[_f]] = _f.result()
                                for _f in _asc(_p_futs):
                                    _patterns_map[_p_futs[_f]] = _f.result()
                            st.session_state.scanner_quality = _quality
                            st.session_state.scanner_patterns = _patterns_map
                        if not results:
                            st.warning(
                                "Scan ran but returned no results. "
                                f"Possible reasons: all tickers outside ${scan_min_price:.0f}–${scan_max_price:.0f} range, "
                                "no gap data available (market closed / weekend), "
                                "or IEX feed selected (no pre-market data). "
                                "Try adjusting the price range filter or switching to SIP feed."
                            )
                    except Exception as e:
                        st.error(f"Scanner error: {e}")

    # ── Display results ────────────────────────────────────────────────────────
    results = st.session_state.scanner_results
    last_run = st.session_state.scanner_last_run

    _scan_filtered_out = st.session_state.get("scanner_filtered_out", [])
    if last_run:
        _pm_ok = results[0].get("pm_data_available", True) if results else True
        _sort_by = "Pre-Market RVOL" if _pm_ok else "Gap %"
        _p_min = st.session_state.get("scan_min_price", 1.0)
        _p_max = st.session_state.get("scan_max_price", 50.0)
        st.caption(f"Last scan: {last_run.strftime('%H:%M:%S')} EST  ·  "
                   f"${_p_min:.0f}–${_p_max:.0f} filter · {len(results)} showing · sorted by {_sort_by}")
        if not _pm_ok:
            st.info("📊 **Gap-Only Mode** — Pre-market volume unavailable on free IEX tier. "
                    "Results are sorted by largest gap %. PM Vol / RVOL columns will be blank. "
                    "Upgrade to Alpaca SIP subscription to unlock pre-market RVOL.")
        if _scan_filtered_out:
            st.warning(
                f"⚠️ **{len(_scan_filtered_out)} ticker(s) excluded** by price filter "
                f"(${_p_min:.0f}–${_p_max:.0f}): "
                + ", ".join(_scan_filtered_out)
                + " — adjust Min/Max Price in the scanner settings to include them."
            )

    if not results:
        st.info("👈 Click **🔍 Scan Gap Plays** in the sidebar to populate this panel.\n\n"
                "The scanner checks every ticker in your watchlist, applies the price range filter, "
                "and ranks results by gap % (free IEX tier) or pre-market RVOL (SIP).")
    else:
        _gap_colors = {
            "up":   ("#4caf50", "#1b5e20"),   # (text, bg-tint)
            "down": ("#ef5350", "#4e1111"),
            "flat": ("#aaaaaa", "#1a1a2e"),
        }
        _rvol_color = lambda r: (
            "#FFD700" if r is not None and r > 5.5 else
            "#FF6B35" if r is not None and r > 4.0 else
            "#FF9500" if r is not None and r > 3.0 else
            "#26a69a" if r is not None and r >= 1.2 else
            "#ef5350"
        )

        for row in results:
            sym   = row["ticker"]
            price = row["price"]
            gap   = row["gap_pct"]
            rvol  = row["pm_rvol"]
            pm_v  = row["pm_vol"]
            avg_v = row["avg_pm_vol"]

            gap_dir    = "up" if gap > 0.2 else "down" if gap < -0.2 else "flat"
            gap_txt    = f"+{gap:.2f}%" if gap >= 0 else f"{gap:.2f}%"
            gap_clr, gap_bg = _gap_colors[gap_dir]
            rc         = _rvol_color(rvol)
            rvol_str   = f"{rvol:.1f}×" if rvol is not None else "N/A"
            pm_str     = f"{pm_v:,}"
            avg_str    = f"{avg_v:,.0f}" if avg_v else "—"

            # ── Pre-trade quality data (computed in parallel during scan) ────
            _sq = st.session_state.get("scanner_quality", {}).get(sym)
            _tcs_v = _ib_pos = _tcs_bkt = _ib_h = _ib_l = _ib_src = None
            _tcs_ok = _ib_ok = _go = False
            _tcs_clr = _ib_clr = "#888"
            _go_txt = _go_clr = _go_bg = _go_brd = ""
            _ib_warn = _src_tag = ""
            _ov_key_h = f"_ib_ov_high_{sym}"
            _ov_key_l = f"_ib_ov_low_{sym}"
            _ov_h = st.session_state.get(_ov_key_h)
            _ov_l = st.session_state.get(_ov_key_l)
            _has_quality = bool(_sq and not _sq.get("error"))

            if _has_quality:
                _tcs_v     = _sq["tcs"]
                _tcs_bkt   = _sq["tcs_bucket"]
                _tcs_ok    = _sq["tcs_ok"]
                _ib_formed = _sq.get("ib_formed", True)
                if _ov_h and _ov_l and _ov_h > _ov_l:
                    _ib_h, _ib_l, _ib_src = _ov_h, _ov_l, "Webull"
                else:
                    _ib_h, _ib_l, _ib_src = _sq["ib_high"], _sq["ib_low"], "Alpaca"
                _margin = (_ib_h - _ib_l) * 0.05
                if price >= _ib_h + _margin:       _ib_pos = "Extended Above IB"
                elif price <= _ib_l - _margin:     _ib_pos = "Extended Below IB"
                elif price <= _ib_l + _margin:     _ib_pos = "At IB Low"
                elif price >= _ib_h - _margin:     _ib_pos = "At IB High"
                else:                              _ib_pos = "Inside IB"
                _ib_ok  = _ib_pos == "At IB Low"
                _go     = _tcs_ok and _ib_ok
                _tcs_clr = "#4caf50" if _tcs_ok else "#FFD700" if _tcs_v >= 70 else "#ef5350"
                _ib_clr  = "#4caf50" if _ib_ok else "#ef5350" if "Extended" in _ib_pos else "#FF9500"
                _go_bg   = "#0d2e1a" if _go else "#2e0d0d"
                _go_brd  = "#4caf50" if _go else "#ef5350"
                _go_txt  = "✅ GO" if _go else "⛔ WAIT"
                _go_clr  = "#4caf50" if _go else "#ef5350"
                _ib_warn = "" if _ib_formed else " ⚠️"
                _src_tag = f'({_ib_src})'

            # ── Fallback quality row from gap data when market closed ────────
            _sq_err = (_sq or {}).get("error", "") if not _has_quality else ""
            _market_closed_fallback = not _has_quality and "No bar data" in _sq_err
            if _market_closed_fallback:
                _abs_gap = abs(gap)
                if _abs_gap >= 10:
                    _gq_lbl, _gq_clr = "Strong Gap", "#4caf50"
                elif _abs_gap >= 5:
                    _gq_lbl, _gq_clr = "Moderate Gap", "#FF9500"
                elif _abs_gap >= 2:
                    _gq_lbl, _gq_clr = "Weak Gap", "#FFD700"
                else:
                    _gq_lbl, _gq_clr = "Minimal", "#888"
                _rvol_fb = f"{rvol:.1f}×" if rvol and rvol > 0 else "—"
                _rvol_fb_clr = _rvol_color(rvol) if rvol and rvol > 0 else "#555"

            # ── Unified card — everything at a glance ────────────────────────
            _quality_row = ""
            if _has_quality:
                _quality_row = (
                    f'<div style="display:flex;align-items:center;flex-wrap:wrap;gap:14px;'
                    f'margin-top:10px;padding-top:10px;border-top:1px solid #1e2a3a;">'
                    f'<div style="text-align:center;min-width:52px;">'
                    f'<div style="font-size:9px;color:#555;text-transform:uppercase;margin-bottom:2px;">TCS</div>'
                    f'<div style="font-size:20px;font-weight:800;color:{_tcs_clr};">{_tcs_v}</div>'
                    f'<div style="font-size:9px;color:#555;">{_tcs_bkt}</div>'
                    f'</div>'
                    f'<div style="text-align:center;">'
                    f'<div style="font-size:9px;color:#555;text-transform:uppercase;margin-bottom:2px;">Structure{_ib_warn}</div>'
                    f'<div style="font-size:13px;font-weight:700;color:{_ib_clr};">{_ib_pos}</div>'
                    f'<div style="font-size:9px;color:#444;">IB ${_ib_l}–${_ib_h} {_src_tag}</div>'
                    f'</div>'
                    f'<div style="margin-left:auto;background:{_go_bg};border:2px solid {_go_brd};'
                    f'border-radius:8px;padding:6px 16px;text-align:center;">'
                    f'<div style="font-size:16px;font-weight:800;color:{_go_clr};">{_go_txt}</div>'
                    f'<div style="font-size:9px;color:#555;margin-top:1px;">'
                    f'TCS 55–70 {"✓" if _tcs_ok else "✗"} · At IB Low {"✓" if _ib_ok else "✗"}</div>'
                    f'</div>'
                    f'</div>'
                )
            elif _market_closed_fallback:
                _quality_row = (
                    f'<div style="display:flex;align-items:center;flex-wrap:wrap;gap:14px;'
                    f'margin-top:10px;padding-top:10px;border-top:1px solid #1e2a3a;">'
                    f'<div style="text-align:center;min-width:72px;">'
                    f'<div style="font-size:9px;color:#555;text-transform:uppercase;margin-bottom:2px;">Gap Quality</div>'
                    f'<div style="font-size:15px;font-weight:800;color:{_gq_clr};">{_gq_lbl}</div>'
                    f'<div style="font-size:9px;color:#555;">{abs(gap):.1f}% move</div>'
                    f'</div>'
                    f'<div style="text-align:center;">'
                    f'<div style="font-size:9px;color:#555;text-transform:uppercase;margin-bottom:2px;">PM RVOL</div>'
                    f'<div style="font-size:15px;font-weight:800;color:{_rvol_fb_clr};">{_rvol_fb}</div>'
                    f'</div>'
                    f'<div style="text-align:center;">'
                    f'<div style="font-size:9px;color:#555;text-transform:uppercase;margin-bottom:2px;">IB</div>'
                    f'<div style="font-size:13px;font-weight:700;color:#555;">Pending</div>'
                    f'<div style="font-size:9px;color:#444;">Forms 9:30–10:30 AM ET</div>'
                    f'</div>'
                    f'<div style="margin-left:auto;background:#1a1a2e;border:2px solid #333;'
                    f'border-radius:8px;padding:6px 16px;text-align:center;">'
                    f'<div style="font-size:14px;font-weight:700;color:#555;">🕐 After Open</div>'
                    f'<div style="font-size:9px;color:#444;margin-top:1px;">TCS + GO/WAIT after 10:30 AM</div>'
                    f'</div>'
                    f'</div>'
                )

            _border_clr = _go_brd if _has_quality else ("#1e3a2e" if _market_closed_fallback else "#2a2a4a")
            st.markdown(
                f'<div style="background:#12122299;border:1px solid {_border_clr};'
                f'border-left:4px solid {_border_clr};'
                f'border-radius:10px;padding:16px 20px;margin:8px 0;">'
                f'<div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:12px;">'
                f'<div>'
                f'<div style="font-size:26px;font-weight:900;color:#e0e0e0;letter-spacing:1px;">{sym}</div>'
                f'<div style="font-size:13px;color:#888;">${price:.2f}</div>'
                f'</div>'
                f'<div style="text-align:center;">'
                f'<div style="font-size:10px;color:#666;text-transform:uppercase;letter-spacing:1px;margin-bottom:3px;">Gap</div>'
                f'<div style="font-size:22px;font-weight:800;color:{gap_clr};">{gap_txt}</div>'
                f'</div>'
                f'<div style="text-align:center;">'
                f'<div style="font-size:10px;color:#666;text-transform:uppercase;letter-spacing:1px;margin-bottom:3px;">PM RVOL</div>'
                f'<div style="font-size:22px;font-weight:800;color:{rc};">{rvol_str}</div>'
                f'<div style="font-size:11px;color:#555;">{pm_str} vs avg {avg_str}</div>'
                f'</div>'
                f'</div>'
                + _quality_row +
                f'</div>',
                unsafe_allow_html=True,
            )

            # IB Override expander (only shown when quality data loaded)
            if _has_quality:
                with st.expander(f"✏️ Override IB levels for {sym} (use your Webull values)", expanded=False):
                    _ov_cols = st.columns(3)
                    _new_ib_h = _ov_cols[0].number_input(
                        "IB High", min_value=0.01, value=float(_ib_h),
                        step=0.01, format="%.2f", key=f"ib_h_input_{sym}"
                    )
                    _new_ib_l = _ov_cols[1].number_input(
                        "IB Low", min_value=0.01, value=float(_ib_l),
                        step=0.01, format="%.2f", key=f"ib_l_input_{sym}"
                    )
                    if _ov_cols[2].button("Apply", key=f"ib_ov_btn_{sym}", use_container_width=True):
                        if _new_ib_h > _new_ib_l:
                            st.session_state[_ov_key_h] = _new_ib_h
                            st.session_state[_ov_key_l] = _new_ib_l
                            st.rerun()
                        else:
                            st.error("IB High must be greater than IB Low.")
                    if _ov_h and _ov_l:
                        if st.button("↩ Reset to Alpaca values", key=f"ib_ov_reset_{sym}"):
                            st.session_state.pop(_ov_key_h, None)
                            st.session_state.pop(_ov_key_l, None)
                            st.rerun()

            if _sq and _sq.get("error") and "No bar data" not in _sq.get("error", ""):
                st.caption(f"⚠️ Quality check unavailable: {_sq['error']}")

            # ── Pattern Alert Badge ──────────────────────────────────────────
            _sp = st.session_state.get("scanner_patterns", {}).get(sym, [])
            _bullish_sp = [p for p in _sp if p["direction"] == "Bullish"]
            if _bullish_sp:
                _p_rows_html = ""
                for _p in _bullish_sp:
                    _pct = int(_p["score"] * 100)
                    _sc = "#4caf50" if _pct >= 80 else "#ffa726" if _pct >= 65 else "#ef9a9a"
                    _tfc = "#90caf9" if _p["timeframe"] == "1hr" else "#b0bec5"
                    _nl = _p.get("neckline")
                    _nl_html = (f' &middot; Neckline <b style="color:#FFD700;">'
                                f'${_nl:.2f}</b>') if _nl else ""
                    _cf = " &middot; ".join(_p["confluence"]) if _p["confluence"] else ""
                    _cf_html = (f'<div style="font-size:10px;color:#FFD700;margin-top:2px;">'
                                f'&#9889; {_cf}</div>') if _cf else ""
                    _p_rows_html += (
                        f'<div style="display:flex;align-items:flex-start;gap:10px;'
                        f'padding:6px 0;border-bottom:1px solid #1a3a1a;">'
                        f'<span style="font-size:18px;line-height:1;">&#128276;</span>'
                        f'<div style="flex:1;">'
                        f'<div style="font-size:12px;font-weight:700;color:#4caf50;">'
                        f'&#9650;&nbsp;{_p["name"]}</div>'
                        f'<div style="font-size:11px;color:#888;margin-top:1px;">'
                        f'{_p["description"]}{_nl_html}</div>'
                        f'{_cf_html}'
                        f'</div>'
                        f'<div style="text-align:right;white-space:nowrap;">'
                        f'<span style="font-size:11px;color:{_tfc};">{_p["timeframe"]}</span>'
                        f'&nbsp;<span style="font-size:14px;font-weight:700;color:{_sc};">'
                        f'{_pct}%</span></div>'
                        f'</div>'
                    )
                st.markdown(
                    f'<div style="background:#0a1f0a;border:1px solid #2a5a2a;'
                    f'border-radius:8px;padding:10px 16px;margin:4px 0;">'
                    f'<div style="font-size:11px;color:#4caf50;text-transform:uppercase;'
                    f'letter-spacing:1px;margin-bottom:6px;font-weight:700;">'
                    f'&#128276; Pattern Alerts</div>'
                    f'{_p_rows_html}'
                    f'</div>',
                    unsafe_allow_html=True,
                )

            # Clickable button — loads Volume Profile for this ticker
            if st.button(f"📊 Load {sym} Volume Profile", key=f"load_{sym}",
                         use_container_width=False):
                st.session_state["_load_ticker"] = sym
                st.session_state["_last_scan_load"] = sym
                st.session_state.auto_run = True
                st.rerun()

        _last = st.session_state.get("_last_scan_load", "")
        if _last:
            st.success(f"✅ **{_last}** loaded — click the **📈 Main Chart** tab to view the Volume Profile.")
        else:
            st.caption("Click a **Load** button to populate the ticker and switch to Main Chart.")

    # ── Watchlist Prediction Engine ────────────────────────────────────────────
    st.markdown("---")
    st.header("🔮 Watchlist Prediction Engine")
    st.caption(
        "Score every ticker in your saved watchlist, save the predictions, "
        "then verify next day to see how accurate the engine was."
    )

    # ── Supabase connectivity check ────────────────────────────────────────────
    _sb_ok = False
    if supabase:
        try:
            supabase.table("trade_journal").select("id").limit(1).execute()
            _sb_ok = True
        except Exception:
            _sb_ok = False
    if not _sb_ok:
        st.warning(
            "⚠️ **Supabase is offline** — predictions will score on-screen only "
            "and won't be saved. To enable saving, go to "
            "[supabase.com](https://supabase.com) → your project → "
            "**Restore / Resume** if paused. Once online, also run the table setup SQL "
            "in the expander below.",
            icon=None,
        )

    # ── Ticker source: saved watchlist OR direct input (fallback) ─────────────
    _saved_ticker_str = (
        st.session_state.get("_watchlist_tickers", "")
        or st.session_state.get("watchlist_textarea", "")
        or st.session_state.get("watchlist_raw", "")
    )
    _wpe_ticker_input = st.text_area(
        "Tickers to score (comma or newline separated)",
        value=_saved_ticker_str,
        height=60,
        key="wpe_ticker_input",
        placeholder="AAPL, GME, AMC — or paste from your watchlist",
        help="These tickers will be scored by the prediction engine. "
             "Auto-filled from your saved watchlist if available.",
    )
    _wpe_saved_tickers = [
        t.strip().upper()
        for t in _wpe_ticker_input.replace("\n", ",").split(",")
        if t.strip()
    ]
    _wpe_count = len(_wpe_saved_tickers)

    # ── Always-visible action buttons ─────────────────────────────────────────
    _wpe_feed = st.selectbox("Feed", ["iex", "sip"], key="wpe_feed_select",
                             help="IEX = free tier. SIP = full tape.")
    _wpe_col1, _wpe_col2, _wpe_col3 = st.columns(3)

    # Predict All — only active when tickers are entered
    if _wpe_count > 0:
        if _wpe_col1.button(f"🔮 Predict All ({_wpe_count})", use_container_width=True, key="wpe_predict_btn"):
            if not api_key or not secret_key:
                st.error("Add your Alpaca credentials in the sidebar first.")
            else:
                with st.spinner(f"Scoring {_wpe_count} tickers + generating setup briefs… (~45 s for large lists)"):
                    _wpe_rows = [{"ticker": t} for t in _wpe_saved_tickers]
                    import copy as _cp
                    import concurrent.futures as _cf
                    _wpe_scored = score_playbook_tickers(
                        _cp.deepcopy(_wpe_rows),
                        api_key, secret_key,
                        feed=_wpe_feed,
                        max_tickers=_wpe_count,
                        user_id=_AUTH_USER_ID,
                    )
                    # Always target the NEXT trading session (strictly after today)
                    # so predictions are never labeled with today's already-open session
                    _wpe_pred_date = get_next_trading_day(
                        as_of=date.today() + timedelta(days=1),
                        api_key=api_key,
                        secret_key=secret_key,
                    )

                    # Generate full setup briefs in parallel (one per ticker)
                    def _gen_brief(_r):
                        return compute_setup_brief(
                            api_key, secret_key,
                            _r["ticker"],
                            pred_date=_wpe_pred_date,
                            user_id=_AUTH_USER_ID,
                            feed=_wpe_feed,
                        )

                    _wpe_briefs = {}
                    with _cf.ThreadPoolExecutor(max_workers=4) as _exec:
                        _futures = {
                            _exec.submit(_gen_brief, r): r["ticker"]
                            for r in _wpe_scored
                        }
                        for _f in _cf.as_completed(_futures):
                            _tk = _futures[_f]
                            try:
                                _b = _f.result()
                                if _b and "error" not in _b:
                                    _wpe_briefs[_tk] = _b
                            except Exception:
                                pass

                    _wpe_payload = []
                    for r in _wpe_scored:
                        _tk = r["ticker"]
                        _brief = _wpe_briefs.get(_tk, {})
                        _row = {
                            "ticker":              _tk,
                            "pred_date":           _wpe_pred_date,
                            "predicted_structure": r.get("structure") or "—",
                            "tcs":                 r.get("tcs") or 0,
                            "edge_score":          r.get("edge_score") or 0,
                        }
                        if _brief:
                            _row.update({
                                "entry_zone_low":   _brief.get("entry_zone_low"),
                                "entry_zone_high":  _brief.get("entry_zone_high"),
                                "entry_trigger":    _brief.get("entry_trigger") or "",
                                "stop_level":       _brief.get("stop_level"),
                                "targets":          _brief.get("targets") or [],
                                "pattern":          _brief.get("pattern") or "",
                                "pattern_neckline": _brief.get("pattern_neckline"),
                                "win_rate_pct":     _brief.get("win_rate_pct"),
                                "win_rate_context": _brief.get("win_rate_context") or "",
                                "confidence_label": _brief.get("confidence_label") or "LOW",
                            })
                        _wpe_payload.append(_row)

                    _wpe_ok = save_watchlist_predictions(_wpe_payload, user_id=_AUTH_USER_ID)
                    _wpe_brief_count = len(_wpe_briefs)
                    st.session_state["_wpe_last_predictions"] = _wpe_scored
                    st.session_state["_wpe_last_briefs"]      = _wpe_briefs
                    st.session_state["_wpe_pred_date"] = str(_wpe_pred_date)
                    if _wpe_ok:
                        st.success(
                            f"✅ {len(_wpe_payload)} predictions saved for {_wpe_pred_date}"
                            + (f" · Setup briefs generated for {_wpe_brief_count}/{len(_wpe_payload)} tickers"
                               if _wpe_brief_count else "")
                        )
                    else:
                        st.warning("Scored locally — Supabase table missing. See setup section below.")
    else:
        _wpe_col1.button("🔮 Predict All", use_container_width=True, key="wpe_predict_btn", disabled=True)
        st.caption("⬅ Add tickers in **⭐ My Watchlist** sidebar then Save to enable Predict All.")

    # ── Verify — date picker + button ──────────────────────────────────────────
    _verify_date = _wpe_col2.date_input(
        "Verify date",
        value=date.today() - timedelta(days=1),
        max_value=date.today() - timedelta(days=1),
        key="wpe_verify_date",
        label_visibility="collapsed",
    )
    if _wpe_col2.button("✅ Verify Date", use_container_width=True, key="wpe_verify_btn"):
        if not api_key or not secret_key:
            st.error("Add your Alpaca credentials in the sidebar first.")
        else:
            with st.spinner("Fetching end-of-day data and verifying predictions…"):
                _vr = verify_watchlist_predictions(
                    api_key, secret_key,
                    user_id=_AUTH_USER_ID,
                    pred_date=_verify_date,
                )
            st.session_state["_wpe_verify_result"] = _vr

    # ── Load Saved — always visible ────────────────────────────────────────────
    if _wpe_col3.button("📂 Load Saved", use_container_width=True, key="wpe_load_btn"):
        _wpe_df = load_watchlist_predictions(user_id=_AUTH_USER_ID)
        st.session_state["_wpe_loaded_df"] = _wpe_df

    # ── Show verify result ─────────────────────────────────────────────────────
    _vr = st.session_state.get("_wpe_verify_result")
    if _vr:
        if _vr.get("error") and _vr.get("verified", 0) == 0:
            st.warning(f"Verify: {_vr['error']}")
        else:
            _acc_color = "#4caf50" if _vr["accuracy"] >= 60 else "#ff9800" if _vr["accuracy"] >= 45 else "#ef5350"
            _vr_total  = _vr.get("total", _vr["verified"])
            _vr_wrong  = _vr["verified"] - _vr["correct"]
            try:
                _vr_date_fmt = date.fromisoformat(_vr.get("date","")).strftime("%b %-d, %Y")
            except Exception:
                _vr_date_fmt = _vr.get("date", "")
            # Show note if bar data came from a different (next) trading day
            _vr_bar_date  = _vr.get("bar_date", _vr.get("date", ""))
            _bar_note = ""
            if _vr_bar_date and _vr_bar_date != _vr.get("date", ""):
                try:
                    _bar_fmt  = date.fromisoformat(_vr_bar_date).strftime("%b %-d")
                    _bar_note = f" &nbsp;·&nbsp; bars from {_bar_fmt} (next trading day)"
                except Exception:
                    pass
            st.markdown(
                f'<div style="background:#12122299;border:1px solid #2a2a4a;border-radius:10px;'
                f'padding:14px 20px;margin:8px 0;">'
                f'<div style="font-size:10px;color:#555;text-transform:uppercase;letter-spacing:1px;margin-bottom:10px;">'
                f'Verify Results — Pred Date: {_vr_date_fmt}{_bar_note}</div>'
                f'<div style="display:flex;gap:32px;align-items:center;flex-wrap:wrap;">'
                f'<div style="text-align:center;">'
                f'<div style="font-size:11px;color:#888;text-transform:uppercase;margin-bottom:2px;">Verified</div>'
                f'<div style="font-size:26px;font-weight:800;color:#e0e0e0;">{_vr["verified"]}'
                f'<span style="font-size:13px;color:#555;">/{_vr_total}</span></div>'
                f'<div style="font-size:9px;color:#555;">predictions checked</div>'
                f'</div>'
                f'<div style="text-align:center;">'
                f'<div style="font-size:11px;color:#888;text-transform:uppercase;margin-bottom:2px;">Correct</div>'
                f'<div style="font-size:26px;font-weight:800;color:#4caf50;">{_vr["correct"]}</div>'
                f'<div style="font-size:9px;color:#555;">structure matched</div>'
                f'</div>'
                f'<div style="text-align:center;">'
                f'<div style="font-size:11px;color:#888;text-transform:uppercase;margin-bottom:2px;">Wrong</div>'
                f'<div style="font-size:26px;font-weight:800;color:#ef5350;">{_vr_wrong}</div>'
                f'<div style="font-size:9px;color:#555;">structure missed</div>'
                f'</div>'
                f'<div style="text-align:center;">'
                f'<div style="font-size:11px;color:#888;text-transform:uppercase;margin-bottom:2px;">Accuracy</div>'
                f'<div style="font-size:26px;font-weight:800;color:{_acc_color};">{_vr["accuracy"]:.1f}%</div>'
                f'<div style="font-size:9px;color:#555;">correct / verified</div>'
                f'</div>'
                f'</div>'
                f'</div>',
                unsafe_allow_html=True,
            )

    # ── Show predictions table ─────────────────────────────────────────────────
    _wpe_preds = st.session_state.get("_wpe_last_predictions")
    _wpe_df_loaded = st.session_state.get("_wpe_loaded_df")

    if _wpe_preds:
        _wpe_briefs_ss = st.session_state.get("_wpe_last_briefs", {})
        _wpe_for_date = st.session_state.get("_wpe_pred_date", "")
        try:
            _wpe_for_fmt = date.fromisoformat(str(_wpe_for_date)).strftime("%b %-d, %Y")
        except Exception:
            _wpe_for_fmt = str(_wpe_for_date)
        st.subheader(f"📋 Predictions for Trading Session: {_wpe_for_fmt}")
        st.caption("These are your predictions to validate when the market opens on that date. "
                   "Run ✅ Verify Date after close to check accuracy.")

        if _wpe_briefs_ss:
            # Rich setup brief cards (with key levels)
            _sc = {
                "Trending Up":       ("#4caf50", "▲"), "Trending Down":     ("#ef5350", "▼"),
                "At IB High":        ("#ffa726", "◆"), "At IB Low":         ("#29b6f6", "◆"),
                "Inside IB":         ("#9e9e9e", "◼"), "Extended Above IB":  ("#7c4dff", "▲"),
                "Extended Below IB": ("#ff5252", "▼"),
            }
            _cc = {"HIGH": ("#4caf50", "🟢"), "MODERATE": ("#ffa726", "🟡"), "LOW": ("#9e9e9e", "⚪")}
            for r in _wpe_preds:
                _tk = r["ticker"]
                b   = _wpe_briefs_ss.get(_tk, {})
                if not b:
                    continue
                _pstr = b.get("predicted_structure", r.get("structure", "—"))
                _pclr, _pico = _sc.get(_pstr, ("#888", "●"))
                _conf = b.get("confidence_label", "LOW")
                _cclr, _cico = _cc.get(_conf, ("#9e9e9e", "⚪"))
                _elo  = b.get("entry_zone_low")
                _ehi  = b.get("entry_zone_high")
                _stop = b.get("stop_level")
                _tgts = b.get("targets") or []
                _trig = str(b.get("entry_trigger") or "—")
                _pat  = str(b.get("pattern") or "")
                _nl   = b.get("pattern_neckline")
                _wrc  = str(b.get("win_rate_context") or "No calibration data yet.")
                _wrp  = b.get("win_rate_pct")
                # Key levels
                _pdh  = b.get("pdh"); _pdl = b.get("pdl"); _pdc = b.get("pdc")
                _onh  = b.get("onh"); _onl = b.get("onl")
                _rns  = b.get("round_numbers") or []
                _sh   = b.get("swing_highs") or []
                _sl   = b.get("swing_lows") or []
                _has_conf = b.get("has_confluence", False)
                _entry_str = (f"${_elo:.4f} – ${_ehi:.4f}"
                              if _elo is not None and _ehi is not None else "—")
                _stop_str  = f"${_stop:.4f}" if _stop is not None else "—"
                _tgt_str   = "  ·  ".join(f"R{i+1} ${t:.4f}" for i, t in enumerate(_tgts[:3]))
                _pat_str   = f"{_pat} · nkl ${_nl:.4f}" if _pat and _nl else (_pat or "")
                _wr_display = (f"  ·  {_cico} {_conf} ({_wrp:.0f}%)" if _wrp
                               else f"  ·  {_cico} {_conf}")
                # Key level badges string
                _kl_parts = []
                if _pdh: _kl_parts.append(f'<span style="background:#ef535022;border:1px solid #ef535044;'
                                           f'border-radius:3px;padding:1px 5px;font-size:9px;color:#ef5350;">PDH ${_pdh:.4f}</span>')
                if _pdl: _kl_parts.append(f'<span style="background:#4caf5022;border:1px solid #4caf5044;'
                                           f'border-radius:3px;padding:1px 5px;font-size:9px;color:#4caf50;">PDL ${_pdl:.4f}</span>')
                if _pdc: _kl_parts.append(f'<span style="background:#ffa72622;border:1px solid #ffa72644;'
                                           f'border-radius:3px;padding:1px 5px;font-size:9px;color:#ffa726;">PDC ${_pdc:.4f}</span>')
                if _onh: _kl_parts.append(f'<span style="background:#7c4dff22;border:1px solid #7c4dff44;'
                                           f'border-radius:3px;padding:1px 5px;font-size:9px;color:#ab82ff;">ONH ${_onh:.4f}</span>')
                if _onl: _kl_parts.append(f'<span style="background:#29b6f622;border:1px solid #29b6f644;'
                                           f'border-radius:3px;padding:1px 5px;font-size:9px;color:#29b6f6;">ONL ${_onl:.4f}</span>')
                for _rn in _rns[:3]:
                    _kl_parts.append(f'<span style="background:#37474f;border:1px solid #546e7a;'
                                     f'border-radius:3px;padding:1px 5px;font-size:9px;color:#90a4ae;">'
                                     f'${_rn:.2f} round</span>')
                for _sv in _sh[:2]:
                    _kl_parts.append(f'<span style="background:#ef535011;border:1px solid #ef535033;'
                                     f'border-radius:3px;padding:1px 5px;font-size:9px;color:#ef9a9a;">liq↑ ${_sv:.4f}</span>')
                for _sv in _sl[:2]:
                    _kl_parts.append(f'<span style="background:#4caf5011;border:1px solid #4caf5033;'
                                     f'border-radius:3px;padding:1px 5px;font-size:9px;color:#a5d6a7;">liq↓ ${_sv:.4f}</span>')
                _kl_html = ('<div style="display:flex;flex-wrap:wrap;gap:4px;margin-bottom:6px;">'
                            + "".join(_kl_parts) + '</div>') if _kl_parts else ""
                _conf_badge = (' <span style="background:#ffa72633;border:1px solid #ffa72666;'
                               'border-radius:3px;padding:1px 6px;font-size:9px;color:#ffa726;">⭐ CONFLUENCE</span>'
                               if _has_conf else "")
                st.markdown(
                    f'<div style="background:#071b2e;border:1px solid #1e3a5f;border-left:4px solid {_pclr};'
                    f'border-radius:8px;padding:12px 16px;margin-bottom:10px;">'
                    f'<div style="display:flex;align-items:center;gap:10px;margin-bottom:8px;">'
                    f'<span style="font-size:15px;font-weight:800;color:#fff;">{_tk}</span>'
                    f'<span style="background:{_pclr}22;border:1px solid {_pclr}66;border-radius:5px;'
                    f'padding:2px 8px;font-size:11px;color:{_pclr};">{_pico} {_pstr}</span>'
                    + (f'<span style="background:#1a1a1a;border:1px solid #333;border-radius:5px;'
                       f'padding:2px 8px;font-size:10px;color:#aaa;">{_pat_str}</span>' if _pat_str else "")
                    + f'<span style="font-size:10px;color:#666;margin-left:4px;">TCS {b.get("tcs",0):.0f}'
                    f'  RVOL {b.get("rvol_band","")}</span>'
                    + _conf_badge
                    + f'</div>'
                    + _kl_html
                    + f'<div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:8px;margin-bottom:8px;">'
                    f'<div style="background:#0d2a42;border-radius:5px;padding:6px 10px;">'
                    f'<div style="font-size:9px;color:#555;text-transform:uppercase;margin-bottom:3px;">Entry Zone</div>'
                    f'<div style="font-size:12px;color:#29b6f6;font-weight:600;">{_entry_str}</div></div>'
                    f'<div style="background:#0d2a42;border-radius:5px;padding:6px 10px;">'
                    f'<div style="font-size:9px;color:#555;text-transform:uppercase;margin-bottom:3px;">Stop</div>'
                    f'<div style="font-size:12px;color:#ef5350;font-weight:600;">{_stop_str}</div></div>'
                    f'<div style="background:#0d2a42;border-radius:5px;padding:6px 10px;">'
                    f'<div style="font-size:9px;color:#555;text-transform:uppercase;margin-bottom:3px;">Targets</div>'
                    f'<div style="font-size:11px;color:#4caf50;font-weight:600;">{_tgt_str or "—"}</div></div></div>'
                    f'<div style="font-size:10px;color:#aaa;margin-bottom:4px;line-height:1.4;">'
                    f'<span style="color:#ffa726;font-weight:600;">Trigger:</span> {_trig}</div>'
                    f'<div style="font-size:10px;color:#7986cb;line-height:1.4;">'
                    f'<span style="font-weight:600;">Win Rate:</span> {_wrc}{_wr_display}</div>'
                    f'</div>',
                    unsafe_allow_html=True,
                )
        else:
            # Fallback simple table when briefs not available
            _wpe_display = []
            for r in _wpe_preds:
                _tcs_v = r.get("tcs")
                _edg_v = r.get("edge_score")
                _wpe_display.append({
                    "Ticker":    r["ticker"],
                    "Structure": r.get("structure") or "—",
                    "TCS":       f"{_tcs_v:.0f}" if _tcs_v is not None else "—",
                    "Edge":      f"{_edg_v:.0f}" if _edg_v is not None else "—",
                })
            st.dataframe(
                _wpe_display,
                use_container_width=True,
                height=min(400, 35 + 35 * len(_wpe_display)),
            )

    elif _wpe_df_loaded is not None and not _wpe_df_loaded.empty:
        st.subheader("📂 Saved Predictions")
        st.caption("Grouped by trading session date — most recent first. "
                   "TCS and Edge are blank for rows saved before the Supabase schema update.")

        _show_cols = ["ticker", "predicted_structure", "tcs", "edge_score",
                      "actual_structure", "correct"]
        _grp_df = _wpe_df_loaded.copy()

        # Normalize pred_date to string for grouping
        if "pred_date" in _grp_df.columns:
            _grp_df["pred_date"] = _grp_df["pred_date"].astype(str)
            _all_dates = sorted(_grp_df["pred_date"].unique(), reverse=True)
        else:
            _all_dates = ["(unknown)"]
            _grp_df["pred_date"] = "(unknown)"

        for _sess_date in _all_dates:
            try:
                _sess_fmt = date.fromisoformat(_sess_date).strftime("%b %-d, %Y")
            except Exception:
                _sess_fmt = _sess_date

            _sess_df = _grp_df[_grp_df["pred_date"] == _sess_date].copy()
            _n_rows  = len(_sess_df)
            _n_corr  = (_sess_df.get("correct", pd.Series()) == "✅").sum() if "correct" in _sess_df.columns else 0
            _n_ver   = (_sess_df.get("correct", pd.Series()).isin(["✅", "❌"])).sum() if "correct" in _sess_df.columns else 0
            _acc_str = f" · {_n_corr}/{_n_ver} correct" if _n_ver > 0 else " · unverified"

            # Most recent date auto-expanded
            _is_next = (_sess_date == _all_dates[0])
            with st.expander(
                f"📅 Session: {_sess_fmt}  —  {_n_rows} ticker{'s' if _n_rows != 1 else ''}{_acc_str}",
                expanded=_is_next,
            ):
                _disp_df = _sess_df[[c for c in _show_cols if c in _sess_df.columns]].copy()
                _col_rename = {
                    "ticker": "Ticker",
                    "predicted_structure": "Predicted Structure",
                    "tcs": "TCS",
                    "edge_score": "Edge",
                    "actual_structure": "Actual Structure",
                    "correct": "Correct?",
                }
                _disp_df.rename(columns=_col_rename, inplace=True)
                if "TCS" in _disp_df.columns:
                    _disp_df["TCS"] = _disp_df["TCS"].apply(
                        lambda x: f"{x:.0f}" if pd.notna(x) and x != "" else "—"
                    )
                if "Edge" in _disp_df.columns:
                    _disp_df["Edge"] = _disp_df["Edge"].apply(
                        lambda x: f"{x:.0f}" if pd.notna(x) and x != "" else "—"
                    )
                st.dataframe(
                    _disp_df, use_container_width=True,
                    height=min(400, 40 + 36 * len(_disp_df)),
                    hide_index=True,
                )
    elif _wpe_df_loaded is not None:
        st.info("No saved predictions found. Run **🔮 Predict All** first.")

    # ── Setup instructions if table missing ───────────────────────────────────
    with st.expander("⚙️ First-time Supabase setup for predictions", expanded=False):
        st.caption("**New table** — run this SQL once in your Supabase SQL editor to enable predictions + setup briefs:")
        st.code(
            "CREATE TABLE IF NOT EXISTS watchlist_predictions (\n"
            "  id                 BIGSERIAL PRIMARY KEY,\n"
            "  user_id            TEXT,\n"
            "  ticker             TEXT,\n"
            "  pred_date          DATE,\n"
            "  predicted_structure TEXT,\n"
            "  tcs                FLOAT,\n"
            "  edge_score         FLOAT,\n"
            "  actual_structure   TEXT DEFAULT '',\n"
            "  verified           BOOLEAN DEFAULT FALSE,\n"
            "  correct            TEXT DEFAULT '',\n"
            "  entry_zone_low     FLOAT,\n"
            "  entry_zone_high    FLOAT,\n"
            "  entry_trigger      TEXT DEFAULT '',\n"
            "  stop_level         FLOAT,\n"
            "  targets            JSONB,\n"
            "  pattern            TEXT DEFAULT '',\n"
            "  pattern_neckline   FLOAT,\n"
            "  win_rate_pct       FLOAT,\n"
            "  win_rate_context   TEXT DEFAULT '',\n"
            "  confidence_label   TEXT DEFAULT 'LOW',\n"
            "  UNIQUE(user_id, ticker, pred_date)\n"
            ");",
            language="sql",
        )
        st.caption("**Existing table migration** — if you already have the table, run this to add the setup brief columns:")
        st.code(
            "ALTER TABLE watchlist_predictions\n"
            "  ADD COLUMN IF NOT EXISTS entry_zone_low     FLOAT,\n"
            "  ADD COLUMN IF NOT EXISTS entry_zone_high    FLOAT,\n"
            "  ADD COLUMN IF NOT EXISTS entry_trigger      TEXT DEFAULT '',\n"
            "  ADD COLUMN IF NOT EXISTS stop_level         FLOAT,\n"
            "  ADD COLUMN IF NOT EXISTS targets            JSONB,\n"
            "  ADD COLUMN IF NOT EXISTS pattern            TEXT DEFAULT '',\n"
            "  ADD COLUMN IF NOT EXISTS pattern_neckline   FLOAT,\n"
            "  ADD COLUMN IF NOT EXISTS win_rate_pct       FLOAT,\n"
            "  ADD COLUMN IF NOT EXISTS win_rate_context   TEXT DEFAULT '',\n"
            "  ADD COLUMN IF NOT EXISTS confidence_label   TEXT DEFAULT 'LOW';",
            language="sql",
        )
        st.caption("Go to supabase.com → your project → SQL Editor → paste and run.")

# ── Volume Profile tab: auto_run + all historical/live content ─────────────────
# Consume the auto-run flag set by scanner ticker buttons (runs before tab renders)
auto_trigger = st.session_state.get("auto_run", False)
if auto_trigger:
    st.session_state.auto_run = False

with tab_chart:
    # ── Historical mode ────────────────────────────────────────────────────────
    if mode == "📅 Historical":
        if run_button or auto_trigger:
            if not api_key or not secret_key:
                st.error("Enter your Alpaca credentials in the sidebar.")
            elif not ticker:
                st.error("Enter a ticker symbol.")
            elif selected_date.weekday() >= 5:
                st.error("Selected date is a weekend. Pick a weekday (Mon–Fri).")
            else:
                # Fresh analysis — reset alert state so alerts fire for this data
                st.session_state.tcs_fired_high = False
                st.session_state.tcs_was_high = False
                with st.spinner(f"Fetching 1-min bars for **{ticker}** on {selected_date} ({data_feed.upper()})..."):
                    try:
                        df = fetch_bars(api_key, secret_key, ticker, selected_date, feed=data_feed)
                        if df.empty:
                            now_et = datetime.now(EASTERN)
                            pre_mkt = (selected_date >= now_et.date() and
                                       now_et <= EASTERN.localize(datetime(selected_date.year, selected_date.month, selected_date.day, 9, 30)))
                            if pre_mkt:
                                st.warning("Market hasn't opened yet (9:30 AM ET). Come back once trading starts and bars are available.")
                            elif data_feed == "sip":
                                st.warning(f"No data for **{ticker}** on {selected_date} via SIP. Try switching to IEX, or confirm the date was a trading day.")
                            else:
                                st.warning(f"No data for **{ticker}** on {selected_date} via IEX. Small-caps may be absent on IEX — try SIP.")
                        else:
                            st.success(f"Loaded **{len(df)}** 1-min bars via {data_feed.upper()}.")
                            # ── Pre-fetch RVOL baseline (5-day avg daily volume) ──────
                            try:
                                avg_vol = fetch_avg_daily_volume(
                                    api_key, secret_key, ticker, selected_date)
                            except Exception:
                                avg_vol = None
                            st.session_state.rvol_avg_vol = avg_vol

                            # ── Time-segmented RVOL intraday curve ───────────────────
                            try:
                                curve = build_rvol_intraday_curve(
                                    api_key, secret_key, ticker, selected_date,
                                    lookback_days=50, feed=data_feed)
                            except Exception:
                                curve = None
                            st.session_state.rvol_intraday_curve = curve

                            # ── Sector ETF % change for that date ────────────────────
                            try:
                                etf_chg = fetch_etf_pct_change(
                                    api_key, secret_key, sector_etf, selected_date, feed=data_feed)
                            except Exception:
                                etf_chg = 0.0
                            sector_bonus = 10.0 if etf_chg > 1.0 else 0.0
                            st.session_state.sector_pct_chg = etf_chg

                            render_analysis(df, num_bins, ticker,
                                            f"{ticker} — Volume Profile | {selected_date.strftime('%B %d, %Y')}",
                                            avg_daily_vol=avg_vol,
                                            sector_bonus=sector_bonus,
                                            sector_etf=sector_etf,
                                            intraday_curve=curve,
                                            is_live=False)
                            render_log_entry_ui()
                    except Exception as e:
                        err = str(e)
                        if "forbidden" in err.lower() or "403" in err or "unauthorized" in err.lower():
                            st.error("Authentication failed — check your API Key and Secret Key.")
                        elif "subscription" in err.lower() or "not entitled" in err.lower() or "422" in err:
                            if data_feed == "sip":
                                st.warning("SIP feed requires a paid Alpaca subscription. Retrying with IEX…")
                                try:
                                    df2 = fetch_bars(api_key, secret_key, ticker, selected_date, feed="iex")
                                    if df2.empty:
                                        st.error(f"No data for **{ticker}** on {selected_date} via IEX either. Confirm the date was a trading day and the ticker is valid.")
                                    else:
                                        st.success(f"Loaded **{len(df2)}** 1-min bars via IEX (auto-switched from SIP).")
                                        render_analysis(df2, num_bins, ticker,
                                                        f"{ticker} — Volume Profile | {selected_date.strftime('%B %d, %Y')} (IEX)",
                                                        avg_daily_vol=None, sector_bonus=0.0,
                                                        sector_etf=sector_etf, intraday_curve=None,
                                                        is_live=False)
                                        render_log_entry_ui()
                                except Exception as e2:
                                    st.error(f"IEX fallback also failed: {e2}")
                            else:
                                st.error("Not subscribed to IEX feed — check your Alpaca account.")
                        else:
                            st.error(f"Error: {err}")
        else:
            # If a previous analysis exists (e.g. user clicked LOG ENTRY), show
            # the log panel instead of resetting to the welcome screen.
            if st.session_state.get("last_analysis_state"):
                render_log_entry_ui()
            else:
                st.info("👈 Enter credentials and settings in the sidebar, then click **Fetch & Analyze**.")
                st.markdown("### How it works")
                c1, c2, c3 = st.columns(3)
                with c1:
                    st.markdown("**📊 Volume Profile**")
                    st.markdown("Bins the day's 1-min bars to show where volume concentrated.")
                with c2:
                    st.markdown("**🎯 Point of Control**")
                    st.markdown("Gold line — the price level with the highest volume. Price gravitates here.")
                with c3:
                    st.markdown("**📐 Initial Balance**")
                    st.markdown("9:30–10:30 EST High/Low — the key reference range for day structure.")

    # ── Replay mode ────────────────────────────────────────────────────────────
    elif mode == "🎬 Replay":
        # ── Load full-day bars on demand ──────────────────────────────────────
        if replay_load:
            if not api_key or not secret_key:
                st.error("Enter your Alpaca credentials in the sidebar.")
            elif not ticker:
                st.error("Enter a ticker symbol.")
            elif selected_date.weekday() >= 5:
                st.error("Selected date is a weekend. Pick a weekday.")
            else:
                with st.spinner(f"Loading full day for **{ticker}** on {selected_date} ({data_feed.upper()})..."):
                    try:
                        _rdf = fetch_bars(api_key, secret_key, ticker, selected_date, feed=data_feed)
                        if _rdf.empty:
                            st.error("No bars returned. Check the ticker/date/feed.")
                        else:
                            st.session_state.replay_bars    = _rdf
                            st.session_state.replay_bar_idx = 0
                            st.session_state.replay_playing = False
                            st.session_state.replay_ticker  = ticker
                            st.session_state.replay_date    = selected_date
                            # Pre-fetch baselines for the replay session
                            try:
                                st.session_state.replay_avg_vol = fetch_avg_daily_volume(
                                    api_key, secret_key, ticker, selected_date)
                            except Exception:
                                st.session_state.replay_avg_vol = None
                            try:
                                st.session_state.replay_intraday_curve = build_rvol_intraday_curve(
                                    api_key, secret_key, ticker, selected_date,
                                    lookback_days=50, feed=data_feed)
                            except Exception:
                                st.session_state.replay_intraday_curve = None
                            try:
                                _etf = fetch_etf_pct_change(
                                    api_key, secret_key, sector_etf, selected_date, feed=data_feed)
                                st.session_state.replay_sector_bonus = 10.0 if _etf > 1.0 else 0.0
                            except Exception:
                                st.session_state.replay_sector_bonus = 0.0
                            # Reset Brain state for fresh replay
                            for _bk in ("brain_ib_high", "brain_ib_low", "brain_ib_set",
                                        "brain_high_touched", "brain_low_touched", "brain_predicted"):
                                st.session_state[_bk] = _DEFAULTS[_bk]
                            st.success(f"✅ Loaded {len(_rdf)} bars — use the slider and controls in the sidebar to replay.")
                            st.rerun()
                    except Exception as _e:
                        st.error(f"Load error: {_e}")

        # ── Run analysis for current replay bar ───────────────────────────────
        if st.session_state.replay_bars is not None:
            _rdf    = st.session_state.replay_bars
            _ridx   = st.session_state.replay_bar_idx
            _rtk    = st.session_state.replay_ticker
            _rdate  = st.session_state.replay_date
            _df_now = _rdf.iloc[:_ridx + 1]   # only bars up to current time

            _cur_et  = pd.Timestamp(_rdf.index[_ridx]).tz_convert(EASTERN)
            _total_et = pd.Timestamp(_rdf.index[-1]).tz_convert(EASTERN)

            # Clock banner
            st.markdown(
                f'<div style="background:#0f3460; border:1px solid #5c6bc0; border-radius:8px; '
                f'padding:10px 20px; margin-bottom:10px; display:flex; align-items:center; gap:16px;">'
                f'<span style="font-size:22px; font-family:monospace; color:#90caf9; font-weight:700;">'
                f'🎬 {_cur_et.strftime("%H:%M")} ET</span>'
                f'<span style="font-size:12px; color:#888;">Bar {_ridx + 1} / {len(_rdf)} &nbsp;|&nbsp; '
                f'{_rtk} &nbsp;|&nbsp; {_rdate}</span>'
                f'<span style="font-size:11px; color:#555; margin-left:auto;">'
                f'through {_total_et.strftime("%H:%M")} ET total</span></div>',
                unsafe_allow_html=True,
            )

            if len(_df_now) < 2:
                st.info("Need at least 2 bars for a full analysis — advance the slider forward.")
            else:
                render_analysis(
                    _df_now, num_bins, _rtk,
                    f"🎬 Replay — {_rtk} | {_cur_et.strftime('%H:%M ET')} | {_rdate}",
                    is_ib_live=(_cur_et.time() <= dtime(10, 30)),
                    avg_daily_vol=st.session_state.replay_avg_vol,
                    sector_bonus=st.session_state.replay_sector_bonus,
                    sector_etf=sector_etf,
                    intraday_curve=st.session_state.replay_intraday_curve,
                    is_live=False,
                )
                render_log_entry_ui()
        else:
            st.info("👈 Pick a date and click **📥 Load Day for Replay** in the sidebar.")
            rc1, rc2 = st.columns(2)
            with rc1:
                st.markdown("**How Replay works**")
                st.markdown(
                    "- Fetches the full day's bars once\n"
                    "- Shows only bars up to the selected time\n"
                    "- All analysis (Volume Profile, Structure, TCS, Brain) updates in real-time\n"
                    "- Use the slider to jump to any moment, or ▶ Play to auto-advance"
                )
            with rc2:
                st.markdown("**Uses**")
                st.markdown(
                    "- Review your trade decisions at the exact moment you entered\n"
                    "- See how the IB formed bar by bar\n"
                    "- Practice reading structure before it becomes obvious\n"
                    "- Study how RVOL evolved during the session"
                )

    # ── Live mode ──────────────────────────────────────────────────────────────
    else:
        if start_live:
            if not api_key or not secret_key:
                st.error("Enter your Alpaca credentials first.")
            elif not ticker:
                st.error("Enter a ticker symbol.")
            else:
                today = date.today()

                # ── Step 1: Pre-load today's historical bars (9:30 AM → now) ──
                _hist_bars: list = []
                with st.spinner(
                    f"Pre-loading today's session bars for {ticker} — "
                    "IB, VWAP, volume profile, and TCS will be fully seeded at start…"
                ):
                    try:
                        _hist_df = fetch_bars(api_key, secret_key, ticker,
                                              today, feed=live_feed)
                        if not _hist_df.empty:
                            for _ts, _row in _hist_df.iterrows():
                                _hist_bars.append({
                                    "open":      float(_row["open"]),
                                    "high":      float(_row["high"]),
                                    "low":       float(_row["low"]),
                                    "close":     float(_row["close"]),
                                    "volume":    float(_row["volume"]),
                                    "timestamp": _ts,
                                })
                    except Exception:
                        _hist_bars = []

                # ── Step 2: RVOL baseline and sector ETF ───────────────────────
                with st.spinner("Computing RVOL baseline & sector data…"):
                    try:
                        avg_vol = fetch_avg_daily_volume(api_key, secret_key, ticker, today)
                    except Exception:
                        avg_vol = None
                    st.session_state.rvol_avg_vol = avg_vol

                    try:
                        curve = build_rvol_intraday_curve(
                            api_key, secret_key, ticker, today,
                            lookback_days=50, feed=live_feed)
                    except Exception:
                        curve = None
                    st.session_state.rvol_intraday_curve = curve

                    try:
                        etf_chg = fetch_etf_pct_change(
                            api_key, secret_key, sector_etf, today, feed=live_feed)
                    except Exception:
                        etf_chg = 0.0
                    st.session_state.sector_pct_chg = etf_chg

                # ── Step 3: Start WebSocket — seeded with full day context ─────
                start_stream(api_key, secret_key, ticker, live_feed,
                             historical_bars=_hist_bars if _hist_bars else None)
                if _hist_bars:
                    st.success(
                        f"✅ Seeded {len(_hist_bars)} bars from today's session — "
                        "IB, VWAP, and volume profile are fully loaded."
                    )
                st.rerun()

        if stop_live:
            stop_stream()
            st.rerun()

        if st.session_state.live_error:
            err = st.session_state.live_error
            if "forbidden" in err.lower() or "unauthorized" in err.lower():
                st.error(f"Auth error: {err}. Check your API credentials.")
            elif "subscription" in err.lower() or "entitled" in err.lower():
                st.error("Subscription error: SIP requires an Alpaca data plan. Switch to IEX.")
            else:
                st.error(f"Stream error: {err}")

        if st.session_state.live_active:
            drain_queue()
            df = build_live_df()
            now_est = datetime.now(EASTERN)
            is_ib_live = now_est.time() <= dtime(10, 30)

            if df.empty:
                if now_est.time() < dtime(9, 30):
                    mins = int((datetime.combine(date.today(), dtime(9, 30)) -
                                now_est.replace(tzinfo=None)).total_seconds() // 60)
                    st.info(f"⏳ Market opens in ~{mins} min (9:30 AM EST). WebSocket connected, waiting...")
                elif now_est.time() > dtime(16, 0):
                    st.warning("Market is closed. No new data will arrive until tomorrow's session.")
                else:
                    st.info(f"🔌 Connected. Waiting for first trade on **{st.session_state.live_ticker}**... "
                            f"({now_est.strftime('%H:%M:%S')} EST)")
            else:
                chart_title = (f"🔴 LIVE — {st.session_state.live_ticker} | "
                               f"{now_est.strftime('%H:%M:%S')} EST"
                               + (" | 📐 IB FORMING" if is_ib_live else ""))
                live_sector_bonus = (10.0
                                     if st.session_state.get("sector_pct_chg", 0.0) > 1.0
                                     else 0.0)
                render_analysis(df, num_bins, st.session_state.live_ticker,
                                chart_title, is_ib_live=is_ib_live,
                                avg_daily_vol=st.session_state.get("rvol_avg_vol"),
                                sector_bonus=live_sector_bonus,
                                sector_etf=sector_etf,
                                intraday_curve=st.session_state.get("rvol_intraday_curve"),
                                is_live=True)
                render_log_entry_ui()
        else:
            if not st.session_state.live_error:
                st.info("👈 Enter credentials and ticker, then click **▶ Start Live Stream**.")
                st.markdown("### What Live Mode does")
                c1, c2, c3, c4 = st.columns(4)
                with c1:
                    st.markdown("**🔌 WebSocket Feed**")
                    st.markdown("Subscribes to real-time trades + 1-min bars from Alpaca.")
                with c2:
                    st.markdown("**📐 Dynamic IB**")
                    st.markdown("IB High/Low lines expand in real time from 9:30–10:30 AM EST.")
                with c3:
                    st.markdown("**⚡ Vol Velocity**")
                    st.markdown("Compares recent vol/min to prior bars — early breakout signal.")
                with c4:
                    st.markdown("**🎯 Probabilities**")
                    st.markdown("Every structure type scored continuously as the tape develops.")

# ── Playbook tab ──────────────────────────────────────────────────────────────
with tab_playbook:
    render_playbook_tab(api_key=api_key, secret_key=secret_key)

# ── Backtest tab ───────────────────────────────────────────────────────────────
with tab_backtest:
    render_backtest_tab(api_key=api_key, secret_key=secret_key)

# ── Journal tab ───────────────────────────────────────────────────────────────
with tab_journal:
    render_journal_tab(api_key=api_key, secret_key=secret_key)

# ── Analytics tab ─────────────────────────────────────────────────────────────
with tab_analytics:
    render_analytics_tab()

# ── Small Account Challenge tab ────────────────────────────────────────────────
with tab_sa:
    render_sa_tab()

# ── Paper Trade tab ────────────────────────────────────────────────────────────
with tab_paper:
    render_paper_trade_tab(api_key=api_key, secret_key=secret_key)

# ── Auto-refresh loop for live mode ───────────────────────────────────────────
if mode == "🔴 Live Stream" and st.session_state.live_active:
    time.sleep(2)
    st.rerun()

# ── Paper Trade live auto-scan loop ───────────────────────────────────────────
if st.session_state.get("_pt_live_mode"):
    _pt_now      = datetime.now(EASTERN)
    _pt_mkt_on   = (
        _pt_now.weekday() < 5
        and _pt_now.replace(hour=9, minute=30, second=0, microsecond=0)
        <= _pt_now
        <= _pt_now.replace(hour=16, minute=0, second=0, microsecond=0)
    )
    if _pt_mkt_on:
        _pt_last_ts  = st.session_state.get("_pt_last_auto_scan", 0)
        _pt_elapsed  = _pt_now.timestamp() - _pt_last_ts
        if _pt_elapsed >= 1800:
            _pt_at  = st.session_state.get("pt_scan_date", date.today())
            _pt_tkrs = [
                t.strip().upper()
                for t in st.session_state.get("pt_tickers", "").replace("\n", ",").split(",")
                if t.strip() and t.strip().isalpha()
            ]
            _pt_min  = st.session_state.get("pt_min_tcs", 50)
            _pt_fd   = "sip" if "SIP" in st.session_state.get("pt_feed", "SIP") else "iex"
            _pt_pr   = st.session_state.get("pt_price_range", (1.0, 20.0))
            if _pt_tkrs and api_key and secret_key:
                _auto_res, _auto_sum = run_historical_backtest(
                    api_key, secret_key,
                    trade_date=_pt_at,
                    tickers=_pt_tkrs,
                    feed=_pt_fd,
                    price_min=float(_pt_pr[0]),
                    price_max=float(_pt_pr[1]),
                    slippage_pct=0.0,
                )
                _auto_q = [
                    dict(r, sim_date=str(_pt_at))
                    for r in _auto_res
                    if float(r.get("tcs", 0)) >= _pt_min
                ]
                if _auto_q:
                    log_paper_trades(_auto_q, user_id=_AUTH_USER_ID, min_tcs=_pt_min)
                st.session_state["_pt_last_auto_scan"] = _pt_now.timestamp()
                st.session_state.pop("pt_tracker_df", None)
        time.sleep(60)
        st.rerun()

# ── Replay auto-advance loop ──────────────────────────────────────────────────
if (mode == "🎬 Replay"
        and st.session_state.replay_playing
        and st.session_state.replay_bars is not None):
    _rdf_all = st.session_state.replay_bars
    _max     = len(_rdf_all) - 1
    _nxt     = min(_max, st.session_state.replay_bar_idx + st.session_state.replay_speed)
    if _nxt >= _max:
        st.session_state.replay_playing = False   # reached end, stop
    st.session_state.replay_bar_idx = _nxt
    time.sleep(0.5)   # ~2 bars/sec at Normal speed
    st.rerun()
