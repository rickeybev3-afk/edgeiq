-- EdgeIQ Row Level Security — paste and run once in Supabase SQL Editor

ALTER TABLE trade_journal ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "edgeiq_user_isolation" ON trade_journal;
CREATE POLICY "edgeiq_user_isolation" ON trade_journal
  FOR ALL USING (user_id::text = auth.uid()::text)
  WITH CHECK (user_id::text = auth.uid()::text);

ALTER TABLE accuracy_tracker ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "edgeiq_user_isolation" ON accuracy_tracker;
CREATE POLICY "edgeiq_user_isolation" ON accuracy_tracker
  FOR ALL USING (user_id::text = auth.uid()::text)
  WITH CHECK (user_id::text = auth.uid()::text);

ALTER TABLE user_watchlist ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "edgeiq_user_isolation" ON user_watchlist;
CREATE POLICY "edgeiq_user_isolation" ON user_watchlist
  FOR ALL USING (user_id::text = auth.uid()::text)
  WITH CHECK (user_id::text = auth.uid()::text);

ALTER TABLE user_preferences ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "edgeiq_user_isolation" ON user_preferences;
CREATE POLICY "edgeiq_user_isolation" ON user_preferences
  FOR ALL USING (user_id::text = auth.uid()::text)
  WITH CHECK (user_id::text = auth.uid()::text);

ALTER TABLE paper_trades ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "edgeiq_user_isolation" ON paper_trades;
CREATE POLICY "edgeiq_user_isolation" ON paper_trades
  FOR ALL USING (user_id::text = auth.uid()::text)
  WITH CHECK (user_id::text = auth.uid()::text);

ALTER TABLE watchlist_predictions ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "edgeiq_user_isolation" ON watchlist_predictions;
CREATE POLICY "edgeiq_user_isolation" ON watchlist_predictions
  FOR ALL USING (user_id::text = auth.uid()::text)
  WITH CHECK (user_id::text = auth.uid()::text);

ALTER TABLE backtest_sim_runs ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "edgeiq_user_isolation" ON backtest_sim_runs;
CREATE POLICY "edgeiq_user_isolation" ON backtest_sim_runs
  FOR ALL USING (user_id::text = auth.uid()::text)
  WITH CHECK (user_id::text = auth.uid()::text);

ALTER TABLE eod_notes ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "edgeiq_user_isolation" ON eod_notes;
CREATE POLICY "edgeiq_user_isolation" ON eod_notes
  FOR ALL USING (user_id::text = auth.uid()::text)
  WITH CHECK (user_id::text = auth.uid()::text);

-- ── Alert tracking columns (run once) ──────────────────────────────────────
-- Captures the price at alert time and measures post-alert price movement.
-- alert_price      = IB close price at 10:30 AM when Telegram alert fires
-- alert_time       = UTC timestamp when the row was logged
-- post_alert_move_pct = (EOD close - alert_price) / alert_price × 100
ALTER TABLE paper_trades
  ADD COLUMN IF NOT EXISTS alert_price         NUMERIC,
  ADD COLUMN IF NOT EXISTS alert_time          TIMESTAMPTZ,
  ADD COLUMN IF NOT EXISTS post_alert_move_pct NUMERIC,
  ADD COLUMN IF NOT EXISTS structure_conf      NUMERIC;
