# EdgeIQ — Master Build Plan & Product Roadmap
*Last updated: April 6, 2026*

---

## 🎯 PRODUCT VISION

**EdgeIQ** — Personal win-rate calibration engine for small-cap volume profile trading.
- Stack: Python Streamlit (port 8080), Alpaca API, Supabase, Plotly — dark mode
- Differentiator: NOT a generic screener. Learns YOUR specific edge over time.
- Competitors: Trade Ideas, Tradervue, StocksToTrade — none do personal calibration
- Pricing: $79/month launch → $149/month post-automation phase
- End goal: Autonomous Alpaca paper → live trading after signal quality proven

---

## 🗺️ PRODUCTION PHASES

### Phase 1 — Manual Signal Quality Validation (CURRENT — IN PROGRESS)
**Goal:** Prove the model's signals are accurate before trusting any automation.

Daily workflow:
1. Pre-market → Load watchlist → **Predict All** (saves predictions for next trading day)
2. During session → Trade, take notes, track levels manually
3. After 4pm → Set date picker → **Verify Date** → scores predictions vs actual structure
4. Every verified trade feeds the win-rate calibration database

Done when: 50+ verified trades with consistent win-rate data per structure type

Current capabilities built:
- Volume profile (POC, VAH, VAL, HVN/LVN)
- **7-structure classification** (already built — see framework below)
- IB detection (9:30–10:30 ET, industry standard inclusive)
- TCS (Trade Confidence Score, 0–100)
- RVOL (time-segmented, 5-day baseline, pace-adjusted)
- Order flow signals — Tier 2 (pressure acceleration, bar quality, vol surge, tape streak)
- Predictive win rates per structure (Analytics tab)
- Trade journal with auto-grade A/B/C/F + grade discipline equity curve
- Watchlist predictions + EOD verification
- MarketBrain (live prediction vs actual tracker)
- Monte Carlo equity curves (1,000 simulations)
- Small Account Challenge tab
- Playbook screener tab
- Historical Backtest Engine tab
- Position management (entry/exit/P&L/MFE overlay on chart)
- Audio/visual alerts (Web Audio API)
- Pre-market gap scanner (30-ticker watchlist, gap% + PM RVOL)

### The Two-Layer Brain Architecture (April 8 insight — CRITICAL)

**Layer 1 — Personal brain (built)**
Each user's brain weights calibrate to their individual win rates per structure.
Your accuracy on Trend Day Up is yours alone. Nobody else's data touches it.

**Layer 2 — Collective brain (to build)**
Anonymized outcomes from ALL users, pooled across the platform.
"Across 847 verified trades from 312 users, Trend Day Up + TCS > 75 resolved correctly 84.7% of the time."
That's a market truth, not a personal opinion. Statistically significant at scale.

How they combine:
- Collective brain → establishes baseline signal quality per structure
- Personal brain → adjusts that baseline up/down based on your specific accuracy
- Final TCS score → market truth + personal edge modifier

Why this is the moat:
- Data network effect: user 1,000 gets a better product than user 10
- Not because code changed — because 999 people verified real outcomes before them
- A competitor who launches later starts with zero data. Unbreakable advantage.
- Analogous to: Tesla Autopilot (each car feeds the fleet), Spotify (collective listening improves everyone's recommendations)

Build requirements:
- All personal data stays isolated per user (privacy, NEVER mix personal weights)
- Collective layer uses only anonymized outcomes (structure predicted, structure actual, TCS band, win/loss)
- Minimum n=50 per structure before collective brain influences base signal
- Personal layer always has override priority — your edge > collective average if they conflict

---

### Phase 2 — Autonomous Pattern Discovery Engine
**Goal:** Let the system find its own edges from accumulated paper trade + scanner data.

How it works:
- Cross-tab every combination of: TCS band × structure type × RVOL band × gap % band × inside bar present (yes/no)
- Calculate win rate + avg follow-thru + sample count per combination
- Surface only combinations with n ≥ 10 (statistically meaningful)
- Flag combinations where win rate > 75% as "discovered edges"
- Output: ranked table sorted by win rate, shown in Analytics tab — one button, runs instantly

Example output it would surface:
> "TCS 70-80 + Trend Day Up + RVOL > 2.5 + gap > 5% pre-market → 84% win rate (n=23)"
> "Inside Bar at POC + Normal Variation structure → 79% win rate (n=11)"

What needs to be stored at scan time (not yet logging):
- Gap % at pre-market detection
- Time of gap detection (within first 10 min of pre-market = stronger signal)
- Pre-market RVOL at scan moment
- Inside bar present on 5m chart at IB close (yes/no flag)

Data threshold: ~500 paper trade rows needed before patterns are statistically real.
At 45 tickers × 5 days/week = ~225 rows/week → meaningful analysis in ~3 weeks.

Done when: at least 3 discovered edges with n ≥ 20 and win rate > 70% reproduced over 2+ weeks.

### Phase 3 — Alpaca Paper Trading Integration (was Phase 2)
**Goal:** Automate entries on high-confidence signals, validate with paper money.

Auto-entry criteria (to be tuned):
- TCS > 80
- Structure = Trend Day Up/Down
- RVOL > 2×
- Order Flow score > 60
- Pattern confirmation from Tier 3 (when built)
- Confirmed discovered edge from Phase 2 pattern engine

Track: paper P&L vs manual P&L — prove automation matches or beats human execution.
Risk controls: max position size, max daily loss, automated stop-loss.
Done when: paper win-rate matches or exceeds BOTH manual journal win-rate AND Webull CSV import win-rate over 30 sessions.
(Webull CSV = real executed trades, journal = curated manual logs — both must be beaten for Phase 4 to be justified.)

### Phase 4 — Live Autonomous Trading
**Goal:** Real money automated execution with guardrails.
- Same criteria as Phase 2 but live Alpaca trading account
- Human override always available (kill switch in sidebar)
- Daily P&L hard limits + drawdown stops
- Full audit trail via journal + Supabase

---

## 📊 SIGNAL TIER ARCHITECTURE

### Tier 1 — Volume Profile + Day Structure ✅ COMPLETE
Core foundation. Classifies the auction process.
- IB detection (9:30–10:30 ET)
- Volume profile (POC, VAH, VAL, HVN/LVN, double distribution detection)
- TCS (Trade Confidence Score)
- Target zones (Coast-to-Coast, Range Extension 1.5×/2.0×, Gap Fill)
- Distance-to-target widget

### Tier 2 — Order Flow Signals ✅ COMPLETE
Real-time intraday momentum layer. Composite score −100 to +100.
- Pressure acceleration (3-bar vs 10-bar buy/sell delta)
- Bar quality score (0–100)
- Volume surge ratio (vs 10-bar average)
- Tape streak (consecutive bullish/bearish bars)
- IB proximity + volume confirmation

### Tier 3 — Chart Pattern Detection 🔴 TO BUILD (PRIORITY)
Confirmatory signal layer. Detects classic patterns on 5m and 1hr bars.

Patterns to detect:
| Pattern | Direction | Confluence Notes |
|---|---|---|
| Reverse Head & Shoulders | Bullish | Neckline break + volume confirm |
| Head & Shoulders | Bearish | Neckline break |
| Double Bottom | Bullish | Often base of cup, or L-shoulder of reverse H&S |
| Double Top | Bearish | — |
| Cup & Handle | Bullish | Double bottom base + handle pullback |
| Bull Flag | Bullish | Tight consolidation after impulse |
| Bear Flag | Bearish | — |
| Inside Bar | Neutral → directional on break | Full bar range contained within prior bar — coiling energy, breakout watch above/below prior bar's high/low |

Confluence scoring logic:
- Single pattern = base score
- Two patterns aligning (e.g., double bottom as left shoulder of reverse H&S) = 1.5× score
- Pattern + volume profile level (HVN/POC/IB) = "confluence confirmed"
- Pattern + trendline hold + volume contraction = "Coiled — breakout watch"

Example model output when built:
> "Neutral day — but 1hr reverse H&S neckline unbroken at $2.49 + trendline hold → bullish resolution probable"
> "Fakeout potential — coiled at trendline + POC confluence → breakout watch, not exit signal"

Real-world gap this fills (from today, April 6):
RENX → model said "fakeout potential" (Neutral structure read, correct)
but user identified 5m AND 1hr reverse H&S manually.
Pattern detection would have flipped the read to: "Neutral + H&S bullish confirmation"

### Tier 4 — Trendline Detection 🔲 FUTURE
Auto-draw trendlines from swing highs/lows on 5m/1hr/daily/weekly.
Required for: compression score, trendline hold confirmation, pattern geometry (necklines, channels).

**Key design insight (April 8):** Trendlines on bigger timeframes carry MORE weight — not less.
Daily/weekly trendlines have thousands of participants watching and placing orders at them,
making them self-fulfilling. 5m trendlines are noise by comparison.

Build priority order:
1. Daily trendline first — most participants watching = strongest signal
2. 1hr trendline second — intraday structure, IB context
3. 5m trendline third — entry timing only, not structure signal

Scoring rule when built:
- Daily trendline hold/break = high confidence signal (weight: 1.5×)
- 1hr trendline hold/break = medium confidence (weight: 1.0×)
- 5m trendline = entry timing only, not a structural signal (weight: 0.5×)
- Multi-timeframe alignment (daily + 1hr trendline both holding same level) = "Compression confirmed" (weight: 2.0×)

---

## 🔧 7-STRUCTURE FRAMEWORK ✅ ALREADY BUILT

Already implemented with hard 3-branch decision tree (no fallthrough):

| Structure | IB Behavior | Signal |
|---|---|---|
| **Trend Day Up** | One side broken (high) only — early, closes at extreme, directional vol | Aggressive long targets |
| **Trend Day Down** | One side broken (low) only — early, closes at extreme, directional vol | Aggressive short targets |
| **Normal Day** | No IB break — wide IB, big players set range | Fade extremes → POC |
| **Normal Variation** | One side broken moderately, returns inside | Conservative fade |
| **Neutral Day** | Both IB sides violated, close in middle | C2C targets, tight stops |
| **Neutral Extreme** | Both sides violated, closes top or bottom 20% | High volatility, wait |
| **Non-Trend Day** | Narrow IB, low volume, no interest | Avoid — no edge |
| **Double Distribution** | Bimodal volume profile, two distinct POCs | Gap fill between nodes |

Branch logic (hard gates, no fallthrough):
- Branch A: no_break → Normal or Non-Trend
- Branch B: both_broken → ONLY Neutral family (Neutral or Neutral Extreme)
- Branch C: one_side → ONLY Trend Day, Normal Variation, or Double Distribution

TODO: run batch backtest on 20+ tickers with new logic to rebuild training data.
Consider tightening Trend Day threshold or adding RVOL floor.

---

## 🕌 ISLAMIC COMPLIANCE FILTER 🔲 BACKLOG
Build after Tier 3 pattern detection.

- API: Musaffa (musaffa.com) — halal / questionable / not-halal per ticker
- Where: Scanner tab — optional toggle filter
- Signal value: not-halal = structurally reduced Islamic buyer pool
- Market value: inclusive to Islamic trading community — unique differentiator
- Build time: ~30 minutes once Tier 3 is done

---

## 📋 CURRENT 7-TAB LAYOUT

| Tab | Name | Status |
|---|---|---|
| 1 | 📈 Main Chart | ✅ Complete |
| 2 | 🔍 Scanner | ✅ Complete |
| 3 | 📋 Playbook | ✅ Complete |
| 4 | 🔬 Backtest Engine | ✅ Complete |
| 5 | 📖 Journal | ✅ Complete |
| 6 | 📊 Analytics & Edge | ✅ Complete |
| 7 | 💪 Small Account | ✅ Complete |

---

## 💡 USER-GENERATED INSIGHTS (Trading Observations)

**Insight 1: Trendline + Level Confluence = Compression → Expansion**
"As long as a stock follows its trendline and holds levels in confluence with it,
it's set up for consolidation then breakout."
→ Encode as compression score in Tier 3 pattern engine.

**Insight 2: Pattern Stacking / Confluence**
Patterns appear together and amplify each other:
- Double bottom = base of cup & handle
- Double bottom = left shoulder of reverse H&S
- Wedge compression = flag before breakout
Tier 3 must detect stacked patterns and score them higher than singles.

**Insight 3: Entry Quality Logging**
Labeling trades as "FOMO" vs "calculated" at entry time builds one of the most
valuable personal edge metrics over time.
Over 50+ trades, win-rate by entry-type reveals discipline edge vs luck.

**Insight 4: After-Hours Small-Cap Reality**
After-hours on thin small caps: a few buy orders can create a big-looking volume spike.
Patterns formed in after-hours are low-conviction until confirmed at regular open.
Key: does the level hold into and through next morning's open?

---

## 📝 TODAY'S TRADES TO LOG (April 6, 2026)

### RENX — RenX Enterprises Corp
| Entry | Time | Price | Shares | Thesis | Grade |
|---|---|---|---|---|---|
| Initial | 9:49 AM ET | $2.45 | ~122 | Calculated — reverse H&S + IB levels | A |
| Re-entry | Midday | $2.49 | ~80 | Trendline pullback (tried 2.45→2.47, missed) | B |
| Add | Midday | $2.50 | ~16 | Adding into trendline hold | B |
| **Total** | — | **~$2.469 avg** | **~218** | — | — |

Key note: model said Neutral/fakeout potential. User identified 1hr + 5m reverse H&S manually.
Model was structurally correct, missed pattern context. This is the Tier 3 build motivation.

### PFSA — Profusa Inc
| Entry | Time | Price | Shares | Thesis | Grade |
|---|---|---|---|---|---|
| Initial | 10:54 AM ET | $1.850 | ~162 | FOMO — chased the move | C |
| Re-entry | Post-pullback | $1.795 | ~111 | Trendline pullback — calculated | A |
| **Total** | — | **~$1.826 avg** | **~273** | — | — |

After-hours: dropped from $1.870 through all support levels to $1.548 low,
bouncing around $1.60–$1.68 range. Possible reverse H&S forming with $1.548 as head.
Overnight hold decision: user holding both positions.

---

## 🔨 TECHNICAL FIXES COMPLETED (Recent Sessions)

| Fix | Details |
|---|---|
| Verify predictions date picker | Manual date picker replaces "Verify Yesterday" |
| Supabase date range query | pred_date is timestamp — use gte()/lt() not eq() |
| Predict All trading day | Uses get_next_trading_day() — no weekend/holiday saves |
| IB computation | pd.Timestamp(tz=tz) cutoff, includes full 10:30 bar |
| IB manual override | st.form prevents collapse; per-ticker; ACTIVE label |
| Log entry timestamp | Date + time picker (1-min step) for accurate backdating |
| load_watchlist import | Added to explicit import block |
| get_next_trading_day | New backend.py function using Alpaca calendar API |

## 🐛 KNOWN ISSUES

| Issue | Priority |
|---|---|
| artifacts/api-server workflow failed state | Low — clean up, doesn't affect main app |
| April 5 predictions in Supabase (Saturday) | Low — unverifiable junk data, can ignore |
| IB 1-3 cent gap vs Webull | Unfixable — data feed fragmentation; use IB Override |

---

## ✅ BUILD CHECKLIST (Tonight / Next Session)

- [x] **Tier 3 pattern detection** — H&S, reverse H&S, double bottom/top, cup & handle, bull/bear flag + confluence scoring — COMPLETE (April 6)
- [x] **Batch calibration run** — One-click "🧠 RUN CALIBRATION" button in Backtest tab. 28 small-cap tickers × configurable 1–22 trading days lookback. Auto-saves to Supabase, shows win rate + structure distribution summary. Original per-ticker simulation unchanged below it. COMPLETE (April 6)
- [ ] **Islamic compliance filter** — Musaffa API, Scanner tab toggle (after Tier 3)
- [ ] **Clean up artifacts/api-server** — failed workflow, not needed

## 🏆 COMPETITIVE POSITIONING & VISION (Saved April 8, 2026)

### What corporate trading desks actually sell
Hedge funds and prop desks sell one thing: consistent, explainable edge with controlled drawdown.
Not prediction accuracy alone — *calibrated* accuracy. Knowing when your signal is right AND when
it isn't is worth more than being right 70% of the time without knowing which 70%.

EdgeIQ is built around that exact concept. The brain weight system doesn't just track win rate —
it knows win rate by structure type, which means it can say "don't take this trade, your historical
edge on this structure is 42%." That's risk-adjusted signal filtering. That's what quant desks do.

### The three things that make it genuinely competitive

**1. The discovery engine (Phase 2)** — if it surfaces real, reproducible edges that hold up over
time, you have something quantifiable and defensible. "Our system discovered that X condition
produces Y outcome with Z% confidence across N trades" is a pitch, not a claim.

**2. Asset class expansion** — right now it's small-cap equities. The same volume profile +
structure framework applies to futures (ES, NQ, crude), crypto, and forex. Same architecture,
different data feeds. A system that works across asset classes with per-instrument calibration
is institutional-grade infrastructure.

**3. The personalization layer at scale** — this is the actual moat. If the brain calibrates to
each user's edge rather than a generic edge, you have something no corporate desk has built for
retail. Renaissance doesn't care about your individual win rate — they run one model across
everything. EdgeIQ runs a different model per trader. At scale, that's a SaaS product that
corporate analytics firms would license, not just individual traders.

### Why it won't hit the "posted my algo" ceiling
The "posting my algo" ceiling: someone backtests something, it works on paper, they publish it,
it stops working. Because they never had a calibration loop — they optimized to historical data.

EdgeIQ has a live feedback loop. Systems with live feedback loops that actually adapt don't stop
working — they learn when market conditions shift. That's why Renaissance has worked for 30+ years
while every "I published my algo" strategy has a 6-month half-life.

---

## 📱 WEBULL SCANNER SETTINGS (User's watchlist source — logged April 8)

These are the exact Webull screener filters used to generate the daily watchlist pasted into the bot:

| Filter | Value |
|---|---|
| Region | United States |
| % Change | 3.00% to 300.00% |
| Volume | 1M to 521.93M |
| Turnover Rate | 10.0% to 3394.4% |
| Free Float | 0M to 100M |

**Columns shown:** % Change, Volume, Turnover Rate, Free Float

**Why these filters:** Catches small-cap stocks that are moving (3%+ gap), have real volume (1M+), have high turnover (active float rotation), and are free-float capped (small floats = bigger moves).

**Workflow (AUTOMATED):** Bot fetches Finviz at 9:15 AM ET using equivalent filters → auto-saves to Supabase → used by 10:46 AM scan. No manual paste needed.

**Future:** When Webull CSV import is built, these same screener results become the source for backfilling real executed trade data into the journal/accuracy tracker.

---

## 🔍 FINVIZ SCREENER CONFIG (Auto-Watchlist — April 8, 2026)

Replaces manual Webull paste. Runs at 9:15 AM ET via bot scheduler.

**URL:** `https://finviz.com/screener.ashx?v=111&f=geo_usa,ta_change_u3,sh_float_u100,sh_avgvol_o1000,sh_relvol_o1,sh_price_o1,sh_price_u20&o=-volume`

| Finviz Filter | Code | Matches Webull |
|---|---|---|
| Region = US | `geo_usa` | ✅ Region: United States |
| % Change ≥ 3% | `ta_change_u3` | ✅ % Change 3–300% |
| Float ≤ 100M | `sh_float_u100` | ✅ Free Float 0–100M |
| Avg Vol ≥ 1M | `sh_avgvol_o1000` | ✅ Volume ≥ 1M (Webull is today's vol, Finviz is avg — close enough for intent) |
| Rel Vol ≥ 1× | `sh_relvol_o1` | ✅ Proxy for Turnover Rate ≥ 10% |
| Price ≥ $1 | `sh_price_o1` | ✅ No Webull equivalent but used for quality |
| Price ≤ $20 | `sh_price_u20` | ✅ No Webull equivalent but matches small-cap target |
| Sort | `-volume` | ✅ Descending volume |

**Elite account:** FINVIZ_EMAIL + FINVIZ_PASSWORD stored as secrets.
Note: Finviz Elite uses Google OAuth — programmatic login is not feasible. Credentials stored for future API token access if Finviz enables it. The screener HTML is freely accessible regardless of auth status; Elite mainly gives real-time quote data in the charts, not different screener results.

**Output:** Up to 100 deduplicated tickers per day (typically 30–60 on active market days).

**Bot UI:** Paper Trade tab shows locked green "Auto-Watchlist" box with ticker count. Only an optional extra-tickers input field is exposed to the user.

---

## 📈 PATTERN NOTE — Ascending Base + Liquidity Break (logged April 8)

**Setup:** Stock in sideways-to-upward angled consolidation (higher lows visible on 5m or 15m). Previous swing high = liquidity zone (cluster of stop orders sitting above it).

**Entry trigger:** 5m or 15m candle closes ABOVE the previous high AND the following candle holds above it (does not immediately reverse back through).

**Why it works:** The close-above filters out stop hunts (wicks through = fake). Two consecutive candles above the level = real buyers absorbed the liquidity and are defending the breakout.

**Tier 4 detection candidate:** Requires trendline detection (ascending base angle auto-identified) + previous high level flagged as liquidity zone + breakout candle + confirmation candle. Full auto-detection needs Tier 4 trendlines first.

---

## 🔒 PRESERVATION RULES (NEVER MODIFY)
- compute_buy_sell_pressure()
- classify_day_structure()
- compute_structure_probabilities()
- brain_weights.json
- Architecture: math/logic → backend.py only; UI/rendering → app.py only


## ── USER WORKFLOW NOTES (Pinned 2026-04-08) ────────────────────────────────

### Correct nightly routine (9 PM – market closed):
1. Run Gap Scanner → find what's gapping / has interesting structure
2. Curate My Watchlist (sidebar) → add only 3–5 tickers with actual homework done
3. Playbook → Predict All → generates full setup briefs (entry, stop, targets,
   key levels, PDH/PDL/PDC, round numbers, confluence) for tomorrow's session
4. Journal today's trades → feeds brain calibration
5. EOD Review note → qualitative record of what market did vs prediction

### Watchlist philosophy (user insight):
- My Watchlist = curated high-conviction tickers (3–5 max). NOT every ticker.
- Gap Scanner = discovery tool. It answers "what's moving?", NOT "what should I trade?"
- The brain calibrates ON the watchlist tickers. Flooding it with 30+ tickers
  dilutes the calibration and generates briefs for setups you'll never take.
- Better approach: use Gap Scanner to surface candidates, pick the top 3–5 you
  have real structure conviction on, THEN add to My Watchlist.

### User's realization (important for product design):
- User initially put EVERY ticker in watchlist expecting the bot to filter.
- This is a valid Phase 4 product feature: Gap Scanner → auto-ranking →
  push top N scoring tickers directly to Predict All queue, bypassing manual curation.
- The system CAN do this eventually: score all gappers by TCS + structure confidence,
  then auto-promote top 5 to the prediction queue. Would remove the homework friction.

### Timing rules (when to use what):
- 9 PM–midnight: Predict All + Journal + EOD note (best time — full day data in)
- Pre-market (6–9 AM): check pre-market watchlist panel in EOD Review
- 9:30–10:30: IB forming — DO NOT enter. Watch structure develop.
- After 10:30: entries valid. System's signals are calibrated around this.
- IB must be complete before ANY entry. This is hardcoded into every trigger string.

## 2026-04-08 — Simulation Log Upgrades
- **Deduplication**: Added dedup logic by `(ticker, sim_date)` key before rendering the trade-by-trade log; shows a count if dupes were removed
- **Per-Ticker Breakdown table**: New expander above the log showing each ticker's: Win %, W/L count, Avg TCS, Top Structure, Avg Follow-Thru %, False Break %, Dates Seen — sorted by win rate; color-coded 🟢/🟡/🔴
- **Date column**: Added "Date" as column 0 in the trade-by-trade log so each row shows which trading date it belongs to (useful for range runs)
- `_BT_COLS` expanded from 10 to 11 columns; all row cell indices shifted accordingly

## 2026-04-08 — Load Saved Simulation Results
- Added "📂 Load Saved Simulation Results" expander in Section 2 (Simulation) of the Backtest tab
- Flow: (1) "Fetch My Saved Dates" → pulls distinct sim_dates from Supabase, (2) multiselect picker for date(s), (3) "Load Selected" reconstructs _results list + _summary dict from saved DB rows, injects into bt_results_cache session state, then st.rerun() so full chart/stats pipeline renders automatically
- Handles field remapping: follow_thru_pct → aft_move_pct; reconstructs actual_icon from outcome text; close_price defaults to 0 if not stored
- Works for single-day and multi-date range loads; _sim_is_range=True when >1 date selected

## 2026-04-08 — Auto Paper Trading Tab (📄 Paper Trade)
- New 8th tab added: "📄 Paper Trade"
- **Section 1 — Scan & Log**: date picker, feed selector, TCS min slider (default 50), price range, tickers textarea (pre-filled with watchlist). Calls run_historical_backtest → filters TCS ≥ min → calls log_paper_trades → deduplicates by (ticker, trade_date) before saving. Shows preview table of qualifying setups.
- **Section 2 — 3-Week Tracker**: 4 KPI cards (win rate, total setups, avg TCS, avg follow-thru), daily win rate trend chart with 55% target line, per-ticker breakdown table, full log expander
- **Backend additions**: ensure_paper_trades_table(), log_paper_trades(), load_paper_trades() in backend.py. Schema shown as SQL fallback if table doesn't exist yet.
- **Table**: paper_trades — user_id, trade_date, ticker, tcs, predicted, ib_low, ib_high, open_price, actual_outcome, follow_thru_pct, win_loss, false_break_up/down, min_tcs_filter, created_at
- User must create paper_trades table in Supabase SQL editor (shown on first load if missing)

## 2026-04-08 (Evening) — Paper Trader Bot + Adaptive Learning Loop

### Paper Trader Bot (paper_trader_bot.py) — FULLY LIVE
- User created paper_trades table in Supabase ✅
- Bot confirmed connected (HTTP 200) and watching **45 tickers** from live Supabase watchlist
- Fixed: was hardcoded to 14 stale tickers. Now calls load_watchlist(USER_ID) on every startup → falls back to 14 only if Supabase load fails
- Schedule: **10:35 AM ET** morning scan → **4:05 PM ET** EOD outcome update → **4:10 PM ET** brain recalibration
- RENX already in watchlist (position 43 of 45) — user noted potential reverse H&S forming on 15m, not confirmed yet

### Paper Trade Tab — 3 New Sections Added
- **Live Auto-Scan toggle**: when browser open during market hours, auto-scans every 30 min
- **Section 3 — Manual EOD Update**: force-update outcomes for any date on demand (don't wait for bot's 4:05 run)
- **Section 4 — IB Window Comparison**: same tickers through 10:30 / 12:00 / 14:00 cutoffs in parallel; shows win rate, W/L, avg TCS, follow-thru, false break side by side; tells you which cutoff produces cleanest signals
- **Section 5 — Brain Health**: live weight table with status badges (🟢 Boosted / ⚪ Neutral / 🔴 Penalized), "Recalibrate Now" button, "Reset to Neutral" button

### Adaptive Learning Loop (recalibrate_from_supabase) — COMPLETE
- New function in backend.py reads from BOTH:
  1. accuracy_tracker (journal-verified trades) — predicted / correct ✅/❌
  2. paper_trades (bot automated signals) — predicted / win_loss
- **50/50 source blending** (volume-neutral): each source's accuracy computed independently per structure, then averaged. Your 45 journal entries have EXACTLY equal vote as 5,400 bot entries. NOT a simple pooling/multiplier.
- Blend rules per structure:
  - Both ≥5 samples → blended = 0.5 × journal_acc + 0.5 × bot_acc
  - Only journal ≥5 → use journal only
  - Only bot ≥5 → use bot only (Gemini's edge case — already handled)
  - Neither ≥5 → skip (no update)
- EMA learning rule: target = 1.5/1.0/0.75/0.5 based on accuracy band; new_weight = old×0.70 + target×0.30
- Weights saved per-user in Supabase (user_preferences.prefs["brain_weights"]) — isolated from other users
- Brain Health table shows: Journal Acc (n), Bot Acc (n), Blended Acc, Last Δ, Status per structure
- Bot auto-runs recalibration at 4:10 PM ET after EOD outcomes settle

### Data Flow Map (complete chain)
```
Journal Tab (pre-market predictions)
    ↓ verify button EOD
watchlist_predictions table
    ↓ verify_watchlist_predictions()
accuracy_tracker table ←── also fed by manual trade log_accuracy_entry()
    ↓
recalibrate_from_supabase() [4:10 PM daily]
    ↑
paper_trades table ←── bot logs at 10:35 AM, outcomes at 4:05 PM
    ↓
50/50 blend per structure (≥5 samples each)
    ↓
brain_weights → Supabase per-user prefs
    ↓
TCS scoring uses updated weights next morning
```

### Gemini Code Review (April 8 evening) — Points Addressed
1. **Slippage 0.0%**: Valid for Phase 4 — paper calibration only measures signal quality not P&L. Add 0.75% default for live sim in Phase 4. ✅ Noted.
2. **Sample skew**: Fixed with 50/50 source blending. Simple 3x multiplier was wrong (2.4% vote ≠ 50/50). ✅ Fixed.
3. **Edge case — 0 journal entries**: Already handled by MIN_SAMPLES=5 gate. Bot data only until journal hits 5. ✅ Already correct.

### Tomorrow's Reminders
0. **Inside Bar pattern**: Add to Tier 3 pattern detection — full bar range contained within prior bar's high/low. Direction determined on break of prior bar's high (bullish) or low (bearish). Score higher when inside bar forms at key level (POC, VAH/VAL, IB boundary).
1. **Clean accuracy_tracker**: Remove entries for tickers outside user's trading universe (random predictions that polluted the table). Calibration reads from accuracy_tracker — out-of-universe tickers skew structure weights.
2. **Webull CSV import pipeline**: Build import flow that maps each Webull trade (entry date + ticker) to an IB structure, feeds accuracy_tracker automatically. Removes all manual work for calibration.
3. **Go through core functions with AI**: Review brain weight math, TCS scoring, IB structure logic, blend accuracy — function by function review (user requested, Gemini timed out on full paste).
4. **Slippage Phase 4**: When building live sim / entry signal layer, default slippage to 0.75% for small-cap $2–$20 range.
5. **Phase 4 planning**: After 3-week paper calibration proves signal quality — add entry trigger (IB breakout + volume confirm), stop loss (IB low - 1 ATR buffer), target (measured move from IB height), position sizing (account % risk).

### Key Decisions Made
- **EOD journal is NOT optional**: Each verified journal entry is a direct training signal for brain weights. Miss journals = weights don't reflect your actual edge.
- **Watchlist predictions (untaken trades) are FINE for calibration**: Measures structure accuracy not trade P&L. Only clean up tickers completely outside your universe.
- **3-week paper window is deliberate**: Structure prediction must be proven before adding entry/exit layer. Bot currently predicts structure + win/loss, NOT buy price / stop / target (Phase 4).
- **Window comparison logic**: More cutoff windows = more calibration data. 3 windows × 45 tickers × 3 weeks = ~405 data points vs 135 single-window. Also reveals whether waiting for midday confirmation improves win rate.

### Current Watchlist (45 tickers as of April 8)
HCAI, MGN, HUBC, TDIC, SILO, CETX, IPST, LNAI, ZSPC, CUE, SKYQ, SIDU, CUPR, LXEH, KPRX, MEHA, JEM, AXTI, ADVB, TPET, WGRX, AAOI, MAXN, IRIX, PROP, AGPU, BFRG, MIGI, PPCB, CAR, AMZE, UK, TBH, AIB, ITP, ARTL, NCL, PSIG, RBNE, CYCU, LPCN, FCHL, RENX, MOVE, TURB
