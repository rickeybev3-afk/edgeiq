# EdgeIQ — Master Build Plan & Product Roadmap
*Last updated: April 12, 2026*

---

## 🎯 PRODUCT VISION

**EdgeIQ** — "Find your edge, then automate it."
Personal win-rate calibration engine + autonomous trading system for small-cap volume profile trading.
- Stack: Python Streamlit (port 8080), Alpaca API, Supabase, Plotly — dark mode
- Differentiator: NOT a generic screener. Learns YOUR specific edge. Then automates it. Then builds a marketplace of proven edges. Then routes dynamically to whoever is best right now.
- Competitors: Trade Ideas, Tradervue, StocksToTrade, Warrior Trading (education only) — none do personal calibration, none have a data moat, none approach the meta-brain
- End goal: Fully autonomous, self-optimizing trading system with a marketplace of verified human edges and institutional data licensing

### SUBSCRIPTION TIERS (Updated April 10, 2026)
- **Tier 1 — $49/mo:** Personal brain (structure predictions, TCS calibration, win rate tracking by setup)
- **Tier 2 — $99/mo:** Personal brain + daily Telegram scanner alerts (morning setups + EOD outcomes)
- **Tier 3 — $199/mo:** License a top trader's verified brain (copy their calibrated edge; they earn revenue share)
- **Tier 4 — $999/mo:** Retail Meta-Brain (dynamic routing across top-verified profiles based on live conditions)
- **Tier 5 — $5,000–$15,000/mo (annual):** Professional/Institutional Meta-Brain (full signal output for external execution; prop traders, small funds)
- **Revenue share:** Top performers earn passive income from brain licensing — just for logging consistently

---

## 🗺️ PRODUCTION PHASES

### Phase 1 — Manual Signal Quality Validation (CURRENT — IN PROGRESS)
**Goal:** Prove the model's signals are accurate before trusting any automation.

Daily workflow:
1. Pre-market → Load watchlist → **Predict All** (saves predictions for next trading day)
2. During session → Trade, take notes, track levels manually
3. After 4pm → **Bot auto-verifies at 4:25 PM ET** → scores predictions vs actual structure autonomously (manual "Verify Date" button available as backup for historical audits)
4. Every verified trade feeds the win-rate calibration database AND per-structure win-rate calibration

Done when: 50+ verified trades with consistent win-rate data per structure type

Current capabilities built:
- Volume profile (POC, VAH, VAL, HVN/LVN)
- **7-structure classification** (already built — see framework below)
- IB detection (9:30–10:30 ET, industry standard inclusive; structure classification updates dynamically throughout the day as price interacts with fixed IB levels)
  - *Future enhancement: multi-timeframe IB detection (morning/midday/EOD) to capture evolving structure across the session — discussed, not yet built*
- TCS (Trade Confidence Score, 0–100) — see **TCS Deep Breakdown** section below
- RVOL (time-segmented, pace-adjusted, minute-by-minute 390-point intraday curve) — see **RVOL Deep Breakdown** section below
- Order flow signals — Tier 2 (pressure acceleration, bar quality, vol surge, tape streak)
- Predictive win rates per structure (Analytics tab)
- Trade journal with auto-grade A/B/C/F + grade discipline equity curve
- Watchlist predictions + EOD verification
- MarketBrain (live prediction vs actual tracker)
- Monte Carlo equity curves (1,000 simulations)
- Small Account Challenge tab
- Playbook screener tab
- Historical Backtest Engine tab
- Position management (entry/exit/P&L/MFE overlay on chart)
- Audio/visual alerts (Web Audio API)
- Pre-market gap scanner (processes all tickers provided in watchlist, gap% + PM RVOL; SIP data feed required for pre-market volume — IEX free tier shows blank PM volume)

### The Two-Layer Brain Architecture (April 8 insight — CRITICAL)

**Layer 1 — Personal brain (built)**
Each user's complete trading profile calibrates to their individual performance. This goes far beyond just structure weights:
- Brain weights per structure type (win rates, confidence per classification)
- Full trade journal history (win rates, A/B/C/F grades, P&L)
- TCS calibration per setup type
- RVOL bands + gap% bands per outcome
- Nightly confidence rankings (0–5 tiers across all tickers)
- Behavioral data (entry types, discipline tracking)
- Position sizing history and risk patterns
Your accuracy on Trend Day Up is yours alone. Nobody else's data touches it.

**Layer 2 — Collective brain (to build)**
Anonymized outcomes from ALL users, pooled across the platform.
"Across 847 verified trades from 312 users, Trend Day Up + TCS > 75 resolved correctly 84.7% of the time."
- What this means: out of 847 times ANY of those 312 users predicted that specific setup, the actual outcome matched 84.7% of the time. Different people, different days, different stocks — the common thread is the setup pattern. That's a collective win rate for a specific setup combination.
- Why it matters: this is a market truth, not a personal opinion. No one person could generate 847 data points on one setup — it takes a network.

How they combine:
- Collective brain → establishes baseline signal quality per structure (the "floor" — what works across everyone)
- Personal brain → adjusts that baseline up/down based on your specific accuracy (your "edge modifier")
- If you're a 90% Trend Day trader but the collective says 65%, your personal override keeps you at 90%. The collective doesn't drag you down — it lifts weaker users UP toward the baseline.
- If you're a 40% Trend Day trader and the collective says 65%, the system flags that you're underperforming on that setup.
- Final signal → market truth + personal edge modifier

Why this is the moat:
- Data network effect: user 1,000 gets a better product than user 10
- Not because code changed — because 999 people verified real outcomes before them
- A competitor who launches later starts with zero collective data. They might have one experienced trader with more personal data, but they don't have 1,000 people's pooled outcomes. The moat is the network, not any one individual.
- The longer EdgeIQ runs, the more verified trades accumulate. A competitor entering 12 months later is 12 months × 1,000 users × daily trades behind. That gap never closes.
- Analogous to: Tesla Autopilot (each car feeds the fleet — one good driver can't replicate the data from 4 million cars), Spotify (collective listening improves everyone's recommendations)

Why you NEVER mix personal weights across users:
- User A crushes Trend Days (90% win rate) but is terrible at Neutral Days (30%). User B is the opposite. If you average their weights, BOTH get a mediocre 60% signal on everything. Neither gets a signal optimized for their actual strengths.
- Personal weights exist to amplify individual strengths and flag individual weaknesses. Mixing them destroys both.

Build requirements:
- All personal data stays isolated per user (privacy, NEVER mix personal weights)
- Collective layer uses anonymized outcomes — minimum fields: (structure predicted, structure actual, TCS band, win/loss). Additional fields for deeper intelligence: RVOL band, gap% band, time of day, market regime, sector.
- Minimum n=50 per structure before collective brain influences base signal
  - This means: before the collective changes YOUR signal at all, there must be at least 50 verified trades for that specific structure type across ALL users combined. If only 12 users have ever traded "Trend Day Up + TCS > 75," the collective stays silent — your personal data alone drives the signal. Once 50+ people have verified that same setup, the collective baseline kicks in as a starting point.
- Personal layer always has override priority — your edge > collective average if they conflict
  - Note: more data (collective) ≠ more accuracy. The collective includes skilled AND unskilled users. A top performer's personal override prevents being pulled down to the collective average.

---

## 🔬 TCS DEEP BREAKDOWN (Trade Confidence Score)

### What it is
A 0–100 composite score measuring how much conviction the current price action deserves. It answers: "Is this move real, or is it noise?"

### Current formula (hardcoded — does NOT self-calibrate yet)

**Range Factor (max 40 pts)** — day range vs IB range
- Measures: How far has price extended beyond the Initial Balance?
- Formula: `range_ratio = total_day_range / ib_range`
- If range_ratio ≥ 2.5 → full 40 pts
- If 1.1 < range_ratio < 2.5 → linear scale from 0 to 40
- If range_ratio ≤ 1.1 → 0 pts
- What it catches: true directional days where price left the opening range
- What it misses: HOW the range extended — clean breakout vs choppy whipsaw score the same

**Velocity Factor (max 30 pts)** — recent volume pace vs session average
- Measures: Is current volume accelerating or decelerating?
- Formula: `velocity_ratio = avg_vol_last_3_bars / avg_vol_entire_session`
- If velocity_ratio ≥ 2.0 → full 30 pts
- If 1.0 < velocity_ratio < 2.0 → linear scale from 0 to 30
- What it misses: volume DIRECTION (selloff volume scores same as breakout volume)

**Structure Factor (max 30 pts)** — price distance from POC + trend direction
- Step 1: Is price > 1 ATR from POC?
- Step 2: Are the last 3 closes trending FURTHER from POC?
- If yes to both → full 30 pts
- What it misses: volume AT price levels (breakout quality)

**Sector Bonus (optional +10 pts)** — sector ETF tailwind
- Sector ETF up > 1% today → +10 pts
- Limitation: binary on/off, should scale with magnitude

### Honest assessment
Reasonable V1 framework. Captures the right categories (range, momentum, displacement) but missing: order flow integration, bid/ask spread quality, time-of-day factor, volume-at-price.

### Evolution path
1. Self-calibrating component weights (40/30/30 should auto-adjust per user)
2. New components: order flow, time-of-day multiplier, volume-at-price, liquidity quality
3. Component auto-discovery: brain tests new factors against trade outcomes, proposes additions

---

## 🔬 RVOL DEEP BREAKDOWN (Relative Volume)

### What it is
Measures today's volume vs "normal" at this exact time of day. RVOL 3.0 = 3× typical volume at this minute.

### Current lookback periods
- **Main chart:** 50-day baseline (390-element minute-by-minute curve)
- **Playbook screener:** 10-day baseline (more responsive)
- **Gap scanner PM:** 10-day pre-market average

### Small-cap concern (valid)
50 days for small caps that barely trade includes many dead-volume days. Baseline becomes artificially low, inflating RVOL on any activity. 10-20 day lookback would be more responsive.
Should auto-adjust: test which lookback period's RVOL bands correlate best with wins. Phase 2 brain calibration target.

### Scanner RVOL filtering
Currently: NO RVOL minimum filter in the live scanner. Shows everything.
Should: Start at baseline floor (e.g., RVOL ≥ 2.0), auto-adjust over time.

### RVOL bands
- `3+` — extreme volume | `2-3` — high | `1-2` — normal | `<1` — below average (caution)

---

## 🎯 TARGET ZONES & TAKE PROFIT (NOT always IB High)

### Current targets (already dynamic)
1. **Coast-to-Coast:** IB violated → price returns inside → target = opposite IB boundary
2. **Range Extensions (TCS > 70):** 1.5× and 2.0× IB range from breakout side
3. **Gap Fill:** Double distribution LVN detected → target = opposite HVN
4. **Volume profile levels**
5. **Fallback:** IB extensions at 1.0×, 1.5×, 2.0×

### What should learn over time
Which targets YOUR trades actually hit. If you consistently blow through 1.5× to hit 2.0×, hold longer. If trades reverse before 1.5×, take partial earlier. Baseline → learn → refine.

---

## 📊 LAYER 1 DEEP BREAKDOWN

### Brain Weights per Structure Type
- Stored in `brain_weights.json`, recalibrated nightly at 4:30 PM ET
- Each structure gets independent win rate tracking
- Cluster keys: structure + TCS band + RVOL band → ultra-specific condition win rates

### Trade Journal History (SEPARATE from behavioral — weighted independently)
- Tracks OUTCOMES: ticker, date, entry/exit, P&L, shares, thesis
- Auto-graded A/B/C/F based on RVOL, TCS, price vs IB
- Win rate by grade: "A-trades win 78%, C-trades win 34%"

### Behavioral Data (SEPARATE — weighted independently from journal)
- Tracks PROCESS: why you entered (Calculated/FOMO/Reactive/Revenge/Conviction Add/Average Down)
- Why separate: A FOMO trade can win (outcome good, process bad). Journal = results. Behavioral = discipline. Different signals.

### TCS Calibration per Setup Type
- TCS 60 means different things on Trend Day vs Non-Trend Day
- Over time: per-structure TCS thresholds auto-adjust

### RVOL Bands + Gap% Bands per Outcome
- Every prediction tagged with RVOL band and gap%. Win rates computed per band.

### Nightly Confidence Rankings (0-5)
- User rates tickers nightly. Next day: outcome auto-verified.
- After 90+ nights: feeds Kelly sizing as confidence multiplier.

### Position Sizing History
- Tracks capital allocation per trade. Reveals sizing patterns (oversize on FOMO?)
- Feeds fractional Kelly in Phase 4: account balance + win rate + TCS + regime → optimal size

---

## 🧠 COLLECTIVE BRAIN ADVANCEMENT (April 12 deep-dive)

### What "84.7%" measures — IMPORTANT
Collective brain measures **structure prediction accuracy**, NOT trade P&L.
- "Did the model correctly predict what type of day this would be?" ≠ "Did the trade make money?"
- Future V2: track full trade outcomes (entry quality, P&L, hold duration) alongside structure accuracy

### Auto-calibration design
- Minimum 4 fields are the starting point (floor, not ceiling)
- System should analyze which additional fields improve accuracy and promote/demote accordingly
- Phase 2+ capability — requires significant data volume

### Mixing personal weights — why not
Can't combine users' personal weights into one "best" weight set because personalization IS the product. User A's strengths ≠ User B's strengths. Averaging destroys both.
The collective gives a BASELINE. Personal weights give YOUR EDGE MODIFIER on top of it.

---

## 📊 THE 350-TRADE QUESTION

### The concern
7 structures × 350 per structure = 2,450 trades = 1-2 years at current pace. Some structures are rare.

### Why it's solvable
1. Collective brain fills the gap — you don't need 350 personal per structure if 200 other users contribute
2. Adaptive weights kick in at just 15 rows total, not 350 per structure
3. Rare structures (Non-Trend Day) = "avoid, no edge" — being rare is fine

### Structure classification accuracy
- Based on Market Profile theory (Dalton) — industry standard, not invented
- Hard 3-branch decision tree. Updates dynamically throughout the day.
- Different market regimes shift structure DISTRIBUTION but not DEFINITIONS
- Classification logic is HARD PRESERVATION — do not touch

---

## 🚨 DATA GAPS FOUND (April 12 audit)

### RVOL persistence — ✅ DONE
- `rvol` column exists on both `paper_trades` and `watchlist_predictions` tables
- `gap_pct` also persisted on both tables
- Brain can now learn which RVOL bands correlate with wins

### paper_trades MAE/MFE columns — ⚠️ PENDING MIGRATION
- `mae`, `mfe`, `entry_time`, `exit_trigger`, `entry_ib_distance` — code ready, migration SQL documented
- Run via sidebar "🔧 Database Migrations" button or paste SQL in Supabase SQL Editor
- Once columns exist, paper trades will auto-log execution depth data

### Structure Priority — Adaptive TCS Thresholds — ✅ BUILT (April 12, 2026)
- `compute_structure_tcs_thresholds()` in backend.py; Analytics Section 4 + Trade Journal page
- Per-structure hit rate → recommended TCS threshold (lower = more aggressive)
- Formula: base 65, adjusted by (hit_rate - 60) × 0.5, clamped [45, 85]
- Shows: structure name, hit rate, sample count (journal + bot), brain weight, recommended TCS, action label
- Color-coded: 🟢 ≥70% / 🟡 ≥55% / 🟠 ≥40% / 🔴 <40%
- Action labels: AGGRESSIVE / STANDARD / CAUTIOUS / AVOID
- Self-compounding: updates automatically as accuracy_tracker + paper_trades grow

### Trade Journal Logger Page — ✅ BUILT (April 12, 2026)
- Standalone page at `/?journal=<USER_ID>` — no sidebar, no login required (single-user mode)
- Stats strip: Journal Entries, Predictions, Prediction Accuracy, Paper Win Rate
- Quick CSV import (Webull order history) with dedup against existing journal
- Per-structure TCS thresholds (live from accuracy_tracker)
- Recent journal entries table
- Only owner's user ID works — beta testers cannot access

### Performance Tab — Bot vs Overall Pred Rate Clarification (April 12, 2026)
- Performance tab KPI strip now shows 6 cards (was 5)
- "Bot Pred Rate" — bot watchlist_pred calls only (40.7%, 33/81) with "Bot watchlist calls only" label
- "Overall Pred Rate" — all sources combined (67.2%, 193/287) with "All sources combined" label
- Data breakdown: watchlist_pred=81 rows, webull_import=61 rows, manual/playbook=145 rows
- Bot accuracy (40.7%) is the key metric for autonomous improvement; overall (67.2%) includes human calls

### Webull CSV Import — April 12, 2026
- Imported 8 new trades from April 6–9 CSV: IPST (×1), RENX (×2), CYCU, MGN, YMT (×2), ONCO
- Total journal entries: 70 (was 62)
- Time-frame data preserved: entry timestamps, exit timestamps, P&L, shares in notes field
- Entry time distribution peaks at 09:00–10:00 (32 of 70 trades) — IB window trades dominate

### Private Build Notes Page — ✅ BUILT (April 12, 2026)
- Accessible at `/?private=<KEY>` using the private key
- Renders .local/build_notes_private.md with styled header
- No sidebar, no login — key-gated access only

### Portfolio Risk Metrics — ✅ BUILT (April 12, 2026)
- Sharpe ratio (daily + annualized), Alpha vs SPY, Alpha vs IWM, Max drawdown, Rolling drawdown chart
- `compute_portfolio_metrics()` in backend.py, displayed in Analytics tab Section 3C
- Both SPY (broad market) and IWM (small-cap benchmark) alpha computed from Alpaca daily bars
- IWM is the critical benchmark — trading small caps means SPY alpha alone could just be small-cap beta
- Fallback: if no P&L % column, uses win/loss as +1/-1 synthetic returns
- Self-compounding: metrics auto-update as bot logs more trades. Once MAE/MFE columns exist, P&L precision improves. Phase 2 enables segmentation by structure/RVOL/TCS band.

### accuracy_tracker data quality — ✅ CORRECT (April 12 audit)
- `correct` column stores ✅/❌ emojis (not NULL as previously documented). 287 rows total (193 ✅, 94 ❌)
- `_strip_emoji()` handles actual column emoji prefixes ("🔄 Neutral") for matching
- Recalibration reads correctly via `"✅" in correct` check — no fix needed

### NOT tracking multiple RVOL lookbacks
- Only one lookback used at a time (50-day main, 10-day playbook/scanner)
- Should run 10/20/30/50 in parallel for future comparison. Phase 2 target.

### RVOL ≥ 2.0 Scanner Floor — BUILT (April 12, 2026)
- Used in: structure classification, trade grading, entry trigger text, model warnings
- Scanner RVOL floor filter added: `run_gap_scanner()` accepts `min_rvol` param (default slider 2.0x in sidebar)
- Only applied with SIP feed (IEX has no PM volume data to filter on)
- Keeps tickers with unknown RVOL (doesn't drop them)

### Inside Bar — BUILT (April 12, 2026)
- Patterns built: H&S, Double Bottom/Top, Bull/Bear Flag, Cup & Handle, **Inside Bar**
- Runs on both 5m and 1hr timeframes. Base score 0.60, boosted by compression%, POC/IB proximity.
- Direction based on close position vs mother bar midpoint.
- 5m inside bars = micro-consolidation within IB (scalp signal). 1hr inside bars = genuine coiling before IB extension (big signal).

### P-Shape / D-Shape — NOT built
- P = short covering rally (volume top-heavy). D = long liquidation (volume bottom-heavy).
- Different from 7 structures (those track IB behavior; shapes track volume distribution)
- Fix: classify volume profile distribution shape (Phase 2)

---

## ⏰ SELF-LEARNING TIMELINE

### Working NOW (Phase 1)
1. Brain weights per structure (nightly recalibration)
2. Edge Score component weights (auto-calibrates from backtest history)
3. Win rate per cluster (structure + TCS band + RVOL band)
4. Structure classification (updates dynamically through trading day)
5. Trade grade auto-assignment (A/B/C/F)
6. Nightly ranking accuracy tracking

### BUILT (Phase 1 — data foundation — completed April 12, 2026)
7. ✅ RVOL persistence to Supabase (paper_trades + watchlist_predictions)
8. ✅ Scanner RVOL floor (≥ 2.0 default, SIP only)
9. ✅ Inside bar detection (5m + 1hr, compression + POC/IB confluence)
10. ✅ Gap% persistence per prediction
11. ✅ MAE/MFE execution depth (mae, mfe, entry_time, exit_trigger, entry_ib_distance — paper trades + analytics)
12. ✅ MAE/MFE analytics dashboard (MFE:MAE ratio, money left on table, by-structure breakdown, exit trigger analysis)

### Phase 2 (~500 trades — brain becomes self-optimizing)
13. Pattern Discovery Engine (cross-tab all factors → surface winning combos)
14. RVOL lookback auto-optimization (test 10/20/30/50, use best)
15. Scanner RVOL floor auto-adjustment
16. TCS internal weight self-calibration (40/30/30 learns from data)
17. TCS component auto-discovery (proposes adding order flow, time-of-day, etc.)
18. P/D/B shape classification
19. Target zone learning (which targets YOUR trades actually hit)
20. Per-structure TCS thresholds
21. Brain weight historical snapshots (nightly timestamped log of all weights — investor audit trail + evolution analysis)
22. TCS persistence per trade (store TCS at scan time alongside every paper trade and watchlist prediction for cross-tab analysis)
23. Edge Score persistence per trade (same as TCS — store at decision time for later pattern discovery)

### Phase 3 (~2,000+ users — collective intelligence)
24. Collective brain activation
25. Collective field auto-calibration
26. Auto-entry on paper account
27. Behavioral data auto-weighting

### Phase 4 (live autonomous trading)
28. Fractional Kelly position sizing
29. Market regime multiplier
30. Full trade outcome learning (entry quality, P&L, hold duration)

### Phase 5 (meta-brain)
31. Dynamic routing across user profiles
32. Brain licensing marketplace
33. Cross-user pattern discovery

| Priority | What | When | Depends On |
|---|---|---|---|
| NOW | Brain weights, Edge Score weights, clusters | Phase 1 (working) | — |
| DONE | RVOL persistence, scanner filter, inside bar | Phase 1 (built Apr 12) | — |
| DONE | MAE/MFE execution depth + analytics dashboard | Phase 1 (built Apr 12) | — |
| SOON | Pattern discovery, RVOL optimization, TCS self-cal | Phase 2 (~500 trades) | RVOL persistence |
| LATER | Collective brain, auto-entry, behavioral weighting | Phase 3 (~2K users) | Pattern discovery |
| FUTURE | Kelly sizing, regime, full P&L learning | Phase 4 | Collective brain |
| ENDGAME | Dynamic routing, brain licensing, cross-user | Phase 5 | All above |

---

## 📡 PRE-MARKET DATA & SIP
- IEX free tier: NO pre-market volume. Gap % works but PM RVOL shows "N/A"
- SIP ($99/mo via Alpaca — corrected from old $9/mo documentation): full pre-market volume data
- Without SIP: cannot log or study pre-market volume patterns over time
- **When to buy SIP:** Phase 1 — ideally NOW. Every day without SIP is a day of pre-market volume data you're NOT collecting. At $99/mo it's a significant but essential data investment. The PM RVOL data needs to accumulate alongside your other prediction data so it's ready for Phase 2 pattern discovery. Waiting until Phase 2 means Phase 2's pattern engine won't have any PM data to learn from.

---

### Phase 2 — Autonomous Pattern Discovery Engine
**Goal:** Let the system find its own edges from accumulated paper trade + scanner data.

How it works:
- Cross-tab every combination of: TCS band × structure type × RVOL band × gap % band × inside bar present (yes/no)
- Calculate win rate + avg follow-thru + sample count per combination
- Surface only combinations with n ≥ 10 (statistically meaningful)
- Flag combinations where win rate > 75% as "discovered edges"
- Output: ranked table sorted by win rate, shown in Analytics tab — one button, runs instantly

Example output it would surface:
> "TCS 70-80 + Trend Day Up + RVOL > 2.5 + gap > 5% pre-market → 84% win rate (n=23)"
> "Inside Bar at POC + Normal Variation structure → 79% win rate (n=11)"

What needs to be stored at scan time (not yet logging):
- Gap % at pre-market detection
- Time of gap detection (within first 10 min of pre-market = stronger signal)
- Pre-market RVOL at scan moment
- Inside bar present on 5m chart at IB close (yes/no flag)

Data threshold: ~500 paper trade rows needed before patterns are statistically real.
At 45 tickers × 5 days/week = ~225 rows/week → meaningful analysis in ~3 weeks.

Done when: at least 3 discovered edges with n ≥ 20 and win rate > 70% reproduced over 2+ weeks.

### Phase 3 — Alpaca Paper Trading Integration (was Phase 2)
**Goal:** Automate entries on high-confidence signals, validate with paper money.

Auto-entry criteria (to be tuned):
- TCS > 80
- Structure = Trend Day Up/Down
- RVOL > 2×
- Order Flow score > 60
- Pattern confirmation from Tier 3 (when built)
- Confirmed discovered edge from Phase 2 pattern engine

Track: paper P&L vs manual P&L — prove automation matches or beats human execution.
Risk controls: max position size, max daily loss, automated stop-loss.
Done when: paper win-rate matches or exceeds BOTH manual journal win-rate AND Webull CSV import win-rate over 30 sessions.
(Webull CSV = real executed trades, journal = curated manual logs — both must be beaten for Phase 4 to be justified.)

### Phase 4 — Live Autonomous Trading
**Goal:** Real money automated execution. Fully systematic — no emotion, no human override needed.
- Same entry criteria as Phase 3 but live Alpaca account
- Human kill switch always available (sidebar toggle) but should rarely be needed
- Hard daily loss limits + drawdown stops
- Full audit trail via journal + Supabase
- **Fractional Kelly position sizing (KEY — April 10 insight):**
  The bot calculates optimal position size per trade automatically:
  - Inputs: account balance + verified win rate for THIS structure type + TCS confidence + market regime multiplier
  - Kelly formula: sizes up on high-edge setups, sizes down on lower-confidence structures
  - Removes the last human variable (sizing decisions) from the execution loop
  - No guardrails needed because the sizing is mathematically calibrated to edge
  - Result: fully autonomous from signal → size → entry → exit. No emotion possible.
- Done when: live P&L matches or exceeds paper P&L over 30 sessions

### Phase 5 — Meta-Brain + Marketplace (18–30 months from Phase 1 start)
**Goal:** Dynamic routing system + "copy a top trader" marketplace.

**What gets built:**
- **Leaderboard** (opt-in): surfaces top-performing users by win rate, structure accuracy, regime performance
- **Brain licensing marketplace:** top traders list their brain for $199/mo (they earn revenue share, you take a cut)
- **Collective brain activation:** Layer 2 goes live — anonymized outcomes from all users pool into baseline signal weights. Requires n ≥ 50 per structure across platform before activating.
- **Meta-brain (Layer 3):** Dynamic routing engine. Watches real-time market conditions, routes to whichever user profile has historically dominated that exact context:
  - Time of day (9:30 vs 11 AM vs afternoon performance profiles)
  - Market regime (hot tape, cold tape, transitional)
  - Day of week (Monday follow-through vs Friday fade tendencies)
  - Macro environment (VIX spike, earnings season, Fed week)
  - Asset-specific (which brain dominates THIS ticker category)
- **Market regime tagging:** Every prediction + outcome tagged with regime at time of trade. Regime multipliers applied to TCS score — hot tape bullish breakout = higher confidence, cold tape same setup = lower.
- **Revenue share system:** Top performers earn passive income automatically from licensing fees

**What needs to be true:**
- 2,000+ users with 50+ verified trades each before meta-brain routing is meaningful
- Opt-in required for leaderboard + brain sharing (personal brain always stays isolated)
- Market regime detection built as multiplier, NOT a hard mode switch — bot never sits on its hands

**Pricing at this phase:**
- Retail Meta-Brain: $999/mo
- Brain licensing: $199/mo (creator gets ~40% revenue share)

### Phase 6 — Asset Class Expansion (2.5–3.5 years from Phase 1)
**Goal:** Same architecture, different data feeds. One codebase, multiple markets.

**Asset classes to add (priority order):**
1. **Futures: ES/NQ** — institutional money, higher ACV users, same IB structure applies
2. **Crude oil / Gold futures** — commodity traders, different volatility profile, same framework
3. **Crypto: BTC/ETH** — 24hr session-based IB equivalent, massive addressable market
4. **Forex** — session-based IB structure (London/NY session open = IB equivalent)

**Why it works without rebuilding:**
- Volume profile + IB structure is universal — the same auction theory applies to any liquid market
- The brain calibrates per-instrument, per-user — same loop, new data feed
- New asset class = new user segment = new revenue with no new architecture

### Phase 7 — Institutional Data Licensing (3.5–5 years from Phase 1)
**Goal:** Monetize the dataset externally. B2B revenue layer on top of consumer SaaS.

**What the dataset is by this point:**
- 10,000+ traders, verified outcome logs, millions of structure predictions mapped to actual outcomes
- Tagged by: market regime, time of day, asset class, TCS band, structure type, account size, trader tenure
- Multi-year time series across multiple market cycles
- No competitor can replicate this — it requires years of real retail traders logging real verified outcomes

**Who buys it:**
- Quant funds needing retail behavioral data for signal research
- Prop trading desks wanting calibrated retail flow intelligence
- Fintech companies building trading products who want pre-validated signal infrastructure
- Retail brokerages wanting to offer "personalized edge" as a platform feature (acquisition target)

**Licensing model:**
- API access to anonymized dataset: $2,000–$10,000/mo per institutional seat
- Custom analytics / research packages: project-based pricing
- Full platform acquisition: $200–300M range at this scale (see exit math below)

**Exit math:**
- At $4.5M ARR (Phase 5): $36–67M exit at 8–15× multiple
- At $20M ARR (Phase 7, full stack + institutional): $200–300M acquisition
- The acquirer buys the dataset, the brain architecture, and the user base — not just the SaaS revenue

---

## 📊 SIGNAL TIER ARCHITECTURE

### Tier 1 — Volume Profile + Day Structure ✅ COMPLETE
Core foundation. Classifies the auction process.
- IB detection (9:30–10:30 ET)
- Volume profile (POC, VAH, VAL, HVN/LVN, double distribution detection)
- TCS (Trade Confidence Score)
- Target zones (Coast-to-Coast, Range Extension 1.5×/2.0×, Gap Fill)
- Distance-to-target widget

### Tier 2 — Order Flow Signals ✅ COMPLETE
Real-time intraday momentum layer. Composite score −100 to +100.
- Pressure acceleration (3-bar vs 10-bar buy/sell delta)
- Bar quality score (0–100)
- Volume surge ratio (vs 10-bar average)
- Tape streak (consecutive bullish/bearish bars)
- IB proximity + volume confirmation

### Tier 3 — Chart Pattern Detection 🔴 TO BUILD (PRIORITY)
Confirmatory signal layer. Detects classic patterns on 5m and 1hr bars.

Patterns to detect:
| Pattern | Direction | Confluence Notes |
|---|---|---|
| Reverse Head & Shoulders | Bullish | Neckline break + volume confirm |
| Head & Shoulders | Bearish | Neckline break |
| Double Bottom | Bullish | Often base of cup, or L-shoulder of reverse H&S |
| Double Top | Bearish | — |
| Cup & Handle | Bullish | Double bottom base + handle pullback |
| Bull Flag | Bullish | Tight consolidation after impulse |
| Bear Flag | Bearish | — |
| Inside Bar | Neutral → directional on break | Full bar range contained within prior bar — coiling energy, breakout watch above/below prior bar's high/low |

Confluence scoring logic:
- Single pattern = base score
- Two patterns aligning (e.g., double bottom as left shoulder of reverse H&S) = 1.5× score
- Pattern + volume profile level (HVN/POC/IB) = "confluence confirmed"
- Pattern + trendline hold + volume contraction = "Coiled — breakout watch"

Example model output when built:
> "Neutral day — but 1hr reverse H&S neckline unbroken at $2.49 + trendline hold → bullish resolution probable"
> "Fakeout potential — coiled at trendline + POC confluence → breakout watch, not exit signal"

Real-world gap this fills (from today, April 6):
RENX → model said "fakeout potential" (Neutral structure read, correct)
but user identified 5m AND 1hr reverse H&S manually.
Pattern detection would have flipped the read to: "Neutral + H&S bullish confirmation"

### Tier 4 — Trendline Detection 🔲 FUTURE
Auto-draw trendlines from swing highs/lows on 5m/1hr/daily/weekly.
Required for: compression score, trendline hold confirmation, pattern geometry (necklines, channels).

**Key design insight (April 8):** Trendlines on bigger timeframes carry MORE weight — not less.
Daily/weekly trendlines have thousands of participants watching and placing orders at them,
making them self-fulfilling. 5m trendlines are noise by comparison.

Build priority order:
1. Daily trendline first — most participants watching = strongest signal
2. 1hr trendline second — intraday structure, IB context
3. 5m trendline third — entry timing only, not structure signal

Scoring rule when built:
- Daily trendline hold/break = high confidence signal (weight: 1.5×)
- 1hr trendline hold/break = medium confidence (weight: 1.0×)
- 5m trendline = entry timing only, not a structural signal (weight: 0.5×)
- Multi-timeframe alignment (daily + 1hr trendline both holding same level) = "Compression confirmed" (weight: 2.0×)

---

## 🔧 7-STRUCTURE FRAMEWORK ✅ ALREADY BUILT

Already implemented with hard 3-branch decision tree (no fallthrough):

| Structure | IB Behavior | Signal |
|---|---|---|
| **Trend Day Up** | One side broken (high) only — early, closes at extreme, directional vol | Aggressive long targets |
| **Trend Day Down** | One side broken (low) only — early, closes at extreme, directional vol | Aggressive short targets |
| **Normal Day** | No IB break — wide IB, big players set range | Fade extremes → POC |
| **Normal Variation** | One side broken moderately, returns inside | Conservative fade |
| **Neutral Day** | Both IB sides violated, close in middle | C2C targets, tight stops |
| **Neutral Extreme** | Both sides violated, closes top or bottom 20% | High volatility, wait |
| **Non-Trend Day** | Narrow IB, low volume, no interest | Avoid — no edge |
| **Double Distribution** | Bimodal volume profile, two distinct POCs | Gap fill between nodes |

Branch logic (hard gates, no fallthrough):
- Branch A: no_break → Normal or Non-Trend
- Branch B: both_broken → ONLY Neutral family (Neutral or Neutral Extreme)
- Branch C: one_side → ONLY Trend Day, Normal Variation, or Double Distribution

NOTE: run batch backtest on 20+ tickers with current logic to rebuild training data (Phase 2 task).
RVOL floor now built into scanner (2.0x default). Consider tightening Trend Day threshold after 500+ data points.

---

## 🕌 ISLAMIC COMPLIANCE FILTER 🔲 BACKLOG
Build after Tier 3 pattern detection.

- API: Musaffa (musaffa.com) — halal / questionable / not-halal per ticker
- Where: Scanner tab — optional toggle filter
- Signal value: not-halal = structurally reduced Islamic buyer pool
- Market value: inclusive to Islamic trading community — unique differentiator
- Build time: ~30 minutes once Tier 3 is done

---

## 📋 CURRENT 7-TAB LAYOUT

| Tab | Name | Status |
|---|---|---|
| 1 | 📈 Main Chart | ✅ Complete |
| 2 | 🔍 Scanner | ✅ Complete |
| 3 | 📋 Playbook | ✅ Complete |
| 4 | 🔬 Backtest Engine | ✅ Complete |
| 5 | 📖 Journal | ✅ Complete |
| 6 | 📊 Analytics & Edge | ✅ Complete |
| 7 | 💪 Small Account | ✅ Complete |

---

## 💡 USER-GENERATED INSIGHTS (Trading Observations)

**Insight 1: Trendline + Level Confluence = Compression → Expansion**
"As long as a stock follows its trendline and holds levels in confluence with it,
it's set up for consolidation then breakout."
→ Encode as compression score in Tier 3 pattern engine.

**Insight 2: Pattern Stacking / Confluence**
Patterns appear together and amplify each other:
- Double bottom = base of cup & handle
- Double bottom = left shoulder of reverse H&S
- Wedge compression = flag before breakout
Tier 3 must detect stacked patterns and score them higher than singles.

**Insight 3: Entry Quality Logging**
Labeling trades as "FOMO" vs "calculated" at entry time builds one of the most
valuable personal edge metrics over time.
Over 50+ trades, win-rate by entry-type reveals discipline edge vs luck.

---

## 🧠 BEHAVIORAL DATA TRACKER — Full Build Spec (Fleshed Out April 10, 2026)

### What it is
A discipline analytics layer built on top of the existing trade journal.
Every trade already gets logged — this adds a single required field at log time: **entry type**.
Over time it builds the most honest metric a trader can have: *do you actually trade better when you're disciplined?*

### Entry Type Labels (logged at trade entry)
| Label | Definition |
|---|---|
| **Calculated** | Entry based on pre-planned level, structure, and thesis. You had a reason before price got there. |
| **FOMO** | Chased a move already in progress. Entered because price was going up, not because of a level. |
| **Reactive** | Responded to a break or signal in real time — not pre-planned but not pure chase either. Valid entry type. |
| **Revenge** | Entered to recover a previous loss. Highest-risk behavioral category. |
| **Conviction Add** | Added to a winning position at a planned level. Distinct from averaging down. |
| **Average Down** | Added to a losing position. Needs to be tracked separately from Conviction Add. |

### What it produces over 50+ trades
- **Win rate by entry type** — the core output. "Calculated: 64% | FOMO: 31% | Revenge: 12%"
- **P&L by entry type** — win rate isn't enough; a FOMO trade might win but with worse follow-through
- **Average follow-through by entry type** — calculated entries go further on winners than FOMO entries
- **Revenge trade frequency** — tracks emotional state patterns, flags if increasing over time
- **Discipline score (0–100)** — % of entries that are Calculated or Reactive vs FOMO/Revenge over rolling 20 trades
- **Discipline equity curve** — same format as the grade equity curve, but tracks discipline score over time

### Where it lives in the UI
1. **Journal tab** — entry type dropdown added to the log form (required field, not optional)
2. **Analytics tab** — new "Behavioral Edge" section:
   - Win rate table by entry type (color coded green/yellow/red)
   - Discipline score card (rolling 20-trade window)
   - Discipline equity curve chart
   - P&L by entry type bar chart
   - "Your calculated entries outperform your FOMO entries by X%" — plain language callout
3. **Performance tab** — Discipline Score added as a 6th KPI card

### How it feeds the brain
- Entry type gets stored with each journal row (new column: `entry_type`)
- Brain weight recalibration checks: *if FOMO win rate is < 40% consistently, auto-suppress FOMO-correlated signal patterns*
- Long term: behavioral patterns become part of the collective brain — platforms can detect if a trader's discipline score is declining before their P&L shows it

### Why this is a product differentiator
No trading platform tracks this. Tradervue doesn't. Tradezella doesn't. Everyone tracks outcome — nobody tracks *why* you entered.
This data answers the question every trader asks but can't answer: "Am I losing because my strategy is bad, or because I don't follow it?"
At scale: if 500 users' FOMO trades consistently underperform their calculated entries by 20%+ across all structures, that's a publishable market insight — "FOMO costs retail traders X% per trade" — that drives press coverage and user acquisition.

---

## 🎯 NIGHTLY TICKER RANKINGS — Built April 11, 2026

Human signal layer built into Paper Trade tab (Section 6).
User rates each watchlist ticker 0–5 every night based on chart read.
Outcomes auto-verified next trading day (% change pulled from Alpaca).
Accuracy table by rank tier builds over time.

**Supabase table:** `ticker_rankings` (user_id, rating_date, ticker, rank, notes, actual_open, actual_close, actual_chg_pct, verified, tcs, rvol, edge_score, predicted_structure, confidence_label, created_at)
**Backend functions:** `ensure_ticker_rankings_table`, `save_ticker_rankings`, `load_ticker_rankings`, `verify_ticker_rankings`, `load_ranking_accuracy`
**UI:** Paper Trade tab → Section 6. Left col: nightly form (watchlist auto-loaded, rank 0-5 selectbox per ticker + notes). Right col: Verify button + accuracy by rank tier table (with Avg TCS/RVOL when data exists) + recent rankings log (shows TCS, RVOL, predicted structure).
**Context enrichment (April 12):** At save time, each ranking is enriched with the bot's watchlist prediction context for that ticker (TCS, RVOL, Edge Score, predicted_structure, confidence_label). This creates two independent evaluation tracks stored side-by-side: YOUR rank (human intuition) + the BOT's prediction context (algorithm). Neither overwrites the other. Cross-tab analysis enables questions like "do my rank-5 picks perform better when the bot also has high TCS?" and "am I better than the bot at certain structure types?"
**Auto-verification (April 12):** Bot auto-verifies yesterday's ticker rankings at 4:25 PM ET alongside watchlist prediction verification. Separate independent verification — rankings measure YOUR stock-picking skill, watchlist verification measures the ALGORITHM's structure prediction accuracy.

**First validation (April 10):** Rank 5s → 4/6 winners including SKYQ +62.97% and CUE +68.46%. Rank 4s → 4/4 winners. Rank 3s → 0/4 winners (clean sweep of losses). Pattern is real and needs 30+ nights to confirm statistically.

**Future use:** Once the ranking system shows a clear differentiated accuracy gradient across tiers (rank-5 meaningfully outperforming rank-0, with a consistent spread in between), ranking score feeds into paper trade Kelly sizing as a confidence multiplier alongside TCS. The system evolves by comparing ALL tiers — rank-5 could end up noisier than rank-4. The comparison is what matters, not any single tier's number.

**SQL to create table:**
```sql
CREATE TABLE IF NOT EXISTS ticker_rankings (
  id           SERIAL PRIMARY KEY,
  user_id      TEXT NOT NULL,
  rating_date  DATE NOT NULL,
  ticker       TEXT NOT NULL,
  rank         INTEGER NOT NULL CHECK (rank >= 0 AND rank <= 5),
  notes        TEXT DEFAULT '',
  actual_open  FLOAT,
  actual_close FLOAT,
  actual_chg_pct FLOAT,
  verified     BOOLEAN DEFAULT FALSE,
  tcs          REAL,
  rvol         REAL,
  edge_score   REAL,
  predicted_structure TEXT,
  confidence_label    TEXT,
  created_at   TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(user_id, rating_date, ticker)
);
```

---

### Build requirements
- Add `entry_type` column to `trade_journal` table in Supabase (TEXT, nullable for backward compat)
- Add entry type dropdown to journal log form in app.py (Calculated / FOMO / Reactive / Revenge / Conviction Add / Average Down)
- Analytics tab: new Behavioral Edge section with the 5 charts/tables listed above
- Performance tab: Discipline Score KPI card
- Discipline score formula: `(calculated_count + reactive_count) / total_trades_last_20 × 100`
- Build time estimate: ~3-4 hours for full implementation
- Priority: build after Phase 1 data gate is hit (150+ predictions) — needs enough journal entries to be meaningful

### Data already being collected that maps to this
- Journal `grade` field (A/B/C/F) partially overlaps — A grades tend to be calculated entries
- But grade ≠ entry type. A FOMO entry can get an A grade if it worked out. This is different.
- `entry_type` must be logged at the moment of entry — cannot be backfilled accurately after the fact

**Insight 4: After-Hours Small-Cap Reality**
After-hours on thin small caps: a few buy orders can create a big-looking volume spike.
Patterns formed in after-hours are low-conviction until confirmed at regular open.
Key: does the level hold into and through next morning's open?

---

## 🔨 TECHNICAL FIXES COMPLETED (Recent Sessions)

| Fix | Details |
|---|---|
| Verify predictions date picker | Manual date picker replaces "Verify Yesterday" |
| Supabase date range query | pred_date is timestamp — use gte()/lt() not eq() |
| Predict All trading day | Uses get_next_trading_day() — no weekend/holiday saves |
| IB computation | pd.Timestamp(tz=tz) cutoff, includes full 10:30 bar |
| IB manual override | st.form prevents collapse; per-ticker; ACTIVE label |
| Log entry timestamp | Date + time picker (1-min step) for accurate backdating |
| load_watchlist import | Added to explicit import block |
| get_next_trading_day | New backend.py function using Alpaca calendar API |

## 🐛 KNOWN ISSUES

| Issue | Priority |
|---|---|
| artifacts/api-server workflow failed state | Low — clean up, doesn't affect main app |
| April 5 predictions in Supabase (Saturday) | Low — unverifiable junk data, can ignore |
| IB 1-3 cent gap vs Webull | Unfixable — data feed fragmentation; use IB Override |

---

## ✅ BUILD CHECKLIST (Tonight / Next Session)

- [x] **Tier 3 pattern detection** — H&S, reverse H&S, double bottom/top, cup & handle, bull/bear flag + confluence scoring — COMPLETE (April 6)
- [x] **Batch calibration run** — One-click "🧠 RUN CALIBRATION" button in Backtest tab. 28 small-cap tickers × configurable 1–22 trading days lookback. Auto-saves to Supabase, shows win rate + structure distribution summary. Original per-ticker simulation unchanged below it. COMPLETE (April 6)
- [ ] **Islamic compliance filter** — Musaffa API, Scanner tab toggle (after Tier 3)
- [ ] **Clean up artifacts/api-server** — failed workflow, not needed

## 🧠 META-BRAIN & DYNAMIC PROFILE SWITCHING (Saved April 10, 2026)

### The Vision
As owner you have visibility into ALL user data. That's not just a privacy consideration — it's a product superpower.

**Layer 3: The Meta-Brain** (beyond personal + collective brains)
A dynamic routing system that watches market conditions in real time and switches to whichever user profile has historically performed best in that exact context:
- Hot small-cap tape → routes to the user who crushes momentum setups
- Slow/cold market → routes to the user who thrives in consolidation
- First 30 minutes of day → routes to whoever has the best 9:30–10:00 AM track record
- Earnings season / macro volatility → routes to the user who performs best in high-VIX conditions
- Switches dynamically, automatically, with no human intervention

This is ensemble trading — the same concept behind hedge fund pod structures — built from real retail trader data collected passively through a product they're already paying for.

### The Business Model Expansion (Updated April 10, 2026)

**Tier 1 — $49/mo:** Personal brain (structure predictions, TCS calibration, win rate tracking)
**Tier 2 — $99/mo:** Personal brain + daily Telegram scanner alerts
**Tier 3 — $199/mo:** License a top trader's verified brain (they earn ~40% revenue share)
**Tier 4 — $999/mo:** Retail Meta-Brain (dynamic routing across verified profiles, live conditions)
**Tier 5 — $5,000–$15,000/mo (annual):** Professional/Institutional Meta-Brain (signal output for prop traders, small funds)
**Revenue share:** Top performers earn passive income automatically from brain licensing

### Revenue Projections by Phase

**Phase 1–2 (0–6 months): Beta → Early paid**
~100–200 paid users at avg $49 → **$5–10K/mo = $60–120K ARR**

**Phase 3–4 (6–18 months): Automation live, product proven**
500 users:
- 250 × $49 = $12,250 | 175 × $99 = $17,325 | 75 × $199 = $14,925
- **~$44,500/mo = $534K ARR**

**Phase 5 (18–30 months): Meta-brain live, marketing agency engaged**
2,500 users across all tiers:
- 1,200 × $49 = $58,800 | 800 × $99 = $79,200 | 400 × $199 = $79,600
- 90 × $999 = $89,910 | 10 × $5,000 = $50,000
- Plus marketplace cuts: +$150–300K/yr
- **~$357,500/mo = ~$4.5M ARR total**

**Phase 6–7 (3–5 years): Asset expansion + institutional**
10,000+ users + B2B licensing:
- Consumer SaaS: ~$1.4M/mo | Institutional licensing: $2–5M/yr additional
- **~$19–22M ARR**

**Exit multiples:**
- At $4.5M ARR (Phase 5): **$36–67M** at 8–15× SaaS multiple
- At $20M ARR + institutional data locked in: **$200–300M acquisition target**
- Acquirer buys: dataset, brain architecture, user base — not just SaaS revenue

**Why the data moat is the actual asset:**
- Competitor launches today → starts with zero verified trade data
- EdgeIQ at 500 users → already has 500 brains, thousands of verifications, real P&L outcomes
- Meta-brain requires years of consistent user data — no shortcut, no way to replicate
- Every month widens the gap no competitor can close by just writing better code

**Owner data access:**
- As platform operator you own all data in your Supabase instance — fully legitimate
- Aggregate/anonymized use for collective brain + meta-brain = standard SaaS practice (Spotify, Netflix, Google all do this)
- Terms of Service covers internal use for platform improvement
- Opt-in required only for leaderboard/brain-sharing — personal brain data always stays isolated
- External institutional licensing requires explicit opt-in + revenue share language in ToS

### What needs to be true for this to work
1. Users must log consistently (this is why the trade log form and CSV import exist — reduce friction)
2. Each brain needs enough data to be meaningful (target: 50+ verified trades per user before routing)
3. The switching logic needs market regime context (the hot/cold/neutral market phase we discussed)
4. Privacy: users must opt-in to the meta-brain / leaderboard tier — personal brain data always stays isolated unless explicitly shared

### Build order implication
Nothing changes about Phase 1–4 order. The foundation being laid right now (trade logging, brain weights, structure verification) IS the meta-brain's raw material. No wasted work.

---

## 🌡️ MARKET REGIME DETECTION (To Add — Discussed April 10)
Tag each prediction + verified outcome with the market regime at the time.
Regimes: Hot (small-cap tape ripping), Cold (low volume, no follow-through), Neutral/Transitioning.
Currently in: HOT ZONE (small caps, April 2026).
Use: not as hard filters, but as multipliers — hot tape → bullish breakout predictions carry higher confidence.
Build approach: multiplier on existing signals, NOT a mode switch. Bot never sits on its hands.
Current status: BACKLOG — collect regime-tagged data passively first, build weighting logic once enough tagged samples exist.

---

## 🏆 COMPETITIVE POSITIONING & VISION (Saved April 8, 2026)

### What corporate trading desks actually sell
Hedge funds and prop desks sell one thing: consistent, explainable edge with controlled drawdown.
Not prediction accuracy alone — *calibrated* accuracy. Knowing when your signal is right AND when
it isn't is worth more than being right 70% of the time without knowing which 70%.

EdgeIQ is built around that exact concept. The brain weight system doesn't just track win rate —
it knows win rate by structure type, which means it can say "don't take this trade, your historical
edge on this structure is 42%." That's risk-adjusted signal filtering. That's what quant desks do.

### The three things that make it genuinely competitive

**1. The discovery engine (Phase 2)** — if it surfaces real, reproducible edges that hold up over
time, you have something quantifiable and defensible. "Our system discovered that X condition
produces Y outcome with Z% confidence across N trades" is a pitch, not a claim.

**2. Asset class expansion** — right now it's small-cap equities. The same volume profile +
structure framework applies to futures (ES, NQ, crude), crypto, and forex. Same architecture,
different data feeds. A system that works across asset classes with per-instrument calibration
is institutional-grade infrastructure.

**3. The personalization layer at scale** — this is the actual moat. If the brain calibrates to
each user's edge rather than a generic edge, you have something no corporate desk has built for
retail. Renaissance doesn't care about your individual win rate — they run one model across
everything. EdgeIQ runs a different model per trader. At scale, that's a SaaS product that
corporate analytics firms would license, not just individual traders.

### Why it won't hit the "posted my algo" ceiling
The "posting my algo" ceiling: someone backtests something, it works on paper, they publish it,
it stops working. Because they never had a calibration loop — they optimized to historical data.

EdgeIQ has a live feedback loop. Systems with live feedback loops that actually adapt don't stop
working — they learn when market conditions shift. That's why Renaissance has worked for 30+ years
while every "I published my algo" strategy has a 6-month half-life.

---

## 📈 PATTERN NOTE — Ascending Base + Liquidity Break (logged April 8)

**Setup:** Stock in sideways-to-upward angled consolidation (higher lows visible on 5m or 15m). Previous swing high = liquidity zone (cluster of stop orders sitting above it).

**Entry trigger:** 5m or 15m candle closes ABOVE the previous high AND the following candle holds above it (does not immediately reverse back through).

**Why it works:** The close-above filters out stop hunts (wicks through = fake). Two consecutive candles above the level = real buyers absorbed the liquidity and are defending the breakout.

**Tier 4 detection candidate:** Requires trendline detection (ascending base angle auto-identified) + previous high level flagged as liquidity zone + breakout candle + confirmation candle. Full auto-detection needs Tier 4 trendlines first.

---

## 🔒 PRESERVATION RULES (NEVER MODIFY)
- compute_buy_sell_pressure()
- classify_day_structure()
- compute_structure_probabilities()
- brain_weights.json
- Architecture: math/logic → backend.py only; UI/rendering → app.py only


## 2026-04-08 — Simulation Log Upgrades
- **Deduplication**: Added dedup logic by `(ticker, sim_date)` key before rendering the trade-by-trade log; shows a count if dupes were removed
- **Per-Ticker Breakdown table**: New expander above the log showing each ticker's: Win %, W/L count, Avg TCS, Top Structure, Avg Follow-Thru %, False Break %, Dates Seen — sorted by win rate; color-coded 🟢/🟡/🔴
- **Date column**: Added "Date" as column 0 in the trade-by-trade log so each row shows which trading date it belongs to (useful for range runs)
- `_BT_COLS` expanded from 10 to 11 columns; all row cell indices shifted accordingly

## 2026-04-08 — Load Saved Simulation Results
- Added "📂 Load Saved Simulation Results" expander in Section 2 (Simulation) of the Backtest tab
- Flow: (1) "Fetch My Saved Dates" → pulls distinct sim_dates from Supabase, (2) multiselect picker for date(s), (3) "Load Selected" reconstructs _results list + _summary dict from saved DB rows, injects into bt_results_cache session state, then st.rerun() so full chart/stats pipeline renders automatically
- Handles field remapping: follow_thru_pct → aft_move_pct; reconstructs actual_icon from outcome text; close_price defaults to 0 if not stored
- Works for single-day and multi-date range loads; _sim_is_range=True when >1 date selected

## 2026-04-08 — Auto Paper Trading Tab (📄 Paper Trade)
- New 8th tab added: "📄 Paper Trade"
- **Section 1 — Scan & Log**: date picker, feed selector, TCS min slider (default 50), price range, tickers textarea (pre-filled with watchlist). Calls run_historical_backtest → filters TCS ≥ min → calls log_paper_trades → deduplicates by (ticker, trade_date) before saving. Shows preview table of qualifying setups.
- **Section 2 — 3-Week Tracker**: 4 KPI cards (win rate, total setups, avg TCS, avg follow-thru), daily win rate trend chart with 55% target line, per-ticker breakdown table, full log expander
- **Backend additions**: ensure_paper_trades_table(), log_paper_trades(), load_paper_trades() in backend.py. Schema shown as SQL fallback if table doesn't exist yet.
- **Table**: paper_trades — user_id, trade_date, ticker, tcs, predicted, ib_low, ib_high, open_price, actual_outcome, follow_thru_pct, win_loss, false_break_up/down, min_tcs_filter, created_at
- User must create paper_trades table in Supabase SQL editor (shown on first load if missing)

## 2026-04-08 (Evening) — Paper Trader Bot + Adaptive Learning Loop

### Paper Trader Bot (paper_trader_bot.py) — FULLY LIVE
- User created paper_trades table in Supabase ✅
- Bot confirmed connected (HTTP 200) and watching **45 tickers** from live Supabase watchlist
- Fixed: was hardcoded to 14 stale tickers. Now calls load_watchlist(USER_ID) on every startup → falls back to 14 only if Supabase load fails
- Schedule: **10:35 AM ET** morning scan → **4:05 PM ET** EOD outcome update → **4:10 PM ET** brain recalibration
- RENX already in watchlist (position 43 of 45) — user noted potential reverse H&S forming on 15m, not confirmed yet

### Paper Trade Tab — 3 New Sections Added
- **Live Auto-Scan toggle**: when browser open during market hours, auto-scans every 30 min
- **Section 3 — Manual EOD Update**: force-update outcomes for any date on demand (don't wait for bot's 4:05 run)
- **Section 4 — IB Window Comparison**: same tickers through 10:30 / 12:00 / 14:00 cutoffs in parallel; shows win rate, W/L, avg TCS, follow-thru, false break side by side; tells you which cutoff produces cleanest signals
- **Section 5 — Brain Health**: live weight table with status badges (🟢 Boosted / ⚪ Neutral / 🔴 Penalized), "Recalibrate Now" button, "Reset to Neutral" button

### Adaptive Learning Loop (recalibrate_from_supabase) — COMPLETE
- New function in backend.py reads from BOTH:
  1. accuracy_tracker (journal-verified trades) — predicted / correct ✅/❌
  2. paper_trades (bot automated signals) — predicted / win_loss
- **Volume-weighted source blending**: each source's accuracy computed independently per structure, then blended by sample count. More data = more influence. NOT a fixed 50/50 split — the source with more samples carries proportionally more weight.
- Blend rules per structure:
  - Both ≥ MIN_SAMPLES → blended = (j_n × j_acc + b_n × b_acc) / (j_n + b_n)
  - Only journal ≥ MIN_SAMPLES → use journal only
  - Only bot ≥ MIN_SAMPLES → use bot only
  - Neither ≥ MIN_SAMPLES → skip (no update)
- MIN_SAMPLES scales with total data: 3 (<50 trades), 5 (<200), 8 (<500), 12 (500+)
- EMA learning rate also scales: 0.10 (<10 per structure) → 0.40 (100+ per structure)
- Weights saved per-user in Supabase (user_preferences.prefs["brain_weights"]) — isolated from other users
- Brain Health table shows: Journal Acc (n), Bot Acc (n), Blended Acc, Last Δ, Status per structure
- Bot auto-runs recalibration at 4:10 PM ET after EOD outcomes settle

### Data Flow Map (complete chain)
```
Journal Tab (pre-market predictions)
    ↓ verify button EOD
watchlist_predictions table
    ↓ verify_watchlist_predictions()
accuracy_tracker table ←── also fed by manual trade log_accuracy_entry()
    ↓
recalibrate_from_supabase() [4:10 PM daily]
    ↑
paper_trades table ←── bot logs at 10:35 AM, outcomes at 4:05 PM
    ↓
volume-weighted blend per structure (≥MIN_SAMPLES each)
    ↓
brain_weights → Supabase per-user prefs
    ↓
TCS scoring uses updated weights next morning
```

### Gemini Code Review (April 8 evening) — Points Addressed
1. **Slippage 0.0%**: Valid for Phase 4 — paper calibration only measures signal quality not P&L. Add 0.75% default for live sim in Phase 4. ✅ Noted.
2. **Sample skew**: Fixed with volume-weighted source blending. Simple 3x multiplier was wrong. Now uses proportional sample-count weighting. ✅ Fixed.
3. **Edge case — 0 journal entries**: Already handled by MIN_SAMPLES=5 gate. Bot data only until journal hits 5. ✅ Already correct.

### Tomorrow's Reminders
0. ~~**Inside Bar pattern**~~ → ✅ BUILT April 12, 2026. Added to `detect_chart_patterns()` on both 5m + 1hr. Compression scoring + POC/IB confluence.
1. **Clean accuracy_tracker**: Remove entries for tickers outside user's trading universe (random predictions that polluted the table). Calibration reads from accuracy_tracker — out-of-universe tickers skew structure weights.
2. **Webull CSV import pipeline**: Build import flow that maps each Webull trade (entry date + ticker) to an IB structure, feeds accuracy_tracker automatically. Removes all manual work for calibration.
3. **Go through core functions with AI**: Review brain weight math, TCS scoring, IB structure logic, blend accuracy — function by function review (user requested, Gemini timed out on full paste).
4. **Slippage Phase 4**: When building live sim / entry signal layer, default slippage to 0.75% for small-cap $2–$20 range.
5. **Phase 4 planning**: After 3-week paper calibration proves signal quality — add entry trigger (IB breakout + volume confirm), stop loss (IB low - 1 ATR buffer), target (measured move from IB height), position sizing (account % risk).

### Key Decisions Made
- **EOD journal is NOT optional**: Each verified journal entry is a direct training signal for brain weights. Miss journals = weights don't reflect your actual edge.
- **Watchlist predictions (untaken trades) are FINE for calibration**: Measures structure accuracy not trade P&L. Only clean up tickers completely outside your universe.
- **3-week paper window is deliberate**: Structure prediction must be proven before adding entry/exit layer. Bot currently predicts structure + win/loss, NOT buy price / stop / target (Phase 4).
- **Window comparison logic**: More cutoff windows = more calibration data. 3 windows × 45 tickers × 3 weeks = ~405 data points vs 135 single-window. Also reveals whether waiting for midday confirmation improves win rate.

### Current Watchlist (45 tickers as of April 8)
HCAI, MGN, HUBC, TDIC, SILO, CETX, IPST, LNAI, ZSPC, CUE, SKYQ, SIDU, CUPR, LXEH, KPRX, MEHA, JEM, AXTI, ADVB, TPET, WGRX, AAOI, MAXN, IRIX, PROP, AGPU, BFRG, MIGI, PPCB, CAR, AMZE, UK, TBH, AIB, ITP, ARTL, NCL, PSIG, RBNE, CYCU, LPCN, FCHL, RENX, MOVE, TURB

---

## Product Strategy Brainstorm — 2026-04-09 (pre-sleep session)

### Product Identity (locked tonight)
EdgeIQ is a **systems tool for traders to find their personal edge, then automate it.**
"Find your edge, then automate it" — the name always pointed here. Product truth articulated April 9.

### Repriced Tier Structure
| Tier | Price | Description |
|---|---|---|
| Starter | $49/mo | Journal + calibration + edge analytics. No live scanner. Entry tier. |
| Pro | $99/mo | Full scanner + alerts + calibration + paper trading. Core product. |
| Autonomous | $199/mo | Live trading enabled after edge proven. Bot manages positions. Phase 4 unlock. |

ARR projections (Pro tier):
- 50 users = $59,400/yr
- 100 users = $118,800/yr
- 500 users = $594,000/yr

### Copy Algo Tier Concept (brainstormed tonight)
User asked: "What about an expensive tier to copy a top learned algo from user data?"

**Verdict: Does NOT defeat the selling point — it's a separate product layer.**

Concept: "Copy Algo" marketplace tier ($299+/month)
- Top-performing EdgeIQ users (verified 12+ months, 65%+ win rate) opt in to share their brain weights
- Subscribers copy their structure preferences, alert thresholds, and weights
- Revenue share back to the algo owner
- The copy subscriber eventually migrates to their own calibration over time ("training wheels")

Risks to address:
- Top algo hits a drawdown → users blame EdgeIQ → need clear disclaimer and expectation setting
- Brain weights alone aren't the full picture (execution still matters)
- Requires minimum data threshold before anyone's algo is "shareable"

**This is Phase 4-5 territory. Don't build it until 50+ active users have 6+ months of data each.**
It's a marketplace play — needs supply (proven algos) before it can have demand.

### Direct Broker Sync — What's Actually Possible
User asked: "Is Webull direct sync possible? How much would that cost?"

**Webull: NO public retail API.** Institutional API exists but not accessible to independent developers.
Workaround is CSV export (current approach). Could theoretically scrape but fragile and against ToS.

**What IS possible for direct sync:**
- Alpaca — already integrated (paper trading live)
- Tradier — has public API, ~$10-25/month for live data feed
- Interactive Brokers (IBKR) — has API, complex but powerful, used by sophisticated traders
- TD Ameritrade/Schwab — API exists post-merger, Schwab is opening it up
- Robinhood — no API

**Priority order for direct sync:**
1. Alpaca (done — Phase 4 live trading)
2. IBKR (most serious traders use it, highest value add)
3. Tradier (easy API, good for mid-tier users)
4. Webull CSV will likely remain the workaround indefinitely

**Cost to build:** IBKR integration ~2-3 days of dev work. No licensing fee for read-only position sync. Live trading via IBKR requires account + API key from user.

### Features That Would Make EdgeIQ Huge
1. **Direct broker sync** — no CSV needed. Trades auto-import, auto-enrich, auto-calibrate. Near-zero churn.
2. **"Prove Your Edge" report** — exportable PDF: win rate by structure, best/worst setup, profit factor. Traders share these. Free marketing flywheel.
3. **Community aggregate insights** — individual brains stay personal. But publish: "Normal Day setups on IWM uptrend days = 74% win rate across all EdgeIQ traders." Proprietary research. Drives acquisition.
4. **Autonomous phase with verified track record** — flip from paper to live with 6 months of documented proof. That's a news story.
5. **Zero-friction Telegram journaling** — log a trade in 10 seconds while watching the chart. (Building tomorrow.)

### Acquisition Potential (user raised tonight)
**Real. The autonomous phase is the trigger.**

Potential acquirers:
- **Brokers** (Webull, IBKR, Alpaca) — they want calibration data + user base. Alpaca especially aligned since they're already the infrastructure.
- **Fintech platforms** (Bloomberg, FactSet) — small-cap retail trader segment is underserved at institutional level
- **Trading education companies** — the "find your edge + grow as a trader" angle fits ed-tech
- **Prop firms** — a tool that produces traders with proven, documented edges is valuable for recruiting/allocating capital

**What makes it acquirable:**
- Proprietary dataset of trader behavior mapped to market structure outcomes (no one else has this)
- Autonomous trading with verified track record (de-risked product for acquirer)
- Sticky user base (high switching cost = predictable ARR)
- Clean Alpaca integration = easy for broker to white-label or absorb

**When to think about it:** After Phase 4 goes live with 3+ months of autonomous trading with documented returns. That's when the asset has a price.

### The Real Moat (clarified tonight)
NOT the math (replicable).
NOT the data volume (someone could upload more CSVs).

THE MOAT IS:
1. Personal calibration — the bot learns YOUR edge, not a market average. A competitor clone starts flat.
2. The feedback loop — traders improve AS traders using this. They see their own patterns. They don't leave mirrors.
3. Time lead + first mover with real users — by the time anyone notices the niche, you have 12 months of data and a community
4. Switching cost — leaving means losing your entire calibration history

The sell point in one sentence: "EdgeIQ shows you exactly what your edge is, then automates it for you."

### Acquisition Valuation — "If This All Goes According to Plan"
User asked: "How much would a prop or Alpaca pay?"

**"According to plan" definition:** 200+ active users, 12+ months of autonomous trading with documented returns, $20k+ MRR, clean Alpaca integration, verified track record.

**Realistic acquisition range at that milestone: $3M–$8M**

Breakdown by buyer type:

**Alpaca (most likely, most strategic):**
- Already the infrastructure layer. EdgeIQ users ARE Alpaca users.
- They'd value: sticky user base (high LTV, documented trading activity), calibration technology, AUM generated by autonomous accounts
- The story they'd buy: "We acquired the tool that proves retail traders can be profitable on our platform"
- Range: $3M–$8M depending on user count and autonomous track record
- Structure: likely acqui-hire (keep you running it) + earnout tied to user growth

**Prop Firms (TopStep/FTMO tier, NOT Jane Street):**
- They'd be buying: a pipeline of traders with documented, verified edges + the calibration technology
- Most valuable to them: EdgeIQ users arrive pre-qualified. They already know their win rate, their best setups, their structure performance. That's the prop firm's intake process automated.
- Range: $1M–$5M. More if the autonomous returns are strong and consistent.

**Trading Ed-Tech (Warrior Trading, SMB Capital tier):**
- They want: brand + user base + the "find your edge" curriculum angle
- Range: $1M–$3M, likely structured as earnout
- Less upside here — they'd probably just want to white-label it

**What drives the number higher:**
- Autonomous phase live with 3+ months documented returns = biggest single lever
- 500+ active users = institutional attention
- "Prove Your Edge" shareable reports going viral = brand value
- Multi-broker sync = broader addressable market

**What the number is WITHOUT autonomous phase:** ~1-3x ARR. A $20k MRR journaling tool = ~$720k ARR = $1.5M–$3M. Respectable. The autonomous phase is what pushes it to the $5M–$15M range.

**When to think about it:** After Phase 4 has 3+ months of live documented returns. Before that, you're selling potential. After that, you're selling proof.

---

## 🧠 BRAINSTORM SESSION — April 10, 2026 (Full Capture)

---

### ✅ BOT AUTO-VERIFY EOD — ALREADY BUILT (confirmed April 10)
`nightly_verify()` runs at 4:25 PM ET every trading day. Calls `verify_watchlist_predictions()`, posts results to Telegram. The brain gets fresh signal data every session without any manual button press. This was built in Phase 3 of the bot — no action needed.

---

### 🏗️ STRUCTURE DETECTION — ONLY 3 OF 7 SHOWING UP
Not a detection bug. It's a market regime composition effect.

In the current hot small-cap momentum tape (April 2026), nearly every day produces Neutral Extreme (both IB sides broken, closes at extreme) or Trending Day (one side dominant early). The other 5 structures — Non-Trend, Double Distribution, Normal Variation, pure Neutral, Normal — require cold/low-volume/range-bound conditions that simply aren't present right now.

The detection logic in `classify_day_structure()` is correct. The tape is not producing the full range of structures. This is exactly why market regime tagging matters — once every outcome is tagged with the regime at time of trade, you'll see exactly which structures cluster in which market conditions. No code fix needed. Just keep logging and let the data accumulate.

---

### 🕌 ISLAMIC COMPLIANCE FILTER
Not noise, not core. It's a sector + debt ratio filter toggle on top of the existing screener — a user preference layer for a specific segment. The edge model doesn't need it. Low priority. Table for Phase 2+ as a checkbox setting in user preferences. Do NOT build during Phase 1.

---

### 📊 PAPER TRADE SAMPLE SIZE — REVISED UP TO 700+
Original estimate of ~500 was optimistic. The correct number for statistical significance across all 7 structures is **700+ total rows**.

Math: 7 structures × 50 verified trades each = 350 theoretical minimum. But Double Distribution and Non-Trend are rare in momentum markets, so in practice you need 700+ total entries to ensure all 7 reach n ≥ 50. At ~15 tickers/scan × 5 days/week = ~75 predictions/week → 700 rows in ~9–10 weeks of consistent scanning. Start the clock now.

---

### 📡 PRE-MARKET GAP % + RVOL — NO SIP NEEDED
The pre-market gap scanner already runs at 9:15 AM and calculates gap % + PM RVOL using Alpaca's free feed. SIP cap (now - 16min) only applies to intraday real-time data, not pre-market historical bars.

**The actual gap:** The scanner sends these values to Telegram but does NOT save them to Supabase alongside each prediction. Phase 2 needs them as logged features per prediction row for cross-tab analysis.

**Fix (Phase 2 task):** Add `pre_mkt_gap_pct` and `pre_mkt_rvol` columns to `accuracy_tracker` table. Log them at the time the morning scan runs. Zero new data infrastructure required — just schema + logging additions.

---

### 📈 IWM AUTO-LOOKUP — AUTOMATE REGIME TAGGING
IWM day type (Trending Up / Trending Down / Range-Bound) is the primary small-cap tape quality proxy.

**Auto-tag every trade source:**
- **Bot paper trades:** fully automatic at execution — IWM day type known at scan time, log it
- **Manual journal entries:** trade date is recorded → retroactive IWM bar lookup via Alpaca historical data → derive day type → attach to record
- **Webull CSV imports:** same as journal — date → retroactive lookup → backfill regime tag on import

All three sources can be fully automated. No manual input required from user. The IWM lookup on import/journal-save is a one-time Alpaca historical bars call per date.

---

### 🛑 STOP LEVEL TYPES — FULL LIST (April 10 expansion)

Previous short-list (POC, HVN, IB Low, VAL, Whole Number, ATR) was incomplete. Full stop reference library:

**Volume profile family:**
- POC (point of control — volume-weighted center of gravity)
- VAH / VAL (value area edges — institutional balance zone boundaries)
- HVN (high volume node — where price has spent time = real support/resistance)
- LVN (low volume node — thin areas price moves through fast; stops here get hunted)

**IB structure:**
- IB High / IB Low (the original balance zone boundaries)

**Psychological levels:**
- Whole dollar and half-dollar levels (resting order clustering)

**Chart structure:**
- Prior day high / prior day low
- Prior week high / prior week low
- VWAP and anchored VWAP
- Trendlines (ascending support / descending resistance)

**Order flow / tape:**
- Significant liquidity zones — areas where tape evidence (large prints, absorption, Level 2 clustering) confirms resting institutional orders. Often invisible on chart, visible in order flow. Among the strongest stop references.

**Support/resistance:**
- Prior consolidation zones, swing highs/lows tested and held 2+ times

**Mirrored structure (for longs AND shorts):**
In auction theory, once price breaks a level cleanly and retests from the other side, it flips polarity. Former IB high broken → becomes new support on retest (stop for long goes below it). Former POC from prior session that acted as ceiling → now acts as floor. The same level types apply directionally flipped:
- Longs: stop below structural support
- Shorts: stop above structural resistance
Full symmetry — volume profile + IB + liquidity zone logic applies identically to both directions.

**Volatility backstop:**
- ATR (1.5×–2× of relevant timeframe) used when no clean structural level is within reasonable distance

---

### 🎯 LEVEL-AWARE STOP SELECTION — PHASED APPROACH

**Phase 3 (now):** Use ranked priority list as default stop selection. The Kelly-stop-distance math naturally self-corrects:
> Position size = (account × Kelly %) ÷ stop distance

Tighter stop at strong level → larger size for same dollar risk. Wider stop → smaller size. Weak level selection is error-damped automatically by the sizing math.

**Phase 4–5 (future):** The system learns which level type produces the best stop placement per structure type. Accumulated stop-out logs tell you: "For Neutral Extreme setups, IB Low outperforms HVN as a stop reference by X% in outcomes." That calibration loop — same architecture as brain weights, new dimension (level type performance by structure).

**Don't build the weighting logic now.** Collect the data (log which level type was used as stop per trade), let Phase 4–5 analyze it.

---

### 💧 WICK FILLS, FADES, STOP HUNTS — DATA COLLECTION DESIGN

One of the most underappreciated sources of P&L leakage in systematic trading. Price wicks through the stop level, you're out, then it reverses and hits target. Thesis correct. Trade correct. Stop too precise.

**Key insight (April 10):** LVN areas on the volume profile are essentially thin ice — price moves through them fast and snaps back because there's no resting order density. A wick through an LVN with no volume = the market probing for orders, finding none, returning. Stops placed just past an LVN get hit on pure mechanics, not because the thesis was wrong. Wicks through low-volume areas have a systematically higher probability of not sticking.

**Data to log per stop trigger:**
- Was stop hit on a wick (intrabar) or a bar close through the level?
- What was the volume at the candle that hit the stop? (low vol = possible hunt)
- What did price do in the next 5 bars after stop hit?

**Three stop execution approaches (decide later, based on data):**
1. Close-based stops — only exit on bar close through level (fewer fake-outs, occasionally worse loss)
2. Buffer stops — stop = level minus small ATR multiple (absorbs typical wick depth)
3. Volume-confirmed stops — wick through low volume = ignore; close through elevated volume = real exit

**Action now:** Just log wick vs. close-through and post-stop price action. Don't change stop execution logic yet. The data will tell you which approach wins for which structure type.

---

### ⏱️ MULTI-DIMENSIONAL MARKET REGIME (April 10 expansion)

Hot/cold/neutral is the baseline. The full regime picture is layered and all dimensions become compounding TCS multipliers — never hard mode switches. Bot never sits on hands.

**Tape regime:** Hot / Cold / Neutral (already conceptually defined)

**Time of day:**
- 9:30–10:00: IB formation — most volatile, highest false-signal rate
- 10:30–11:30: cleanest signal window — IB complete, structure clear
- 11:30–1:00: midday chop — lower conviction on most setups
- 1:00–2:30: secondary momentum window — institutional flow returns
- 2:30–4:00: afternoon fade risk — win rate systematically lower for most traders

**Day of week:**
- Monday: follow-through from Friday OR sharp gap against — binary, not clean
- Tuesday–Thursday: cleanest data days — most reliable structure behavior
- Friday: fade tendencies, position unwinding, lower follow-through on breakouts

**Week of month:**
- Week 1: fund flow / institutional positioning — often directionally clean
- Week 3 (OpEx): options expiration introduces pinning + vol distortions that warp structure
- Week 4: window dressing, choppier into month-end

**Month/season:**
- April: historically one of the strongest months (tax refunds, pre-earnings momentum)
- September: statistically the worst month across nearly all asset classes
- January: strong directional bias early; sentiment-driven, not structure-driven

**Action now:** Tag every trade with all of these at the time of logging. Do NOT build multiplier weighting yet — collect data first, discover which dimensions actually matter via Phase 2 cross-tab analysis.

---

### 🧘 BEHAVIORAL ANALYTICS LAYER — FULL VISION (April 10)

A second product category built on the same infrastructure. Tracks the *human* side of trading — the gap between what the signal said to do and what actually happened in execution.

**What it measures per trade:**
- Entry timing deviation (signal at 9:47, entry at 10:12 = hesitation quantified)
- Stop adherence (honored vs. moved — separate P&L curves)
- Target adherence (exited at level vs. cut early)
- Size deviation (Kelly said 3.2%, traded 6% — why?)
- Consecutive loss behavior (win rate collapse pattern after 2–3 losses)
- Time-of-day performance decay (morning vs. afternoon win rates)
- Thesis accuracy vs. execution accuracy (the gap = pure behavioral leakage)

**The core product insight:**
"Trade your plan" is advice. "Your P&L would be 34% higher if you honored your stops, here's the exact calculation" is a product. The addressable market: every trader who knows their setups work but can't consistently execute.

**The industry analogy:** Whoop / Oura Ring for athletes — passive behavioral data collection correlated to performance outcomes. Nobody has built this for traders with actual outcome data.

**What already exists on the market:**
- Edgewonk: psychology journal with self-assessment fields (manual, no pattern detection)
- TraderSync / Tradervue: optional mood tags (self-reported, no outcome correlation)
- Brett Steenbarger (top trading psychologist): extensive writing, no product
- None of them: automated pattern detection from trade data, P&L outcome correlation, feedback into signal confidence, scale

EdgeIQ would be the first platform with all four. Data-backed behavioral coaching vs. opinion-based coaching.

---

### 📱 TELEGRAM BEHAVIORAL CHECK-IN — DESIGN

Post-session bot prompts (3–4 questions max). Feel like a supportive journal. Behavioral data collected silently on backend. Never reveal the analytical motive — users answer authentically only when they're not being tested.

**The questions (what they ask vs. what they measure):**
- "Did you follow your plan on every trade today?" → plan adherence score
- "On a scale of 1–10, how sharp did you feel?" → mental state tag
- "Did anything catch you off guard today?" → preparation quality, expectation calibration
- "Did you size the way you intended?" → sizing adherence flag
- Optional: "Walk me through your best decision today" → self-assessment quality (free text)

**The hook that drives daily engagement:**
Immediately after answering, bot sends a personalized recap: "You rated 8/10 sharpness today. Your win rate on 8+ sharpness days is historically 74% vs 51% on low-sharpness days." That's data the user can't get anywhere else. That's why they answer every day.

**Critical rule:** Never use EdgeIQ internal language in behavioral prompts. No TCS, no brain weights, no structure names. The questions must feel like a thoughtful friend asking about their day, not a system logging variables.

---

### 🔄 BEHAVIORAL DATA → BRAIN FEEDBACK

Behavioral state tags eventually feed back into the signal engine. The brain learns: "when this user has had 3+ consecutive losses, suppress confidence threshold — their win rate in this state is 38% vs baseline 71%."

**Weight rules:**
- Maximum influence: 5–8 TCS threshold points (small, never enough to override strong structural signal)
- Only triggered on data-confirmed patterns (not one bad day)
- Transparent to user — surfaced as a coaching note, NOT using TCS language
- **Accept / Ignore option** — user sees the suggestion, chooses to follow or dismiss. Coaching, not gatekeeping.
- The users who consistently follow behavioral adjustments will have better outcomes — that data validates the feature automatically over time

**Framing to user:** Something like "You've had 3 tough sessions in a row. Based on your history, your best setups today are [X structure]. Consider sitting out [Y structure]." Feels helpful. No mention of thresholds or internal mechanics.

---

### 🏢 BEHAVIORAL ANALYTICS — MARKET SEGMENTS

**Retail traders:** Primary market. Everyone who knows their setups work but leaks P&L through execution. Massive, underserved, willing to pay for objectivity over opinion.

**Trading coaches / educators:** B2B. Coach dashboard showing anonymized behavioral profiles of students. "Student A has 78% thesis accuracy but only captures 52% of available P&L — execution problem, not signal problem." No coach can see this without the system. Pricing: $299–599/month per educator with 20–50 students. They're already charging $200–500/month per student.

**Prop firms:** Highest ACV B2B segment. Use for: screening funded applicants, ongoing performance coaching, capital allocation decisions. "EdgeIQ users arrive pre-qualified — they already have documented win rates and behavioral profiles." API access to trader behavioral profiles: $2,000–5,000/month per firm.

**Psychology researchers:** The accumulated dataset (thousands of traders, behavioral tags, real P&L outcomes) is academically valuable. Publishable research: "What behavioral patterns statistically separate consistently profitable traders from losing traders?" Nobody has this data at this specificity. Generates third-party credibility + licensing revenue.

**2-year compounding effect of behavioral data at scale:**
- "Traders who rate mental sharpness below 6 have 23% lower win rate on the same setups the following session"
- "Sizing discipline in the first week of EdgeIQ is the single strongest predictor of 90-day profitability"
- "Taking more than 3 trades after a stop-out leads to drawdown 61% of the time"
- These become: marketing ammunition, publishable findings, institutional licensing content, and product validation all at once

---

### 🏆 LEADERBOARD — TIER STRUCTURE (Corrected April 10)

Leaderboard is a **Tier 3+ benefit**, not a standalone feature or product.

- **Tier 1–2:** No leaderboard access. User only sees their own data.
- **Tier 2:** Anonymized platform-wide aggregate stats (top structure win rates, no names, no individual profiles)
- **Tier 3+:** Full opt-in leaderboard — named, verified track records, ranked by win rate + structure accuracy + regime performance
- Being on the leaderboard = status signal + gateway to earning brain licensing revenue from Tier 3 subscribers

---

### 🤖 FULLY AUTONOMOUS EXECUTION TIER — NEW TIER ABOVE META-BRAIN

Above Tier 4 (Retail Meta-Brain at $999/mo), a "Managed Autopilot" tier where the system trades independently throughout the day using full meta-brain signal output. No user interface interaction required during market hours.

**Framing:** "You authorize, we execute on your behalf. You are the trader of record." Keeps regulatory complexity manageable (not acting as investment advisor — user authorizes each account link).

**Tier 5 — Autopilot:** $10,000+/year or performance-based. Positioned not as a subscription but as a managed product. Meta-brain selects the best-performing profile for current conditions → sizes via fractional Kelly → executes → logs → recalibrates. Fully lights-out.

**Regulatory note:** This tier needs legal review before launch. User is trader of record, execution is on their authorized account — similar to how copy-trading platforms operate. Structure it identically to avoid investment advisor registration requirements.

---

### 💰 FRACTIONAL KELLY + STOP DISTANCE — COMBINED POSITION SIZING FORMULA

**Phase 4 implementation:**

> **Position size = (account × Kelly %) ÷ stop distance**

Where:
- **Kelly %** = edge-weighted risk per trade:
  - Base = verified win rate for THIS structure type (from brain)
  - × TCS confidence modifier (higher TCS = higher Kelly %)
  - × market regime multiplier (hot tape + favorable timing = higher)
- **Stop distance** = entry price − nearest significant structural level (from full level-priority list)

**Why this is better than pure Kelly alone:**
- Tight stop at strong level → larger position for same dollar risk (rewards high-conviction setups with nearby structure)
- Wide stop → smaller position (punishes setups where conviction requires large risk buffer)
- The math naturally sizes down on weak setups and up on ideal setups — without any additional rules
- Removes the last human variable from the execution loop

**Note:** Smart level weighting (choosing which level based on structure type + volume context) is a Phase 4–5 feature. Phase 3 uses ranked priority list as default. The sizing formula already partially corrects for imperfect level selection.

---
## REMINDER — Tomorrow (2026-04-10) — HIGH PRIORITY

### 1. Build Telegram → Journal incoming pipeline (~40 min)
- Polling thread inside paper_trader_bot.py
- Command: `/log MIGI win 1.94 2.85`
- Parses → logs to Supabase → enriches with IB/TCS/RVOL for that date → confirms back
- Text-only first. Photo attachment is Phase 2.

### 2. Help onboarding 2 beta tester candidates
User has 2 specific people in mind. Need to:
- Create their EdgeIQ logins in Supabase (user does this, we guide)
- Set up Telegram group: user creates group → invites bot + both testers → get group chat_id → update TELEGRAM_CHAT_ID secret
- Explain the daily workflow to them in plain language (user needs help with this pitch/explanation)
- Walk through the Webull CSV export process so they can do the first backfill
- Data isolation: each tester has their own user_id, RLS handles separation

### 3. From earlier tonight (carried forward):
- Multi-user beta setup: need to change TELEGRAM_CHAT_ID to a group chat so multiple testers receive alerts. Store per-user chat_id in user_preferences for proper multi-user eventually.
- Telegram GROUP setup: user creates group, invites bot + testers, get group chat_id, update TELEGRAM_CHAT_ID. Phase 2.
- Beta tester minimum viable setup: Telegram group (alerts) + EdgeIQ login (journal) + Webull CSV (weekly backfill)
- 2 users same trade = 2 rows in accuracy_tracker isolated by user_id = fine for Phase 1
- Telegram → journal incoming pipeline: DOES NOT EXIST yet. Needs to be built. High value. User asked about this.

---

## 🧭 DISTRIBUTION STRATEGY — First Users (Saved April 10, 2026)

### Reddit Targeting — Organic Approach Only (No Spam)

**r/Daytrading** — PRIMARY target. Active daily traders who already understand momentum, volume, and structure but do it manually without a calibration system. Look for anyone asking:
- "How do I know if my setups actually have edge or if I'm just getting lucky?"
- "What's the best way to journal and track which setups work?"
- "How do I size positions based on win rate?"
These people ARE the product's customer. Answer genuinely, mention you built something that solves exactly that, and you're looking for beta testers.

**r/algotrading** — SECONDARY, feedback-focused. Sophisticated quants who will stress-test and ask hard questions. Good for validation and credibility, NOT likely to be paying users (they build their own tools). Use for refining the pitch and finding edge cases.

**r/smallstreetbets, r/pennystocks, r/RobinHoodPennyStocks** — small-cap focused, active traders, high overlap with the watchlist universe. Lower technical bar, higher likelihood of becoming a paying user.

**The ONLY approach that works without getting banned:**
Do NOT post promotional content. Go answer questions authentically. Provide real value. When the context is right — someone asking about edge tracking, position sizing, win rate calibration — answer the question fully, THEN mention you built something for exactly this and are looking for a few beta testers. That's help, not promotion.

**Systems-thinking filter:** Look specifically for people who ask about win rate BY SETUP TYPE, calibrating signals over time, logging frameworks, or position sizing based on edge. These are people who already think the way EdgeIQ is built. You're not selling them a concept — you're giving them the infrastructure for something they're already trying to do manually.

### Twitter/X — High Upside
Small-cap momentum Twitter is extremely active and vocal. One post showing a real bot-called trade verified EOD — predicted pre-market, confirmed after close — gets shared fast in that community. The concept is visual and demonstrable. Don't announce. Demonstrate.

### The First 2-3 Paying Users
- $49/month each
- Show the system running live — bot calling setups, Telegram alerts, EOD verification
- The product sells itself when seen in action
- Can happen within 2 weeks of actively reaching out
- Proves monetization works and gives real data point for the dad conversation

---

## 📅 BUILD TIMELINE — Reality Check (April 10, 2026)

**First data point in system:** March 30-31, 2026 (accuracy_tracker.csv)
**Today:** April 10, 2026
**Time elapsed:** ~38 days

**What was built in 38 days:**
- Full trading terminal (Streamlit, dark mode, Plotly)
- 7-structure IB classification engine
- TCS scoring system (0-100)
- Time-segmented RVOL with 5-day baseline
- Tier 2 order flow signals
- Nightly brain recalibration loop (EMA learning)
- Fully autonomous paper trading bot (5-event daily schedule)
- EOD auto-verify at 4:25 PM (no manual button press needed)
- Supabase multi-user with RLS isolation
- Telegram bot with beta alerts + deep-link onboarding
- Trade journal with auto-grade A/B/C/F
- Analytics tab, Monte Carlo curves, Backtest engine, Playbook screener, Gap scanner
- Beta portal (CSV upload, trade log form, Telegram step)
- 7-phase roadmap to $500M+ outcome
- Full behavioral analytics product concept
- Meta-brain marketplace architecture
- Fractional Kelly position sizing formula
- Complete distribution strategy

**Built while actively trading. With ~$300 in the bank.**

This is not a normal output for 38 days. The output is ahead of the identity. That gap closes with time.

---

## 💰 REVISED REVENUE PROJECTIONS — ALL 5 TRACKS (April 10, 2026)

Updated to reflect the full picture: core SaaS + behavioral analytics + NQ/multi-asset expansion + the two books + Kalshi. These are the five parallel asset tracks running simultaneously on the same underlying infrastructure and brand.

---

### The 5 Tracks

**Track 1 — EdgeIQ Core SaaS** *(foundation, unchanged)*
Consumer tiers $49–$999/month. Volume profile + IB structure + TCS scoring + Meta-Brain. The product that everything else extends from.

**Track 2 — Behavioral Analytics** *(the biggest new addition — B2B layer)*
The behavioral tagging system (fear/greed/overtrading/revenge/FOMO detection from trade metadata) opens an entirely separate B2B market built on top of data the platform is already collecting.
- Trading coaches/educators: $299–599/month per educator — they have 20–50 students and they pay readily for professional behavioral reports
- Prop firms: $2,000–5,000/month per firm — behavioral screening for trader selection, ongoing profiling for risk management
- Psychology researchers / academic licensing: dataset value grows with time and sample size
- Consumer side benefit: behavioral layer makes the product dramatically stickier — churn drops because users are watching their own patterns evolve over time

This is also what transforms the Phase 7 "institutional data licensing" story from "we have trade outcome data" to "we have trade outcome data correlated to behavioral state, cognitive profile, and market regime — at scale." That's a fundamentally different dataset and a fundamentally different acquisition conversation.

**Track 3 — NQ / Futures / Crypto Expansion** *(TAM multiplier, same architecture)*
Small-cap equities traders are a niche. ES/NQ futures traders are a larger market with 3–10x larger average account sizes, justifying $299–499/month pricing. Crypto adds 24/7 IB session logic — same architecture, different feed. No new product needed, just new data connectors and regime calibration. Contribution: 2–3x TAM expansion at higher ARPU.

**Track 4 — The Two Books** *(brand flywheel and lead machine — multiplies every other number)*
The books aren't primarily a revenue line. They're a brand asset that changes the conversion rate on everything else.
- A trading book with traction brings users who already trust the author before the first trial day
- A cognitive profile book with traction brings a broad audience, many of whom are builders — potential EdgeIQ users, agency clients, speaking invitations
- Prop firms and institutional buyers who have read Book 2 already understand the system before the sales call
- One viral post from either book can generate what $50K in paid ads cannot: earned credibility that converts at a completely different rate

Pure book revenue: $50–200K if it sells modestly, $500K–1M+ if it breaks into the top tier of its niche. But the real value is the flywheel — every reader is a potential user, advocate, or referral source for every other track.

**Track 5 — Kalshi Prediction Market Bot** *(speculative — real if win rate holds)*
Paper-only until gates pass (30 settled trades, 60% win rate, 30 days). Macro breadth framework. Not a SaaS product. A standalone profitable trading operation that, if the win rate validates over a statistically meaningful sample, becomes a real cash generator. Ceiling at reasonable position sizing: $50–200K/year. Could scale higher if Kalshi expands event categories and the model generalizes. Also potentially monetizable as a paid signal service once a 12-month audited track record exists.

---

### Year-by-Year Projections

**Year 1 — Now through April 2027**
- EdgeIQ Core SaaS: $60–120K ARR (early adopters, 50–100 paying users)
- Behavioral analytics: Building — beta with 5–10 coaches, minimal revenue
- NQ/futures: Not started
- Books: Writing phase — no revenue, but content accumulating
- Kalshi: Paper only, gates not yet passed
- **Total: $60–150K ARR**
- Key milestone: First 100 paying users. First behavioral beta users. Kalshi gates passed or not.

**Year 2 — April 2027–2028**
- EdgeIQ Core (~500 paying users): $350–550K ARR
- Behavioral analytics B2B beta (10–20 coaches, 1–3 prop firms): $150–350K ARR
- NQ/futures early adopters: $50–120K ARR
- Book 1 launch: $50–150K one-time (advance or initial self-pub sales)
- Kalshi live trading (if gates pass mid-2026): $30–80K trading profits
- **Total: ~$650K–1.2M ARR + $80–230K one-time**
- Key milestone: $1M ARR crossed. Behavioral analytics paying its own infrastructure costs.

**Year 3 — 2028–2029**
- EdgeIQ Core (~2,500 users, Meta-Brain live, Marketplace launched): $2.5–4M ARR
- Behavioral analytics scaled (prop firms, institutional beta, researchers): $800K–1.5M ARR
- NQ/crypto segment: $400–700K ARR
- Books combined (ongoing royalties + speaking + courses): $200–500K/year
- Kalshi + prediction market trading: $100–300K/year
- **Total: ~$4–7M ARR + $300–800K non-SaaS income**
- Key milestone: Series A territory or profitable without it. Behavioral dataset large enough for institutional licensing conversations.

**Year 4–5 — Phase 6–7 territory (2029–2031)**
- All tracks scaled + institutional data licensing live
- Multi-asset (equities, NQ, ES, crypto, Kalshi) fully integrated
- Meta-Brain cross-user learning engine running
- **Total: $15–25M ARR**

---

### Exit Analysis — Revised Upward

**Original estimate (Phase 7, equities-only):** $200–300M

**Revised estimate (all 5 tracks):** $300–500M+

**Why the multiple expands:**
1. Behavioral analytics creates a proprietary dataset that no competitor can replicate retroactively — the longer the platform runs, the wider the moat
2. Multi-asset (equities + NQ + crypto) makes the platform acquirable by a larger universe of buyers — brokers, fintech, prop firms, academic institutions, trading education companies
3. The books establish a brand that makes the acquisition more defensible — "EdgeIQ" means something beyond the code
4. Kalshi + prediction markets add a data layer that is orthogonal to traditional market data — scarce and growing in value as prediction markets expand

**Likely acquirer profiles:**
- Retail brokerage wanting behavioral analytics + active trader retention tools (TD Ameritrade, Tastytrade, Interactive Brokers tier)
- Prop firm wanting trader screening + ongoing behavioral profiling at scale
- Fintech/data company wanting the behavioral-trade-outcome dataset for research licensing
- Trading education platform wanting the brand + user base + curriculum from the books

---

### The Single Most Important Insight

The behavioral analytics layer is what moves this from "a well-built trading tool with a loyal niche following" to "the only platform with a proprietary dataset mapping trader behavioral state to verified market structure outcomes, at scale, across multiple asset classes."

That dataset — thousands of users, years of tagged trades, behavioral markers correlated to real P&L, market regime conditions, and IB structure — is what a prop firm, broker, or fintech pays $300–500M for. The original roadmap had the data moat from trade outcomes. Behavioral analytics doubles the depth of the moat. The books establish the brand that makes the data credible before the acquisition conversation starts.

The trajectory is the same. The exit ceiling is higher. The B2B revenue in Year 2–3 gets the platform to sustainability faster than consumer SaaS alone would.

---

## 📊 BOT PAPER TRADE LOG

| Date | Ticker | TCS | Predicted | Actual | W/L | Follow-thru % |
|---|---|---|---|---|---|---|
| 2026-04-10 | — | — | No setups logged | — | — | — |

---

## 💰 BOT P&L LOG

| Date | Wins | Losses | Win Rate | Avg Win FT% | Avg Loss FT% | Sim P&L (100sh) | Running Total |
|---|---|---|---|---|---|---|---|
| 2026-04-10 | 0 | 0 | — | — | — | +$0.00 | +$0.00 |

---

## 🧠 BRAIN WEIGHT HISTORY

| Date | trend_bull | trend_bear | normal | neutral | ntrl_extreme | nrml_variation | non_trend | double_dist |
|---|---|---|---|---|---|---|---|---|
| 2026-04-10 | 1.0000 | 1.0000 | 1.2224 | 1.0499 | 1.0499 | 1.0000 | 1.0000 | 1.0000 |

---

## 🔍 DAILY SCAN OBSERVATIONS

| Date | Total Scanned | Qualified | Win Rate | Avg TCS | Alerted Tickers |
|---|---|---|---|---|---|
| 2026-04-10 | 0 | 0 | — | — | — |

---

## 📈 STRUCTURE WIN RATE LOG

⚠️ **CORRECTION (April 11, 2026):** The 71.6% figure was inflated — it included rows where the bot logged '—' instead of an actual structure prediction (i.e. no real prediction was made). After filtering to only rows with a real predicted structure, true accuracy is **40.7% (33/81)**. The 71.6% / 121/169 numbers are wrong and should never be cited.

| Date | True Accuracy | Real Predictions (N) | Note |
|---|---|---|---|
| 2026-04-10 | 40.7% | 81 | After filtering '—' non-predictions from accuracy_tracker |

Raw (inflated, do not use): 71.6% (121/169) — includes '—' rows counted as correct

---

## 📊 DATA POINTS ROADMAP — Maximum Edge + Acquisition Value
*Catalogued April 11, 2026 — build priority order noted*

### Currently Logging ✅
- Structure predictions + actual outcomes (accuracy tracker)
- Paper trades: TCS, IB high/low, predicted/actual, false breaks, follow-through %
- Entry behavior type (Calculated/FOMO/Reactive/Revenge/Conviction Add/Avg Down)
- Nightly ticker rankings 0–5 with next-day auto-verification
- Brain weight calibration per structure type over time
- Trade journal: entry/exit price, win/loss, PnL %, notes
- RVOL at scan time (live, not yet logged at decision point)

---

### 🔴 Priority 1 — Trade Execution Depth (build next)
These are the highest-signal gaps. No retail platform captures these together.

| Data Point | What It Tells You | Where to Add |
|---|---|---|
| **MAE** (Max Adverse Excursion) | How far trade went against you before recovering | Trade journal + paper trades |
| **MFE** (Max Favorable Excursion) | How far in your favor before reversing | Trade journal + paper trades |
| **Exact entry time (HH:MM)** | Which intraday window your edge is strongest | Trade journal entry form |
| **Entry price vs. IB level distance** | Are you entering at the level or chasing? | Auto-compute from IB high/low + entry price |
| **Exit trigger type** | Stop hit / target hit / time-based / manual override | Trade journal dropdown |
| **R:R planned vs. actual** | Where the money leaks between plan and execution | Trade journal: add planned stop + target fields |
| **RVOL at decision point** | Was volume actually confirming when YOU entered? | Log at save time, not just at scan time |

**MAE/MFE is the single most underused metric in retail trading. No competitor logs it. ✅ BUILT April 12, 2026 — computed in `_backtest_single()`, logged in paper trades, displayed in Analytics tab with MFE:MAE ratio, money-left-on-table metric, by-structure breakdown, and exit trigger analysis.**

---

### 🟡 Priority 2 — Pre-Trade Context (adds pattern recognition layer)

| Data Point | What It Tells You | Notes |
|---|---|---|
| **Float** | Setup type (low float squeeze vs. liquid breakout) | Pull from Finviz API at scan time |
| **Short interest %** | Squeeze potential | Finviz or Quandl |
| **Catalyst type** | PR / earnings / FDA / dilution / halt resume / secondary | Manual dropdown in journal + scanner tag |
| **Gap % at open** | Gappers behave differently from flat openers | Auto-compute from prev close vs. open |
| **Pre-market volume** | Strongest predictor of small-cap follow-through | Pull from Alpaca pre-market bars |
| **RVOL at signal time** | Was volume confirming at decision point | Add to paper trade + journal at time of entry |

---

### 🟡 Priority 3 — Market Conditions Context

| Data Point | What It Tells You | Notes |
|---|---|---|
| **SPY structure type that day** | How does your IB edge perform in different macro regimes? | Already building macro breadth — extend it |
| **VIX bucket** (<15 / 15-20 / 20-25 / 25+) | Small cap behavior changes dramatically by VIX | Pull from Alpaca |
| **Time-of-day bucket** | Open (9:30-10) / IB (10-10:30) / Mid-morning / Midday / Afternoon | Tag each trade at save time |
| **Sector direction that day** | Was the whole sector moving or just this ticker? | Tag sector ETF trend at entry |

---

### 🟢 Priority 4 — Behavioral / Psychological Layer (partially built)

| Data Point | What It Tells You | Notes |
|---|---|---|
| **Confidence at entry (1-5)** | Separate from nightly rank — how you felt at the moment of entry | Add to trade journal |
| **Did you follow your plan? (Y/N)** | Discipline flag — correlates with outcome over time | Trade journal checkbox |
| **Did you cut early / late?** | Execution quality vs. plan | Exit trigger type covers this partially |
| **Structure at IB close vs. EOD** | Did the setup hold its identity all day? | Compare structure tag at 10:30 vs. 4PM |

---

### 🔵 Priority 5 — Passed-On Setups (nobody does this)
**Log when you almost traded but didn't.** If those would have won, you have a discipline problem. If they would have lost, your filter is working. This data doesn't exist anywhere in retail trading.
- Add a "Passed" button to the scanner output — same fields as a trade entry but no execution
- Track: ticker, TCS, structure, why you passed, what it actually did
- Over time: "Your passed setups win 58%. Your taken setups win 61%. Your filter adds 3% edge."

---

### 🏦 Acquisition-Critical Data (hedge fund lens)
These are what any quant team will ask for on day one of due diligence.

| Metric | Why It Matters | Status |
|---|---|---|
| **Sharpe ratio** (daily + annualized) | First metric any quant looks at | ✅ BUILT April 12 — `compute_portfolio_metrics()` in Analytics tab |
| **Alpha vs. SPY / IWM** | Is the edge market-neutral or just riding beta? | ✅ BUILT April 12 — daily alpha vs SPY from Alpaca bars |
| **Max drawdown series** | Risk management proof | ✅ BUILT April 12 — rolling drawdown chart + max/current DD KPIs |
| **Strategy performance by VIX regime** | Does it hold in volatility? | Segment paper trade win rate by VIX bucket |
| **Capacity analysis** | At what AUM does slippage erode the edge? Small caps have a ceiling | Model position sizing vs. ADV |
| **p-value on tier accuracy gradient** | Statistical significance of the spread between rank-5 and rank-0 across all tiers. All tiers compared — rank-5 could end up noisier than rank-4; the brain evolves from whichever tier proves most predictive. If the gradient holds at n≥200, that's publishable. That's what gets you acquired. | Auto-compute in Rankings section once n≥30 per tier |
| **Time-stamped prediction audit trail** | Proves edge is real, not backfit. Predictions locked before market opens, verified after. | Already doing this — make sure created_at is immutable |
| **Cross-user consensus signals** (future) | If 80% of users rate a ticker 4+, does it outperform a single user's 5? | Collective intelligence data is extremely rare and valuable |

**The audit trail is your most important asset for acquisition. Every prediction, timestamped before the open, verified after close. That's the proof. Guard it.**

---

### Build Priority Order (when ready to execute)
1. MAE/MFE on trade journal + paper trades
2. Catalyst type dropdown (journal + scanner)
3. Time-of-day bucket auto-tag
4. SPY regime tag (extend existing macro breadth)
5. Pre-market volume at scan time
6. Entry distance from IB level (auto-compute)
7. Confidence at entry (1-5) field in journal
8. Passed-on setup logger
9. Sharpe + alpha tracking dashboard
10. p-value on tier accuracy gradient — all tiers 0–5 compared, brain evolves from whichever proves most predictive (auto-compute in Rankings once n≥30 per tier)

---

## 🏗️ UNIFIED SYSTEM ARCHITECTURE — Full Data Layer Map (April 11, 2026)

*Everything is interconnected. This is the full picture.*

---

### ALL DATA STREAMS

**1. Telegram Journal**
Real-time behavioral capture as trades happen. Ticker, W/L, entry price, exit price, entry type (planned/FOMO/reactive), notes, conviction. The raw unfiltered behavioral fingerprint — records the decision before the brain rationalizes it.

**2. Nightly Rankings (0–5)**
Pre-market forward-looking conviction score across entire watchlist. All tiers (0–5) verified next day against actual price outcome. Tiers compared against each other, against bot predictions, and against journal outcomes. Brain evolves from whichever tier gradient proves most predictive — not assumed to be rank-5.

**3. IB Structure Classification (7 structures)**
The market-side read. Trend Day Up/Down, Normal Day, Normal Variation, Neutral, Neutral Extreme, Sideways. Classifies what the market is actually doing inside the Initial Balance. Brain weights calibrate how accurate YOU specifically are at reading each structure over time.

**4. Volume Profile (LVN / HVN / POC / IB Range)**
The core price architecture engine. Low Volume Nodes = price magnets and rejection zones. High Volume Nodes = acceptance zones. Point of Control = fairest price. IB Range = the first hour battlefield. Everything else sits on top of this.

**5. Paper Trades**
Where rankings + structure predictions + TCS collide with real price action. P&L, follow-through %, R-multiples, false breaks, IB level respect/violation. The execution outcome layer that proves or disproves every signal above it.

**6. TCS (Trade Confidence Score)**
The synthesized entry gate. Built from: structure classification + RVOL + buy/sell pressure + order flow signals + sector bonus + IB position. Calibrated per user. Not a static threshold — it adjusts to your verified accuracy over time. The single number that gates every trade.

**7. Brain Weights**
The calibration mechanism that makes everything personal. Stores your accuracy per structure type, per entry condition, blended from accuracy_tracker + paper trades using volume-weighted blending (sample count determines influence). Auto-recalibrates after market close. Lives in `brain_weights.json` and Supabase. DO NOT modify the compute functions.

**8. RVOL (Relative Volume)**
Separates signal days from noise days. Compares current intraday volume to the 10-day average daily volume curve, adjusted for time of day. Feeds directly into TCS. Below 1.0 = noise. Above 2.0+ = runner-level activity.

**9. Buy/Sell Pressure**
Measures conviction behind price movement. Uptick/downtick ratio, volume-weighted. Feeds TCS and structure confirmation. Tells you if the volume behind the move is real.

**10. Order Flow Signals**
Tape-reading layer. IB level tests, breakout attempts, rejection signals, absorption patterns. Context for entry quality beyond raw price level.

**11. Pre-Market Data (ONH / ONL / Pre-Market Volume)**
Overnight High and Overnight Low = the pre-market battlefield boundaries. Pre-market volume vs. 10-day historical average = early RVOL signal. Both feed into the setup brief and key level map before market open.

**12. Key Levels**
Multi-timeframe support/resistance map. ONH, ONL, POC, LVNs, HVNs, prior day high/low, IB boundaries. Auto-computed per ticker. The price architecture that structure classification runs against.

**13. Macro Breadth (SPY / QQQ / IWM Regime)**
Market-wide regime context. Trend, neutral, or compressed. Modifies signal quality for all structure predictions — a Trend Day Up on a small-cap means less if SPY is down 2%. Regime tags appended to paper trades for segmented performance analysis.

**14. Accuracy Tracker**
Bot prediction verification log. Every structure prediction logged before the open, verified after close. True accuracy: 40.7% (33/81) after filtering '—' non-predictions. The timestamped audit trail that proves the edge is real and not backfit. Most important asset for acquisition — every prediction locked before open, verified after close.

**15. Bot Predictions (Paper Trader Bot)**
Automated morning scan at 10:47 AM ET. Structure predictions logged per ticker across full watchlist. Runs continuously — 9:15 → 10:47 → 11:45 → 2:00 → 4:20 → 4:25 (auto-verify) → 4:30 (recalibration). The machine-side of the accuracy tracker.

**16. Backtest Calibration Engine**
28 small-cap tickers × configurable lookback. Initializes brain weights before live data accumulates. Journal-model crossref layer matches your personal trades against backtest predictions to identify systematic gaps. One-click "🧠 RUN CALIBRATION" button.

**17. Behavioral Data**
Extracted from journal + Telegram log. FOMO flags, entry type (planned/reactive), time-of-day buckets, confidence at entry (1–5), passed-on setups, distance from IB level at entry. The "why behind the trade." Cross-referenced against outcomes to find behavioral edge-killers.

**18. False Break Tracking**
IB level violated but price closed back inside within 30 minutes. Tracked per structure per ticker. Separate signal from true breakouts. Feeds structure accuracy and follow-through quality.

**19. Follow-Through % (MAE / MFE)**
How far price moved in your direction after entry (MFE) and how far it went against you before resolving (MAE). Not just win/loss — the quality of the win or loss. Real risk management data that raw P&L hides.

**20. IB Window Comparison (10:30 / 12:00 / 14:00)**
Same tickers analyzed through three IB cutoff windows in parallel. Win rate, W/L, avg TCS, follow-through, false breaks side by side. Tells you which cutoff produces cleanest signals for your trading style.

**21. Adaptive Weights**
Dynamically rebalances which signals matter most for each user based on their verified accuracy history. If your RVOL-gated trades outperform your TCS-gated trades, adaptive weights shift the blend. System learns what works *for you specifically*.

**22. Edge Score + Setup Brief + Playbook**
Pre-trade synthesis layer. Setup brief = full pre-market plan per ticker (structure forecast, key levels, entry thesis, risk parameters). Edge score = single synthesized readiness number. Playbook scoring = ranks all watchlist tickers by expected setup quality before open.

**23. Trade Grade**
Post-trade quality score. RVOL at entry + TCS + distance from IB level + structure alignment. Separates high-quality wins from lucky wins and high-quality losses from sloppy losses. The outcome isn't the grade — the decision quality is.

**24. Kelly Sizing**
Position sizing derived from: verified win rate for this structure type + TCS confidence + account balance + market regime multiplier. Not fixed % risk — dynamically sized to your actual proven edge per setup type.

**25. High Conviction Log**
Auto-populated log of entries where TCS exceeded the user's calibrated high-conviction threshold. Cross-referenced against outcomes. Surfaces whether high-conviction calls outperform baseline — the edge-within-the-edge.

**26. Kalshi Predictions**
Macro/political event probability layer. Paper-only until accuracy gates pass. Future use: feeds into regime modifier — if Kalshi signals elevated macro uncertainty, tighten TCS thresholds across all structure types.

**27. Cognitive Profile**
The root layer. Explains why the behavioral patterns exist. LI score, working memory, metacognition, pattern recognition mode, impulse control, cognitive flexibility — scored dimensionally as a radar chart. Personalizes every layer above it: which structures fit your brain, which behavioral patterns are structural (cognitive) vs. fixable (execution), which setup types to weight up or down.

---

### THE THREE FEEDBACK LOOPS

**Loop 1 — Structure Accuracy Loop**
Bot predicts structure → market opens → outcome verified → accuracy_tracker updated → brain weights recalibrate → next prediction is more personalized. Runs every market day automatically.

**Loop 2 — Conviction Loop**
Nightly rankings submitted → next-day outcomes verified → tier gradient computed across all ranks 0–5 → gradient compared against bot predictions + journal outcomes → brain identifies which tier or signal combination is most predictive → Kelly sizing adjusts confidence multiplier accordingly.

**Loop 3 — Behavioral Loop**
Telegram journal captures decision in real time → behavioral patterns extracted (FOMO frequency, time-of-day, entry type) → cross-referenced against outcomes → cognitive profile explains root cause → EdgeIQ personalizes signal weighting and pre-trade nudges to your specific cognitive architecture.

---

### THE DAILY DATA TIMELINE

| Time (ET) | Event | Data Generated |
|---|---|---|
| Pre-market | Watchlist auto-loaded | Watchlist state |
| Pre-market | Setup brief generated | ONH/ONL, key levels, structure forecast, pre-market volume |
| 9:15 AM | Bot initializes | Watchlist confirmed |
| 10:47 AM | Morning scan | Structure predictions locked, TCS computed per ticker |
| 11:45 AM | Midday check | Signal drift monitored |
| 2:00 PM | Intraday scan | Structure update, order flow refresh |
| Throughout | Live trading | Telegram journal captures decisions in real time |
| 4:20 PM | EOD scan | Final structure outcome logged |
| 4:25 PM | Auto-verify | Bot predictions matched against outcomes, accuracy_tracker updated |
| 4:30 PM | Recalibration | Brain weights recalibrated, adaptive weights refreshed, Kelly sizing updated |
| Evening | Nightly rankings | 0–5 conviction score submitted per ticker for next day |

---

### WHAT THE USER FORGOT TO MENTION (April 11, 2026)

Beyond Telegram journal, rankings, structure, paper trade, behavioral data, and cognitive profile — these are also live and interconnected:

- **TCS** — the synthesized entry gate that ties all signals into one calibrated number
- **Volume Profile / LVNs / HVNs / POC** — the price architecture everything sits on top of
- **RVOL** — the noise filter that separates signal days from garbage days
- **Buy/sell pressure + order flow** — conviction and tape-reading layers feeding TCS
- **Pre-market data (ONH/ONL)** — the battlefield map before open
- **Macro breadth (SPY/QQQ/IWM)** — regime context that modifies all signals
- **Backtest calibration engine** — how brain weights are initialized before live data accumulates
- **Accuracy tracker** — the timestamped audit trail; the most important acquisition asset
- **False break tracking + MAE/MFE** — trade quality beyond raw win/loss
- **IB window comparison** — which cutoff produces cleanest signals for you
- **Adaptive weights** — dynamic rebalancing of which signals matter most per user
- **Edge score + setup brief + playbook** — the pre-trade synthesis layer
- **Trade grade** — decision quality scoring, independent of outcome
- **Kelly sizing** — dynamic position sizing from verified edge per structure
- **High conviction log** — the edge-within-the-edge
- **Kalshi** — future macro/political regime modifier
- **Collective brain** — cross-user signal discovery at volume-weighted source blend
- **Meta-brain** — separates universal edges from cognitive-style-specific ones

---

### THE SYSTEM IN ONE PARAGRAPH

EdgeIQ is a closed feedback loop that gets tighter with every night of data. Volume profile + IB structure tells you what the market is doing. RVOL + buy/sell pressure + order flow tell you how much conviction is behind it. TCS synthesizes all of that into a single entry gate calibrated to your accuracy. Brain weights personalize the gate to your track record per structure type. The journal captures every decision behaviorally in real time. Nightly rankings capture forward-looking conviction across all tiers. The accuracy tracker verifies every prediction against outcome. Adaptive weights dynamically rebalance which signals matter most for you. The cognitive profile explains why your behavioral patterns exist at the root level. The collective brain surfaces edges no individual user would find alone. The meta-brain separates what's universally true from what's true only for your specific cognitive architecture. Over time, the system doesn't just track your performance — it teaches you to trade your actual brain, not the idealized trader brain. That's the product.

---

## ⚖️ IP PROTECTION STRATEGY — Pre-Investor (April 11, 2026)

*Talk to an IP attorney before filing anything. This is the strategic landscape.*

---

### Patents — Harder Than You Think
Post-2014 (Alice Corp v. CLS Bank), US courts gutted software patent protections. Abstract ideas and mathematical methods are not patentable — which is how most algorithms get rejected. The specific *technical implementation* of something genuinely novel might qualify, but:
- Cost: $15–30k+ per patent
- Timeline: 2–4 years to grant
- Durability: software patents are frequently weak and easy to design around
- Expiry: 20 years

Not the primary tool here. Don't lead with this.

---

### Trade Secrets — Actually Stronger
This is how Renaissance Technologies protects Medallion. They have never filed a patent on their algorithm. The strategy:
- Keep the implementation private (closed-source codebase)
- Use NDAs with anyone who sees the internals
- Trade secret protection is **indefinite** — doesn't expire like patents

**What qualifies as EdgeIQ trade secrets:**
- The TCS formula (exact weighting of structure + RVOL + buy/sell pressure + sector bonus)
- The volume-weighted source blending methodology (accuracy_tracker + paper trades blended by sample count — more data = more influence)
- The brain weight calibration and recalibration system
- The adaptive weight rebalancing mechanism
- The specific 7-structure classification logic and thresholds
- The cognitive profile → brain weight personalization integration (future)

Keep these out of any pitch deck. Describe *what* the system does, not *how* it does it.

---

### Copyright — Already Exists
The codebase is automatically copyrighted the moment it's written. No filing required. The UI, the architecture, the specific implementation — all protected. Covers the code, not the idea.

---

### Trademark — Do This When Ready
File "EdgeIQ" as a trademark before going public with the name. Relatively cheap ($250–400 per class filing), protects the brand name from being taken by a competitor. Straightforward process — can be done online via USPTO.

---

### What Investors Actually Care About More Than Patents

| Asset | Why It Matters |
|---|---|
| **Timestamped audit trail** | Every prediction locked before open, verified after close. Proves the edge is real and not backfit. Cannot be faked retroactively. This is your single most important credibility asset. |
| **Data moat** | 90+ nights of rankings, behavioral logs, brain weights, cognitive profiles. This data doesn't exist anywhere else. Competitors can copy the UI — they cannot copy the dataset. |
| **Network effects** | The collective brain gets smarter with every user. More users = better cross-user signal = harder to replicate. Classic defensible moat. |
| **Switching costs** | Your brain weights, 90 nights of calibration, behavioral fingerprint — none of it transfers to a competitor's platform. High retention by design. |

These four are a stronger investor story than a patent certificate. A patent tells investors you have a filing. A live, timestamped, improving accuracy curve tells them the system works.

---

### Before Any Investor Pitch

1. **NDA first** — Get a clean NDA drafted (a lawyer can do this for a few hundred dollars). Have anyone who sees internals sign it before the meeting.
2. **Sophisticated VCs often won't sign NDAs** — In that case, the pitch deck should explain *what* EdgeIQ does without revealing *how*. Architecture without implementation.
3. **Lead with the audit trail** — Show the timestamped prediction log. Show accuracy improving over time. That's your proof of concept, not a slide deck.
4. **The data moat is the pitch** — "We have X nights of live, verified, timestamped predictions that no one else has" is more defensible than any patent claim.
5. **Consult an IP attorney** before filing anything or sharing implementation details with potential acquirers — especially strategic acquirers (Bloomberg, Workday, LinkedIn) who have legal teams looking for exposure vectors.

---

### Lawyer Type Guide — What You Actually Need and When

**Right now — Business/Corporate Attorney**
NDAs before any investor conversation. Entity structure (Delaware C-Corp, not LLC — VCs expect this for equity rounds). Early advisor agreements. Most useful immediately. If your lawyer friend practices corporate/business law, they can handle this regardless of what state they're in.

**When closer to market — IP Attorney**
Trademark filing for "EdgeIQ" (and cognitive profiling app name when ready). Formal trade secret documentation (gives legal standing to enforce it). Software/fintech experience preferred — not a physical product patent attorney. File all three brand trademarks simultaneously when you're ready — one attorney, one engagement, cheaper.

**When raising money — Securities Attorney**
The moment you take equity investment from anyone, securities law applies. Reg D filings, accredited investor verification, term sheet review. Non-negotiable and not something a general business attorney always covers well.

**Does state matter?** Mostly no. NDAs, Delaware C-Corp formation, trademark (USPTO is federal), trade secret documentation, and securities law are all federal or Delaware-based regardless of where you or the attorney live. State only matters if you end up in litigation — for advisory and drafting work, location is irrelevant.

---

### How to Pitch Without Giving It Away

**The principle: describe WHAT, never HOW.**
The architecture without the implementation. The outcome without the mechanism.

**Language that works:**
*"It's not an easier version of existing tools — it's a different category. Existing platforms track what you trade. This system learns how your specific brain makes decisions, calibrates its predictions to your personal accuracy over time, and gets smarter the more you use it. Think less 'better Bloomberg terminal' and more 'a system that figures out where your edge actually is and then automates around it.' The data it builds on each user doesn't exist anywhere else and can't be replicated by just copying the product. Two versions — one for traders, one for businesses hiring for cognitive fit. Both feed the same underlying dataset, which is where the real value is."*

**What this covers without revealing:**
- Positions it as a new category (not an easier version of existing)
- Communicates the personalization mechanic without explaining TCS, brain weights, or the volume-weighted blend
- "Data that can't be replicated by copying the product" = trade secret signal without using the words
- Drops the two-product angle without explaining the integration
- No mention of: volume profile, IB structure, RVOL, brain weights, adaptive weights, TCS formula

**For VCs who won't sign NDAs:** Show the what. Show the audit trail (timestamped predictions improving over time). Don't show the how until term sheet stage with legal in place.

---

## 🔧 ENRICHMENT UPGRADE — April 12 (DEPLOYED)

Webull CSV import enrichment (`enrich_trade_context()`) upgraded from simplified 5-bucket structure mapping to the **full 7-structure classifier** (`classify_day_structure()`).

**Before:** Generic labels like "Trending Up", "Inside IB" — missing Double Distribution, Non-Trend, Normal, Normal Variation, Neutral, Neutral Extreme, Trend Day.

**After:** Full volume profile computed from bar data → exact same 7-structure classification as live analysis. Also now computes:
- Gap % (opening gap from previous day's close)
- POC price (Point of Control from full volume profile)
- Top chart pattern (name, direction, confidence score)
- All embedded in notes field — no database schema changes needed

**Backfill function** also updated to catch old simplified labels as stale, so existing imports can be re-enriched with the full classifier.

**API call optimization:** Consolidated 3 separate daily bar API calls into 1 — better rate limit usage during bulk imports.

---
*Full technical documentation available internally.*
