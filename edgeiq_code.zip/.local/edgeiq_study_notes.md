# EdgeIQ — Full Study Notes
*Everything discussed April 8–9, 2026. Written for review, not just reference.*

---

## PART 1 — WHAT EDGEIQ ACTUALLY IS

### The one-sentence truth
**EdgeIQ is a systems tool that helps traders find their personal edge, then automates it.**

This sounds simple but it took 48 hours of conversation to get there. Most trading tools are generic — they show you the same signals as everyone else. EdgeIQ does the opposite: it learns what specifically works for YOU and gets better at predicting your outcomes over time. The name always pointed at this. "Edge" = your personal advantage. "IQ" = the intelligence that discovers and tracks it.

### What problem it actually solves
Most traders grind for years without ever knowing if they have an edge or what it is. They win some, lose some, repeat. They can't tell you why Monday worked and Tuesday didn't. They can't tell you which setups are genuinely profitable for them vs which ones they just feel good about taking.

EdgeIQ solves that by being a mirror. Every trade you log, every alert you verify — the system is building a picture of your specific behavior and mapping it to market structure outcomes. After 6 months, it can tell you: "You win 84% on Normal Day setups. You lose 58% on Neutral Extreme days. Stop trading Neutral Extreme."

That's not something money can buy. It's built from your own data, over time, and it belongs only to you.

---

## PART 2 — THE TRADING FRAMEWORK (THE SCIENCE BEHIND IT)

This is the academic foundation the whole system is built on. Understanding this is important because it explains WHY the signals work.

### What is the Initial Balance (IB)?
The first hour of trading — 9:30 AM to 10:30 AM Eastern — is called the Initial Balance. During this hour, the biggest participants (institutions, market makers) are setting their range for the day. The high and low of that first hour are not random. They represent where the serious money has decided the day's auction boundaries are.

After 10:30 AM, everything becomes a test of those boundaries:
- Does price break above the IB high? → Buyers are stronger. Bullish signal.
- Does price break below the IB low? → Sellers are stronger. Bearish signal.
- Does price stay inside the IB all day? → Nobody won. Range-bound day.

This framework is used by professional futures traders, prop desks, and institutional traders worldwide. It's not EdgeIQ's invention — it's a proven methodology that EdgeIQ applies to small-cap stocks.

### The 7 Day Structures
Not all trading days behave the same way. EdgeIQ classifies every trading day into one of 7 structures based on how price behaved relative to the IB. Knowing the structure tells you what the market is actually doing — and therefore what trades make sense.

**1. Trend Day Up**
- Only the IB HIGH is broken. Price goes up and stays up.
- Closes near the high of the day.
- What it means: Buyers are fully in control. One-directional move.
- Trade: Aggressive long targets, don't fade the move.

**2. Trend Day Down**
- Only the IB LOW is broken. Price goes down and stays down.
- Closes near the low of the day.
- What it means: Sellers are fully in control. One-directional move.
- Trade: Aggressive short targets, don't fade the move.

**3. Normal Day**
- Neither IB high nor low is broken.
- Wide IB range — big players set the range and hold it.
- What it means: Large institutions established a range. Price likely oscillates between IB levels.
- Trade: Fade extremes back toward the POC (Point of Control).

**4. Normal Variation Day**
- One side of the IB is broken, but only moderately. Price returns inside the IB.
- What it means: An attempt to break out failed. The range held.
- Trade: Conservative fade of the failed breakout.

**5. Neutral Day**
- BOTH IB sides are violated during the day.
- Price closes somewhere in the middle.
- What it means: No one won. Indecision. Two-sided auction.
- Trade: Coast-to-Coast targets (IB high to IB low), tight stops.

**6. Neutral Extreme Day**
- Both IB sides are violated.
- But price closes in the TOP or BOTTOM 20% of the day's range.
- What it means: High volatility, indecision at first, then a late directional push.
- Trade: High volatility — wait for the close confirmation before trading direction.

**7. Non-Trend Day**
- Narrow IB. Low volume. No participation.
- What it means: Nobody cares today. No institutional interest.
- Trade: Avoid. There is no edge on days like this.

**Bonus: Double Distribution**
- Volume profile shows two separate peaks (bimodal) rather than one.
- What it means: Two separate auction processes happened. A gap formed between them.
- Trade: Gap fill between the two distribution nodes.

### What is Volume Profile?
Think of a bar chart turned sideways. Instead of showing price over time, it shows how much volume traded at each price level. The result is a shape — sometimes a bell curve, sometimes bimodal, sometimes skewed.

Key levels within the volume profile:
- **POC (Point of Control):** The single price level with the most volume traded. This is where the most agreement happened. Price is magnetically attracted back to it.
- **VAH (Value Area High):** Top of the range where 70% of trading happened.
- **VAL (Value Area Low):** Bottom of the range where 70% of trading happened.
- **HVN (High Volume Node):** A price area with heavy volume. Acts as a magnet / support or resistance.
- **LVN (Low Volume Node):** A price area with thin volume. Price moves through these quickly — they act as gaps.

Why this matters for small-caps: Institutions use these levels for entries and exits. When a small-cap stock approaches a HVN, it often stalls. When it enters an LVN, it accelerates. EdgeIQ maps these automatically for every ticker on the watchlist.

### What is TCS (Trade Confidence Score)?
TCS is EdgeIQ's internal score from 0–100 that grades the quality of a setup. It is NOT just one factor — it combines multiple inputs:

- Volume profile clarity (how clean are the levels?)
- IB quality (is the IB well-defined or sloppy?)
- RVOL (is there unusual volume supporting the move?)
- Structure probability (historically, how often does this structure resolve correctly?)
- Order flow score (is the buying/selling pressure behind this move?)
- Brain weight multiplier (your personal historical accuracy on this structure type)

A TCS of 60+ means everything is aligning. A TCS of 40 means mixed signals. The current alert threshold is TCS ≥ 50 — meaning EdgeIQ only sends you alerts when the setup quality is above average.

As you get more data, the threshold rises (50 → 55 → 60). Not because you're cutting structures — but because the bar for what counts as "worth alerting" gets higher as the brain gets more confident.

### What is RVOL (Relative Volume)?
RVOL compares today's volume to the average volume at the same time of day over the last 5 days. 

- RVOL of 1.0 = exactly average. Nothing special.
- RVOL of 2.0 = twice the usual volume at this time. Something is happening.
- RVOL of 3.0+ = major unusual activity. Institutional or news-driven interest.

EdgeIQ's RVOL is time-segmented and pace-adjusted. This is important because raw volume comparisons miss the point — if you've only been trading for 45 minutes, you can't compare to a full day. EdgeIQ extrapolates the current pace to project what the full-day volume would be if it continued at this rate.

### The Asymmetry — The Actual Edge
This is the most important concept in the whole system. Read it slowly.

On April 8, the full scanner ran 21 setups. The stats:
- Average WIN: +10.9% move
- Average LOSS: −1.5% slippage (just the cost of entering and exiting)

That's a profit factor of 9.1. Meaning for every $1 lost, the system made $9.10 on winners.

Win rate on that day was only 47.6%. Less than half. And the system STILL made money.

This is the asymmetry. When the IB setup works, it REALLY works — the momentum extends far beyond the IB level. When it fails, you're just stopped out for slippage. The losses are structurally small because the stop is at the opposite IB level. The wins are structurally large because the move can extend far if the structure resolves correctly.

This is why win rate matters less than most traders think. A 40% win rate with a 10:1 profit factor is more profitable than a 70% win rate with a 1:1 profit factor. EdgeIQ is designed around maximizing the asymmetry, not the win rate.

---

## PART 3 — THE BRAIN / CALIBRATION SYSTEM

### What the brain actually does
The brain is a set of multipliers — currently three numbers:
- `normal = 1.2887`
- `ntrl_extreme = 1.2112`
- `neutral = 1.2112`

These multipliers are applied to the TCS score for each structure type. When the brain calculates a TCS for a Normal Day setup, it multiplies by 1.2887 — making it rank HIGHER relative to other structures. When it calculates a Neutral Extreme setup, it multiplies by 1.2112 — lower confidence.

Why? Because YOUR verified trade data shows:
- Normal Day setups: very high accuracy in your history
- Neutral Extreme: moderate accuracy in your history

The brain didn't start there. It started flat — all multipliers were 1.0 (equal weight for everything). Over 181 verified trades, it learned which structures YOU do better on and adjusted the weights accordingly.

### Where the numbers come from
Every time you verify a trade (hit "Verify Date" after 4pm), the system logs:
- What structure was predicted
- What structure actually happened
- Was it a win or a loss

The brain runs an EMA (exponential moving average) — recent performance matters more than old performance. If your Normal Day accuracy drops in the future, the weight gradually decreases. If a structure you were struggling with improves, its weight gradually increases.

The weight adjustments are smooth and slow — no single trade swings the whole brain. As the sample count grows, the EMA rate increases, meaning the brain responds faster to recent patterns.

### The critical bug that was fixed (April 9)
This is important to understand because it affected the brain's training data.

When you upload a Webull CSV (your real executed trades), the system enriches each trade with the IB structure and TCS from that actual trading day. Good. But there was a bug: after enriching the trade, when logging it to the brain, the system was writing:
- "Predicted: Normal Day. Actual: Normal Day. Correct: ✅"

...on EVERY SINGLE TRADE. Regardless of whether you made money or lost money on it.

The brain was receiving zero signal from CSV imports. A losing MIGI trade from 3 months ago was training the brain identically to a winning MIGI trade. This is now fixed: win (exit price > entry price) = ✅, loss (exit price ≤ entry price) = ❌.

### Why individual brain isolation matters
Each user has their own brain. They do not share. This is intentional and fundamental.

Two traders can use the exact same signals and get completely different results because they execute differently. One trader might be great at holding Normal Day trends but panic-exit Neutral Extreme setups too early. Another might be the opposite. If you merged their data into one brain, the weights would average out to something that doesn't represent either trader's actual behavior.

The brain is personal because the edge is personal. That's the whole point.

### The Two-Layer Architecture (future)
Right now: one personal brain per user. This is correct for Phase 1.

Future vision: two layers stacked.

**Layer 1 (personal):** What you have now. Calibrates to your individual trade history. Always your top layer — your personal edge overrides everything.

**Layer 2 (collective):** Anonymized outcomes pooled across ALL EdgeIQ users. "Across 847 verified trades from 312 users, Trend Day Up + TCS > 75 resolved correctly 84.7% of the time." This becomes the BASE signal — the market truth. Your personal layer then adjusts it up or down based on YOUR accuracy with that structure.

Why this is powerful: User 1,000 gets a better product than User 10 because 999 people have already verified outcomes before them. This is the data network effect. The product improves for everyone as the user base grows without any code changes. It's how Tesla Autopilot works — each car feeds the fleet.

---

## PART 4 — THE COMPETITIVE QUESTION (HONEST VERSION)

### What can be copied
The math is replicable. IB structure classification, TCS scoring, RVOL calculation — a skilled developer who understands volume profile trading could study this and rebuild it in a few months. That's the honest truth. Don't build your confidence on "the algorithm is unbeatable."

Someone with more Webull history could upload more CSV data than you and have more calibration rows. That's also true. Data volume alone is not the moat.

### What cannot be easily copied
**Your specific trade history.** If a competitor starts today, they start at zero. Your historical verified trades cannot be backdated — they represent real market days that have already passed. Every day you're running and collecting data, the lead grows by one day.

**The personal calibration loop.** This is the strongest point. A clone of EdgeIQ for someone else would need THEIR trade history to become useful. It's not a general AI model where more data benefits everyone on the same brain. Each user's calibration is unique to that user. Copying the code doesn't copy the product.

**First-mover with real traders.** The moment you have 20 traders with 6 months of logged data each, the switching cost becomes real. They'd lose their entire calibration history if they left. That's a lock-in that's hard to overcome.

### The real threat
Not a 1-day Claude build. The real threat is a well-funded team with 10 developers who notices the niche, builds fast, and markets aggressively before you have enough users to create network effects. The counter to that is moving fast and getting real users before that window opens. That's why the beta tester pipeline matters more than any single feature right now.

---

## PART 5 — THE BUSINESS

### Revised pricing (locked April 9)

| Tier | Price | What it includes |
|---|---|---|
| **Starter** | $49/month | Journal + calibration + edge analytics. No live scanner. Entry-level — gets traders in the door at low friction. |
| **Pro** | $99/month | Full scanner + live alerts + calibration + paper trading. The core product. |
| **Autonomous** | $199/month | Live trading enabled after edge is proven. Bot manages real positions. Phase 4 unlock. |

### ARR projections (Pro tier at $99)
- 10 users = $11,880/year
- 50 users = $59,400/year
- 100 users = $118,800/year
- 500 users = $594,000/year

These numbers are achievable. The small-cap trading community is large and underserved by tools that do personal calibration. The key is distribution — getting the first 20-30 paying users who talk about it.

### Copy Algo tier (future, Phase 4-5)
Concept discussed April 9. A marketplace tier ($299+/month) where top-performing EdgeIQ users opt in to share their brain weights. Subscribers copy their structure preferences and alert thresholds. Revenue share back to the algo owner. Subscribers use it as "training wheels" while building their own calibration.

Why this doesn't defeat the selling point: it's a separate layer. Personal calibration is still the core product. The copy algo tier is for people who want to start making money immediately while their personal brain is still young.

When to build: NOT until 50+ active users have 6+ months of data each. Needs supply (proven algos) before demand.

### Direct broker sync — what's actually possible
Webull has no public retail API. CSV export remains the workaround indefinitely.

What IS possible for direct sync:
- **Alpaca** — already live. Paper trading running now.
- **IBKR (Interactive Brokers)** — has API, complex but powerful, used by serious traders. ~2-3 days of dev work. Highest priority after Alpaca.
- **Tradier** — clean public API, easier to integrate, good for mid-tier users.
- **Schwab/TD Ameritrade** — API opening up post-merger. Future option.

Direct sync removes the last manual step. Trades auto-import, auto-enrich, auto-calibrate. This is the feature that takes churn to near-zero because the tool gets smarter every day without the user doing anything.

---

## PART 6 — THE ACQUISITION QUESTION (HONEST VERSION)

### The numbers I gave and what they actually mean
I said $3M–$8M and the user rightly pushed back. Here's the full picture.

**Those numbers are a CEILING, not a floor. They are conditional on many things going right.**

Scenario that produces $3M–$8M:
- Phase 4 (live autonomous trading) is live
- 3+ months of documented autonomous returns — verified, auditable, real money
- 200+ active users
- $20,000+ monthly recurring revenue
- Clean Alpaca integration (already partway there)
- No major legal/regulatory issues with automated trading

**Most startups don't get acquired.** The majority of software products that are built never reach acquisition. The realistic scenarios in order of probability:

1. **Most likely: You run it as a profitable lifestyle business.** Even at 100 Pro users = $118,800/year in revenue. That's real money for something you built yourself.

2. **Second most likely: You raise a small round and grow faster.** If the autonomous phase performs and you have 50+ users with documented results, you could raise $500k-$1M to hire and scale distribution.

3. **Third most likely: Acquisition at a small number ($500k–$2M).** A fintech or broker acqui-hires you. They pay for the technology, the user base, and you come with it. This is the most common "acquisition" at this scale.

4. **Less likely but possible: Meaningful acquisition ($3M–$8M+).** Requires everything in the ceiling scenario above. Requires the autonomous trading phase to actually work consistently. Requires a buyer who values the calibration technology at scale.

### Why Alpaca is the most natural buyer
EdgeIQ users ARE Alpaca users. Every trade EdgeIQ makes in paper mode goes through Alpaca's infrastructure. Every live trade in Phase 4 generates commission for Alpaca. From their perspective, EdgeIQ is a tool that turns retail traders into active, profitable accounts — which is exactly what they want. They'd be acquiring the calibration layer that sits on top of what they've already built. The integration story is clean.

### Why prop firms would pay differently
A prop firm like TopStep or FTMO makes money by finding traders with proven edges and giving them capital to trade. Their entire business is the intake process: evaluate traders, fund the good ones.

EdgeIQ automates their intake. A trader who has used EdgeIQ for 12 months arrives with a documented win rate by structure, a profit factor, a verified trade history, and a calibrated brain. That's everything the prop firm needs to know. They'd be buying a pipeline.

### The trigger moment
The acquisition trigger is not "you have users." It's "you have documented autonomous trading returns." That's when the asset becomes quantifiable. Before that, you're selling potential. After that, you're selling proof. Those are fundamentally different conversations.

---

## PART 7 — THE PHASE ROADMAP

### Phase 1 — Manual Signal Quality Validation (CURRENT)
Running now. Bot fires alerts autonomously. User verifies outcomes manually after 4pm.

Goal: 50+ verified trades with consistent accuracy per structure type.
At current pace (1–3 alerts/day): 3–6 weeks.

Daily workflow:
1. Pre-market: Load watchlist → Predict All (saves predictions)
2. During session: Trade, take notes
3. After 4pm: Set date picker → Verify Date → brain recalibrates nightly at 4:30pm

What NOT to do during Phase 1:
- Do NOT split backend.py (too risky while bot is running live)
- Do NOT add IWM/breadth weighting to TCS (wait for 60+ trades)
- Do NOT hard-cut any structure from alerts (brain needs to keep seeing all structures)

### Phase 2 — Autonomous Pattern Discovery Engine
After 50+ trades. System cross-tabs all combinations of setup factors and surfaces discovered edges automatically.

Example output: "TCS 70-80 + Trend Day Up + RVOL > 2.5 + gap > 5% pre-market → 84% win rate (n=23)"

Also Phase 2: backend.py splits into brain.py / data.py / trades.py / auth.py. Telegram → journal incoming pipeline. Per-user Telegram chat_id.

### Phase 3 — Alpaca Paper Trading Integration
Automated entries on high-confidence signals. Paper money only.

Auto-entry criteria (to be tuned):
- TCS > 80
- Structure = Trend Day Up or Down
- RVOL > 2×
- Order Flow score > 60

Done when: paper win-rate matches or exceeds both the manual journal AND Webull CSV import win-rate over 30 sessions.

### Phase 4 — Live Autonomous Trading
Real money. Same criteria as Phase 3 but live Alpaca account.
Human kill switch always available.
Daily P&L hard limits + drawdown stops.
Full audit trail via journal + Supabase.

This is the Autonomous tier unlock ($199/month). This is also the acquisition trigger.

---

## PART 8 — SIGNAL TIER ARCHITECTURE

### Tier 1 — Volume Profile + Day Structure ✅ BUILT
The foundation. Classifies the auction process. IB detection, volume profile levels (POC/VAH/VAL/HVN/LVN), TCS scoring, target zones (Coast-to-Coast, Range Extension 1.5×/2.0×, Gap Fill), distance-to-target widget.

### Tier 2 — Order Flow Signals ✅ BUILT
Real-time intraday momentum. Composite score −100 to +100.
- Pressure acceleration (3-bar vs 10-bar buy/sell delta)
- Bar quality score (0–100)
- Volume surge ratio vs 10-bar average
- Tape streak (consecutive bullish/bearish bars)
- IB proximity + volume confirmation

### Tier 3 — Chart Pattern Detection 🔴 TO BUILD
Confirmatory layer. Detects classic patterns on 5m and 1hr.

Patterns: Reverse Head & Shoulders, Head & Shoulders, Double Bottom, Double Top, Cup & Handle, Bull Flag, Bear Flag, Inside Bar.

Confluence logic: two patterns aligning = 1.5× score. Pattern at volume profile level = "confluence confirmed."

Real-world example of why this matters: On April 6, RENX was classified as Neutral by the bot. Correct reading. But a human spotted a 5m AND 1hr reverse H&S formation. Pattern detection would have flipped the read to "Neutral + bullish H&S confirmation." That's the gap this tier fills.

### Tier 4 — Trendline Detection 🔲 FUTURE
Auto-draw trendlines from swing highs/lows. Important design insight: trendlines on BIGGER timeframes carry MORE weight, not less. Daily/weekly trendlines have thousands of participants watching and placing orders at them — making them partially self-fulfilling. Build order: daily first → 1hr → 5m.

### Tier 5 — Macro Context Layer 🔲 FUTURE (Phase 2-3)
IWM day-type classifier (bullish/bearish/choppy) at 60+ trades.
Breadth score at Phase 2/3.
Fed regime at Phase 3 (quarterly).

Rule: passive tagging of `iwm_day_type` per trade at 60 trades. Wire into TCS scoring only at 150-200 trades. Add complexity only after data justifies it.

---

## PART 9 — FEATURES THAT WOULD MAKE THIS HUGE

In rough priority order:

**1. Telegram → Journal pipeline (building tomorrow)**
Send `/log MIGI win 1.94 2.85` from Telegram → trade logged, enriched, confirmed back. Zero browser needed. Daily journaling friction drops to near-zero. This is the retention lever.

**2. Direct broker sync (IBKR first)**
No more CSV. Trades auto-import, auto-enrich, auto-calibrate. The tool gets smarter every day without user action. This is the churn-killer.

**3. "Prove Your Edge" report**
Exportable PDF: win rate by structure, best setup, worst setup, profit factor, best market conditions. Traders will post these. Free marketing flywheel. Every shared report is an EdgeIQ ad.

**4. Community aggregate insights**
Anonymized cross-user data: "Normal Day setups on IWM uptrend days = 74% win rate across all EdgeIQ traders this quarter." Proprietary research nobody else can publish. Drives acquisition marketing.

**5. Islamic compliance filter (Musaffa API)**
Halal/not-halal ticker filter in the scanner. 30-minute build once Tier 3 is done. Unique differentiator that opens the platform to an underserved trading community.

**6. Copy Algo marketplace**
Phase 4-5 play. Top performers share brain weights. Subscribers copy while building their own. Revenue share model.

---

## PART 10 — CURRENT SYSTEM STATE (April 9, 2026)

### Bot schedule (Eastern Time)
- 9:15 AM — Watchlist refresh (pulls from Finviz, saves to Supabase)
- 10:47 AM — Morning scan + Telegram alerts (17 min after IB close, safe for SIP free-tier 15-min delay)
- 2:00 PM — Intraday scan
- 4:20 PM — EOD outcome update (16-min buffer after 4pm close)
- 4:30 PM — Nightly brain recalibration

### Current brain weights
- `normal = 1.2887` (↑ from 1.0 baseline — 100% accuracy / 68 samples)
- `ntrl_extreme = 1.2112` (↓ from 1.4999 baseline — 56.6% accuracy / 53 samples)
- `neutral = 1.2112` (↓ from 1.4999 baseline — 59.1% accuracy / 67 samples)

What this tells you: Normal Day setups have been your most reliable structure. The brain is actively boosting them. Neutral and Neutral Extreme have been less reliable, so the brain is becoming more skeptical — their scores get boosted less, so they appear lower in the alert rankings.

### Paper trade performance (7 trades, 3 days — too small to trust statistically)
- 5W / 2L = 71.4% win rate
- +$411 simulated on $1,000/trade sizing
- +5.9% in 3 days
- **Caution:** April 6-8 was a macro sell-off environment. Strong trending conditions favor IB breakout strategies. Choppy/low-vol weeks will bring this number down. Need 60+ trades across varied conditions before drawing conclusions.

### The actual edge (confirmed in the numbers)
- Avg win: +10.9%
- Avg loss: −1.5% (slippage only)
- Profit factor: ~9.1

The asymmetry is real. You don't need to win 70% of the time for this to be profitable. You need the wins to be bigger than the losses. Right now they are — by a factor of 9. That is the edge. Everything else is just improving the win rate around that asymmetry.

### Data: accuracy_tracker
- 181 total rows
- 132 ✅ wins, 49 ❌ losses
- Note: CSV import bug was previously logging all imported trades as ✅ regardless of P&L. Fixed April 9. Brain was partially trained on bad data. Will self-correct over time as new clean data comes in.

---

## PART 11 — TOMORROW'S AGENDA (April 10, 2026)

### Priority 1: Build Telegram → Journal pipeline (~40 min)
Polling thread inside paper_trader_bot.py. Listens for messages. Parses `/log TICKER win/loss ENTRY EXIT`. Saves to Supabase journal with IB enrichment. Sends confirmation. Text-only first. Photo attachment Phase 2.

### Priority 2: Onboard 2 beta testers
User has 2 specific candidates. Walk through:
- Create their EdgeIQ logins in Supabase
- Telegram group setup: user creates group → invites bot + testers → gets group chat_id → update TELEGRAM_CHAT_ID secret
- Plain-language explanation of the daily workflow for the testers
- First Webull CSV export walkthrough

Beta tester minimum viable setup:
- Telegram group membership (to receive alerts)
- EdgeIQ login (to view journal, analytics, scanner)
- Webull account (to export CSV weekly)
- Zero API keys needed — everything runs on your server

---

## KEY RULES (NEVER VIOLATE)

1. **NEVER modify** `compute_buy_sell_pressure`, `classify_day_structure`, `compute_structure_probabilities`, or `brain_weights.json` directly
2. **Math/logic → backend.py only.** UI/rendering → app.py only. No exceptions.
3. **SIP 16-min cap rule:** `fetch_bars` ALWAYS applies `now - 16min` cap for today's data, even after market close
4. **Do NOT split backend.py** during Phase 1. Maintenance window only.
5. **Do NOT add IWM/breadth to TCS scoring** until 60+ trades. Passive tagging OK at 60, scoring integration at 150-200.
6. **Never hard-cut structure types.** Raise MIN_TCS threshold instead. Brain needs to keep seeing all structures.
7. **Alpaca SIP free tier:** queries for data less than 15 minutes old are blocked. 10:47 AM scan is safe (17 min after 10:30 IB close). EOD at 4:20 PM is safe (20 min after 4pm close).
