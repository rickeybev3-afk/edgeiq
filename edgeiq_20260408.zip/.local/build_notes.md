# EdgeIQ — Master Build Plan & Product Roadmap
*Last updated: April 6, 2026*

---

## 🎯 PRODUCT VISION

**EdgeIQ** — Personal win-rate calibration engine for small-cap volume profile trading.
- Stack: Python Streamlit (port 8080), Alpaca API, Supabase, Plotly — dark mode
- Differentiator: NOT a generic screener. Learns YOUR specific edge over time.
- Competitors: Trade Ideas, Tradervue, StocksToTrade — none do personal calibration
- Pricing: $79/month launch → $149/month post-automation phase
- End goal: Autonomous Alpaca paper → live trading after signal quality proven

---

## 🗺️ PRODUCTION PHASES

### Phase 1 — Manual Signal Quality Validation (CURRENT — IN PROGRESS)
**Goal:** Prove the model's signals are accurate before trusting any automation.

Daily workflow:
1. Pre-market → Load watchlist → **Predict All** (saves predictions for next trading day)
2. During session → Trade, take notes, track levels manually
3. After 4pm → Set date picker → **Verify Date** → scores predictions vs actual structure
4. Every verified trade feeds the win-rate calibration database

Done when: 50+ verified trades with consistent win-rate data per structure type

Current capabilities built:
- Volume profile (POC, VAH, VAL, HVN/LVN)
- **7-structure classification** (already built — see framework below)
- IB detection (9:30–10:30 ET, industry standard inclusive)
- TCS (Trade Confidence Score, 0–100)
- RVOL (time-segmented, 5-day baseline, pace-adjusted)
- Order flow signals — Tier 2 (pressure acceleration, bar quality, vol surge, tape streak)
- Predictive win rates per structure (Analytics tab)
- Trade journal with auto-grade A/B/C/F + grade discipline equity curve
- Watchlist predictions + EOD verification
- MarketBrain (live prediction vs actual tracker)
- Monte Carlo equity curves (1,000 simulations)
- Small Account Challenge tab
- Playbook screener tab
- Historical Backtest Engine tab
- Position management (entry/exit/P&L/MFE overlay on chart)
- Audio/visual alerts (Web Audio API)
- Pre-market gap scanner (30-ticker watchlist, gap% + PM RVOL)

### Phase 2 — Alpaca Paper Trading Integration
**Goal:** Automate entries on high-confidence signals, validate with paper money.

Auto-entry criteria (to be tuned):
- TCS > 80
- Structure = Trend Day Up/Down
- RVOL > 2×
- Order Flow score > 60
- Pattern confirmation from Tier 3 (when built)

Track: paper P&L vs manual P&L — prove automation matches or beats human execution.
Risk controls: max position size, max daily loss, automated stop-loss.
Done when: paper win-rate matches or exceeds manual win-rate over 30 sessions.

### Phase 3 — Live Autonomous Trading
**Goal:** Real money automated execution with guardrails.
- Same criteria as Phase 2 but live Alpaca trading account
- Human override always available (kill switch in sidebar)
- Daily P&L hard limits + drawdown stops
- Full audit trail via journal + Supabase

---

## 📊 SIGNAL TIER ARCHITECTURE

### Tier 1 — Volume Profile + Day Structure ✅ COMPLETE
Core foundation. Classifies the auction process.
- IB detection (9:30–10:30 ET)
- Volume profile (POC, VAH, VAL, HVN/LVN, double distribution detection)
- TCS (Trade Confidence Score)
- Target zones (Coast-to-Coast, Range Extension 1.5×/2.0×, Gap Fill)
- Distance-to-target widget

### Tier 2 — Order Flow Signals ✅ COMPLETE
Real-time intraday momentum layer. Composite score −100 to +100.
- Pressure acceleration (3-bar vs 10-bar buy/sell delta)
- Bar quality score (0–100)
- Volume surge ratio (vs 10-bar average)
- Tape streak (consecutive bullish/bearish bars)
- IB proximity + volume confirmation

### Tier 3 — Chart Pattern Detection 🔴 TO BUILD (PRIORITY)
Confirmatory signal layer. Detects classic patterns on 5m and 1hr bars.

Patterns to detect:
| Pattern | Direction | Confluence Notes |
|---|---|---|
| Reverse Head & Shoulders | Bullish | Neckline break + volume confirm |
| Head & Shoulders | Bearish | Neckline break |
| Double Bottom | Bullish | Often base of cup, or L-shoulder of reverse H&S |
| Double Top | Bearish | — |
| Cup & Handle | Bullish | Double bottom base + handle pullback |
| Bull Flag | Bullish | Tight consolidation after impulse |
| Bear Flag | Bearish | — |

Confluence scoring logic:
- Single pattern = base score
- Two patterns aligning (e.g., double bottom as left shoulder of reverse H&S) = 1.5× score
- Pattern + volume profile level (HVN/POC/IB) = "confluence confirmed"
- Pattern + trendline hold + volume contraction = "Coiled — breakout watch"

Example model output when built:
> "Neutral day — but 1hr reverse H&S neckline unbroken at $2.49 + trendline hold → bullish resolution probable"
> "Fakeout potential — coiled at trendline + POC confluence → breakout watch, not exit signal"

Real-world gap this fills (from today, April 6):
RENX → model said "fakeout potential" (Neutral structure read, correct)
but user identified 5m AND 1hr reverse H&S manually.
Pattern detection would have flipped the read to: "Neutral + H&S bullish confirmation"

### Tier 4 — Trendline Detection 🔲 FUTURE
Auto-draw trendlines from swing highs/lows on 5m/1hr.
Required for: compression score, trendline hold confirmation, pattern geometry (necklines, channels).

---

## 🔧 7-STRUCTURE FRAMEWORK ✅ ALREADY BUILT

Already implemented with hard 3-branch decision tree (no fallthrough):

| Structure | IB Behavior | Signal |
|---|---|---|
| **Trend Day Up** | One side broken (high) only — early, closes at extreme, directional vol | Aggressive long targets |
| **Trend Day Down** | One side broken (low) only — early, closes at extreme, directional vol | Aggressive short targets |
| **Normal Day** | No IB break — wide IB, big players set range | Fade extremes → POC |
| **Normal Variation** | One side broken moderately, returns inside | Conservative fade |
| **Neutral Day** | Both IB sides violated, close in middle | C2C targets, tight stops |
| **Neutral Extreme** | Both sides violated, closes top or bottom 20% | High volatility, wait |
| **Non-Trend Day** | Narrow IB, low volume, no interest | Avoid — no edge |
| **Double Distribution** | Bimodal volume profile, two distinct POCs | Gap fill between nodes |

Branch logic (hard gates, no fallthrough):
- Branch A: no_break → Normal or Non-Trend
- Branch B: both_broken → ONLY Neutral family (Neutral or Neutral Extreme)
- Branch C: one_side → ONLY Trend Day, Normal Variation, or Double Distribution

TODO: run batch backtest on 20+ tickers with new logic to rebuild training data.
Consider tightening Trend Day threshold or adding RVOL floor.

---

## 🕌 ISLAMIC COMPLIANCE FILTER 🔲 BACKLOG
Build after Tier 3 pattern detection.

- API: Musaffa (musaffa.com) — halal / questionable / not-halal per ticker
- Where: Scanner tab — optional toggle filter
- Signal value: not-halal = structurally reduced Islamic buyer pool
- Market value: inclusive to Islamic trading community — unique differentiator
- Build time: ~30 minutes once Tier 3 is done

---

## 📋 CURRENT 7-TAB LAYOUT

| Tab | Name | Status |
|---|---|---|
| 1 | 📈 Main Chart | ✅ Complete |
| 2 | 🔍 Scanner | ✅ Complete |
| 3 | 📋 Playbook | ✅ Complete |
| 4 | 🔬 Backtest Engine | ✅ Complete |
| 5 | 📖 Journal | ✅ Complete |
| 6 | 📊 Analytics & Edge | ✅ Complete |
| 7 | 💪 Small Account | ✅ Complete |

---

## 💡 USER-GENERATED INSIGHTS (Trading Observations)

**Insight 1: Trendline + Level Confluence = Compression → Expansion**
"As long as a stock follows its trendline and holds levels in confluence with it,
it's set up for consolidation then breakout."
→ Encode as compression score in Tier 3 pattern engine.

**Insight 2: Pattern Stacking / Confluence**
Patterns appear together and amplify each other:
- Double bottom = base of cup & handle
- Double bottom = left shoulder of reverse H&S
- Wedge compression = flag before breakout
Tier 3 must detect stacked patterns and score them higher than singles.

**Insight 3: Entry Quality Logging**
Labeling trades as "FOMO" vs "calculated" at entry time builds one of the most
valuable personal edge metrics over time.
Over 50+ trades, win-rate by entry-type reveals discipline edge vs luck.

**Insight 4: After-Hours Small-Cap Reality**
After-hours on thin small caps: a few buy orders can create a big-looking volume spike.
Patterns formed in after-hours are low-conviction until confirmed at regular open.
Key: does the level hold into and through next morning's open?

---

## 📝 TODAY'S TRADES TO LOG (April 6, 2026)

### RENX — RenX Enterprises Corp
| Entry | Time | Price | Shares | Thesis | Grade |
|---|---|---|---|---|---|
| Initial | 9:49 AM ET | $2.45 | ~122 | Calculated — reverse H&S + IB levels | A |
| Re-entry | Midday | $2.49 | ~80 | Trendline pullback (tried 2.45→2.47, missed) | B |
| Add | Midday | $2.50 | ~16 | Adding into trendline hold | B |
| **Total** | — | **~$2.469 avg** | **~218** | — | — |

Key note: model said Neutral/fakeout potential. User identified 1hr + 5m reverse H&S manually.
Model was structurally correct, missed pattern context. This is the Tier 3 build motivation.

### PFSA — Profusa Inc
| Entry | Time | Price | Shares | Thesis | Grade |
|---|---|---|---|---|---|
| Initial | 10:54 AM ET | $1.850 | ~162 | FOMO — chased the move | C |
| Re-entry | Post-pullback | $1.795 | ~111 | Trendline pullback — calculated | A |
| **Total** | — | **~$1.826 avg** | **~273** | — | — |

After-hours: dropped from $1.870 through all support levels to $1.548 low,
bouncing around $1.60–$1.68 range. Possible reverse H&S forming with $1.548 as head.
Overnight hold decision: user holding both positions.

---

## 🔨 TECHNICAL FIXES COMPLETED (Recent Sessions)

| Fix | Details |
|---|---|
| Verify predictions date picker | Manual date picker replaces "Verify Yesterday" |
| Supabase date range query | pred_date is timestamp — use gte()/lt() not eq() |
| Predict All trading day | Uses get_next_trading_day() — no weekend/holiday saves |
| IB computation | pd.Timestamp(tz=tz) cutoff, includes full 10:30 bar |
| IB manual override | st.form prevents collapse; per-ticker; ACTIVE label |
| Log entry timestamp | Date + time picker (1-min step) for accurate backdating |
| load_watchlist import | Added to explicit import block |
| get_next_trading_day | New backend.py function using Alpaca calendar API |

## 🐛 KNOWN ISSUES

| Issue | Priority |
|---|---|
| artifacts/api-server workflow failed state | Low — clean up, doesn't affect main app |
| April 5 predictions in Supabase (Saturday) | Low — unverifiable junk data, can ignore |
| IB 1-3 cent gap vs Webull | Unfixable — data feed fragmentation; use IB Override |

---

## ✅ BUILD CHECKLIST (Tonight / Next Session)

- [x] **Tier 3 pattern detection** — H&S, reverse H&S, double bottom/top, cup & handle, bull/bear flag + confluence scoring — COMPLETE (April 6)
- [x] **Batch calibration run** — One-click "🧠 RUN CALIBRATION" button in Backtest tab. 28 small-cap tickers × configurable 1–22 trading days lookback. Auto-saves to Supabase, shows win rate + structure distribution summary. Original per-ticker simulation unchanged below it. COMPLETE (April 6)
- [ ] **Islamic compliance filter** — Musaffa API, Scanner tab toggle (after Tier 3)
- [ ] **Clean up artifacts/api-server** — failed workflow, not needed

## 🔒 PRESERVATION RULES (NEVER MODIFY)
- compute_buy_sell_pressure()
- classify_day_structure()
- compute_structure_probabilities()
- brain_weights.json
- Architecture: math/logic → backend.py only; UI/rendering → app.py only


## ── USER WORKFLOW NOTES (Pinned 2026-04-08) ────────────────────────────────

### Correct nightly routine (9 PM – market closed):
1. Run Gap Scanner → find what's gapping / has interesting structure
2. Curate My Watchlist (sidebar) → add only 3–5 tickers with actual homework done
3. Playbook → Predict All → generates full setup briefs (entry, stop, targets,
   key levels, PDH/PDL/PDC, round numbers, confluence) for tomorrow's session
4. Journal today's trades → feeds brain calibration
5. EOD Review note → qualitative record of what market did vs prediction

### Watchlist philosophy (user insight):
- My Watchlist = curated high-conviction tickers (3–5 max). NOT every ticker.
- Gap Scanner = discovery tool. It answers "what's moving?", NOT "what should I trade?"
- The brain calibrates ON the watchlist tickers. Flooding it with 30+ tickers
  dilutes the calibration and generates briefs for setups you'll never take.
- Better approach: use Gap Scanner to surface candidates, pick the top 3–5 you
  have real structure conviction on, THEN add to My Watchlist.

### User's realization (important for product design):
- User initially put EVERY ticker in watchlist expecting the bot to filter.
- This is a valid Phase 4 product feature: Gap Scanner → auto-ranking →
  push top N scoring tickers directly to Predict All queue, bypassing manual curation.
- The system CAN do this eventually: score all gappers by TCS + structure confidence,
  then auto-promote top 5 to the prediction queue. Would remove the homework friction.

### Timing rules (when to use what):
- 9 PM–midnight: Predict All + Journal + EOD note (best time — full day data in)
- Pre-market (6–9 AM): check pre-market watchlist panel in EOD Review
- 9:30–10:30: IB forming — DO NOT enter. Watch structure develop.
- After 10:30: entries valid. System's signals are calibrated around this.
- IB must be complete before ANY entry. This is hardcoded into every trigger string.

## 2026-04-08 — Simulation Log Upgrades
- **Deduplication**: Added dedup logic by `(ticker, sim_date)` key before rendering the trade-by-trade log; shows a count if dupes were removed
- **Per-Ticker Breakdown table**: New expander above the log showing each ticker's: Win %, W/L count, Avg TCS, Top Structure, Avg Follow-Thru %, False Break %, Dates Seen — sorted by win rate; color-coded 🟢/🟡/🔴
- **Date column**: Added "Date" as column 0 in the trade-by-trade log so each row shows which trading date it belongs to (useful for range runs)
- `_BT_COLS` expanded from 10 to 11 columns; all row cell indices shifted accordingly

## 2026-04-08 — Load Saved Simulation Results
- Added "📂 Load Saved Simulation Results" expander in Section 2 (Simulation) of the Backtest tab
- Flow: (1) "Fetch My Saved Dates" → pulls distinct sim_dates from Supabase, (2) multiselect picker for date(s), (3) "Load Selected" reconstructs _results list + _summary dict from saved DB rows, injects into bt_results_cache session state, then st.rerun() so full chart/stats pipeline renders automatically
- Handles field remapping: follow_thru_pct → aft_move_pct; reconstructs actual_icon from outcome text; close_price defaults to 0 if not stored
- Works for single-day and multi-date range loads; _sim_is_range=True when >1 date selected

## 2026-04-08 — Auto Paper Trading Tab (📄 Paper Trade)
- New 8th tab added: "📄 Paper Trade"
- **Section 1 — Scan & Log**: date picker, feed selector, TCS min slider (default 50), price range, tickers textarea (pre-filled with watchlist). Calls run_historical_backtest → filters TCS ≥ min → calls log_paper_trades → deduplicates by (ticker, trade_date) before saving. Shows preview table of qualifying setups.
- **Section 2 — 3-Week Tracker**: 4 KPI cards (win rate, total setups, avg TCS, avg follow-thru), daily win rate trend chart with 55% target line, per-ticker breakdown table, full log expander
- **Backend additions**: ensure_paper_trades_table(), log_paper_trades(), load_paper_trades() in backend.py. Schema shown as SQL fallback if table doesn't exist yet.
- **Table**: paper_trades — user_id, trade_date, ticker, tcs, predicted, ib_low, ib_high, open_price, actual_outcome, follow_thru_pct, win_loss, false_break_up/down, min_tcs_filter, created_at
- User must create paper_trades table in Supabase SQL editor (shown on first load if missing)
